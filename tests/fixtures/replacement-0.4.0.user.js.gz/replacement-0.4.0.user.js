// ==UserScript==
// @name         TSDM Workspace
// @namespace    https://github.com/Benson-mk/tsdm-ui
// @version      0.4.0
// @description  Current-account forum workspace. Manual installation and updates.
// @match        https://www.tsdm39.com/*
// @exclude      https://www.tsdm39.com/*tsdm-native=1*
// @grant        GM_registerMenuCommand
// @run-at       document-end
// ==/UserScript==

(function() {
	"use strict";
	var __defProp = Object.defineProperty;
	var __exportAll = (all, no_symbols) => {
		let target = {};
		for (var name in all) __defProp(target, name, {
			get: all[name],
			enumerable: true
		});
		if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
		return target;
	};
	function createBrowserDownloads() {
		return { prepare(bytes, name, contentType) {
			const blob = new Blob([new Uint8Array(bytes)], { type: contentType });
			const url = URL.createObjectURL(blob);
			return {
				save() {
					const anchor = document.createElement("a");
					anchor.href = url;
					anchor.download = name;
					document.body.append(anchor);
					try {
						anchor.click();
					} finally {
						anchor.remove();
					}
				},
				dispose() {
					URL.revokeObjectURL(url);
				}
			};
		} };
	}
	function makeMap(str) {
		const map = Object.create(null);
		for (const key of str.split(",")) map[key] = 1;
		return (val) => val in map;
	}
	var EMPTY_OBJ = {};
	var EMPTY_ARR = [];
	var NOOP = () => {};
	var NO = () => false;
	var isOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && (key.charCodeAt(2) > 122 || key.charCodeAt(2) < 97);
	var isModelListener = (key) => key.startsWith("onUpdate:");
	var extend = Object.assign;
	var remove = (arr, el) => {
		const i = arr.indexOf(el);
		if (i > -1) arr.splice(i, 1);
	};
	var hasOwnProperty$1 = Object.prototype.hasOwnProperty;
	var hasOwn = (val, key) => hasOwnProperty$1.call(val, key);
	var isArray = Array.isArray;
	var isMap = (val) => toTypeString(val) === "[object Map]";
	var isSet = (val) => toTypeString(val) === "[object Set]";
	var isDate = (val) => toTypeString(val) === "[object Date]";
	var isRegExp = (val) => toTypeString(val) === "[object RegExp]";
	var isFunction = (val) => typeof val === "function";
	var isString = (val) => typeof val === "string";
	var isSymbol = (val) => typeof val === "symbol";
	var isObject$1 = (val) => val !== null && typeof val === "object";
	var isPromise = (val) => {
		return (isObject$1(val) || isFunction(val)) && isFunction(val.then) && isFunction(val.catch);
	};
	var objectToString = Object.prototype.toString;
	var toTypeString = (value) => objectToString.call(value);
	var toRawType = (value) => {
		return toTypeString(value).slice(8, -1);
	};
	var isPlainObject$1 = (val) => toTypeString(val) === "[object Object]";
	var isIntegerKey = (key) => isString(key) && key !== "NaN" && key[0] !== "-" && "" + parseInt(key, 10) === key;
	var isReservedProp = makeMap(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted");
	var cacheStringFunction$1 = (fn) => {
		const cache = Object.create(null);
		return ((str) => {
			return cache[str] || (cache[str] = fn(str));
		});
	};
	var camelizeRE$1 = /-\w/g;
	var camelize$1 = cacheStringFunction$1((str) => {
		return str.replace(camelizeRE$1, (c) => c.slice(1).toUpperCase());
	});
	var hyphenateRE$1 = /\B([A-Z])/g;
	var hyphenate$1 = cacheStringFunction$1((str) => str.replace(hyphenateRE$1, "-$1").toLowerCase());
	var capitalize = cacheStringFunction$1((str) => {
		return str.charAt(0).toUpperCase() + str.slice(1);
	});
	var toHandlerKey = cacheStringFunction$1((str) => {
		return str ? `on${capitalize(str)}` : ``;
	});
	var hasChanged = (value, oldValue) => !Object.is(value, oldValue);
	var invokeArrayFns = (fns, ...arg) => {
		for (let i = 0; i < fns.length; i++) fns[i](...arg);
	};
	var def = (obj, key, value, writable = false) => {
		Object.defineProperty(obj, key, {
			configurable: true,
			enumerable: false,
			writable,
			value
		});
	};
	var looseToNumber = (val) => {
		const n = parseFloat(val);
		return isNaN(n) ? val : n;
	};
	var toNumber = (val) => {
		const n = isString(val) ? Number(val) : NaN;
		return isNaN(n) ? val : n;
	};
	var _globalThis;
	var getGlobalThis = () => {
		return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
	};
	var isGloballyAllowed = makeMap("Infinity,undefined,NaN,isFinite,isNaN,parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,BigInt,console,Error,Symbol");
	function normalizeStyle(value) {
		if (isArray(value)) {
			const res = {};
			for (let i = 0; i < value.length; i++) {
				const item = value[i];
				const normalized = isString(item) ? parseStringStyle(item) : normalizeStyle(item);
				if (normalized) for (const key in normalized) res[key] = normalized[key];
			}
			return res;
		} else if (isString(value) || isObject$1(value)) return value;
	}
	var listDelimiterRE = /;(?![^(]*\))/g;
	var propertyDelimiterRE = /:([^]+)/;
	var styleCommentRE = /"(?:[^"\\]|\\[^])*"|'(?:[^'\\]|\\[^])*'|\\[^]|\/\*[^]*?\*\//g;
	function parseStringStyle(cssText) {
		const ret = {};
		cssText.replace(styleCommentRE, (match) => match.startsWith("/*") ? "" : match).split(listDelimiterRE).forEach((item) => {
			if (item) {
				const tmp = item.split(propertyDelimiterRE);
				tmp.length > 1 && (ret[tmp[0].trim()] = tmp[1].trim());
			}
		});
		return ret;
	}
	function normalizeClass(value) {
		let res = "";
		if (isString(value)) res = value;
		else if (isArray(value)) for (let i = 0; i < value.length; i++) {
			const normalized = normalizeClass(value[i]);
			if (normalized) res += normalized + " ";
		}
		else if (isObject$1(value)) {
			for (const name in value) if (value[name]) res += name + " ";
		}
		return res.trim();
	}
	function normalizeProps(props) {
		if (!props) return null;
		let { class: klass, style } = props;
		if (klass && !isString(klass)) props.class = normalizeClass(klass);
		if (style) props.style = normalizeStyle(style);
		return props;
	}
	var isSpecialBooleanAttr = makeMap(`itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,playsinline,readonly`);
	function includeBooleanAttr(value) {
		return !!value || value === "";
	}
	function looseCompareArrays(a, b, seen) {
		if (a.length !== b.length) return false;
		let equal = true;
		for (let i = 0; equal && i < a.length; i++) equal = looseEqual(a[i], b[i], seen);
		return equal;
	}
	function looseCompareCollections(a, b, seen) {
		if (a.size !== b.size) return false;
		const candidates = Array.from(b);
		const matched = new Uint8Array(candidates.length);
		for (const item of a) {
			let index = -1;
			for (let i = 0; i < candidates.length; i++) if (!matched[i] && looseEqual(item, candidates[i], seen)) {
				index = i;
				break;
			}
			if (index < 0) return false;
			matched[index] = 1;
		}
		return true;
	}
	function looseCompareObjects(a, b, seen) {
		let aValidType = isMap(a);
		let bValidType = isMap(b);
		if (aValidType || bValidType) return aValidType && bValidType ? looseCompareCollections(a, b, seen) : false;
		aValidType = isSet(a);
		bValidType = isSet(b);
		if (aValidType || bValidType) return aValidType && bValidType ? looseCompareCollections(a, b, seen) : false;
		if (Object.keys(a).length !== Object.keys(b).length) return false;
		for (const key in a) {
			const aHasKey = a.hasOwnProperty(key);
			const bHasKey = b.hasOwnProperty(key);
			if (aHasKey && !bHasKey || !aHasKey && bHasKey || !looseEqual(a[key], b[key], seen)) return false;
		}
		return String(a) === String(b);
	}
	function looseCompareNested(a, b, seen, compare) {
		if (!seen) seen = [new Map(), new Map()];
		const [seenA, seenB] = seen;
		if (seenA.has(a) || seenB.has(b)) return seenA.get(a) === b && seenB.get(b) === a;
		seenA.set(a, b);
		seenB.set(b, a);
		const equal = compare(a, b, seen);
		seenA.delete(a);
		seenB.delete(b);
		return equal;
	}
	function looseEqual(a, b, seen) {
		if (a === b) return true;
		let aValidType = isDate(a);
		let bValidType = isDate(b);
		if (aValidType || bValidType) return aValidType && bValidType ? a.getTime() === b.getTime() : false;
		aValidType = isSymbol(a);
		bValidType = isSymbol(b);
		if (aValidType || bValidType) return a === b;
		aValidType = isArray(a);
		bValidType = isArray(b);
		if (aValidType || bValidType) return aValidType && bValidType ? looseCompareNested(a, b, seen, looseCompareArrays) : false;
		aValidType = isObject$1(a);
		bValidType = isObject$1(b);
		if (aValidType || bValidType) {
			if (!aValidType || !bValidType) return false;
			return looseCompareNested(a, b, seen, looseCompareObjects);
		}
		return String(a) === String(b);
	}
	function looseIndexOf(arr, val) {
		return arr.findIndex((item) => looseEqual(item, val));
	}
	var isRef$1 = (val) => {
		return !!(val && val["__v_isRef"] === true);
	};
	var toDisplayString = (val) => {
		return isString(val) ? val : val == null ? "" : isArray(val) || isObject$1(val) && (val.toString === objectToString || !isFunction(val.toString)) ? isRef$1(val) ? toDisplayString(val.value) : JSON.stringify(val, replacer, 2) : String(val);
	};
	var replacer = (_key, val) => {
		if (isRef$1(val)) return replacer(_key, val.value);
		else if (isMap(val)) return { [`Map(${val.size})`]: [...val.entries()].reduce((entries, [key, val2], i) => {
			entries[stringifySymbol(key, i) + " =>"] = val2;
			return entries;
		}, {}) };
		else if (isSet(val)) return { [`Set(${val.size})`]: [...val.values()].map((v) => stringifySymbol(v)) };
		else if (isSymbol(val)) return stringifySymbol(val);
		else if (isObject$1(val) && !isArray(val) && !isPlainObject$1(val)) return String(val);
		return val;
	};
	var stringifySymbol = (v, i = "") => {
		var _a;
		return isSymbol(v) ? `Symbol(${(_a = v.description) != null ? _a : i})` : v;
	};
	function normalizeCssVarValue(value) {
		if (value == null) return "initial";
		if (typeof value === "string") return value === "" ? " " : value;
		if (typeof value !== "number" || !Number.isFinite(value)) {}
		return String(value);
	}
	var activeEffectScope;
	var EffectScope = class {
		constructor(detached = false) {
			this.detached = detached;
			this._active = true;
			this._on = 0;
			this.effects = [];
			this.cleanups = [];
			this._isPaused = false;
			this._warnOnRun = true;
			this.__v_skip = true;
			if (!detached && activeEffectScope) {
				if (activeEffectScope.active) {
					this.parent = activeEffectScope;
					this.index = (activeEffectScope.scopes || (activeEffectScope.scopes = [])).push(this) - 1;
				} else {
					this._active = false;
					this._warnOnRun = false;
				}
			}
		}
		get active() {
			return this._active;
		}
		pause() {
			if (this._active) {
				this._isPaused = true;
				let i, l;
				if (this.scopes) {
					const scopes = this.scopes.slice();
					for (i = 0, l = scopes.length; i < l; i++) scopes[i].pause();
				}
				for (i = 0, l = this.effects.length; i < l; i++) this.effects[i].pause();
			}
		}
		resume() {
			if (this._active) {
				if (this._isPaused) {
					this._isPaused = false;
					let i, l;
					if (this.scopes) {
						const scopes = this.scopes.slice();
						for (i = 0, l = scopes.length; i < l; i++) scopes[i].resume();
					}
					const effects = this.effects.slice();
					for (i = 0, l = effects.length; i < l; i++) effects[i].resume();
				}
			}
		}
		run(fn) {
			if (this._active) {
				const currentEffectScope = activeEffectScope;
				try {
					activeEffectScope = this;
					return fn();
				} finally {
					activeEffectScope = currentEffectScope;
				}
			}
		}
		on() {
			if (++this._on === 1) {
				this.prevScope = activeEffectScope;
				activeEffectScope = this;
			}
		}
		off() {
			if (this._on > 0 && --this._on === 0) {
				if (activeEffectScope === this) activeEffectScope = this.prevScope;
				else {
					let current = activeEffectScope;
					while (current) {
						if (current.prevScope === this) {
							current.prevScope = this.prevScope;
							break;
						}
						current = current.prevScope;
					}
				}
				this.prevScope = void 0;
			}
		}
		stop(fromParent) {
			if (this._active) {
				this._active = false;
				let i, l;
				for (i = 0, l = this.effects.length; i < l; i++) this.effects[i].stop();
				this.effects.length = 0;
				for (i = 0, l = this.cleanups.length; i < l; i++) this.cleanups[i]();
				this.cleanups.length = 0;
				if (this.scopes) {
					const scopes = this.scopes.slice();
					for (i = 0, l = scopes.length; i < l; i++) scopes[i].stop(true);
					this.scopes.length = 0;
				}
				if (!this.detached && this.parent && !fromParent) {
					const last = this.parent.scopes.pop();
					if (last && last !== this) {
						this.parent.scopes[this.index] = last;
						last.index = this.index;
					}
				}
				this.parent = void 0;
			}
		}
	};
	function effectScope(detached) {
		return new EffectScope(detached);
	}
	function getCurrentScope() {
		return activeEffectScope;
	}
	function onScopeDispose(fn, failSilently = false) {
		if (activeEffectScope) activeEffectScope.cleanups.push(fn);
	}
	var activeSub;
	var pausedQueueEffects = new WeakSet();
	var ReactiveEffect = class {
		constructor(fn) {
			this.fn = fn;
			this.deps = void 0;
			this.depsTail = void 0;
			this.flags = 5;
			this.next = void 0;
			this.cleanup = void 0;
			this.scheduler = void 0;
			if (activeEffectScope) {
				if (activeEffectScope.active) activeEffectScope.effects.push(this);
				else this.flags &= -2;
			}
		}
		pause() {
			this.flags |= 64;
		}
		resume() {
			if (this.flags & 64) {
				this.flags &= -65;
				if (pausedQueueEffects.has(this)) {
					pausedQueueEffects.delete(this);
					this.trigger();
				}
			}
		}
		notify() {
			if (this.flags & 2 && !(this.flags & 32)) return;
			if (!(this.flags & 8)) batch(this);
		}
		run() {
			if (!(this.flags & 1)) return this.fn();
			this.flags |= 2;
			cleanupEffect(this);
			prepareDeps(this);
			const prevEffect = activeSub;
			const prevShouldTrack = shouldTrack;
			activeSub = this;
			shouldTrack = true;
			try {
				return this.fn();
			} finally {
				cleanupDeps(this);
				activeSub = prevEffect;
				shouldTrack = prevShouldTrack;
				this.flags &= -3;
			}
		}
		stop() {
			if (this.flags & 1) {
				for (let link = this.deps; link; link = link.nextDep) removeSub(link);
				this.deps = this.depsTail = void 0;
				cleanupEffect(this);
				this.onStop && this.onStop();
				this.flags &= -2;
			}
		}
		trigger() {
			if (this.flags & 64) pausedQueueEffects.add(this);
			else if (this.scheduler) this.scheduler();
			else this.runIfDirty();
		}
		runIfDirty() {
			if (isDirty(this)) this.run();
		}
		get dirty() {
			return isDirty(this);
		}
	};
	var batchDepth = 0;
	var batchedSub;
	var batchedComputed;
	function batch(sub, isComputed = false) {
		sub.flags |= 8;
		if (isComputed) {
			sub.next = batchedComputed;
			batchedComputed = sub;
			return;
		}
		sub.next = batchedSub;
		batchedSub = sub;
	}
	function startBatch() {
		batchDepth++;
	}
	function endBatch() {
		if (--batchDepth > 0) return;
		if (batchedComputed) {
			let e = batchedComputed;
			batchedComputed = void 0;
			while (e) {
				const next = e.next;
				e.next = void 0;
				e.flags &= -9;
				e = next;
			}
		}
		let error;
		while (batchedSub) {
			let e = batchedSub;
			batchedSub = void 0;
			while (e) {
				const next = e.next;
				e.next = void 0;
				e.flags &= -9;
				if (e.flags & 1) try {
					e.trigger();
				} catch (err) {
					if (!error) error = err;
				}
				e = next;
			}
		}
		if (error) throw error;
	}
	function prepareDeps(sub) {
		for (let link = sub.deps; link; link = link.nextDep) {
			link.version = -1;
			link.prevActiveLink = link.dep.activeLink;
			link.dep.activeLink = link;
		}
	}
	function cleanupDeps(sub) {
		let head;
		let tail = sub.depsTail;
		let link = tail;
		while (link) {
			const prev = link.prevDep;
			if (link.version === -1) {
				if (link === tail) tail = prev;
				removeSub(link);
				removeDep(link);
			} else head = link;
			link.dep.activeLink = link.prevActiveLink;
			link.prevActiveLink = void 0;
			link = prev;
		}
		sub.deps = head;
		sub.depsTail = tail;
	}
	function isDirty(sub) {
		for (let link = sub.deps; link; link = link.nextDep) if (link.dep.version !== link.version || link.dep.computed && (refreshComputed(link.dep.computed) || link.dep.version !== link.version)) return true;
		if (sub._dirty) return true;
		return false;
	}
	function refreshComputed(computed) {
		if (computed.flags & 4 && !(computed.flags & 16)) return;
		computed.flags &= -17;
		if (computed.globalVersion === globalVersion) return;
		computed.globalVersion = globalVersion;
		if (!computed.isSSR && computed.flags & 128 && (!computed.deps && !computed._dirty || !isDirty(computed))) return;
		computed.flags |= 2;
		const dep = computed.dep;
		const prevSub = activeSub;
		const prevShouldTrack = shouldTrack;
		activeSub = computed;
		shouldTrack = true;
		try {
			prepareDeps(computed);
			const value = computed.fn(computed._value);
			if (dep.version === 0 || hasChanged(value, computed._value)) {
				computed.flags |= 128;
				computed._value = value;
				dep.version++;
			}
		} catch (err) {
			dep.version++;
			throw err;
		} finally {
			activeSub = prevSub;
			shouldTrack = prevShouldTrack;
			cleanupDeps(computed);
			computed.flags &= -3;
		}
	}
	function removeSub(link, soft = false) {
		const { dep, prevSub, nextSub } = link;
		if (prevSub) {
			prevSub.nextSub = nextSub;
			link.prevSub = void 0;
		}
		if (nextSub) {
			nextSub.prevSub = prevSub;
			link.nextSub = void 0;
		}
		if (dep.subs === link) {
			dep.subs = prevSub;
			if (!prevSub && dep.computed) {
				dep.computed.flags &= -5;
				for (let l = dep.computed.deps; l; l = l.nextDep) removeSub(l, true);
			}
		}
		if (!soft && !--dep.sc && dep.map) dep.map.delete(dep.key);
	}
	function removeDep(link) {
		const { prevDep, nextDep } = link;
		if (prevDep) {
			prevDep.nextDep = nextDep;
			link.prevDep = void 0;
		}
		if (nextDep) {
			nextDep.prevDep = prevDep;
			link.nextDep = void 0;
		}
	}
	function effect(fn, options) {
		if (fn.effect instanceof ReactiveEffect) fn = fn.effect.fn;
		const e = new ReactiveEffect(fn);
		if (options) extend(e, options);
		try {
			e.run();
		} catch (err) {
			e.stop();
			throw err;
		}
		const runner = e.run.bind(e);
		runner.effect = e;
		return runner;
	}
	function stop$1(runner) {
		runner.effect.stop();
	}
	var shouldTrack = true;
	var trackStack = [];
	function pauseTracking() {
		trackStack.push(shouldTrack);
		shouldTrack = false;
	}
	function resetTracking() {
		const last = trackStack.pop();
		shouldTrack = last === void 0 ? true : last;
	}
	function cleanupEffect(e) {
		const { cleanup } = e;
		e.cleanup = void 0;
		if (cleanup) {
			const prevSub = activeSub;
			activeSub = void 0;
			try {
				cleanup();
			} finally {
				activeSub = prevSub;
			}
		}
	}
	var globalVersion = 0;
	var Link = class {
		constructor(sub, dep) {
			this.sub = sub;
			this.dep = dep;
			this.version = dep.version;
			this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
		}
	};
	var Dep = class {
		constructor(computed) {
			this.computed = computed;
			this.version = 0;
			this.activeLink = void 0;
			this.subs = void 0;
			this.map = void 0;
			this.key = void 0;
			this.sc = 0;
			this.__v_skip = true;
		}
		track(debugInfo) {
			if (!activeSub || !shouldTrack || activeSub === this.computed) return;
			let link = this.activeLink;
			if (link === void 0 || link.sub !== activeSub) {
				link = this.activeLink = new Link(activeSub, this);
				if (!activeSub.deps) activeSub.deps = activeSub.depsTail = link;
				else {
					link.prevDep = activeSub.depsTail;
					activeSub.depsTail.nextDep = link;
					activeSub.depsTail = link;
				}
				addSub(link);
			} else if (link.version === -1) {
				link.version = this.version;
				if (link.nextDep) {
					const next = link.nextDep;
					next.prevDep = link.prevDep;
					if (link.prevDep) link.prevDep.nextDep = next;
					link.prevDep = activeSub.depsTail;
					link.nextDep = void 0;
					activeSub.depsTail.nextDep = link;
					activeSub.depsTail = link;
					if (activeSub.deps === link) activeSub.deps = next;
				}
			}
			return link;
		}
		trigger(debugInfo) {
			this.version++;
			globalVersion++;
			this.notify(debugInfo);
		}
		notify(debugInfo) {
			startBatch();
			try {
				for (let link = this.subs; link; link = link.prevSub) if (link.sub.notify()) link.sub.dep.notify();
			} finally {
				endBatch();
			}
		}
	};
	function addSub(link) {
		link.dep.sc++;
		if (link.sub.flags & 4) {
			const computed = link.dep.computed;
			if (computed && !link.dep.subs) {
				computed.flags |= 20;
				for (let l = computed.deps; l; l = l.nextDep) addSub(l);
			}
			const currentTail = link.dep.subs;
			if (currentTail !== link) {
				link.prevSub = currentTail;
				if (currentTail) currentTail.nextSub = link;
			}
			link.dep.subs = link;
		}
	}
	var targetMap = new WeakMap();
	var ITERATE_KEY = Symbol("");
	var MAP_KEY_ITERATE_KEY = Symbol("");
	var ARRAY_ITERATE_KEY = Symbol("");
	function track(target, type, key) {
		if (shouldTrack && activeSub) {
			let depsMap = targetMap.get(target);
			if (!depsMap) targetMap.set(target, depsMap = new Map());
			let dep = depsMap.get(key);
			if (!dep) {
				depsMap.set(key, dep = new Dep());
				dep.map = depsMap;
				dep.key = key;
			}
			dep.track();
		}
	}
	function trigger(target, type, key, newValue, oldValue, oldTarget) {
		const depsMap = targetMap.get(target);
		if (!depsMap) {
			globalVersion++;
			return;
		}
		const run = (dep) => {
			if (dep) dep.trigger();
		};
		startBatch();
		if (type === "clear") depsMap.forEach(run);
		else {
			const targetIsArray = isArray(target);
			const isArrayIndex = targetIsArray && isIntegerKey(key);
			if (targetIsArray && key === "length") {
				const newLength = Number(newValue);
				depsMap.forEach((dep, key2) => {
					if (key2 === "length" || key2 === ARRAY_ITERATE_KEY || !isSymbol(key2) && key2 >= newLength) run(dep);
				});
			} else {
				if (key !== void 0 || depsMap.has(void 0)) run(depsMap.get(key));
				if (isArrayIndex) run(depsMap.get(ARRAY_ITERATE_KEY));
				switch (type) {
					case "add":
						if (!targetIsArray) {
							run(depsMap.get(ITERATE_KEY));
							if (isMap(target)) run(depsMap.get(MAP_KEY_ITERATE_KEY));
						} else if (isArrayIndex) run(depsMap.get("length"));
						break;
					case "delete":
						if (!targetIsArray) {
							run(depsMap.get(ITERATE_KEY));
							if (isMap(target)) run(depsMap.get(MAP_KEY_ITERATE_KEY));
						}
						break;
					case "set": if (isMap(target)) run(depsMap.get(ITERATE_KEY));
				}
			}
		}
		endBatch();
	}
	function getDepFromReactive(object, key) {
		const depMap = targetMap.get(object);
		return depMap && depMap.get(key);
	}
	function reactiveReadArray(array) {
		const raw = toRaw(array);
		if (raw === array) return raw;
		track(raw, "iterate", ARRAY_ITERATE_KEY);
		if (isShallow(array)) return raw;
		if (!isReadonly(array)) return raw.map(toReactive);
		return isReactive(array) ? raw.map((item) => toReadonly(toReactive(item))) : raw.map(toReadonly);
	}
	function shallowReadArray(arr) {
		track(arr = toRaw(arr), "iterate", ARRAY_ITERATE_KEY);
		return arr;
	}
	function toWrapped(target, item) {
		if (isReadonly(target)) return isReactive(target) ? toReadonly(toReactive(item)) : toReadonly(item);
		return toReactive(item);
	}
	var arrayInstrumentations = {
		__proto__: null,
		[Symbol.iterator]() {
			return iterator(this, Symbol.iterator, (item) => toWrapped(this, item));
		},
		concat(...args) {
			return reactiveReadArray(this).concat(...args.map((x) => isArray(x) ? reactiveReadArray(x) : x));
		},
		entries() {
			return iterator(this, "entries", (value) => {
				value[1] = toWrapped(this, value[1]);
				return value;
			});
		},
		every(fn, thisArg) {
			return apply(this, "every", fn, thisArg, void 0, arguments);
		},
		filter(fn, thisArg) {
			return apply(this, "filter", fn, thisArg, (v) => v.map((item) => toWrapped(this, item)), arguments);
		},
		find(fn, thisArg) {
			return apply(this, "find", fn, thisArg, (item) => toWrapped(this, item), arguments);
		},
		findIndex(fn, thisArg) {
			return apply(this, "findIndex", fn, thisArg, void 0, arguments);
		},
		findLast(fn, thisArg) {
			return apply(this, "findLast", fn, thisArg, (item) => toWrapped(this, item), arguments);
		},
		findLastIndex(fn, thisArg) {
			return apply(this, "findLastIndex", fn, thisArg, void 0, arguments);
		},
		forEach(fn, thisArg) {
			return apply(this, "forEach", fn, thisArg, void 0, arguments);
		},
		includes(...args) {
			return searchProxy(this, "includes", args);
		},
		indexOf(...args) {
			return searchProxy(this, "indexOf", args);
		},
		join(separator) {
			return reactiveReadArray(this).join(separator);
		},
		lastIndexOf(...args) {
			return searchProxy(this, "lastIndexOf", args);
		},
		map(fn, thisArg) {
			return apply(this, "map", fn, thisArg, void 0, arguments);
		},
		pop() {
			return noTracking(this, "pop");
		},
		push(...args) {
			return noTracking(this, "push", args);
		},
		reduce(fn, ...args) {
			return reduce(this, "reduce", fn, args);
		},
		reduceRight(fn, ...args) {
			return reduce(this, "reduceRight", fn, args);
		},
		shift() {
			return noTracking(this, "shift");
		},
		some(fn, thisArg) {
			return apply(this, "some", fn, thisArg, void 0, arguments);
		},
		splice(...args) {
			return noTracking(this, "splice", args);
		},
		toReversed() {
			return reactiveReadArray(this).toReversed();
		},
		toSorted(comparer) {
			return reactiveReadArray(this).toSorted(comparer);
		},
		toSpliced(...args) {
			return reactiveReadArray(this).toSpliced(...args);
		},
		unshift(...args) {
			return noTracking(this, "unshift", args);
		},
		values() {
			return iterator(this, "values", (item) => toWrapped(this, item));
		}
	};
	function iterator(self, method, wrapValue) {
		const arr = shallowReadArray(self);
		const methodFn = arr[method];
		const iter = methodFn.call(arr);
		if (arr !== self && !isShallow(self)) {
			if (iter[Symbol.toStringTag] === "Array Iterator") {
				const wrapped = Object.create(Object.getPrototypeOf(iter));
				wrapped.next = () => wrapResult(iter.next(), wrapValue);
				if (methodFn !== arrayProto[method]) Object.defineProperties(wrapped, {
					return: { get() {
						const fn = iter.return;
						return typeof fn === "function" ? fn.bind(iter) : fn;
					} },
					throw: { get() {
						const fn = iter.throw;
						return typeof fn === "function" ? fn.bind(iter) : fn;
					} }
				});
				return wrapped;
			}
			iter._next = iter.next;
			iter.next = () => wrapResult(iter._next(), wrapValue);
		}
		return iter;
	}
	function wrapResult(result, wrapValue) {
		if (!result.done) result.value = wrapValue(result.value);
		return result;
	}
	var arrayProto = Array.prototype;
	function apply(self, method, fn, thisArg, wrappedRetFn, args) {
		const arr = shallowReadArray(self);
		const needsWrap = arr !== self && !isShallow(self);
		const methodFn = arr[method];
		if (methodFn !== arrayProto[method]) {
			const result2 = methodFn.apply(self, args);
			return needsWrap ? toReactive(result2) : result2;
		}
		let wrappedFn = fn;
		if (arr !== self) {
			if (needsWrap) wrappedFn = function(item, index) {
				return fn.call(this, toWrapped(self, item), index, self);
			};
			else if (fn.length > 2) wrappedFn = function(item, index) {
				return fn.call(this, item, index, self);
			};
		}
		const result = methodFn.call(arr, wrappedFn, thisArg);
		return needsWrap && wrappedRetFn ? wrappedRetFn(result) : result;
	}
	function reduce(self, method, fn, args) {
		const arr = shallowReadArray(self);
		const needsWrap = arr !== self && !isShallow(self);
		let wrappedFn = fn;
		let wrapInitialAccumulator = false;
		if (arr !== self) {
			if (needsWrap) {
				wrapInitialAccumulator = args.length === 0;
				wrappedFn = function(acc, item, index) {
					if (wrapInitialAccumulator) {
						wrapInitialAccumulator = false;
						acc = toWrapped(self, acc);
					}
					return fn.call(this, acc, toWrapped(self, item), index, self);
				};
			} else if (fn.length > 3) wrappedFn = function(acc, item, index) {
				return fn.call(this, acc, item, index, self);
			};
		}
		const result = arr[method](wrappedFn, ...args);
		return wrapInitialAccumulator ? toWrapped(self, result) : result;
	}
	function searchProxy(self, method, args) {
		const arr = toRaw(self);
		track(arr, "iterate", ARRAY_ITERATE_KEY);
		const res = arr[method](...args);
		if ((res === -1 || res === false) && isProxy(args[0])) {
			args[0] = toRaw(args[0]);
			return arr[method](...args);
		}
		return res;
	}
	function noTracking(self, method, args = []) {
		pauseTracking();
		startBatch();
		const res = toRaw(self)[method].apply(self, args);
		endBatch();
		resetTracking();
		return res;
	}
	var isNonTrackableKeys = makeMap(`__proto__,__v_isRef,__isVue`);
	var builtInSymbols = new Set(Object.getOwnPropertyNames(Symbol).filter((key) => key !== "arguments" && key !== "caller").map((key) => Symbol[key]).filter(isSymbol));
	function hasOwnProperty(key) {
		if (!isSymbol(key)) key = String(key);
		const obj = toRaw(this);
		track(obj, "has", key);
		return obj.hasOwnProperty(key);
	}
	var BaseReactiveHandler = class {
		constructor(_isReadonly = false, _isShallow = false) {
			this._isReadonly = _isReadonly;
			this._isShallow = _isShallow;
		}
		get(target, key, receiver) {
			if (key === "__v_skip") return target["__v_skip"];
			const isReadonly2 = this._isReadonly, isShallow2 = this._isShallow;
			if (key === "__v_isReactive") return !isReadonly2;
			else if (key === "__v_isReadonly") return isReadonly2;
			else if (key === "__v_isShallow") return isShallow2;
			else if (key === "__v_raw") {
				if (receiver === (isReadonly2 ? isShallow2 ? shallowReadonlyMap : readonlyMap : isShallow2 ? shallowReactiveMap : reactiveMap).get(target) || Object.getPrototypeOf(target) === Object.getPrototypeOf(receiver)) return target;
				return;
			}
			const targetIsArray = isArray(target);
			if (!isReadonly2) {
				let fn;
				if (targetIsArray && (fn = arrayInstrumentations[key])) return fn;
				if (key === "hasOwnProperty") return hasOwnProperty;
			}
			const res = Reflect.get(target, key, isRef(target) ? target : receiver);
			if (isSymbol(key) ? builtInSymbols.has(key) : isNonTrackableKeys(key)) return res;
			if (!isReadonly2) track(target, "get", key);
			if (isShallow2) return res;
			if (isRef(res)) {
				const value = targetIsArray && isIntegerKey(key) ? res : res.value;
				return isReadonly2 && isObject$1(value) ? readonly(value) : value;
			}
			if (isObject$1(res)) return isReadonly2 ? readonly(res) : reactive(res);
			return res;
		}
	};
	var MutableReactiveHandler = class extends BaseReactiveHandler {
		constructor(isShallow2 = false) {
			super(false, isShallow2);
		}
		set(target, key, value, receiver) {
			let oldValue = target[key];
			const isArrayWithIntegerKey = isArray(target) && isIntegerKey(key);
			if (!this._isShallow) {
				const isOldValueReadonly = isReadonly(oldValue);
				if (!isShallow(value) && !isReadonly(value)) {
					oldValue = toRaw(oldValue);
					value = toRaw(value);
				}
				if (!isArrayWithIntegerKey && isRef(oldValue) && !isRef(value)) {
					if (isOldValueReadonly) return true;
					else {
						oldValue.value = value;
						return true;
					}
				}
			}
			const hadKey = isArrayWithIntegerKey ? Number(key) < target.length : hasOwn(target, key);
			const result = Reflect.set(target, key, value, isRef(target) ? target : receiver);
			if (target === toRaw(receiver) && result) {
				if (!hadKey) trigger(target, "add", key, value);
				else if (hasChanged(value, oldValue)) trigger(target, "set", key, value, oldValue);
			}
			return result;
		}
		deleteProperty(target, key) {
			const hadKey = hasOwn(target, key);
			const oldValue = target[key];
			const result = Reflect.deleteProperty(target, key);
			if (result && hadKey) trigger(target, "delete", key, void 0, oldValue);
			return result;
		}
		has(target, key) {
			const result = Reflect.has(target, key);
			if (!isSymbol(key) || !builtInSymbols.has(key)) track(target, "has", key);
			return result;
		}
		ownKeys(target) {
			track(target, "iterate", isArray(target) ? "length" : ITERATE_KEY);
			return Reflect.ownKeys(target);
		}
	};
	var ReadonlyReactiveHandler = class extends BaseReactiveHandler {
		constructor(isShallow2 = false) {
			super(true, isShallow2);
		}
		set(target, key) {
			return true;
		}
		deleteProperty(target, key) {
			return true;
		}
	};
	var mutableHandlers = new MutableReactiveHandler();
	var readonlyHandlers = new ReadonlyReactiveHandler();
	var shallowReactiveHandlers = new MutableReactiveHandler(true);
	var shallowReadonlyHandlers = new ReadonlyReactiveHandler(true);
	var toShallow = (value) => value;
	var getProto = (v) => Reflect.getPrototypeOf(v);
	function createIterableMethod(method, isReadonly2, isShallow2) {
		return function(...args) {
			const target = this["__v_raw"];
			const rawTarget = toRaw(target);
			const targetIsMap = isMap(rawTarget);
			const isPair = method === "entries" || method === Symbol.iterator && targetIsMap;
			const isKeyOnly = method === "keys" && targetIsMap;
			const innerIterator = target[method](...args);
			const wrap = isShallow2 ? toShallow : isReadonly2 ? toReadonly : toReactive;
			!isReadonly2 && track(rawTarget, "iterate", isKeyOnly ? MAP_KEY_ITERATE_KEY : ITERATE_KEY);
			return extend(Object.create(innerIterator), { next() {
				const { value, done } = innerIterator.next();
				return done ? {
					value,
					done
				} : {
					value: isPair ? [wrap(value[0]), wrap(value[1])] : wrap(value),
					done
				};
			} });
		};
	}
	function createReadonlyMethod(type) {
		return function(...args) {
			return type === "delete" ? false : type === "clear" ? void 0 : this;
		};
	}
	function createInstrumentations(readonly, shallow) {
		const instrumentations = {
			get(key) {
				const target = this["__v_raw"];
				const rawTarget = toRaw(target);
				const rawKey = toRaw(key);
				if (!readonly) {
					if (hasChanged(key, rawKey)) track(rawTarget, "get", key);
					track(rawTarget, "get", rawKey);
				}
				const { has } = getProto(rawTarget);
				const wrap = shallow ? toShallow : readonly ? toReadonly : toReactive;
				if (has.call(rawTarget, key)) return wrap(target.get(key));
				else if (has.call(rawTarget, rawKey)) return wrap(target.get(rawKey));
				else if (target !== rawTarget) target.get(key);
			},
			get size() {
				const target = this["__v_raw"];
				!readonly && track(toRaw(target), "iterate", ITERATE_KEY);
				return target.size;
			},
			has(key) {
				const target = this["__v_raw"];
				const rawTarget = toRaw(target);
				const rawKey = toRaw(key);
				if (!readonly) {
					if (hasChanged(key, rawKey)) track(rawTarget, "has", key);
					track(rawTarget, "has", rawKey);
				}
				return key === rawKey ? target.has(key) : target.has(key) || target.has(rawKey);
			},
			forEach(callback, thisArg) {
				const observed = this;
				const target = observed["__v_raw"];
				const rawTarget = toRaw(target);
				const wrap = shallow ? toShallow : readonly ? toReadonly : toReactive;
				!readonly && track(rawTarget, "iterate", ITERATE_KEY);
				return target.forEach((value, key) => {
					return callback.call(thisArg, wrap(value), wrap(key), observed);
				});
			}
		};
		extend(instrumentations, readonly ? {
			add: createReadonlyMethod("add"),
			set: createReadonlyMethod("set"),
			delete: createReadonlyMethod("delete"),
			clear: createReadonlyMethod("clear")
		} : {
			add(value) {
				const target = toRaw(this);
				const proto = getProto(target);
				const rawValue = toRaw(value);
				const valueToAdd = !shallow && !isShallow(value) && !isReadonly(value) ? rawValue : value;
				if (!(proto.has.call(target, valueToAdd) || hasChanged(value, valueToAdd) && proto.has.call(target, value) || hasChanged(rawValue, valueToAdd) && proto.has.call(target, rawValue))) {
					target.add(valueToAdd);
					trigger(target, "add", valueToAdd, valueToAdd);
				}
				return this;
			},
			set(key, value) {
				if (!shallow && !isShallow(value) && !isReadonly(value)) value = toRaw(value);
				const target = toRaw(this);
				const { has, get } = getProto(target);
				let hadKey = has.call(target, key);
				if (!hadKey) {
					key = toRaw(key);
					hadKey = has.call(target, key);
				}
				const oldValue = get.call(target, key);
				target.set(key, value);
				if (!hadKey) trigger(target, "add", key, value);
				else if (hasChanged(value, oldValue)) trigger(target, "set", key, value, oldValue);
				return this;
			},
			delete(key) {
				const target = toRaw(this);
				const { has, get } = getProto(target);
				let hadKey = has.call(target, key);
				if (!hadKey) {
					key = toRaw(key);
					hadKey = has.call(target, key);
				}
				const oldValue = get ? get.call(target, key) : void 0;
				const result = target.delete(key);
				if (hadKey) trigger(target, "delete", key, void 0, oldValue);
				return result;
			},
			clear() {
				const target = toRaw(this);
				const hadItems = target.size !== 0;
				const oldTarget = void 0;
				const result = target.clear();
				if (hadItems) trigger(target, "clear", void 0, void 0, oldTarget);
				return result;
			}
		});
		[
			"keys",
			"values",
			"entries",
			Symbol.iterator
		].forEach((method) => {
			instrumentations[method] = createIterableMethod(method, readonly, shallow);
		});
		return instrumentations;
	}
	function createInstrumentationGetter(isReadonly2, shallow) {
		const instrumentations = createInstrumentations(isReadonly2, shallow);
		return (target, key, receiver) => {
			if (key === "__v_isReactive") return !isReadonly2;
			else if (key === "__v_isReadonly") return isReadonly2;
			else if (key === "__v_isShallow") return shallow;
			else if (key === "__v_raw") return target;
			return Reflect.get(hasOwn(instrumentations, key) && key in target ? instrumentations : target, key, receiver);
		};
	}
	var mutableCollectionHandlers = { get: createInstrumentationGetter(false, false) };
	var shallowCollectionHandlers = { get: createInstrumentationGetter(false, true) };
	var readonlyCollectionHandlers = { get: createInstrumentationGetter(true, false) };
	var shallowReadonlyCollectionHandlers = { get: createInstrumentationGetter(true, true) };
	var reactiveMap = new WeakMap();
	var shallowReactiveMap = new WeakMap();
	var readonlyMap = new WeakMap();
	var shallowReadonlyMap = new WeakMap();
	function targetTypeMap(rawType) {
		switch (rawType) {
			case "Object":
			case "Array": return 1;
			case "Map":
			case "Set":
			case "WeakMap":
			case "WeakSet": return 2;
			default: return 0;
		}
	}
	function reactive(target) {
		if (isReadonly(target)) return target;
		return createReactiveObject(target, false, mutableHandlers, mutableCollectionHandlers, reactiveMap);
	}
	function shallowReactive(target) {
		return createReactiveObject(target, false, shallowReactiveHandlers, shallowCollectionHandlers, shallowReactiveMap);
	}
	function readonly(target) {
		return createReactiveObject(target, true, readonlyHandlers, readonlyCollectionHandlers, readonlyMap);
	}
	function shallowReadonly(target) {
		return createReactiveObject(target, true, shallowReadonlyHandlers, shallowReadonlyCollectionHandlers, shallowReadonlyMap);
	}
	function createReactiveObject(target, isReadonly2, baseHandlers, collectionHandlers, proxyMap) {
		if (!isObject$1(target)) return target;
		if (target["__v_raw"] && !(isReadonly2 && target["__v_isReactive"])) return target;
		if (target["__v_skip"] || !Object.isExtensible(target)) return target;
		const existingProxy = proxyMap.get(target);
		if (existingProxy) return existingProxy;
		const targetType = targetTypeMap(toRawType(target));
		if (targetType === 0) return target;
		const proxy = new Proxy(target, targetType === 2 ? collectionHandlers : baseHandlers);
		proxyMap.set(target, proxy);
		return proxy;
	}
	function isReactive(value) {
		if (isReadonly(value)) return isReactive(value["__v_raw"]);
		return !!(value && value["__v_isReactive"]);
	}
	function isReadonly(value) {
		return !!(value && value["__v_isReadonly"]);
	}
	function isShallow(value) {
		return !!(value && value["__v_isShallow"]);
	}
	function isProxy(value) {
		return value ? !!value["__v_raw"] : false;
	}
	function toRaw(observed) {
		const raw = observed && observed["__v_raw"];
		return raw ? toRaw(raw) : observed;
	}
	function markRaw(value) {
		if (!hasOwn(value, "__v_skip") && Object.isExtensible(value)) def(value, "__v_skip", true);
		return value;
	}
	var toReactive = (value) => isObject$1(value) ? reactive(value) : value;
	var toReadonly = (value) => isObject$1(value) ? readonly(value) : value;
	function isRef(r) {
		return r ? r["__v_isRef"] === true : false;
	}
	function ref(value) {
		return createRef(value, false);
	}
	function shallowRef(value) {
		return createRef(value, true);
	}
	function createRef(rawValue, shallow) {
		if (isRef(rawValue)) return rawValue;
		return new RefImpl(rawValue, shallow);
	}
	var RefImpl = class {
		constructor(value, isShallow2) {
			this.dep = new Dep();
			this["__v_isRef"] = true;
			this["__v_isShallow"] = false;
			this._rawValue = isShallow2 ? value : toRaw(value);
			this._value = isShallow2 ? value : toReactive(value);
			this["__v_isShallow"] = isShallow2;
		}
		get value() {
			this.dep.track();
			return this._value;
		}
		set value(newValue) {
			const oldValue = this._rawValue;
			const useDirectValue = this["__v_isShallow"] || isShallow(newValue) || isReadonly(newValue);
			newValue = useDirectValue ? newValue : toRaw(newValue);
			if (hasChanged(newValue, oldValue)) {
				this._rawValue = newValue;
				this._value = useDirectValue ? newValue : toReactive(newValue);
				this.dep.trigger();
			}
		}
	};
	function triggerRef(ref2) {
		if (ref2.dep) ref2.dep.trigger();
	}
	function unref(ref2) {
		return isRef(ref2) ? ref2.value : ref2;
	}
	function toValue(source) {
		return isFunction(source) ? source() : unref(source);
	}
	var shallowUnwrapHandlers = {
		get: (target, key, receiver) => key === "__v_raw" ? target : unref(Reflect.get(target, key, receiver)),
		set: (target, key, value, receiver) => {
			const oldValue = target[key];
			if (isRef(oldValue) && !isRef(value)) {
				oldValue.value = value;
				return true;
			} else return Reflect.set(target, key, value, receiver);
		}
	};
	function proxyRefs(objectWithRefs) {
		return isReactive(objectWithRefs) ? objectWithRefs : new Proxy(objectWithRefs, shallowUnwrapHandlers);
	}
	var CustomRefImpl = class {
		constructor(factory) {
			this["__v_isRef"] = true;
			this._value = void 0;
			const dep = this.dep = new Dep();
			const { get, set } = factory(dep.track.bind(dep), dep.trigger.bind(dep));
			this._get = get;
			this._set = set;
		}
		get value() {
			return this._value = this._get();
		}
		set value(newVal) {
			this._set(newVal);
		}
	};
	function customRef(factory) {
		return new CustomRefImpl(factory);
	}
	function toRefs(object) {
		const ret = isArray(object) ? new Array(object.length) : {};
		for (const key in object) ret[key] = propertyToRef(object, key);
		return ret;
	}
	var ObjectRefImpl = class {
		constructor(_object, key, _defaultValue) {
			this._object = _object;
			this._defaultValue = _defaultValue;
			this["__v_isRef"] = true;
			this._value = void 0;
			this._key = isSymbol(key) ? key : String(key);
			this._raw = toRaw(_object);
			let shallow = true;
			let obj = _object;
			if (!isArray(_object) || isSymbol(this._key) || !isIntegerKey(this._key)) do
				shallow = !isProxy(obj) || isShallow(obj);
			while (shallow && (obj = obj["__v_raw"]));
			this._shallow = shallow;
		}
		get value() {
			let val = this._object[this._key];
			if (this._shallow) val = unref(val);
			return this._value = val === void 0 ? this._defaultValue : val;
		}
		set value(newVal) {
			if (this._shallow && isRef(this._raw[this._key])) {
				const nestedRef = this._object[this._key];
				if (isRef(nestedRef)) {
					nestedRef.value = newVal;
					return;
				}
			}
			this._object[this._key] = newVal;
		}
		get dep() {
			return getDepFromReactive(this._raw, this._key);
		}
	};
	var GetterRefImpl = class {
		constructor(_getter) {
			this._getter = _getter;
			this["__v_isRef"] = true;
			this["__v_isReadonly"] = true;
			this._value = void 0;
		}
		get value() {
			return this._value = this._getter();
		}
	};
	function toRef(source, key, defaultValue) {
		if (isRef(source)) return source;
		else if (isFunction(source)) return new GetterRefImpl(source);
		else if (isObject$1(source) && arguments.length > 1) return propertyToRef(source, key, defaultValue);
		else return ref(source);
	}
	function propertyToRef(source, key, defaultValue) {
		return new ObjectRefImpl(source, key, defaultValue);
	}
	var ComputedRefImpl = class {
		constructor(fn, setter, isSSR) {
			this.fn = fn;
			this.setter = setter;
			this._value = void 0;
			this.dep = new Dep(this);
			this.__v_isRef = true;
			this.deps = void 0;
			this.depsTail = void 0;
			this.flags = 16;
			this.globalVersion = globalVersion - 1;
			this.next = void 0;
			this.effect = this;
			this["__v_isReadonly"] = !setter;
			this.isSSR = isSSR;
		}
		notify() {
			this.flags |= 16;
			if (!(this.flags & 8) && activeSub !== this) {
				batch(this, true);
				return true;
			}
		}
		get value() {
			const link = this.dep.track();
			refreshComputed(this);
			if (link) link.version = this.dep.version;
			return this._value;
		}
		set value(newValue) {
			if (this.setter) this.setter(newValue);
		}
	};
	function computed$1(getterOrOptions, debugOptions, isSSR = false) {
		let getter;
		let setter;
		if (isFunction(getterOrOptions)) getter = getterOrOptions;
		else {
			getter = getterOrOptions.get;
			setter = getterOrOptions.set;
		}
		return new ComputedRefImpl(getter, setter, isSSR);
	}
	var TrackOpTypes = {
		"GET": "get",
		"HAS": "has",
		"ITERATE": "iterate"
	};
	var TriggerOpTypes = {
		"SET": "set",
		"ADD": "add",
		"DELETE": "delete",
		"CLEAR": "clear"
	};
	var INITIAL_WATCHER_VALUE = {};
	var cleanupMap = new WeakMap();
	var activeWatcher = void 0;
	function getCurrentWatcher() {
		return activeWatcher;
	}
	function onWatcherCleanup(cleanupFn, failSilently = false, owner = activeWatcher) {
		if (owner) {
			let cleanups = cleanupMap.get(owner);
			if (!cleanups) cleanupMap.set(owner, cleanups = []);
			cleanups.push(cleanupFn);
		}
	}
	function watch$1(source, cb, options = EMPTY_OBJ) {
		const { immediate, deep, once, scheduler, augmentJob, call } = options;
		const reactiveGetter = (source2) => {
			if (deep) return source2;
			if (isShallow(source2) || deep === false || deep === 0) return traverse(source2, 1);
			return traverse(source2);
		};
		let effect;
		let getter;
		let cleanup;
		let boundCleanup;
		let forceTrigger = false;
		let isMultiSource = false;
		if (isRef(source)) {
			getter = () => source.value;
			forceTrigger = isShallow(source);
		} else if (isReactive(source)) {
			getter = () => reactiveGetter(source);
			forceTrigger = true;
		} else if (isArray(source)) {
			isMultiSource = true;
			forceTrigger = source.some((s) => isReactive(s) || isShallow(s));
			getter = () => source.map((s) => {
				if (isRef(s)) return s.value;
				else if (isReactive(s)) return reactiveGetter(s);
				else if (isFunction(s)) return call ? call(s, 2) : s();
			});
		} else if (isFunction(source)) {
			if (cb) getter = call ? () => call(source, 2) : source;
			else getter = () => {
				if (cleanup) {
					pauseTracking();
					try {
						cleanup();
					} finally {
						resetTracking();
					}
				}
				const currentEffect = activeWatcher;
				activeWatcher = effect;
				try {
					return call ? call(source, 3, [boundCleanup]) : source(boundCleanup);
				} finally {
					activeWatcher = currentEffect;
				}
			};
		} else getter = NOOP;
		if (cb && deep) {
			const baseGetter = getter;
			const depth = deep === true ? Infinity : deep;
			getter = () => traverse(baseGetter(), depth);
		}
		const scope = getCurrentScope();
		const watchHandle = () => {
			effect.stop();
			if (scope && scope.active) remove(scope.effects, effect);
		};
		if (once && cb) {
			const _cb = cb;
			cb = (...args) => {
				try {
					return _cb(...args);
				} finally {
					watchHandle();
				}
			};
		}
		let oldValue = isMultiSource ? new Array(source.length).fill(INITIAL_WATCHER_VALUE) : INITIAL_WATCHER_VALUE;
		const job = (immediateFirstRun) => {
			if (!(effect.flags & 1) || !effect.dirty && !immediateFirstRun) return;
			if (cb) {
				const newValue = effect.run();
				if (immediateFirstRun || deep || forceTrigger || (isMultiSource ? newValue.some((v, i) => hasChanged(v, oldValue[i])) : hasChanged(newValue, oldValue))) {
					const currentWatcher = activeWatcher;
					pauseTracking();
					try {
						if (cleanup) cleanup();
						activeWatcher = effect;
						const args = [
							newValue,
							oldValue === INITIAL_WATCHER_VALUE ? void 0 : isMultiSource && oldValue[0] === INITIAL_WATCHER_VALUE ? [] : oldValue,
							boundCleanup
						];
						oldValue = newValue;
						call ? call(cb, 3, args) : cb(...args);
					} finally {
						activeWatcher = currentWatcher;
						resetTracking();
					}
				}
			} else effect.run();
		};
		if (augmentJob) augmentJob(job);
		effect = new ReactiveEffect(getter);
		effect.scheduler = scheduler ? () => scheduler(job, false) : job;
		boundCleanup = (fn) => onWatcherCleanup(fn, false, effect);
		cleanup = effect.onStop = () => {
			const cleanups = cleanupMap.get(effect);
			if (cleanups) {
				if (call) call(cleanups, 4);
				else for (const cleanup2 of cleanups) cleanup2();
				cleanupMap.delete(effect);
			}
		};
		if (cb) {
			if (immediate) job(true);
			else oldValue = effect.run();
		} else if (scheduler) scheduler(job.bind(null, true), true);
		else effect.run();
		watchHandle.pause = effect.pause.bind(effect);
		watchHandle.resume = effect.resume.bind(effect);
		watchHandle.stop = watchHandle;
		return watchHandle;
	}
	function traverse(value, depth = Infinity, seen) {
		if (depth <= 0 || !isObject$1(value) || value["__v_skip"]) return value;
		seen = seen || new Map();
		if ((seen.get(value) || 0) >= depth) return value;
		seen.set(value, depth);
		depth--;
		if (isRef(value)) traverse(value.value, depth, seen);
		else if (isArray(value)) for (let i = 0; i < value.length; i++) traverse(value[i], depth, seen);
		else if (isSet(value) || isMap(value)) value.forEach((v) => {
			traverse(v, depth, seen);
		});
		else if (isPlainObject$1(value)) {
			for (const key in value) traverse(value[key], depth, seen);
			for (const key of Object.getOwnPropertySymbols(value)) if (Object.prototype.propertyIsEnumerable.call(value, key)) traverse(value[key], depth, seen);
		}
		return value;
	}
	var stack = [];
	function pushWarningContext(vnode) {
		stack.push(vnode);
	}
	function popWarningContext() {
		stack.pop();
	}
	function assertNumber(val, type) {}
	var ErrorCodes = {
		"SETUP_FUNCTION": 0,
		"0": "SETUP_FUNCTION",
		"RENDER_FUNCTION": 1,
		"1": "RENDER_FUNCTION",
		"NATIVE_EVENT_HANDLER": 5,
		"5": "NATIVE_EVENT_HANDLER",
		"COMPONENT_EVENT_HANDLER": 6,
		"6": "COMPONENT_EVENT_HANDLER",
		"VNODE_HOOK": 7,
		"7": "VNODE_HOOK",
		"DIRECTIVE_HOOK": 8,
		"8": "DIRECTIVE_HOOK",
		"TRANSITION_HOOK": 9,
		"9": "TRANSITION_HOOK",
		"APP_ERROR_HANDLER": 10,
		"10": "APP_ERROR_HANDLER",
		"APP_WARN_HANDLER": 11,
		"11": "APP_WARN_HANDLER",
		"FUNCTION_REF": 12,
		"12": "FUNCTION_REF",
		"ASYNC_COMPONENT_LOADER": 13,
		"13": "ASYNC_COMPONENT_LOADER",
		"SCHEDULER": 14,
		"14": "SCHEDULER",
		"COMPONENT_UPDATE": 15,
		"15": "COMPONENT_UPDATE",
		"APP_UNMOUNT_CLEANUP": 16,
		"16": "APP_UNMOUNT_CLEANUP"
	};
	var ErrorTypeStrings$1 = {
		["sp"]: "serverPrefetch hook",
		["bc"]: "beforeCreate hook",
		["c"]: "created hook",
		["bm"]: "beforeMount hook",
		["m"]: "mounted hook",
		["bu"]: "beforeUpdate hook",
		["u"]: "updated",
		["bum"]: "beforeUnmount hook",
		["um"]: "unmounted hook",
		["a"]: "activated hook",
		["da"]: "deactivated hook",
		["ec"]: "errorCaptured hook",
		["rtc"]: "renderTracked hook",
		["rtg"]: "renderTriggered hook",
		[0]: "setup function",
		[1]: "render function",
		[2]: "watcher getter",
		[3]: "watcher callback",
		[4]: "watcher cleanup function",
		[5]: "native event handler",
		[6]: "component event handler",
		[7]: "vnode hook",
		[8]: "directive hook",
		[9]: "transition hook",
		[10]: "app errorHandler",
		[11]: "app warnHandler",
		[12]: "ref function",
		[13]: "async component loader",
		[14]: "scheduler flush",
		[15]: "component update",
		[16]: "app unmount cleanup function"
	};
	function callWithErrorHandling(fn, instance, type, args) {
		try {
			return args ? fn(...args) : fn();
		} catch (err) {
			handleError(err, instance, type);
		}
	}
	function callWithAsyncErrorHandling(fn, instance, type, args) {
		if (isFunction(fn)) {
			const res = callWithErrorHandling(fn, instance, type, args);
			if (res && isPromise(res)) res.catch((err) => {
				handleError(err, instance, type);
			});
			return res;
		}
		if (isArray(fn)) {
			const values = [];
			for (let i = 0; i < fn.length; i++) values.push(callWithAsyncErrorHandling(fn[i], instance, type, args));
			return values;
		}
	}
	function handleError(err, instance, type, throwInDev = true) {
		const contextVNode = instance ? instance.vnode : null;
		const { errorHandler, throwUnhandledErrorInProduction } = instance && instance.appContext.config || EMPTY_OBJ;
		if (instance) {
			let cur = instance.parent;
			const exposedInstance = instance.proxy;
			const errorInfo = `https://vuejs.org/error-reference/#runtime-${type}`;
			while (cur) {
				const errorCapturedHooks = cur.ec;
				if (errorCapturedHooks) {
					for (let i = 0; i < errorCapturedHooks.length; i++) if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) return;
				}
				cur = cur.parent;
			}
			if (errorHandler) {
				pauseTracking();
				callWithErrorHandling(errorHandler, null, 10, [
					err,
					exposedInstance,
					errorInfo
				]);
				resetTracking();
				return;
			}
		}
		logError(err, type, contextVNode, throwInDev, throwUnhandledErrorInProduction);
	}
	function logError(err, type, contextVNode, throwInDev = true, throwInProd = false) {
		if (throwInProd) throw err;
		else console.error(err);
	}
	var queue = [];
	var flushIndex = -1;
	var pendingPostFlushCbs = [];
	var activePostFlushCbs = null;
	var postFlushIndex = 0;
	var resolvedPromise = Promise.resolve();
	var currentFlushPromise = null;
	function nextTick(fn) {
		const p = currentFlushPromise || resolvedPromise;
		return fn ? p.then(this ? fn.bind(this) : fn) : p;
	}
	function findInsertionIndex(id) {
		let start = flushIndex + 1;
		let end = queue.length;
		while (start < end) {
			const middle = start + end >>> 1;
			const middleJob = queue[middle];
			const middleJobId = getId(middleJob);
			if (middleJobId < id || middleJobId === id && middleJob.flags & 2) start = middle + 1;
			else end = middle;
		}
		return start;
	}
	function queueJob(job) {
		if (!(job.flags & 1)) {
			const jobId = getId(job);
			const lastJob = queue[queue.length - 1];
			if (!lastJob || !(job.flags & 2) && jobId >= getId(lastJob)) queue.push(job);
			else queue.splice(findInsertionIndex(jobId), 0, job);
			job.flags |= 1;
			queueFlush();
		}
	}
	function queueFlush() {
		if (!currentFlushPromise) currentFlushPromise = resolvedPromise.then(flushJobs);
	}
	function queuePostFlushCb(cb) {
		if (!isArray(cb)) {
			if (activePostFlushCbs && cb.id === -1) activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
			else if (!(cb.flags & 1)) {
				pendingPostFlushCbs.push(cb);
				cb.flags |= 1;
			}
		} else for (let i = 0; i < cb.length; i++) pendingPostFlushCbs.push(cb[i]);
		queueFlush();
	}
	function flushPreFlushCbs(instance, minUid, seen, i = flushIndex + 1) {
		for (; i < queue.length; i++) {
			const cb = queue[i];
			if (cb && cb.flags & 2) {
				if (instance && cb.id !== instance.uid || minUid !== void 0 && !(cb.id >= minUid)) continue;
				queue.splice(i, 1);
				i = instance ? i - 1 : flushIndex;
				if (cb.flags & 4) cb.flags &= -2;
				cb();
				if (!(cb.flags & 4)) cb.flags &= -2;
			}
		}
	}
	function flushPostFlushCbs(seen, skip, minUid = 0) {
		if (pendingPostFlushCbs.length) {
			let cbs = pendingPostFlushCbs;
			let kept = 0;
			if (skip) {
				cbs = [];
				for (let i = 0; i < pendingPostFlushCbs.length; i++) {
					const cb = pendingPostFlushCbs[i];
					if (cb.i !== void 0 ? !cb.i || cb.i.uid < minUid : skip.has(cb)) pendingPostFlushCbs[kept++] = cb;
					else cbs.push(cb);
				}
			}
			const deduped = [...new Set(cbs)].sort((a, b) => getId(a) - getId(b));
			pendingPostFlushCbs.length = kept;
			if (activePostFlushCbs) {
				for (let i = 0; i < deduped.length; i++) activePostFlushCbs.push(deduped[i]);
				return;
			}
			activePostFlushCbs = deduped;
			for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
				const cb = activePostFlushCbs[postFlushIndex];
				if (cb.flags & 4) cb.flags &= -2;
				if (!(cb.flags & 8)) cb();
				cb.flags &= -2;
			}
			activePostFlushCbs = null;
			postFlushIndex = 0;
		}
	}
	var isFlushing = false;
	function flushOnAppMount(fn, minUid) {
		if (isFlushing) {
			fn();
			return;
		}
		const queued = minUid === void 0 ? void 0 : new Set(pendingPostFlushCbs);
		fn();
		isFlushing = true;
		try {
			flushPreFlushCbs(void 0, minUid);
			flushPostFlushCbs(void 0, queued, minUid);
		} finally {
			isFlushing = false;
		}
	}
	var getId = (job) => job.id == null ? job.flags & 2 ? -1 : Infinity : job.id;
	function flushJobs(seen) {
		try {
			for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
				const job = queue[flushIndex];
				if (job && !(job.flags & 8)) {
					if (job.flags & 4) job.flags &= -2;
					callWithErrorHandling(job, job.i, job.i ? 15 : 14);
					if (!(job.flags & 4)) job.flags &= -2;
				}
			}
		} finally {
			for (; flushIndex < queue.length; flushIndex++) {
				const job = queue[flushIndex];
				if (job) job.flags &= -2;
			}
			flushIndex = -1;
			queue.length = 0;
			flushPostFlushCbs(seen);
			currentFlushPromise = null;
			if (queue.length || pendingPostFlushCbs.length) flushJobs(seen);
		}
	}
	var devtools$1;
	var buffer = [];
	function setDevtoolsHook$1(hook, target) {
		var _a, _b;
		devtools$1 = hook;
		if (devtools$1) {
			devtools$1.enabled = true;
			buffer.forEach(({ event, args }) => devtools$1.emit(event, ...args));
			buffer = [];
		} else if (typeof window !== "undefined" && window.HTMLElement && !((_b = (_a = window.navigator) == null ? void 0 : _a.userAgent) == null ? void 0 : _b.includes("jsdom"))) {
			(target.__VUE_DEVTOOLS_HOOK_REPLAY__ = target.__VUE_DEVTOOLS_HOOK_REPLAY__ || []).push((newHook) => {
				setDevtoolsHook$1(newHook, target);
			});
			setTimeout(() => {
				if (!devtools$1) {
					target.__VUE_DEVTOOLS_HOOK_REPLAY__ = null;
					buffer = [];
				}
			}, 3e3);
		} else buffer = [];
	}
	var currentRenderingInstance = null;
	var currentScopeId = null;
	function setCurrentRenderingInstance(instance) {
		const prev = currentRenderingInstance;
		currentRenderingInstance = instance;
		currentScopeId = instance && instance.type.__scopeId || null;
		return prev;
	}
	function pushScopeId(id) {
		currentScopeId = id;
	}
	function popScopeId() {
		currentScopeId = null;
	}
	var withScopeId = (_id) => withCtx;
	function withCtx(fn, ctx = currentRenderingInstance, isNonScopedSlot) {
		if (!ctx) return fn;
		if (fn._n) return fn;
		const renderFnWithContext = (...args) => {
			if (renderFnWithContext._d) setBlockTracking(-1);
			const prevInstance = setCurrentRenderingInstance(ctx);
			const prevStackSize = blockStack.length;
			let res;
			try {
				res = fn(...args);
			} finally {
				for (let i = blockStack.length; i > prevStackSize; i--) closeBlock();
				setCurrentRenderingInstance(prevInstance);
				if (renderFnWithContext._d) setBlockTracking(1);
			}
			return res;
		};
		renderFnWithContext._n = true;
		renderFnWithContext._c = true;
		renderFnWithContext._d = true;
		return renderFnWithContext;
	}
	function withDirectives(vnode, directives) {
		if (currentRenderingInstance === null) return vnode;
		const instance = getComponentPublicInstance(currentRenderingInstance);
		const bindings = vnode.dirs || (vnode.dirs = []);
		for (let i = 0; i < directives.length; i++) {
			let [dir, value, arg, modifiers = EMPTY_OBJ] = directives[i];
			if (dir) {
				if (isFunction(dir)) dir = {
					mounted: dir,
					updated: dir
				};
				if (dir.deep) traverse(value);
				bindings.push({
					dir,
					instance,
					value,
					oldValue: void 0,
					arg,
					modifiers
				});
			}
		}
		return vnode;
	}
	function invokeDirectiveHook(vnode, prevVNode, instance, name) {
		const bindings = vnode.dirs;
		const oldBindings = prevVNode && prevVNode.dirs;
		for (let i = 0; i < bindings.length; i++) {
			const binding = bindings[i];
			if (oldBindings) binding.oldValue = oldBindings[i].value;
			let hook = binding.dir[name];
			if (hook) {
				pauseTracking();
				callWithAsyncErrorHandling(hook, instance, 8, [
					vnode.el,
					binding,
					vnode,
					prevVNode
				]);
				resetTracking();
			}
		}
	}
	function provide(key, value) {
		if (currentInstance) {
			let provides = currentInstance.provides;
			const parentProvides = currentInstance.parent && currentInstance.parent.provides;
			if (parentProvides === provides) provides = currentInstance.provides = Object.create(parentProvides);
			provides[key] = value;
		}
	}
	function inject(key, defaultValue, treatDefaultAsFactory = false) {
		const instance = getCurrentInstance();
		if (instance || currentApp) {
			let provides = currentApp ? currentApp._context.provides : instance ? instance.parent == null || instance.ce ? instance.vnode.appContext && instance.vnode.appContext.provides : instance.parent.provides : void 0;
			if (provides && key in provides) return provides[key];
			else if (arguments.length > 1) return treatDefaultAsFactory && isFunction(defaultValue) ? defaultValue.call(instance && instance.proxy) : defaultValue;
		}
	}
	function hasInjectionContext() {
		return !!(getCurrentInstance() || currentApp);
	}
	var ssrContextKey = Symbol.for("v-scx");
	var useSSRContext = () => {
		{
			const ctx = inject(ssrContextKey);
			if (!ctx) {}
			return ctx;
		}
	};
	function watchEffect(effect, options) {
		return doWatch(effect, null, options);
	}
	function watchPostEffect(effect, options) {
		return doWatch(effect, null, { flush: "post" });
	}
	function watchSyncEffect(effect, options) {
		return doWatch(effect, null, { flush: "sync" });
	}
	function watch(source, cb, options) {
		return doWatch(source, cb, options);
	}
	function doWatch(source, cb, options = EMPTY_OBJ) {
		const { immediate, deep, flush, once } = options;
		const baseWatchOptions = extend({}, options);
		const runsImmediately = cb && immediate || !cb && flush !== "post";
		let ssrCleanup;
		if (isInSSRComponentSetup) {
			if (flush === "sync") {
				const ctx = useSSRContext();
				ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
			} else if (!runsImmediately) {
				const watchStopHandle = () => {};
				watchStopHandle.stop = NOOP;
				watchStopHandle.resume = NOOP;
				watchStopHandle.pause = NOOP;
				return watchStopHandle;
			}
		}
		const instance = currentInstance;
		baseWatchOptions.call = (fn, type, args) => callWithAsyncErrorHandling(fn, instance, type, args);
		let isPre = false;
		if (flush === "post") baseWatchOptions.scheduler = (job) => {
			job.i = instance;
			queuePostRenderEffect(job, instance && instance.suspense);
		};
		else if (flush !== "sync") {
			isPre = true;
			baseWatchOptions.scheduler = (job, isFirstRun) => {
				if (isFirstRun) job();
				else queueJob(job);
			};
		}
		baseWatchOptions.augmentJob = (job) => {
			if (cb) job.flags |= 4;
			if (isPre) {
				job.flags |= 2;
				if (instance) {
					job.id = instance.uid;
					job.i = instance;
				}
			}
		};
		const watchHandle = watch$1(source, cb, baseWatchOptions);
		if (isInSSRComponentSetup) {
			if (ssrCleanup) ssrCleanup.push(watchHandle);
			else if (runsImmediately) watchHandle();
		}
		return watchHandle;
	}
	function instanceWatch(source, value, options) {
		const publicThis = this.proxy;
		const getter = isString(source) ? source.includes(".") ? createPathGetter(publicThis, source) : () => publicThis[source] : source.bind(publicThis, publicThis);
		let cb;
		if (isFunction(value)) cb = value;
		else {
			cb = value.handler;
			options = value;
		}
		const reset = setCurrentInstance(this);
		const res = doWatch(getter, cb.bind(publicThis), options);
		reset();
		return res;
	}
	function createPathGetter(ctx, path) {
		const segments = path.split(".");
		return () => {
			let cur = ctx;
			for (let i = 0; i < segments.length && cur; i++) cur = cur[segments[i]];
			return cur;
		};
	}
	var pendingMounts = new WeakMap();
	var TeleportEndKey = Symbol("_vte");
	var isTeleport = (type) => type.__isTeleport;
	var isTeleportDisabled = (props) => props && (props.disabled || props.disabled === "");
	var isTeleportDeferred = (props) => props && (props.defer || props.defer === "");
	var isTargetSVG = (target) => typeof SVGElement !== "undefined" && target instanceof SVGElement;
	var isTargetMathML = (target) => typeof MathMLElement === "function" && target instanceof MathMLElement;
	var resolveTarget = (props, select) => {
		const targetSelector = props && props.to;
		if (isString(targetSelector)) {
			if (!select) return null;
			else return select(targetSelector);
		} else return targetSelector;
	};
	var TeleportImpl = {
		name: "Teleport",
		__isTeleport: true,
		process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals) {
			const { mc: mountChildren, pc: patchChildren, pbc: patchBlockChildren, o: { insert, querySelector, createText, createComment, parentNode } } = internals;
			const disabled = isTeleportDisabled(n2.props);
			let { dynamicChildren } = n2;
			const mount = (vnode, container2, anchor2) => {
				if (vnode.shapeFlag & 16) mountChildren(vnode.children, container2, anchor2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			};
			const mountToTarget = (vnode = n2) => {
				const disabled2 = isTeleportDisabled(vnode.props);
				const target = vnode.target = resolveTarget(vnode.props, querySelector);
				const targetAnchor = prepareAnchor(target, vnode, createText, insert);
				if (target) {
					if (namespace !== "svg" && isTargetSVG(target)) namespace = "svg";
					else if (namespace !== "mathml" && isTargetMathML(target)) namespace = "mathml";
					if (parentComponent && parentComponent.isCE) (parentComponent.ce._teleportTargets || (parentComponent.ce._teleportTargets = new Set())).add(target);
					if (!disabled2) {
						mount(vnode, target, targetAnchor);
						updateCssVars(vnode, false);
					}
				}
			};
			const queuePendingMount = (vnode) => {
				const mountJob = () => {
					if (pendingMounts.get(vnode) !== mountJob) return;
					pendingMounts.delete(vnode);
					if (isTeleportDisabled(vnode.props)) {
						const mountContainer = parentNode(vnode.el) || container;
						mount(vnode, mountContainer, vnode.anchor);
						updateCssVars(vnode, true);
					}
					mountToTarget(vnode);
				};
				pendingMounts.set(vnode, mountJob);
				queuePostRenderEffect(mountJob, parentSuspense);
			};
			if (n1 == null) {
				const placeholder = n2.el = createText("");
				const mainAnchor = n2.anchor = createText("");
				insert(placeholder, container, anchor);
				insert(mainAnchor, container, anchor);
				if (isTeleportDeferred(n2.props) || parentSuspense && parentSuspense.pendingBranch) {
					queuePendingMount(n2);
					return;
				}
				if (disabled) {
					mount(n2, container, mainAnchor);
					updateCssVars(n2, true);
				}
				mountToTarget();
			} else {
				n2.el = n1.el;
				const mainAnchor = n2.anchor = n1.anchor;
				const pendingMount = pendingMounts.get(n1);
				if (pendingMount) {
					pendingMount.flags |= 8;
					pendingMounts.delete(n1);
					queuePendingMount(n2);
					return;
				}
				n2.targetStart = n1.targetStart;
				const target = n2.target = n1.target;
				const targetAnchor = n2.targetAnchor = n1.targetAnchor;
				const wasDisabled = isTeleportDisabled(n1.props);
				const currentContainer = wasDisabled ? container : target;
				const currentAnchor = wasDisabled ? mainAnchor : targetAnchor;
				if (namespace === "svg" || isTargetSVG(target)) namespace = "svg";
				else if (namespace === "mathml" || isTargetMathML(target)) namespace = "mathml";
				if (dynamicChildren) {
					patchBlockChildren(n1.dynamicChildren, dynamicChildren, currentContainer, parentComponent, parentSuspense, namespace, slotScopeIds);
					traverseStaticChildren(n1, n2, true);
				} else if (!optimized) patchChildren(n1, n2, currentContainer, currentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, false);
				if (disabled) {
					if (!wasDisabled) moveTeleport(n2, container, mainAnchor, internals, 1);
					else if (n2.props && n1.props && n2.props.to !== n1.props.to) n2.props.to = n1.props.to;
				} else if ((n2.props && n2.props.to) !== (n1.props && n1.props.to)) {
					const nextTarget = resolveTarget(n2.props, querySelector);
					if (nextTarget) {
						n2.target = nextTarget;
						moveTeleport(n2, nextTarget, null, internals, 0);
					}
				} else if (wasDisabled) moveTeleport(n2, target, targetAnchor, internals, 1);
				updateCssVars(n2, disabled);
			}
		},
		remove(vnode, parentComponent, parentSuspense, { um: unmount, o: { remove: hostRemove } }, doRemove) {
			const { shapeFlag, children, anchor, targetStart, targetAnchor, target, props } = vnode;
			const disabled = isTeleportDisabled(props);
			const shouldRemove = doRemove || !disabled;
			const pendingMount = pendingMounts.get(vnode);
			if (pendingMount) {
				pendingMount.flags |= 8;
				pendingMounts.delete(vnode);
			}
			if (target) {
				hostRemove(targetStart);
				hostRemove(targetAnchor);
			}
			doRemove && hostRemove(anchor);
			if (!pendingMount && (disabled || target) && shapeFlag & 16) for (let i = 0; i < children.length; i++) {
				const child = children[i];
				unmount(child, parentComponent, parentSuspense, shouldRemove, !!child.dynamicChildren);
			}
		},
		move: moveTeleport,
		hydrate: hydrateTeleport
	};
	function moveTeleport(vnode, container, parentAnchor, { o: { insert }, m: move }, moveType = 2) {
		if (moveType === 0) {
			if (vnode.targetStart) insert(vnode.targetStart, container, parentAnchor);
			insert(vnode.targetAnchor, container, parentAnchor);
			parentAnchor = vnode.targetAnchor;
		}
		const { el, anchor, shapeFlag, children, props } = vnode;
		const isReorder = moveType === 2;
		if (isReorder) insert(el, container, parentAnchor);
		if (!pendingMounts.has(vnode) && (!isReorder || isTeleportDisabled(props))) {
			if (shapeFlag & 16) for (let i = 0; i < children.length; i++) move(children[i], container, parentAnchor, 2);
		}
		if (isReorder) insert(anchor, container, parentAnchor);
	}
	function hydrateTeleport(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized, { o: { nextSibling, parentNode, querySelector, insert, createText } }, hydrateChildren) {
		function hydrateAnchor(target2, targetNode) {
			let targetAnchor = targetNode;
			while (targetAnchor) {
				if (targetAnchor && targetAnchor.nodeType === 8) {
					if (targetAnchor.data === "teleport start anchor") vnode.targetStart = targetAnchor;
					else if (targetAnchor.data === "teleport anchor") {
						vnode.targetAnchor = targetAnchor;
						target2._lpa = vnode.targetAnchor && nextSibling(vnode.targetAnchor);
						break;
					}
				}
				targetAnchor = nextSibling(targetAnchor);
			}
		}
		function hydrateDisabledTeleport(node2, vnode2) {
			vnode2.anchor = hydrateChildren(nextSibling(node2), vnode2, parentNode(node2), parentComponent, parentSuspense, slotScopeIds, optimized);
		}
		const target = vnode.target = resolveTarget(vnode.props, querySelector);
		const disabled = isTeleportDisabled(vnode.props);
		if (target) {
			const targetNode = target._lpa || target.firstChild;
			if (vnode.shapeFlag & 16) {
				if (disabled) {
					hydrateDisabledTeleport(node, vnode);
					hydrateAnchor(target, targetNode);
					if (!vnode.targetAnchor) prepareAnchor(target, vnode, createText, insert, parentNode(node) === target ? node : null);
				} else {
					vnode.anchor = nextSibling(node);
					hydrateAnchor(target, targetNode);
					if (!vnode.targetAnchor) prepareAnchor(target, vnode, createText, insert);
					hydrateChildren(targetNode && nextSibling(targetNode), vnode, target, parentComponent, parentSuspense, slotScopeIds, optimized);
				}
			}
			updateCssVars(vnode, disabled);
		} else if (disabled) {
			if (vnode.shapeFlag & 16) {
				hydrateDisabledTeleport(node, vnode);
				vnode.targetStart = node;
				vnode.targetAnchor = nextSibling(node);
			}
		}
		return vnode.anchor && nextSibling(vnode.anchor);
	}
	var Teleport = TeleportImpl;
	function updateCssVars(vnode, isDisabled) {
		const ctx = vnode.ctx;
		if (ctx && ctx.ut) {
			let node, anchor;
			if (isDisabled) {
				node = vnode.el;
				anchor = vnode.anchor;
			} else {
				node = vnode.targetStart;
				anchor = vnode.targetAnchor;
			}
			while (node && node !== anchor) {
				if (node.nodeType === 1) node.setAttribute("data-v-owner", ctx.uid);
				node = node.nextSibling;
			}
			ctx.ut();
		}
	}
	function prepareAnchor(target, vnode, createText, insert, anchor = null) {
		const targetStart = vnode.targetStart = createText("");
		const targetAnchor = vnode.targetAnchor = createText("");
		targetStart[TeleportEndKey] = targetAnchor;
		if (target) {
			insert(targetStart, target, anchor);
			insert(targetAnchor, target, anchor);
		}
		return targetAnchor;
	}
	var leaveCbKey = Symbol("_leaveCb");
	var enterCbKey$1 = Symbol("_enterCb");
	function useTransitionState() {
		const state = {
			isMounted: false,
			isLeaving: false,
			isUnmounting: false,
			leavingVNodes: new Map()
		};
		onMounted(() => {
			state.isMounted = true;
		});
		onBeforeUnmount(() => {
			state.isUnmounting = true;
		});
		return state;
	}
	var TransitionHookValidator = [Function, Array];
	var BaseTransitionPropsValidators = {
		mode: String,
		appear: Boolean,
		persisted: Boolean,
		onBeforeEnter: TransitionHookValidator,
		onEnter: TransitionHookValidator,
		onAfterEnter: TransitionHookValidator,
		onEnterCancelled: TransitionHookValidator,
		onBeforeLeave: TransitionHookValidator,
		onLeave: TransitionHookValidator,
		onAfterLeave: TransitionHookValidator,
		onLeaveCancelled: TransitionHookValidator,
		onBeforeAppear: TransitionHookValidator,
		onAppear: TransitionHookValidator,
		onAfterAppear: TransitionHookValidator,
		onAppearCancelled: TransitionHookValidator
	};
	var BaseTransitionImpl = {
		name: `BaseTransition`,
		props: BaseTransitionPropsValidators,
		setup(props, { slots }) {
			const instance = getCurrentInstance();
			const state = useTransitionState();
			return () => {
				const children = slots.default && getTransitionRawChildren(slots.default(), true);
				const child = children && children.length ? findNonCommentChild(children) : instance.subTree ? createCommentVNode() : void 0;
				if (!child) return;
				const rawProps = toRaw(props);
				const { mode } = rawProps;
				if (state.isLeaving) return emptyPlaceholder(child);
				const innerChild = getInnerChild$1(child);
				if (!innerChild) return emptyPlaceholder(child);
				let enterHooks = resolveTransitionHooks(innerChild, rawProps, state, instance, (hooks) => enterHooks = hooks);
				if (innerChild.type !== Comment) setTransitionHooks(innerChild, enterHooks);
				let oldInnerChild = instance.subTree && getInnerChild$1(instance.subTree);
				if (oldInnerChild && oldInnerChild.type !== Comment && !isSameVNodeType(oldInnerChild, innerChild) && getTransitionRoot(instance.subTree)) {
					let leavingHooks = resolveTransitionHooks(oldInnerChild, rawProps, state, instance);
					setTransitionHooks(oldInnerChild, leavingHooks);
					if (mode === "out-in" && innerChild.type !== Comment) {
						state.isLeaving = true;
						leavingHooks.afterLeave = () => {
							state.isLeaving = false;
							if (!(instance.job.flags & 8)) instance.update();
							delete leavingHooks.afterLeave;
							oldInnerChild = void 0;
						};
						return emptyPlaceholder(child);
					} else if (mode === "in-out" && innerChild.type !== Comment) leavingHooks.delayLeave = (el, earlyRemove, delayedLeave) => {
						const leavingVNodesCache = getLeavingNodesForType(state, oldInnerChild);
						leavingVNodesCache[String(oldInnerChild.key)] = oldInnerChild;
						el[leaveCbKey] = () => {
							earlyRemove();
							el[leaveCbKey] = void 0;
							delete enterHooks.delayedLeave;
							oldInnerChild = void 0;
						};
						enterHooks.delayedLeave = () => {
							delayedLeave();
							delete enterHooks.delayedLeave;
							oldInnerChild = void 0;
						};
					};
					else oldInnerChild = void 0;
				} else if (oldInnerChild) oldInnerChild = void 0;
				return child;
			};
		}
	};
	function findNonCommentChild(children) {
		let child = children[0];
		if (children.length > 1) {
			for (const c of children) if (c.type !== Comment) {
				child = c;
				break;
			}
		}
		return child;
	}
	var BaseTransition = BaseTransitionImpl;
	function getLeavingNodesForType(state, vnode) {
		const { leavingVNodes } = state;
		let leavingVNodesCache = leavingVNodes.get(vnode.type);
		if (!leavingVNodesCache) {
			leavingVNodesCache = Object.create(null);
			leavingVNodes.set(vnode.type, leavingVNodesCache);
		}
		return leavingVNodesCache;
	}
	function resolveTransitionHooks(vnode, props, state, instance, postClone) {
		const { appear, mode, persisted = false, onBeforeEnter, onEnter, onAfterEnter, onEnterCancelled, onBeforeLeave, onLeave, onAfterLeave, onLeaveCancelled, onBeforeAppear, onAppear, onAfterAppear, onAppearCancelled } = props;
		const key = String(vnode.key);
		const leavingVNodesCache = getLeavingNodesForType(state, vnode);
		const callHook = (hook, args) => {
			hook && callWithAsyncErrorHandling(hook, instance, 9, args);
		};
		const callAsyncHook = (hook, args) => {
			const done = args[1];
			callHook(hook, args);
			if (isArray(hook)) {
				if (hook.every((hook2) => hook2.length <= 1)) done();
			} else if (hook.length <= 1) done();
		};
		const hooks = {
			mode,
			persisted,
			beforeEnter(el) {
				let hook = onBeforeEnter;
				if (!state.isMounted) {
					if (appear) hook = onBeforeAppear || onBeforeEnter;
					else return;
				}
				if (el[leaveCbKey]) el[leaveCbKey](true);
				const leavingVNode = leavingVNodesCache[key];
				if (leavingVNode && isSameVNodeType(vnode, leavingVNode)) {
					let leavingCb = leavingVNode.el[leaveCbKey];
					if (!leavingCb) {
						const leavingRoot = getTransitionRoot(leavingVNode);
						leavingCb = leavingRoot && leavingRoot.el[leaveCbKey];
					}
					if (leavingCb) leavingCb();
				}
				callHook(hook, [el]);
			},
			enter(el) {
				if (leavingVNodesCache[key] === vnode) return;
				let hook = onEnter;
				let afterHook = onAfterEnter;
				let cancelHook = onEnterCancelled;
				if (!state.isMounted) {
					if (appear) {
						hook = onAppear || onEnter;
						afterHook = onAfterAppear || onAfterEnter;
						cancelHook = onAppearCancelled || onEnterCancelled;
					} else return;
				}
				let called = false;
				el[enterCbKey$1] = (cancelled) => {
					if (called) return;
					called = true;
					if (cancelled) callHook(cancelHook, [el]);
					else callHook(afterHook, [el]);
					if (hooks.delayedLeave) hooks.delayedLeave();
					el[enterCbKey$1] = void 0;
				};
				const done = el[enterCbKey$1].bind(null, false);
				if (hook) callAsyncHook(hook, [el, done]);
				else done();
			},
			leave(el, remove) {
				const key2 = String(vnode.key);
				if (el[enterCbKey$1]) el[enterCbKey$1](true);
				if (state.isUnmounting) return remove();
				callHook(onBeforeLeave, [el]);
				let called = false;
				el[leaveCbKey] = (cancelled) => {
					if (called) return;
					called = true;
					remove();
					if (cancelled) callHook(onLeaveCancelled, [el]);
					else callHook(onAfterLeave, [el]);
					el[leaveCbKey] = void 0;
					if (leavingVNodesCache[key2] === vnode) delete leavingVNodesCache[key2];
				};
				const done = el[leaveCbKey].bind(null, false);
				leavingVNodesCache[key2] = vnode;
				if (onLeave) callAsyncHook(onLeave, [el, done]);
				else done();
			},
			clone(vnode2) {
				const hooks2 = resolveTransitionHooks(vnode2, props, state, instance, postClone);
				if (postClone) postClone(hooks2);
				return hooks2;
			}
		};
		return hooks;
	}
	function emptyPlaceholder(vnode) {
		if (isKeepAlive(vnode)) {
			vnode = cloneVNode(vnode);
			vnode.children = null;
			return vnode;
		}
	}
	function getInnerChild$1(vnode) {
		if (!isKeepAlive(vnode)) {
			if (isTeleport(vnode.type) && vnode.children) return findNonCommentChild(vnode.children);
			return vnode;
		}
		if (vnode.component) return vnode.component.subTree;
		const { shapeFlag, children } = vnode;
		if (children) {
			if (shapeFlag & 16) return children[0];
			if (shapeFlag & 32 && isFunction(children.default)) return children.default();
		}
	}
	function setTransitionHooks(vnode, hooks) {
		if (vnode.shapeFlag & 6 && vnode.component) {
			vnode.transition = hooks;
			const subTree = vnode.component.subTree;
			setTransitionHooks(isTeleport(subTree.type) ? getInnerChild$1(subTree) || subTree : subTree, hooks);
		} else if (vnode.shapeFlag & 128) {
			vnode.ssContent.transition = hooks.clone(vnode.ssContent);
			vnode.ssFallback.transition = hooks.clone(vnode.ssFallback);
		} else {
			vnode.transition = hooks;
			if (vnode.type === Fragment && isArray(vnode.children)) {
				const child = filterSingleRoot(vnode.children, false);
				if (child) setTransitionHooks(child, hooks);
			}
		}
	}
	function getTransitionRawChildren(children, keepComment = false, parentKey) {
		let ret = [];
		let keyedFragmentCount = 0;
		for (let i = 0; i < children.length; i++) {
			let child = children[i];
			const key = parentKey == null ? child.key : String(parentKey) + String(child.key != null ? child.key : i);
			if (child.type === Fragment) {
				if (child.patchFlag & 128) keyedFragmentCount++;
				ret = ret.concat(getTransitionRawChildren(child.children, keepComment, key));
			} else if (keepComment || child.type !== Comment) ret.push(key != null ? cloneVNode(child, { key }) : child);
		}
		if (keyedFragmentCount > 1) for (let i = 0; i < ret.length; i++) ret[i].patchFlag = -2;
		return ret;
	}
	function getTransitionRoot(vnode) {
		if (vnode.component) return getTransitionRoot(vnode.component.subTree);
		if (vnode.type === Fragment) {
			const child = isArray(vnode.children) && filterSingleRoot(vnode.children, false);
			return child ? getTransitionRoot(child) : void 0;
		}
		if (vnode.type !== Comment) return vnode;
	}
	function defineComponent(options, extraOptions) {
		return isFunction(options) ? (() => extend({ name: options.name }, extraOptions, { setup: options }))() : options;
	}
	function useId$1() {
		const i = getCurrentInstance();
		if (i) return (i.appContext.config.idPrefix || "v") + "-" + i.ids[0] + i.ids[1]++;
		return "";
	}
	function markAsyncBoundary(instance) {
		instance.ids = [
			instance.ids[0] + instance.ids[2]++ + "-",
			0,
			0
		];
	}
	function useTemplateRef(key) {
		const i = getCurrentInstance();
		const r = shallowRef(null);
		if (i) {
			const refs = i.refs === EMPTY_OBJ ? i.refs = {} : i.refs;
			Object.defineProperty(refs, key, {
				enumerable: true,
				get: () => r.value,
				set: (val) => r.value = val
			});
		}
		return r;
	}
	function isTemplateRefKey(refs, key) {
		let desc;
		return !!((desc = Object.getOwnPropertyDescriptor(refs, key)) && !desc.configurable);
	}
	var pendingSetRefMap = new WeakMap();
	function setRef(rawRef, oldRawRef, parentSuspense, vnode, isUnmount = false) {
		if (isArray(rawRef)) {
			rawRef.forEach((r, i) => setRef(r, oldRawRef && (isArray(oldRawRef) ? oldRawRef[i] : oldRawRef), parentSuspense, vnode, isUnmount));
			return;
		}
		if (isAsyncWrapper(vnode) && !isUnmount) {
			if (vnode.shapeFlag & 512 && vnode.type.__asyncResolved && vnode.component.subTree.component) setRef(rawRef, oldRawRef, parentSuspense, vnode.component.subTree);
			return;
		}
		const refValue = vnode.shapeFlag & 4 ? getComponentPublicInstance(vnode.component) : vnode.el;
		const value = isUnmount ? null : refValue;
		const { i: owner, r: ref } = rawRef;
		const oldRef = oldRawRef && oldRawRef.r;
		const refs = owner.refs === EMPTY_OBJ ? owner.refs = {} : owner.refs;
		const setupState = owner.setupState;
		const rawSetupState = toRaw(setupState);
		const canSetSetupRef = setupState === EMPTY_OBJ ? NO : (key) => {
			if (isTemplateRefKey(refs, key)) return false;
			return hasOwn(rawSetupState, key);
		};
		const canSetRef = (ref2, key) => {
			if (key && isTemplateRefKey(refs, key)) return false;
			return true;
		};
		if (oldRef != null && oldRef !== ref) {
			invalidatePendingSetRef(oldRawRef);
			if (isString(oldRef)) {
				refs[oldRef] = null;
				if (canSetSetupRef(oldRef)) setupState[oldRef] = null;
			} else if (isRef(oldRef)) {
				const oldRawRefAtom = oldRawRef;
				if (canSetRef(oldRef, oldRawRefAtom.k)) oldRef.value = null;
				if (oldRawRefAtom.k) refs[oldRawRefAtom.k] = null;
			}
		}
		if (isFunction(ref)) callWithErrorHandling(ref, owner, 12, [value, refs]);
		else {
			const _isString = isString(ref);
			const _isRef = isRef(ref);
			if (_isString || _isRef) {
				const doSet = () => {
					if (rawRef.f) {
						const existing = _isString ? canSetSetupRef(ref) ? setupState[ref] : refs[ref] : canSetRef(ref) || !rawRef.k ? ref.value : refs[rawRef.k];
						if (isUnmount) isArray(existing) && remove(existing, refValue);
						else if (!isArray(existing)) {
							if (_isString) {
								refs[ref] = [refValue];
								if (canSetSetupRef(ref)) setupState[ref] = refs[ref];
							} else {
								const newVal = [refValue];
								if (canSetRef(ref, rawRef.k)) ref.value = newVal;
								if (rawRef.k) refs[rawRef.k] = newVal;
							}
						} else if (!existing.includes(refValue)) existing.push(refValue);
					} else if (_isString) {
						refs[ref] = value;
						if (canSetSetupRef(ref)) setupState[ref] = value;
					} else if (_isRef) {
						if (canSetRef(ref, rawRef.k)) ref.value = value;
						if (rawRef.k) refs[rawRef.k] = value;
					}
				};
				if (value) {
					const job = () => {
						doSet();
						pendingSetRefMap.delete(rawRef);
					};
					job.id = -1;
					pendingSetRefMap.set(rawRef, job);
					queuePostRenderEffect(job, parentSuspense);
				} else {
					invalidatePendingSetRef(rawRef);
					doSet();
				}
			}
		}
	}
	function invalidatePendingSetRef(rawRef) {
		const pendingSetRef = pendingSetRefMap.get(rawRef);
		if (pendingSetRef) {
			pendingSetRef.flags |= 8;
			pendingSetRefMap.delete(rawRef);
		}
	}
	var hasLoggedMismatchError = false;
	var logMismatchError = () => {
		if (hasLoggedMismatchError) return;
		console.error("Hydration completed but contains mismatches.");
		hasLoggedMismatchError = true;
	};
	var isSVGContainer = (container) => container.namespaceURI.includes("svg") && container.tagName !== "foreignObject";
	var isMathMLContainer = (container) => container.namespaceURI.includes("MathML");
	var getContainerType = (container) => {
		if (container.nodeType !== 1) return void 0;
		if (isSVGContainer(container)) return "svg";
		if (isMathMLContainer(container)) return "mathml";
	};
	var isComment = (node) => node.nodeType === 8;
	function createHydrationFunctions(rendererInternals) {
		const { mt: mountComponent, p: patch, o: { patchProp, createText, nextSibling, parentNode, remove, insert, createComment } } = rendererInternals;
		const hydrate = (vnode, container) => {
			if (!container.hasChildNodes()) {
				patch(null, vnode, container);
				flushPostFlushCbs();
				container._vnode = vnode;
				return;
			}
			hydrateNode(container.firstChild, vnode, null, null, null);
			flushPostFlushCbs();
			container._vnode = vnode;
		};
		const hydrateNode = (node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized = false) => {
			optimized = optimized || !!vnode.dynamicChildren;
			const isFragmentStart = isComment(node) && node.data === "[";
			const onMismatch = () => handleMismatch(node, vnode, parentComponent, parentSuspense, slotScopeIds, isFragmentStart);
			const { type, ref, shapeFlag, patchFlag } = vnode;
			let domType = node.nodeType;
			vnode.el = node;
			if (patchFlag === -2) {
				optimized = false;
				vnode.dynamicChildren = null;
			}
			let nextNode = null;
			switch (type) {
				case Text:
					if (domType !== 3) {
						if (vnode.children === "") {
							insert(vnode.el = createText(""), parentNode(node), node);
							nextNode = node;
						} else nextNode = onMismatch();
					} else {
						if (node.data !== vnode.children) {
							logMismatchError();
							node.data = vnode.children;
						}
						nextNode = nextSibling(node);
					}
					break;
				case Comment:
					if (isTemplateNode(node)) {
						nextNode = nextSibling(node);
						replaceNode(vnode.el = node.content.firstChild, node, parentComponent);
					} else if (domType !== 8 || isFragmentStart) nextNode = onMismatch();
					else nextNode = nextSibling(node);
					break;
				case Static:
					if (isFragmentStart) {
						node = nextSibling(node);
						domType = node.nodeType;
					}
					if (domType === 1 || domType === 3) {
						nextNode = node;
						const needToAdoptContent = !vnode.children.length;
						for (let i = 0; i < vnode.staticCount; i++) {
							if (needToAdoptContent) vnode.children += nextNode.nodeType === 1 ? nextNode.outerHTML : nextNode.data;
							if (i === vnode.staticCount - 1) vnode.anchor = nextNode;
							nextNode = nextSibling(nextNode);
						}
						return isFragmentStart ? nextSibling(nextNode) : nextNode;
					} else onMismatch();
					break;
				case Fragment:
					if (!isFragmentStart) nextNode = onMismatch();
					else nextNode = hydrateFragment(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized);
					break;
				default: if (shapeFlag & 1) {
					if ((domType !== 1 || vnode.type.toLowerCase() !== node.tagName.toLowerCase()) && !isTemplateNode(node)) nextNode = onMismatch();
					else nextNode = hydrateElement(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized);
				} else if (shapeFlag & 6) {
					vnode.slotScopeIds = slotScopeIds;
					const container = parentNode(node);
					if (isFragmentStart) nextNode = locateClosingAnchor(node);
					else if (isComment(node) && node.data === "teleport start") nextNode = locateClosingAnchor(node, node.data, "teleport end");
					else nextNode = nextSibling(node);
					mountComponent(vnode, container, null, parentComponent, parentSuspense, getContainerType(container), optimized);
					if ((isAsyncWrapper(vnode) || vnode.component.asyncDep) && !vnode.component.subTree) {
						let subTree;
						if (isFragmentStart) {
							subTree = createVNode(Static);
							subTree.anchor = nextNode ? nextNode.previousSibling : container.lastChild;
						} else subTree = node.nodeType === 3 ? createTextVNode("") : createVNode(node.nodeType === 8 ? Comment : "div");
						subTree.el = node;
						vnode.component.subTree = subTree;
					}
				} else if (shapeFlag & 64) {
					if (domType !== 8) nextNode = onMismatch();
					else nextNode = vnode.type.hydrate(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized, rendererInternals, hydrateChildren);
				} else if (shapeFlag & 128) nextNode = vnode.type.hydrate(node, vnode, parentComponent, parentSuspense, getContainerType(parentNode(node)), slotScopeIds, optimized, rendererInternals, hydrateNode);
			}
			if (ref != null) setRef(ref, null, parentSuspense, vnode);
			return nextNode;
		};
		const hydrateElement = (el, vnode, parentComponent, parentSuspense, slotScopeIds, optimized) => {
			optimized = optimized || !!vnode.dynamicChildren;
			const { type, dynamicProps, props, patchFlag, shapeFlag, dirs, transition } = vnode;
			const forcePatch = type === "input" || type === "option";
			const hasDynamicProps = !!dynamicProps;
			if (forcePatch || hasDynamicProps || patchFlag !== -1) {
				if (dirs) invokeDirectiveHook(vnode, null, parentComponent, "created");
				let needCallTransitionHooks = false;
				if (isTemplateNode(el)) {
					needCallTransitionHooks = needTransition(null, transition) && parentComponent && parentComponent.vnode.props && parentComponent.vnode.props.appear;
					const content = el.content.firstChild;
					if (needCallTransitionHooks) {
						const cls = content.getAttribute("class");
						if (cls) content.$cls = cls;
						transition.beforeEnter(content);
					}
					replaceNode(content, el, parentComponent);
					vnode.el = el = content;
				}
				if (shapeFlag & 16 && !(props && (props.innerHTML || props.textContent))) {
					let next = hydrateChildren(el.firstChild, vnode, el, parentComponent, parentSuspense, slotScopeIds, optimized);
					if (next && !isMismatchAllowed(el, 1)) logMismatchError();
					while (next) {
						const cur = next;
						next = next.nextSibling;
						remove(cur);
					}
				} else if (shapeFlag & 8) {
					let clientText = vnode.children;
					if (clientText[0] === "\n" && (el.tagName === "PRE" || el.tagName === "TEXTAREA")) clientText = clientText.slice(1);
					const { textContent } = el;
					if (textContent !== clientText && textContent !== clientText.replace(/\r\n|\r/g, "\n")) {
						if (!isMismatchAllowed(el, 0)) logMismatchError();
						el.textContent = vnode.children;
					}
				}
				if (props) {
					if (forcePatch || hasDynamicProps || !optimized || patchFlag & 48) {
						const isCustomElement = el.tagName.includes("-");
						const namespace = el.namespaceURI.includes("svg") ? "svg" : el.namespaceURI.includes("MathML") ? "mathml" : void 0;
						for (const key in props) if (forcePatch && (key.endsWith("value") || key === "indeterminate") || isOn(key) && !isReservedProp(key) || key[0] === "." || isCustomElement && !isReservedProp(key) || dynamicProps && dynamicProps.includes(key)) {
							if (isUnchangedResourceProp(el, key, props[key])) continue;
							patchProp(el, key, null, props[key], namespace, parentComponent);
						}
					} else if (props.onClick) patchProp(el, "onClick", null, props.onClick, void 0, parentComponent);
					else if (patchFlag & 4 && isReactive(props.style)) for (const key in props.style) props.style[key];
				}
				let vnodeHooks;
				if (vnodeHooks = props && props.onVnodeBeforeMount) invokeVNodeHook(vnodeHooks, parentComponent, vnode);
				if (dirs) invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
				if ((vnodeHooks = props && props.onVnodeMounted) || dirs || needCallTransitionHooks) queueEffectWithSuspense(() => {
					vnodeHooks && invokeVNodeHook(vnodeHooks, parentComponent, vnode);
					needCallTransitionHooks && transition.enter(el);
					dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
				}, parentSuspense);
			}
			return el.nextSibling;
		};
		const hydrateChildren = (node, parentVNode, container, parentComponent, parentSuspense, slotScopeIds, optimized) => {
			optimized = optimized || !!parentVNode.dynamicChildren;
			const children = parentVNode.children;
			const l = children.length;
			let hasCheckedMismatch = false;
			for (let i = 0; i < l; i++) {
				const vnode = optimized ? children[i] : children[i] = normalizeVNode(children[i]);
				const isText = vnode.type === Text;
				if (node) {
					if (isText && !optimized) {
						if (i + 1 < l && normalizeVNode(children[i + 1]).type === Text) {
							insert(createText(node.data.slice(vnode.children.length)), container, nextSibling(node));
							node.data = vnode.children;
						}
					}
					node = hydrateNode(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized);
				} else if (isText && !vnode.children) insert(vnode.el = createText(""), container);
				else {
					if (!hasCheckedMismatch) {
						hasCheckedMismatch = true;
						if (!isMismatchAllowed(container, 1)) logMismatchError();
					}
					patch(null, vnode, container, null, parentComponent, parentSuspense, getContainerType(container), slotScopeIds);
				}
			}
			return node;
		};
		const hydrateFragment = (node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized) => {
			const { slotScopeIds: fragmentSlotScopeIds } = vnode;
			if (fragmentSlotScopeIds) slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
			const container = parentNode(node);
			const next = hydrateChildren(nextSibling(node), vnode, container, parentComponent, parentSuspense, slotScopeIds, optimized);
			if (next && isComment(next) && next.data === "]") return nextSibling(vnode.anchor = next);
			else {
				logMismatchError();
				insert(vnode.anchor = createComment(`]`), container, next);
				return next;
			}
		};
		const handleMismatch = (node, vnode, parentComponent, parentSuspense, slotScopeIds, isFragment) => {
			if (!isNodeMismatchAllowed(node, vnode)) logMismatchError();
			vnode.el = null;
			if (isFragment) {
				const end = locateClosingAnchor(node);
				while (true) {
					const next2 = nextSibling(node);
					if (next2 && next2 !== end) remove(next2);
					else break;
				}
			}
			const next = nextSibling(node);
			const container = parentNode(node);
			remove(node);
			patch(null, vnode, container, next, parentComponent, parentSuspense, getContainerType(container), slotScopeIds);
			if (parentComponent) {
				parentComponent.vnode.el = vnode.el;
				updateHOCHostEl(parentComponent, vnode.el);
			}
			return next;
		};
		const locateClosingAnchor = (node, open = "[", close = "]") => {
			let match = 0;
			while (node) {
				node = nextSibling(node);
				if (node && isComment(node)) {
					if (node.data === open) match++;
					if (node.data === close) {
						if (match === 0) return nextSibling(node);
						else match--;
					}
				}
			}
			return node;
		};
		const replaceNode = (newNode, oldNode, parentComponent) => {
			const parentNode2 = oldNode.parentNode;
			if (parentNode2) parentNode2.replaceChild(newNode, oldNode);
			let parent = parentComponent;
			while (parent) {
				if (parent.vnode.el === oldNode) parent.vnode.el = parent.subTree.el = newNode;
				parent = parent.parent;
			}
		};
		const isTemplateNode = (node) => {
			return node.nodeType === 1 && node.tagName === "TEMPLATE";
		};
		return [hydrate, hydrateNode];
	}
	var resourceProps = new Set([
		"src",
		"srcset",
		"href",
		"poster"
	]);
	function isUnchangedResourceProp(el, key, clientValue) {
		if (!resourceProps.has(key)) return false;
		return el.getAttribute(key) === (clientValue == null ? null : `${clientValue}`);
	}
	var allowMismatchAttr = "data-allow-mismatch";
	var MismatchTypeString = {
		[0]: "text",
		[1]: "children",
		[2]: "class",
		[3]: "style",
		[4]: "attribute"
	};
	function isMismatchAllowed(el, allowedType) {
		if (allowedType === 0 || allowedType === 1) while (el && !el.hasAttribute(allowMismatchAttr)) el = el.parentElement;
		return isMismatchAllowedByAttr(el && el.getAttribute(allowMismatchAttr), allowedType);
	}
	function isMismatchAllowedByAttr(allowedAttr, allowedType) {
		if (allowedAttr == null) return false;
		else if (allowedAttr === "") return true;
		else {
			const list = allowedAttr.split(",");
			if (allowedType === 0 && list.includes("children")) return true;
			return list.includes(MismatchTypeString[allowedType]);
		}
	}
	function isNodeMismatchAllowed(node, vnode) {
		return isMismatchAllowed(node.parentElement, 1) || isMismatchAllowedByNode(node) || isMismatchAllowedByVNode(vnode);
	}
	function isMismatchAllowedByNode(node) {
		return node.nodeType === 1 && isMismatchAllowedByAttr(node.getAttribute(allowMismatchAttr), 1);
	}
	function isMismatchAllowedByVNode({ props }) {
		const allowedAttr = props && props[allowMismatchAttr];
		return typeof allowedAttr === "string" && isMismatchAllowedByAttr(allowedAttr, 1);
	}
	var requestIdleCallback = getGlobalThis().requestIdleCallback || ((cb) => setTimeout(cb, 1));
	var cancelIdleCallback = getGlobalThis().cancelIdleCallback || ((id) => clearTimeout(id));
	var hydrateOnIdle = (timeout = 1e4) => (hydrate) => {
		const id = requestIdleCallback(hydrate, { timeout });
		return () => cancelIdleCallback(id);
	};
	function elementIsVisibleInViewport(el) {
		const { top, left, bottom, right } = el.getBoundingClientRect();
		const { innerHeight, innerWidth } = window;
		return (top > 0 && top < innerHeight || bottom > 0 && bottom < innerHeight) && (left > 0 && left < innerWidth || right > 0 && right < innerWidth);
	}
	var hydrateOnVisible = (opts) => (hydrate, forEach) => {
		const ob = new IntersectionObserver((entries) => {
			for (const e of entries) {
				if (!e.isIntersecting) continue;
				ob.disconnect();
				hydrate();
				break;
			}
		}, opts);
		const observe = (el) => {
			if (elementIsVisibleInViewport(el)) {
				hydrate();
				ob.disconnect();
				return false;
			}
			if (getComputedStyle(el).display === "contents") {
				for (let i = 0; i < el.children.length; i++) if (observe(el.children[i]) === false) return false;
			}
			ob.observe(el);
		};
		forEach((el) => {
			if (!(el instanceof Element)) return;
			return observe(el);
		});
		return () => ob.disconnect();
	};
	var hydrateOnMediaQuery = (query) => (hydrate) => {
		if (query) {
			const mql = matchMedia(query);
			if (mql.matches) hydrate();
			else {
				mql.addEventListener("change", hydrate, { once: true });
				return () => mql.removeEventListener("change", hydrate);
			}
		}
	};
	var hydrateOnInteraction = (interactions = []) => (hydrate, forEach) => {
		if (isString(interactions)) interactions = [interactions];
		let hasHydrated = false;
		const doHydrate = (e) => {
			if (!hasHydrated) {
				hasHydrated = true;
				teardown();
				hydrate();
				e.target.dispatchEvent(new e.constructor(e.type, e));
			}
		};
		const teardown = () => {
			forEach((el) => {
				for (const i of interactions) el.removeEventListener(i, doHydrate);
			});
		};
		forEach((el) => {
			for (const i of interactions) el.addEventListener(i, doHydrate, { once: true });
		});
		return teardown;
	};
	function forEachElement(node, cb) {
		if (isComment(node) && node.data === "[") {
			let depth = 1;
			let next = node.nextSibling;
			while (next) {
				if (next.nodeType === 1) {
					if (cb(next) === false) break;
				} else if (isComment(next)) {
					if (next.data === "]") {
						if (--depth === 0) break;
					} else if (next.data === "[") depth++;
				}
				next = next.nextSibling;
			}
		} else cb(node);
	}
	var isAsyncWrapper = (i) => !!i.type.__asyncLoader;
	function defineAsyncComponent(source) {
		if (isFunction(source)) source = { loader: source };
		const { loader, loadingComponent, errorComponent, delay = 200, hydrate: hydrateStrategy, timeout, suspensible = true, onError: userOnError } = source;
		let pendingRequest = null;
		let resolvedComp;
		let retries = 0;
		const retry = () => {
			retries++;
			pendingRequest = null;
			return load();
		};
		const load = () => {
			let thisRequest;
			return pendingRequest || (thisRequest = pendingRequest = loader().catch((err) => {
				err = err instanceof Error ? err : new Error(String(err));
				if (userOnError) return new Promise((resolve, reject) => {
					const userRetry = () => resolve(retry());
					const userFail = () => reject(err);
					userOnError(err, userRetry, userFail, retries + 1);
				});
				else throw err;
			}).then((comp) => {
				if (thisRequest !== pendingRequest && pendingRequest) return pendingRequest;
				if (comp && (comp.__esModule || comp[Symbol.toStringTag] === "Module")) comp = comp.default;
				resolvedComp = comp;
				return comp;
			}));
		};
		return defineComponent({
			name: "AsyncComponentWrapper",
			__asyncLoader: load,
			__asyncHydrate(el, instance, hydrate) {
				const wasConnected = el.isConnected;
				let patched = false;
				(instance.bu || (instance.bu = [])).push(() => patched = true);
				const performHydrate = () => {
					if (patched) return;
					if (!el.parentNode || wasConnected && !el.isConnected) return;
					hydrate();
				};
				const doHydrate = hydrateStrategy ? () => {
					const teardown = hydrateStrategy(performHydrate, (cb) => forEachElement(el, cb));
					if (teardown) (instance.bum || (instance.bum = [])).push(teardown);
				} : performHydrate;
				if (resolvedComp) doHydrate();
				else load().then(() => !instance.isUnmounted && doHydrate());
			},
			get __asyncResolved() {
				return resolvedComp;
			},
			setup() {
				const instance = currentInstance;
				markAsyncBoundary(instance);
				if (resolvedComp) return () => createInnerComp(resolvedComp, instance);
				const onError = (err) => {
					pendingRequest = null;
					handleError(err, instance, 13, !errorComponent);
				};
				if (suspensible && instance.suspense || isInSSRComponentSetup) return load().then((comp) => {
					return () => createInnerComp(comp, instance);
				}).catch((err) => {
					onError(err);
					return () => errorComponent ? createVNode(errorComponent, { error: err }) : null;
				});
				const loaded = ref(false);
				const error = ref();
				const delayed = ref(!!delay);
				let timeoutTimer;
				let delayTimer;
				onUnmounted(() => {
					if (timeoutTimer != null) clearTimeout(timeoutTimer);
					if (delayTimer != null) clearTimeout(delayTimer);
				});
				if (delay) delayTimer = setTimeout(() => {
					if (instance.isUnmounted) return;
					delayed.value = false;
				}, delay);
				if (timeout != null) timeoutTimer = setTimeout(() => {
					if (instance.isUnmounted) return;
					if (!loaded.value && !error.value) {
						const err = new Error(`Async component timed out after ${timeout}ms.`);
						onError(err);
						error.value = err;
					}
				}, timeout);
				load().then(() => {
					if (instance.isUnmounted) return;
					loaded.value = true;
					if (instance.parent && isKeepAlive(instance.parent.vnode)) instance.parent.update();
				}).catch((err) => {
					if (instance.isUnmounted) {
						pendingRequest = null;
						return;
					}
					onError(err);
					error.value = err;
				});
				return () => {
					if (loaded.value && resolvedComp) return createInnerComp(resolvedComp, instance);
					else if (error.value && errorComponent) return createVNode(errorComponent, { error: error.value });
					else if (loadingComponent && !delayed.value) return createInnerComp(loadingComponent, instance);
				};
			}
		});
	}
	function createInnerComp(comp, parent) {
		const { ref: ref2, props, children, ce } = parent.vnode;
		const vnode = createVNode(comp, props, children);
		vnode.ref = ref2;
		vnode.ce = ce;
		delete parent.vnode.ce;
		return vnode;
	}
	var isKeepAlive = (vnode) => vnode.type.__isKeepAlive;
	var KeepAlive = {
		name: `KeepAlive`,
		__isKeepAlive: true,
		props: {
			include: [
				String,
				RegExp,
				Array
			],
			exclude: [
				String,
				RegExp,
				Array
			],
			max: [String, Number]
		},
		setup(props, { slots }) {
			const instance = getCurrentInstance();
			const sharedContext = instance.ctx;
			if (!sharedContext.renderer) return () => {
				const children = slots.default && slots.default();
				return children && children.length === 1 ? children[0] : children;
			};
			const cache = new Map();
			const keys = new Set();
			let current = null;
			const parentSuspense = instance.suspense;
			const { renderer: { p: patch, m: move, um: _unmount, o: { createElement } } } = sharedContext;
			const storageContainer = createElement("div");
			sharedContext.activate = (vnode, container, anchor, namespace, optimized) => {
				const instance2 = vnode.component;
				move(vnode, container, anchor, 0, parentSuspense);
				patch(instance2.vnode, vnode, container, anchor, instance2, parentSuspense, namespace, vnode.slotScopeIds, optimized);
				queuePostRenderEffect(() => {
					instance2.isDeactivated = false;
					if (instance2.a) invokeArrayFns(instance2.a);
					const vnodeHook = vnode.props && vnode.props.onVnodeMounted;
					if (vnodeHook) invokeVNodeHook(vnodeHook, instance2.parent, vnode);
				}, parentSuspense);
			};
			sharedContext.deactivate = (vnode) => {
				const instance2 = vnode.component;
				invalidateMount(instance2.m);
				invalidateMount(instance2.a);
				move(vnode, storageContainer, null, 1, parentSuspense);
				queuePostRenderEffect(() => {
					if (instance2.da) invokeArrayFns(instance2.da);
					const vnodeHook = vnode.props && vnode.props.onVnodeUnmounted;
					if (vnodeHook) invokeVNodeHook(vnodeHook, instance2.parent, vnode);
					instance2.isDeactivated = true;
				}, parentSuspense);
			};
			function unmount(vnode) {
				resetShapeFlag(vnode);
				_unmount(vnode, instance, parentSuspense, true);
			}
			function pruneCache(filter) {
				cache.forEach((vnode, key) => {
					const name = getComponentName(isAsyncWrapper(vnode) ? vnode.type.__asyncResolved || {} : vnode.type);
					if (name && !filter(name)) pruneCacheEntry(key);
				});
			}
			function pruneCacheEntry(key) {
				const cached = cache.get(key);
				if (cached && (!current || !isSameVNodeType(cached, current))) unmount(cached);
				else if (current) {
					resetShapeFlag(current);
					if (cached) resetShapeFlag(cached);
				}
				cache.delete(key);
				keys.delete(key);
			}
			watch(() => [props.include, props.exclude], ([include, exclude]) => {
				include && pruneCache((name) => matches(include, name));
				exclude && pruneCache((name) => !matches(exclude, name));
			}, {
				flush: "post",
				deep: true
			});
			let pendingCacheKey = null;
			const cacheSubtree = () => {
				if (pendingCacheKey != null) {
					if (isSuspense(instance.subTree.type)) queuePostRenderEffect(() => {
						const vnode = getInnerChild(instance.subTree);
						if (vnode.component) cache.set(pendingCacheKey, vnode);
					}, instance.subTree.suspense);
					else cache.set(pendingCacheKey, getInnerChild(instance.subTree));
				}
			};
			onMounted(cacheSubtree);
			onUpdated(cacheSubtree);
			onBeforeUnmount(() => {
				cache.forEach((cached) => {
					const { subTree, suspense } = instance;
					const vnode = getInnerChild(subTree);
					if (cached.type === vnode.type && cached.key === vnode.key) {
						resetShapeFlag(vnode);
						const da = vnode.component.da;
						da && queuePostRenderEffect(da, suspense);
						return;
					}
					unmount(cached);
				});
			});
			return () => {
				pendingCacheKey = null;
				if (!slots.default) return current = null;
				const children = slots.default();
				const rawVNode = children[0];
				if (children.length > 1) {
					current = null;
					return children;
				} else if (!isVNode(rawVNode) || !(rawVNode.shapeFlag & 4) && !(rawVNode.shapeFlag & 128)) {
					current = null;
					return rawVNode;
				}
				let vnode = getInnerChild(rawVNode);
				if (vnode.type === Comment) {
					current = null;
					return vnode;
				}
				const comp = vnode.type;
				const name = getComponentName(isAsyncWrapper(vnode) ? vnode.type.__asyncResolved || {} : comp);
				const { include, exclude, max } = props;
				if (include && (!name || !matches(include, name)) || exclude && name && matches(exclude, name)) {
					vnode.shapeFlag &= -257;
					current = vnode;
					return rawVNode;
				}
				const key = vnode.key == null ? comp : vnode.key;
				const cachedVNode = cache.get(key);
				if (vnode.el) {
					vnode = cloneVNode(vnode);
					if (rawVNode.shapeFlag & 128) rawVNode.ssContent = vnode;
				}
				pendingCacheKey = key;
				if (cachedVNode) {
					vnode.el = cachedVNode.el;
					vnode.component = cachedVNode.component;
					if (vnode.transition) setTransitionHooks(vnode, vnode.transition);
					vnode.shapeFlag |= 512;
					keys.delete(key);
					keys.add(key);
				} else {
					keys.add(key);
					if (max && keys.size > parseInt(max, 10)) pruneCacheEntry(keys.values().next().value);
				}
				vnode.shapeFlag |= 256;
				current = vnode;
				return isSuspense(rawVNode.type) ? rawVNode : vnode;
			};
		}
	};
	function matches(pattern, name) {
		if (isArray(pattern)) return pattern.some((p) => matches(p, name));
		else if (isString(pattern)) return pattern.split(",").includes(name);
		else if (isRegExp(pattern)) {
			pattern.lastIndex = 0;
			return pattern.test(name);
		}
		return false;
	}
	function onActivated(hook, target) {
		registerKeepAliveHook(hook, "a", target);
	}
	function onDeactivated(hook, target) {
		registerKeepAliveHook(hook, "da", target);
	}
	function registerKeepAliveHook(hook, type, target = currentInstance) {
		const wrappedHook = hook.__wdc || (hook.__wdc = () => {
			let current = target;
			while (current) {
				if (current.isDeactivated) return;
				current = current.parent;
			}
			return hook();
		});
		injectHook(type, wrappedHook, target);
		if (target) {
			let current = target.parent;
			while (current && current.parent) {
				if (isKeepAlive(current.parent.vnode)) injectToKeepAliveRoot(wrappedHook, type, target, current);
				current = current.parent;
			}
		}
	}
	function injectToKeepAliveRoot(hook, type, target, keepAliveRoot) {
		const injected = injectHook(type, hook, keepAliveRoot, true);
		onUnmounted(() => {
			remove(keepAliveRoot[type], injected);
		}, target);
	}
	function resetShapeFlag(vnode) {
		vnode.shapeFlag &= -257;
		vnode.shapeFlag &= -513;
	}
	function getInnerChild(vnode) {
		return vnode.shapeFlag & 128 ? vnode.ssContent : vnode;
	}
	function injectHook(type, hook, target = currentInstance, prepend = false) {
		if (target) {
			const hooks = target[type] || (target[type] = []);
			const wrappedHook = hook.__weh || (hook.__weh = (...args) => {
				pauseTracking();
				const reset = setCurrentInstance(target);
				const res = callWithAsyncErrorHandling(hook, target, type, args);
				reset();
				resetTracking();
				return res;
			});
			if (prepend) hooks.unshift(wrappedHook);
			else hooks.push(wrappedHook);
			return wrappedHook;
		}
	}
	var createHook = (lifecycle) => (hook, target = currentInstance) => {
		if (!isInSSRComponentSetup || lifecycle === "sp") injectHook(lifecycle, (...args) => hook(...args), target);
	};
	var onBeforeMount = createHook("bm");
	var onMounted = createHook("m");
	var onBeforeUpdate = createHook("bu");
	var onUpdated = createHook("u");
	var onBeforeUnmount = createHook("bum");
	var onUnmounted = createHook("um");
	var onServerPrefetch = createHook("sp");
	var onRenderTriggered = createHook("rtg");
	var onRenderTracked = createHook("rtc");
	function onErrorCaptured(hook, target = currentInstance) {
		injectHook("ec", hook, target);
	}
	var COMPONENTS = "components";
	var DIRECTIVES = "directives";
	function resolveComponent(name, maybeSelfReference) {
		return resolveAsset(COMPONENTS, name, true, maybeSelfReference) || name;
	}
	var NULL_DYNAMIC_COMPONENT = Symbol.for("v-ndc");
	function resolveDynamicComponent(component) {
		if (isString(component)) return resolveAsset(COMPONENTS, component, false) || component;
		else return component || NULL_DYNAMIC_COMPONENT;
	}
	function resolveDirective(name) {
		return resolveAsset(DIRECTIVES, name);
	}
	function resolveAsset(type, name, warnMissing = true, maybeSelfReference = false) {
		const instance = currentRenderingInstance || currentInstance;
		if (instance) {
			const Component = instance.type;
			if (type === COMPONENTS) {
				const selfName = getComponentName(Component, false);
				if (selfName && (selfName === name || selfName === camelize$1(name) || selfName === capitalize(camelize$1(name)))) return Component;
			}
			const res = resolve(instance[type] || Component[type], name) || resolve(instance.appContext[type], name);
			if (!res && maybeSelfReference) return Component;
			return res;
		}
	}
	function resolve(registry, name) {
		return registry && (registry[name] || registry[camelize$1(name)] || registry[capitalize(camelize$1(name))]);
	}
	function renderList(source, renderItem, cache, index) {
		let ret;
		const cached = cache && cache[index];
		const sourceIsArray = isArray(source);
		if (sourceIsArray || isString(source)) {
			const sourceIsReactiveArray = sourceIsArray && isReactive(source);
			let needsWrap = false;
			let isReadonlySource = false;
			if (sourceIsReactiveArray) {
				needsWrap = !isShallow(source);
				isReadonlySource = isReadonly(source);
				source = shallowReadArray(source);
			}
			ret = new Array(source.length);
			for (let i = 0, l = source.length; i < l; i++) ret[i] = renderItem(needsWrap ? isReadonlySource ? toReadonly(toReactive(source[i])) : toReactive(source[i]) : source[i], i, void 0, cached && cached[i]);
		} else if (typeof source === "number") {
			if (!Number.isInteger(source) || source < 0) ret = [];
			else {
				ret = new Array(source);
				for (let i = 0; i < source; i++) ret[i] = renderItem(i + 1, i, void 0, cached && cached[i]);
			}
		} else if (isObject$1(source)) {
			if (source[Symbol.iterator]) ret = Array.from(source, (item, i) => renderItem(item, i, void 0, cached && cached[i]));
			else {
				const keys = Object.keys(source);
				ret = new Array(keys.length);
				for (let i = 0, l = keys.length; i < l; i++) {
					const key = keys[i];
					ret[i] = renderItem(source[key], key, i, cached && cached[i]);
				}
			}
		} else ret = [];
		if (cache) cache[index] = ret;
		return ret;
	}
	function createSlots(slots, dynamicSlots) {
		for (let i = 0; i < dynamicSlots.length; i++) {
			const slot = dynamicSlots[i];
			if (isArray(slot)) for (let j = 0; j < slot.length; j++) slots[slot[j].name] = slot[j].fn;
			else if (slot) slots[slot.name] = slot.key ? (...args) => {
				const res = slot.fn(...args);
				if (res) res.key = slot.key;
				return res;
			} : slot.fn;
		}
		return slots;
	}
	function renderSlot(slots, name, props, fallback, noSlotted, branchKey) {
		if (props == null) props = {};
		if (currentRenderingInstance.ce || currentRenderingInstance.parent && isAsyncWrapper(currentRenderingInstance.parent) && currentRenderingInstance.parent.ce) {
			const slotProps = branchKey != null && props.key == null ? extend({}, props, { key: branchKey }) : props;
			const hasProps = Object.keys(slotProps).length > 0;
			if (name !== "default") slotProps.name = name;
			return openBlock(), createBlock(Fragment, null, [createVNode("slot", slotProps, fallback && fallback())], hasProps ? -2 : 64);
		}
		let slot = slots[name];
		if (slot && slot._c) slot._d = false;
		const prevStackSize = blockStack.length;
		openBlock();
		let rendered;
		try {
			const validSlotContent = slot && ensureValidVNode(slot(props));
			const slotKey = props.key || branchKey || validSlotContent && validSlotContent.key;
			rendered = createBlock(Fragment, { key: (slotKey && !isSymbol(slotKey) ? slotKey : `_${name}`) + (!validSlotContent && fallback ? "_fb" : "") }, validSlotContent || (fallback ? fallback() : []), validSlotContent && slots._ === 1 ? 64 : -2);
		} catch (err) {
			for (let i = blockStack.length; i > prevStackSize; i--) closeBlock();
			throw err;
		} finally {
			if (slot && slot._c) slot._d = true;
		}
		if (!noSlotted && rendered.scopeId) rendered.slotScopeIds = [rendered.scopeId + "-s"];
		return rendered;
	}
	function ensureValidVNode(vnodes) {
		return vnodes.some((child) => {
			if (!isVNode(child)) return true;
			if (child.type === Comment) return false;
			if (child.type === Fragment && !ensureValidVNode(child.children)) return false;
			return true;
		}) ? vnodes : null;
	}
	function toHandlers(obj, preserveCaseIfNecessary) {
		const ret = {};
		for (const key in obj) ret[preserveCaseIfNecessary && /[A-Z]/.test(key) ? `on:${key}` : toHandlerKey(key)] = obj[key];
		return ret;
	}
	var getPublicInstance = (i) => {
		if (!i) return null;
		if (isStatefulComponent(i)) return getComponentPublicInstance(i);
		return getPublicInstance(i.parent);
	};
	var publicPropertiesMap = extend(Object.create(null), {
		$: (i) => i,
		$el: (i) => i.vnode.el,
		$data: (i) => i.data,
		$props: (i) => i.props,
		$attrs: (i) => i.attrs,
		$slots: (i) => i.slots,
		$refs: (i) => i.refs,
		$parent: (i) => getPublicInstance(i.parent),
		$root: (i) => getPublicInstance(i.root),
		$host: (i) => i.ce,
		$emit: (i) => i.emit,
		$options: (i) => resolveMergedOptions(i),
		$forceUpdate: (i) => i.f || (i.f = () => {
			queueJob(i.update);
		}),
		$nextTick: (i) => i.n || (i.n = nextTick.bind(i.proxy)),
		$watch: (i) => instanceWatch.bind(i)
	});
	var hasSetupBinding = (state, key) => state !== EMPTY_OBJ && !state.__isScriptSetup && hasOwn(state, key);
	var PublicInstanceProxyHandlers = {
		get({ _: instance }, key) {
			if (key === "__v_skip") return true;
			const { ctx, setupState, data, props, accessCache, type, appContext } = instance;
			if (key[0] !== "$") {
				const n = accessCache[key];
				if (n !== void 0) switch (n) {
					case 1: return setupState[key];
					case 2: return data[key];
					case 4: return ctx[key];
					case 3: return props[key];
				}
				else if (hasSetupBinding(setupState, key)) {
					accessCache[key] = 1;
					return setupState[key];
				} else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
					accessCache[key] = 2;
					return data[key];
				} else if (hasOwn(props, key)) {
					accessCache[key] = 3;
					return props[key];
				} else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
					accessCache[key] = 4;
					return ctx[key];
				} else if (shouldCacheAccess) accessCache[key] = 0;
			}
			const publicGetter = publicPropertiesMap[key];
			let cssModule, globalProperties;
			if (publicGetter) {
				if (key === "$attrs") track(instance.attrs, "get", "");
				return publicGetter(instance);
			} else if ((cssModule = type.__cssModules) && (cssModule = cssModule[key])) return cssModule;
			else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
				accessCache[key] = 4;
				return ctx[key];
			} else if (globalProperties = appContext.config.globalProperties, hasOwn(globalProperties, key)) return globalProperties[key];
		},
		set({ _: instance }, key, value) {
			const { data, setupState, ctx } = instance;
			if (hasSetupBinding(setupState, key)) {
				setupState[key] = value;
				return true;
			} else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
				data[key] = value;
				return true;
			} else if (hasOwn(instance.props, key)) return false;
			if (key[0] === "$" && key.slice(1) in instance) return false;
			else ctx[key] = value;
			return true;
		},
		has({ _: { data, setupState, accessCache, ctx, appContext, props, type } }, key) {
			let cssModules;
			return !!(accessCache[key] || data !== EMPTY_OBJ && key[0] !== "$" && hasOwn(data, key) || hasSetupBinding(setupState, key) || hasOwn(props, key) || hasOwn(ctx, key) || hasOwn(publicPropertiesMap, key) || hasOwn(appContext.config.globalProperties, key) || (cssModules = type.__cssModules) && cssModules[key]);
		},
		defineProperty(target, key, descriptor) {
			if (descriptor.get != null) target._.accessCache[key] = 0;
			else if (hasOwn(descriptor, "value")) this.set(target, key, descriptor.value, null);
			return Reflect.defineProperty(target, key, descriptor);
		}
	};
	var RuntimeCompiledPublicInstanceProxyHandlers = extend({}, PublicInstanceProxyHandlers, {
		get(target, key) {
			if (key === Symbol.unscopables) return;
			return PublicInstanceProxyHandlers.get(target, key, target);
		},
		has(_, key) {
			return key[0] !== "_" && !isGloballyAllowed(key);
		}
	});
	function defineProps() {
		return null;
	}
	function defineEmits() {
		return null;
	}
	function defineExpose(exposed) {}
	function defineOptions(options) {}
	function defineSlots() {
		return null;
	}
	function defineModel() {}
	function withDefaults(props, defaults) {
		return null;
	}
	function useSlots() {
		return getContext("useSlots").slots;
	}
	function useAttrs() {
		return getContext("useAttrs").attrs;
	}
	function getContext(calledFunctionName) {
		const i = getCurrentInstance();
		return i.setupContext || (i.setupContext = createSetupContext(i));
	}
	function normalizePropsOrEmits(props) {
		return isArray(props) ? props.reduce((normalized, p) => (normalized[p] = null, normalized), {}) : props;
	}
	function mergeDefaults(raw, defaults) {
		const props = normalizePropsOrEmits(raw);
		for (const key in defaults) {
			if (key.startsWith("__skip")) continue;
			let opt = props[key];
			if (opt) {
				if (isArray(opt) || isFunction(opt)) opt = props[key] = {
					type: opt,
					default: defaults[key]
				};
				else opt.default = defaults[key];
			} else if (opt === null) opt = props[key] = { default: defaults[key] };
			if (opt && defaults[`__skip_${key}`]) opt.skipFactory = true;
		}
		return props;
	}
	function mergeModels(a, b) {
		if (!a || !b) return a || b;
		if (isArray(a) && isArray(b)) return a.concat(b);
		return extend({}, normalizePropsOrEmits(a), normalizePropsOrEmits(b));
	}
	function createPropsRestProxy(props, excludedKeys) {
		const ret = {};
		for (const key in props) if (!excludedKeys.includes(key)) Object.defineProperty(ret, key, {
			enumerable: true,
			get: () => props[key]
		});
		return ret;
	}
	function withAsyncContext(getAwaitable) {
		const ctx = getCurrentInstance();
		const inSSRSetup = isInSSRComponentSetup;
		let awaitable = getAwaitable();
		unsetCurrentInstance();
		if (inSSRSetup) setInSSRSetupState(false);
		const restore = () => {
			setCurrentInstance(ctx);
			if (inSSRSetup) setInSSRSetupState(true);
		};
		const cleanup = () => {
			if (getCurrentInstance() !== ctx) ctx.scope.off();
			unsetCurrentInstance();
			if (inSSRSetup) setInSSRSetupState(false);
		};
		if (isPromise(awaitable)) awaitable = awaitable.catch((e) => {
			restore();
			Promise.resolve().then(() => Promise.resolve().then(cleanup));
			throw e;
		});
		return [awaitable, () => {
			restore();
			Promise.resolve().then(cleanup);
		}];
	}
	var shouldCacheAccess = true;
	function applyOptions(instance) {
		const options = resolveMergedOptions(instance);
		const publicThis = instance.proxy;
		const ctx = instance.ctx;
		shouldCacheAccess = false;
		if (options.beforeCreate) callHook$1(options.beforeCreate, instance, "bc");
		const { data: dataOptions, computed: computedOptions, methods, watch: watchOptions, provide: provideOptions, inject: injectOptions, created, beforeMount, mounted, beforeUpdate, updated, activated, deactivated, beforeDestroy, beforeUnmount, destroyed, unmounted, render, renderTracked, renderTriggered, errorCaptured, serverPrefetch, expose, inheritAttrs, components, directives, filters } = options;
		const checkDuplicateProperties = null;
		if (injectOptions) resolveInjections(injectOptions, ctx, checkDuplicateProperties);
		if (methods) for (const key in methods) {
			const methodHandler = methods[key];
			if (isFunction(methodHandler)) ctx[key] = methodHandler.bind(publicThis);
		}
		if (dataOptions) {
			const data = dataOptions.call(publicThis, publicThis);
			if (!isObject$1(data)) {} else instance.data = reactive(data);
		}
		shouldCacheAccess = true;
		if (computedOptions) for (const key in computedOptions) {
			const opt = computedOptions[key];
			const c = computed({
				get: isFunction(opt) ? opt.bind(publicThis, publicThis) : isFunction(opt.get) ? opt.get.bind(publicThis, publicThis) : NOOP,
				set: !isFunction(opt) && isFunction(opt.set) ? opt.set.bind(publicThis) : NOOP
			});
			Object.defineProperty(ctx, key, {
				enumerable: true,
				configurable: true,
				get: () => c.value,
				set: (v) => c.value = v
			});
		}
		if (watchOptions) for (const key in watchOptions) createWatcher(watchOptions[key], ctx, publicThis, key);
		if (provideOptions) {
			const provides = isFunction(provideOptions) ? provideOptions.call(publicThis) : provideOptions;
			Reflect.ownKeys(provides).forEach((key) => {
				provide(key, provides[key]);
			});
		}
		if (created) callHook$1(created, instance, "c");
		function registerLifecycleHook(register, hook) {
			if (isArray(hook)) hook.forEach((_hook) => register(_hook.bind(publicThis)));
			else if (hook) register(hook.bind(publicThis));
		}
		registerLifecycleHook(onBeforeMount, beforeMount);
		registerLifecycleHook(onMounted, mounted);
		registerLifecycleHook(onBeforeUpdate, beforeUpdate);
		registerLifecycleHook(onUpdated, updated);
		registerLifecycleHook(onActivated, activated);
		registerLifecycleHook(onDeactivated, deactivated);
		registerLifecycleHook(onErrorCaptured, errorCaptured);
		registerLifecycleHook(onRenderTracked, renderTracked);
		registerLifecycleHook(onRenderTriggered, renderTriggered);
		registerLifecycleHook(onBeforeUnmount, beforeUnmount);
		registerLifecycleHook(onUnmounted, unmounted);
		registerLifecycleHook(onServerPrefetch, serverPrefetch);
		if (isArray(expose)) {
			if (expose.length) {
				const exposed = instance.exposed || (instance.exposed = {});
				expose.forEach((key) => {
					Object.defineProperty(exposed, key, {
						get: () => publicThis[key],
						set: (val) => publicThis[key] = val,
						enumerable: true
					});
				});
			} else if (!instance.exposed) instance.exposed = {};
		}
		if (render && instance.render === NOOP) instance.render = render;
		if (inheritAttrs != null) instance.inheritAttrs = inheritAttrs;
		if (components) instance.components = components;
		if (directives) instance.directives = directives;
		if (serverPrefetch) markAsyncBoundary(instance);
	}
	function resolveInjections(injectOptions, ctx, checkDuplicateProperties = NOOP) {
		if (isArray(injectOptions)) injectOptions = normalizeInject(injectOptions);
		for (const key in injectOptions) {
			const opt = injectOptions[key];
			let injected;
			if (isObject$1(opt)) {
				if ("default" in opt) injected = inject(opt.from || key, opt.default, true);
				else injected = inject(opt.from || key);
			} else injected = inject(opt);
			if (isRef(injected)) Object.defineProperty(ctx, key, {
				enumerable: true,
				configurable: true,
				get: () => injected.value,
				set: (v) => injected.value = v
			});
			else ctx[key] = injected;
		}
	}
	function callHook$1(hook, instance, type) {
		callWithAsyncErrorHandling(isArray(hook) ? hook.map((h) => h.bind(instance.proxy)) : hook.bind(instance.proxy), instance, type);
	}
	function createWatcher(raw, ctx, publicThis, key) {
		let getter = key.includes(".") ? createPathGetter(publicThis, key) : () => publicThis[key];
		if (isString(raw)) {
			const handler = ctx[raw];
			if (isFunction(handler)) watch(getter, handler);
		} else if (isFunction(raw)) watch(getter, raw.bind(publicThis));
		else if (isObject$1(raw)) {
			if (isArray(raw)) raw.forEach((r) => createWatcher(r, ctx, publicThis, key));
			else {
				const handler = isFunction(raw.handler) ? raw.handler.bind(publicThis) : ctx[raw.handler];
				if (isFunction(handler)) watch(getter, handler, raw);
			}
		}
	}
	function resolveMergedOptions(instance) {
		const base = instance.type;
		const { mixins, extends: extendsOptions } = base;
		const { mixins: globalMixins, optionsCache: cache, config: { optionMergeStrategies } } = instance.appContext;
		const cached = cache.get(base);
		let resolved;
		if (cached) resolved = cached;
		else if (!globalMixins.length && !mixins && !extendsOptions) resolved = base;
		else {
			resolved = {};
			if (globalMixins.length) globalMixins.forEach((m) => mergeOptions(resolved, m, optionMergeStrategies, true));
			mergeOptions(resolved, base, optionMergeStrategies);
		}
		if (isObject$1(base)) cache.set(base, resolved);
		return resolved;
	}
	function mergeOptions(to, from, strats, asMixin = false) {
		const { mixins, extends: extendsOptions } = from;
		if (extendsOptions) mergeOptions(to, extendsOptions, strats, true);
		if (mixins) mixins.forEach((m) => mergeOptions(to, m, strats, true));
		for (const key in from) if (asMixin && key === "expose") {} else {
			const strat = internalOptionMergeStrats[key] || strats && strats[key];
			to[key] = strat ? strat(to[key], from[key]) : from[key];
		}
		return to;
	}
	var internalOptionMergeStrats = {
		data: mergeDataFn,
		props: mergeEmitsOrPropsOptions,
		emits: mergeEmitsOrPropsOptions,
		methods: mergeObjectOptions,
		computed: mergeObjectOptions,
		beforeCreate: mergeAsArray,
		created: mergeAsArray,
		beforeMount: mergeAsArray,
		mounted: mergeAsArray,
		beforeUpdate: mergeAsArray,
		updated: mergeAsArray,
		beforeDestroy: mergeAsArray,
		beforeUnmount: mergeAsArray,
		destroyed: mergeAsArray,
		unmounted: mergeAsArray,
		activated: mergeAsArray,
		deactivated: mergeAsArray,
		errorCaptured: mergeAsArray,
		serverPrefetch: mergeAsArray,
		components: mergeObjectOptions,
		directives: mergeObjectOptions,
		watch: mergeWatchOptions,
		provide: mergeDataFn,
		inject: mergeInject
	};
	function mergeDataFn(to, from) {
		if (!from) return to;
		if (!to) return from;
		return function mergedDataFn() {
			return extend(isFunction(to) ? to.call(this, this) : to, isFunction(from) ? from.call(this, this) : from);
		};
	}
	function mergeInject(to, from) {
		return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
	}
	function normalizeInject(raw) {
		if (isArray(raw)) {
			const res = {};
			for (let i = 0; i < raw.length; i++) res[raw[i]] = raw[i];
			return res;
		}
		return raw;
	}
	function mergeAsArray(to, from) {
		return to ? [...new Set([].concat(to, from))] : from;
	}
	function mergeObjectOptions(to, from) {
		return to ? extend(Object.create(null), to, from) : from;
	}
	function mergeEmitsOrPropsOptions(to, from) {
		if (to) {
			if (isArray(to) && isArray(from)) return [...new Set([...to, ...from])];
			return extend(Object.create(null), normalizePropsOrEmits(to), normalizePropsOrEmits(from != null ? from : {}));
		} else return from;
	}
	function mergeWatchOptions(to, from) {
		if (!to) return from;
		if (!from) return to;
		const merged = extend(Object.create(null), to);
		for (const key in from) merged[key] = mergeAsArray(to[key], from[key]);
		return merged;
	}
	function createAppContext() {
		return {
			app: null,
			config: {
				isNativeTag: NO,
				performance: false,
				globalProperties: {},
				optionMergeStrategies: {},
				errorHandler: void 0,
				warnHandler: void 0,
				compilerOptions: {}
			},
			mixins: [],
			components: {},
			directives: {},
			provides: Object.create(null),
			optionsCache: new WeakMap(),
			propsCache: new WeakMap(),
			emitsCache: new WeakMap()
		};
	}
	var uid$1 = 0;
	function createAppAPI(render, hydrate) {
		return function createApp(rootComponent, rootProps = null) {
			if (!isFunction(rootComponent)) rootComponent = extend({}, rootComponent);
			if (rootProps != null && !isObject$1(rootProps)) rootProps = null;
			const context = createAppContext();
			const installedPlugins = new WeakSet();
			const pluginCleanupFns = [];
			let isMounted = false;
			const app = context.app = {
				_uid: uid$1++,
				_component: rootComponent,
				_props: rootProps,
				_container: null,
				_context: context,
				_instance: null,
				version,
				get config() {
					return context.config;
				},
				set config(v) {},
				use(plugin, ...options) {
					if (installedPlugins.has(plugin)) {} else if (plugin && isFunction(plugin.install)) {
						installedPlugins.add(plugin);
						plugin.install(app, ...options);
					} else if (isFunction(plugin)) {
						installedPlugins.add(plugin);
						plugin(app, ...options);
					}
					return app;
				},
				mixin(mixin) {
					if (!context.mixins.includes(mixin)) context.mixins.push(mixin);
					return app;
				},
				component(name, component) {
					if (!component) return context.components[name];
					context.components[name] = component;
					return app;
				},
				directive(name, directive) {
					if (!directive) return context.directives[name];
					context.directives[name] = directive;
					return app;
				},
				mount(rootContainer, isHydrate, namespace) {
					if (!isMounted) {
						const vnode = app._ceVNode || createVNode(rootComponent, rootProps);
						vnode.appContext = context;
						if (namespace === true) namespace = "svg";
						else if (namespace === false) namespace = void 0;
						if (isHydrate && hydrate) hydrate(vnode, rootContainer);
						else render(vnode, rootContainer, namespace);
						isMounted = true;
						app._container = rootContainer;
						rootContainer.__vue_app__ = app;
						return getComponentPublicInstance(vnode.component);
					}
				},
				onUnmount(cleanupFn) {
					pluginCleanupFns.push(cleanupFn);
				},
				unmount() {
					if (isMounted) {
						callWithAsyncErrorHandling(pluginCleanupFns, app._instance, 16);
						render(null, app._container);
						delete app._container.__vue_app__;
					}
				},
				provide(key, value) {
					context.provides[key] = value;
					return app;
				},
				runWithContext(fn) {
					const lastApp = currentApp;
					currentApp = app;
					try {
						return fn();
					} finally {
						currentApp = lastApp;
					}
				}
			};
			return app;
		};
	}
	var currentApp = null;
	function useModel(props, name, options = EMPTY_OBJ) {
		const i = getCurrentInstance();
		const camelizedName = camelize$1(name);
		const hyphenatedName = hyphenate$1(name);
		const modifiers = getModelModifiers(props, camelizedName);
		const res = customRef((track, trigger) => {
			let localValue;
			let prevSetValue = EMPTY_OBJ;
			let prevEmittedValue;
			watchSyncEffect(() => {
				const propValue = props[camelizedName];
				if (hasChanged(localValue, propValue)) {
					localValue = propValue;
					trigger();
				}
			});
			return {
				get() {
					track();
					return options.get ? options.get(localValue) : localValue;
				},
				set(value) {
					const emittedValue = options.set ? options.set(value) : value;
					if (!hasChanged(emittedValue, localValue) && !(prevSetValue !== EMPTY_OBJ && hasChanged(value, prevSetValue))) return;
					const rawProps = i.vnode.props;
					const hasVModel = !!(rawProps && (name in rawProps || camelizedName in rawProps || hyphenatedName in rawProps) && (`onUpdate:${name}` in rawProps || `onUpdate:${camelizedName}` in rawProps || `onUpdate:${hyphenatedName}` in rawProps));
					if (!hasVModel) {
						localValue = value;
						trigger();
					}
					i.emit(`update:${name}`, emittedValue);
					if (hasChanged(value, prevSetValue) && (hasChanged(value, emittedValue) && !hasChanged(emittedValue, prevEmittedValue) || hasVModel && prevSetValue !== EMPTY_OBJ && !hasChanged(emittedValue, localValue))) trigger();
					prevSetValue = value;
					prevEmittedValue = emittedValue;
				}
			};
		});
		res[Symbol.iterator] = () => {
			let i2 = 0;
			return { next() {
				if (i2 < 2) return {
					value: i2++ ? modifiers || EMPTY_OBJ : res,
					done: false
				};
				else return { done: true };
			} };
		};
		return res;
	}
	var getModelModifiers = (props, modelName) => {
		return modelName === "modelValue" || modelName === "model-value" ? props.modelModifiers : props[`${modelName}Modifiers`] || props[`${camelize$1(modelName)}Modifiers`] || props[`${hyphenate$1(modelName)}Modifiers`];
	};
	function emit(instance, event, ...rawArgs) {
		if (instance.isUnmounted) return;
		const props = instance.vnode.props || EMPTY_OBJ;
		let args = rawArgs;
		const isModelListener = event.startsWith("update:");
		const modifiers = isModelListener && getModelModifiers(props, event.slice(7));
		if (modifiers) {
			if (modifiers.trim) args = rawArgs.map((a) => isString(a) ? a.trim() : a);
			if (modifiers.number) args = args.map(looseToNumber);
		}
		let handlerName;
		let handler = props[handlerName = toHandlerKey(event)] || props[handlerName = toHandlerKey(camelize$1(event))];
		if (!handler && isModelListener) handler = props[handlerName = toHandlerKey(hyphenate$1(event))];
		if (handler) callWithAsyncErrorHandling(handler, instance, 6, args);
		const onceHandler = props[handlerName + `Once`];
		if (onceHandler) {
			if (!instance.emitted) instance.emitted = {};
			else if (instance.emitted[handlerName]) return;
			instance.emitted[handlerName] = true;
			callWithAsyncErrorHandling(onceHandler, instance, 6, args);
		}
	}
	var mixinEmitsCache = new WeakMap();
	function normalizeEmitsOptions(comp, appContext, asMixin = false) {
		const cache = asMixin ? mixinEmitsCache : appContext.emitsCache;
		const cached = cache.get(comp);
		if (cached !== void 0) return cached;
		const raw = comp.emits;
		let normalized = {};
		let hasExtends = false;
		if (!isFunction(comp)) {
			const extendEmits = (raw2) => {
				const normalizedFromExtend = normalizeEmitsOptions(raw2, appContext, true);
				if (normalizedFromExtend) {
					hasExtends = true;
					extend(normalized, normalizedFromExtend);
				}
			};
			if (!asMixin && appContext.mixins.length) appContext.mixins.forEach(extendEmits);
			if (comp.extends) extendEmits(comp.extends);
			if (comp.mixins) comp.mixins.forEach(extendEmits);
		}
		if (!raw && !hasExtends) {
			if (isObject$1(comp)) cache.set(comp, null);
			return null;
		}
		if (isArray(raw)) raw.forEach((key) => normalized[key] = null);
		else extend(normalized, raw);
		if (isObject$1(comp)) cache.set(comp, normalized);
		return normalized;
	}
	function isEmitListener(options, key) {
		if (!options || !isOn(key)) return false;
		key = key.slice(2);
		key = key === "Once" ? key : key.replace(/Once$/, "");
		return hasOwn(options, key[0].toLowerCase() + key.slice(1)) || hasOwn(options, hyphenate$1(key)) || hasOwn(options, key);
	}
	function renderComponentRoot(instance) {
		const { type: Component, vnode, proxy, withProxy, propsOptions: [propsOptions], slots, attrs, emit, render, renderCache, props, data, setupState, ctx, inheritAttrs } = instance;
		const prev = setCurrentRenderingInstance(instance);
		let result;
		let fallthroughAttrs;
		try {
			if (vnode.shapeFlag & 4) {
				const proxyToUse = withProxy || proxy;
				const thisProxy = proxyToUse;
				result = normalizeVNode(render.call(thisProxy, proxyToUse, renderCache, props, setupState, data, ctx));
				fallthroughAttrs = attrs;
			} else {
				const render2 = Component;
				result = normalizeVNode(render2.length > 1 ? render2(props, {
					attrs,
					slots,
					emit
				}) : render2(props, null));
				fallthroughAttrs = Component.props ? attrs : getFunctionalFallthrough(attrs);
			}
		} catch (err) {
			blockStack.length = 0;
			handleError(err, instance, 1);
			result = createVNode(Comment);
		}
		let root = result;
		if (fallthroughAttrs && inheritAttrs !== false) {
			const keys = Object.keys(fallthroughAttrs);
			const { shapeFlag } = root;
			if (keys.length) {
				if (shapeFlag & 7) {
					if (propsOptions && keys.some(isModelListener)) fallthroughAttrs = filterModelListeners(fallthroughAttrs, propsOptions);
					root = cloneVNode(root, fallthroughAttrs, false, true);
				}
			}
		}
		if (vnode.dirs) {
			root = cloneVNode(root, null, false, true);
			root.dirs = root.dirs ? root.dirs.concat(vnode.dirs) : vnode.dirs;
		}
		if (vnode.transition) setTransitionHooks(isTeleport(root.type) ? getInnerChild$1(root) || root : root, vnode.transition);
		result = root;
		setCurrentRenderingInstance(prev);
		return result;
	}
	function filterSingleRoot(children, recurse = true) {
		let singleRoot;
		for (let i = 0; i < children.length; i++) {
			const child = children[i];
			if (isVNode(child)) {
				if (child.type !== Comment || child.children === "v-if") {
					if (singleRoot) return;
					else singleRoot = child;
				}
			} else return;
		}
		return singleRoot;
	}
	var getFunctionalFallthrough = (attrs) => {
		let res;
		for (const key in attrs) if (key === "class" || key === "style" || isOn(key)) (res || (res = {}))[key] = attrs[key];
		return res;
	};
	var filterModelListeners = (attrs, props) => {
		const res = {};
		for (const key in attrs) if (!isModelListener(key) || !(key.slice(9) in props)) res[key] = attrs[key];
		return res;
	};
	function shouldUpdateComponent(prevVNode, nextVNode, optimized) {
		const { props: prevProps, children: prevChildren, component } = prevVNode;
		const { props: nextProps, children: nextChildren, patchFlag } = nextVNode;
		const emits = component.emitsOptions;
		if (nextVNode.dirs || nextVNode.transition) return true;
		if (optimized && patchFlag >= 0) {
			if (patchFlag & 1024) return true;
			if (patchFlag & 16) {
				if (!prevProps) return !!nextProps;
				return hasPropsChanged(prevProps, nextProps, emits);
			} else if (patchFlag & 8) {
				const dynamicProps = nextVNode.dynamicProps;
				for (let i = 0; i < dynamicProps.length; i++) {
					const key = dynamicProps[i];
					if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emits, key)) return true;
				}
			}
		} else {
			if (prevChildren || nextChildren) {
				if (!nextChildren || !nextChildren.$stable) return true;
			}
			if (prevProps === nextProps) return false;
			if (!prevProps) return !!nextProps;
			if (!nextProps) return true;
			return hasPropsChanged(prevProps, nextProps, emits);
		}
		return false;
	}
	function hasPropsChanged(prevProps, nextProps, emitsOptions) {
		const nextKeys = Object.keys(nextProps);
		if (nextKeys.length !== Object.keys(prevProps).length) return true;
		for (let i = 0; i < nextKeys.length; i++) {
			const key = nextKeys[i];
			if (!hasOwn(prevProps, key) || hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emitsOptions, key)) return true;
		}
		return false;
	}
	function hasPropValueChanged(nextProps, prevProps, key) {
		const nextProp = nextProps[key];
		const prevProp = prevProps[key];
		if (key === "style" && isObject$1(nextProp) && isObject$1(prevProp)) return !looseEqual(nextProp, prevProp);
		return nextProp !== prevProp;
	}
	function updateHOCHostEl({ vnode, parent, suspense }, el) {
		while (parent) {
			const root = parent.subTree;
			if (root.suspense && root.suspense.activeBranch === vnode) {
				root.suspense.vnode.el = root.el = el;
				vnode = root;
			}
			if (root === vnode) {
				(vnode = parent.vnode).el = el;
				parent = parent.parent;
			} else break;
		}
		if (suspense && suspense.activeBranch === vnode) suspense.vnode.el = el;
	}
	var internalObjectProto = {};
	var createInternalObject = () => Object.create(internalObjectProto);
	var isInternalObject = (obj) => Object.getPrototypeOf(obj) === internalObjectProto;
	function initProps(instance, rawProps, isStateful, isSSR = false) {
		const props = {};
		const attrs = createInternalObject();
		instance.propsDefaults = Object.create(null);
		setFullProps(instance, rawProps, props, attrs);
		for (const key in instance.propsOptions[0]) if (!(key in props)) props[key] = void 0;
		if (isStateful) instance.props = isSSR ? props : shallowReactive(props);
		else if (!instance.type.props) instance.props = attrs;
		else instance.props = props;
		instance.attrs = attrs;
	}
	function updateProps(instance, rawProps, rawPrevProps, optimized) {
		const { props, attrs, vnode: { patchFlag } } = instance;
		const rawCurrentProps = toRaw(props);
		const [options] = instance.propsOptions;
		let hasAttrsChanged = false;
		if ((optimized || patchFlag > 0) && !(patchFlag & 16)) {
			if (patchFlag & 8) {
				const propsToUpdate = instance.vnode.dynamicProps;
				for (let i = 0; i < propsToUpdate.length; i++) {
					let key = propsToUpdate[i];
					if (isEmitListener(instance.emitsOptions, key)) continue;
					const value = rawProps[key];
					if (options) {
						if (hasOwn(attrs, key)) {
							if (value !== attrs[key]) {
								attrs[key] = value;
								hasAttrsChanged = true;
							}
						} else {
							const camelizedKey = camelize$1(key);
							props[camelizedKey] = resolvePropValue(options, rawCurrentProps, camelizedKey, value, instance, false);
						}
					} else if (value !== attrs[key]) {
						attrs[key] = value;
						hasAttrsChanged = true;
					}
				}
			}
		} else {
			if (setFullProps(instance, rawProps, props, attrs)) hasAttrsChanged = true;
			let kebabKey;
			for (const key in rawCurrentProps) if (!rawProps || !hasOwn(rawProps, key) && ((kebabKey = hyphenate$1(key)) === key || !hasOwn(rawProps, kebabKey))) {
				if (options) {
					if (rawPrevProps && (rawPrevProps[key] !== void 0 || rawPrevProps[kebabKey] !== void 0)) props[key] = resolvePropValue(options, rawCurrentProps, key, void 0, instance, true);
				} else delete props[key];
			}
			if (attrs !== rawCurrentProps) {
				for (const key in attrs) if (!rawProps || !hasOwn(rawProps, key) && true) {
					delete attrs[key];
					hasAttrsChanged = true;
				}
			}
		}
		if (hasAttrsChanged) trigger(instance.attrs, "set", "");
	}
	function setFullProps(instance, rawProps, props, attrs) {
		const [options, needCastKeys] = instance.propsOptions;
		let hasAttrsChanged = false;
		let rawCastValues;
		if (rawProps) for (let key in rawProps) {
			if (isReservedProp(key)) continue;
			const value = rawProps[key];
			let camelKey;
			if (options && hasOwn(options, camelKey = camelize$1(key))) {
				if (!needCastKeys || !needCastKeys.includes(camelKey)) props[camelKey] = value;
				else (rawCastValues || (rawCastValues = {}))[camelKey] = value;
			} else if (!isEmitListener(instance.emitsOptions, key)) {
				if (!(key in attrs) || value !== attrs[key]) {
					attrs[key] = value;
					hasAttrsChanged = true;
				}
			}
		}
		if (needCastKeys) {
			const rawCurrentProps = toRaw(props);
			const castValues = rawCastValues || EMPTY_OBJ;
			for (let i = 0; i < needCastKeys.length; i++) {
				const key = needCastKeys[i];
				props[key] = resolvePropValue(options, rawCurrentProps, key, castValues[key], instance, !hasOwn(castValues, key));
			}
		}
		return hasAttrsChanged;
	}
	function resolvePropValue(options, props, key, value, instance, isAbsent) {
		const opt = options[key];
		if (opt != null) {
			const hasDefault = hasOwn(opt, "default");
			if (hasDefault && value === void 0) {
				const defaultValue = opt.default;
				if (opt.type !== Function && !opt.skipFactory && isFunction(defaultValue)) {
					const { propsDefaults } = instance;
					if (key in propsDefaults) value = propsDefaults[key];
					else {
						const reset = setCurrentInstance(instance);
						value = propsDefaults[key] = defaultValue.call(null, props);
						reset();
					}
				} else value = defaultValue;
				if (instance.ce) instance.ce._setProp(key, value);
			}
			if (opt[0]) {
				if (isAbsent && !hasDefault) value = false;
				else if (opt[1] && (value === "" || value === hyphenate$1(key))) value = true;
			}
		}
		return value;
	}
	var mixinPropsCache = new WeakMap();
	function normalizePropsOptions(comp, appContext, asMixin = false) {
		const cache = asMixin ? mixinPropsCache : appContext.propsCache;
		const cached = cache.get(comp);
		if (cached) return cached;
		const raw = comp.props;
		const normalized = {};
		const needCastKeys = [];
		let hasExtends = false;
		if (!isFunction(comp)) {
			const extendProps = (raw2) => {
				hasExtends = true;
				const [props, keys] = normalizePropsOptions(raw2, appContext, true);
				extend(normalized, props);
				if (keys) needCastKeys.push(...keys);
			};
			if (!asMixin && appContext.mixins.length) appContext.mixins.forEach(extendProps);
			if (comp.extends) extendProps(comp.extends);
			if (comp.mixins) comp.mixins.forEach(extendProps);
		}
		if (!raw && !hasExtends) {
			if (isObject$1(comp)) cache.set(comp, EMPTY_ARR);
			return EMPTY_ARR;
		}
		if (isArray(raw)) for (let i = 0; i < raw.length; i++) {
			const normalizedKey = camelize$1(raw[i]);
			if (validatePropName(normalizedKey)) normalized[normalizedKey] = EMPTY_OBJ;
		}
		else if (raw) for (const key in raw) {
			const normalizedKey = camelize$1(key);
			if (validatePropName(normalizedKey)) {
				const opt = raw[key];
				const prop = normalized[normalizedKey] = isArray(opt) || isFunction(opt) ? { type: opt } : extend({}, opt);
				const propType = prop.type;
				let shouldCast = false;
				let shouldCastTrue = true;
				if (isArray(propType)) for (let index = 0; index < propType.length; ++index) {
					const type = propType[index];
					const typeName = isFunction(type) && type.name;
					if (typeName === "Boolean") {
						shouldCast = true;
						break;
					} else if (typeName === "String") shouldCastTrue = false;
				}
				else shouldCast = isFunction(propType) && propType.name === "Boolean";
				prop[0] = shouldCast;
				prop[1] = shouldCastTrue;
				if (shouldCast || hasOwn(prop, "default")) needCastKeys.push(normalizedKey);
			}
		}
		const res = [normalized, needCastKeys];
		if (isObject$1(comp)) cache.set(comp, res);
		return res;
	}
	function validatePropName(key) {
		if (key[0] !== "$" && !isReservedProp(key)) return true;
		return false;
	}
	var isInternalKey = (key) => key === "_" || key === "_ctx" || key === "$stable";
	var normalizeSlotValue = (value) => isArray(value) ? value.map(normalizeVNode) : [normalizeVNode(value)];
	var normalizeSlot = (key, rawSlot, ctx) => {
		if (rawSlot._n) return rawSlot;
		const normalized = withCtx((...args) => {
			return normalizeSlotValue(rawSlot(...args));
		}, ctx);
		normalized._c = false;
		return normalized;
	};
	var normalizeObjectSlots = (rawSlots, slots, instance) => {
		const ctx = rawSlots._ctx;
		for (const key in rawSlots) {
			if (isInternalKey(key)) continue;
			const value = rawSlots[key];
			if (isFunction(value)) slots[key] = normalizeSlot(key, value, ctx);
			else if (value != null) {
				const normalized = normalizeSlotValue(value);
				slots[key] = () => normalized;
			}
		}
	};
	var normalizeVNodeSlots = (instance, children) => {
		const normalized = normalizeSlotValue(children);
		instance.slots.default = () => normalized;
	};
	var assignSlots = (slots, children, optimized) => {
		for (const key in children) if (optimized || !isInternalKey(key)) slots[key] = children[key];
	};
	var initSlots = (instance, children, optimized) => {
		const slots = instance.slots = createInternalObject();
		if (instance.vnode.shapeFlag & 32) {
			const type = children._;
			if (type) {
				assignSlots(slots, children, optimized);
				if (optimized) def(slots, "_", type, true);
			} else normalizeObjectSlots(children, slots);
		} else if (children) normalizeVNodeSlots(instance, children);
	};
	var updateSlots = (instance, children, optimized) => {
		const { vnode, slots } = instance;
		let needDeletionCheck = true;
		let deletionComparisonTarget = EMPTY_OBJ;
		if (vnode.shapeFlag & 32) {
			const type = children._;
			if (type) {
				if (optimized && type === 1) needDeletionCheck = false;
				else assignSlots(slots, children, optimized);
			} else {
				needDeletionCheck = !children.$stable;
				normalizeObjectSlots(children, slots);
			}
			deletionComparisonTarget = children;
		} else if (children) {
			normalizeVNodeSlots(instance, children);
			deletionComparisonTarget = { default: 1 };
		}
		if (needDeletionCheck) {
			for (const key in slots) if (!isInternalKey(key) && deletionComparisonTarget[key] == null) delete slots[key];
		}
	};
	var queuePostRenderEffect = queueEffectWithSuspense;
	function createRenderer(options) {
		return baseCreateRenderer(options);
	}
	function createHydrationRenderer(options) {
		return baseCreateRenderer(options, createHydrationFunctions);
	}
	function baseCreateRenderer(options, createHydrationFns) {
		const target = getGlobalThis();
		target.__VUE__ = true;
		const { insert: hostInsert, remove: hostRemove, patchProp: hostPatchProp, createElement: hostCreateElement, createText: hostCreateText, createComment: hostCreateComment, setText: hostSetText, setElementText: hostSetElementText, parentNode: hostParentNode, nextSibling: hostNextSibling, setScopeId: hostSetScopeId = NOOP, insertStaticContent: hostInsertStaticContent } = options;
		const patch = (n1, n2, container, anchor = null, parentComponent = null, parentSuspense = null, namespace = void 0, slotScopeIds = null, optimized = !!n2.dynamicChildren) => {
			if (n1 === n2) return;
			if (n1 && !isSameVNodeType(n1, n2)) {
				anchor = getNextHostNode(n1);
				unmount(n1, parentComponent, parentSuspense, true);
				n1 = null;
			}
			if (n2.patchFlag === -2) {
				optimized = false;
				n2.dynamicChildren = null;
			}
			if (n2.dynamicChildren && n1 && n1.dynamicChildren && n1.dynamicChildren.hasOnce) {
				if (n2.dynamicChildren === EMPTY_ARR) n2.dynamicChildren = [];
				n2.dynamicChildren.hasOnce = true;
			}
			const { type, ref, shapeFlag } = n2;
			switch (type) {
				case Text:
					processText(n1, n2, container, anchor);
					break;
				case Comment:
					processCommentNode(n1, n2, container, anchor);
					break;
				case Static:
					if (n1 == null) mountStaticNode(n2, container, anchor, namespace);
					break;
				case Fragment:
					processFragment(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
					break;
				default: if (shapeFlag & 1) processElement(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				else if (shapeFlag & 6) processComponent(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				else if (shapeFlag & 64) type.process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals);
				else if (shapeFlag & 128) type.process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals);
			}
			if (ref != null && parentComponent) setRef(ref, n1 && n1.ref, parentSuspense, n2 || n1, !n2);
			else if (ref == null && n1 && n1.ref != null) setRef(n1.ref, null, parentSuspense, n1, true);
		};
		const processText = (n1, n2, container, anchor) => {
			if (n1 == null) hostInsert(n2.el = hostCreateText(n2.children), container, anchor);
			else {
				const el = n2.el = n1.el;
				if (n2.children !== n1.children) hostSetText(el, n2.children);
			}
		};
		const processCommentNode = (n1, n2, container, anchor) => {
			if (n1 == null) hostInsert(n2.el = hostCreateComment(n2.children || ""), container, anchor);
			else n2.el = n1.el;
		};
		const mountStaticNode = (n2, container, anchor, namespace) => {
			[n2.el, n2.anchor] = hostInsertStaticContent(n2.children, container, anchor, namespace, n2.el, n2.anchor);
		};
		const moveStaticNode = ({ el, anchor }, container, nextSibling) => {
			let next;
			while (el && el !== anchor) {
				next = hostNextSibling(el);
				hostInsert(el, container, nextSibling);
				el = next;
			}
			hostInsert(anchor, container, nextSibling);
		};
		const removeStaticNode = ({ el, anchor }) => {
			let next;
			while (el && el !== anchor) {
				next = hostNextSibling(el);
				hostRemove(el);
				el = next;
			}
			hostRemove(anchor);
		};
		const processElement = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
			if (n2.type === "svg") namespace = "svg";
			else if (n2.type === "math") namespace = "mathml";
			if (n1 == null) mountElement(n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			else {
				const customElement = n1.el && n1.el._isVueCE ? n1.el : null;
				try {
					if (customElement) customElement._beginPatch();
					patchElement(n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				} finally {
					if (customElement) customElement._endPatch();
				}
			}
		};
		const mountElement = (vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
			let el;
			let vnodeHook;
			const { props, shapeFlag, transition, dirs } = vnode;
			el = vnode.el = hostCreateElement(vnode.type, namespace, props && props.is, props);
			if (shapeFlag & 8) hostSetElementText(el, vnode.children);
			else if (shapeFlag & 16) mountChildren(vnode.children, el, null, parentComponent, parentSuspense, resolveChildrenNamespace(vnode, namespace), slotScopeIds, optimized);
			if (dirs) invokeDirectiveHook(vnode, null, parentComponent, "created");
			setScopeId(el, vnode, vnode.scopeId, slotScopeIds, parentComponent);
			if (props) {
				for (const key in props) if (key !== "value" && !isReservedProp(key)) hostPatchProp(el, key, null, props[key], namespace, parentComponent);
				if ("value" in props) hostPatchProp(el, "value", null, props.value, namespace);
				if (vnodeHook = props.onVnodeBeforeMount) invokeVNodeHook(vnodeHook, parentComponent, vnode);
			}
			if (dirs) invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
			const needCallTransitionHooks = needTransition(parentSuspense, transition);
			if (needCallTransitionHooks) transition.beforeEnter(el);
			hostInsert(el, container, anchor);
			if ((vnodeHook = props && props.onVnodeMounted) || needCallTransitionHooks || dirs) queuePostRenderEffect(() => {
				try {
					vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
					needCallTransitionHooks && transition.enter(el);
					dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
				} finally {}
			}, parentSuspense);
		};
		const setScopeId = (el, vnode, scopeId, slotScopeIds, parentComponent) => {
			if (scopeId) hostSetScopeId(el, scopeId);
			if (slotScopeIds) for (let i = 0; i < slotScopeIds.length; i++) hostSetScopeId(el, slotScopeIds[i]);
			if (parentComponent) {
				let subTree = parentComponent.subTree;
				if (vnode === subTree || isSuspense(subTree.type) && (subTree.ssContent === vnode || subTree.ssFallback === vnode)) {
					const parentVNode = parentComponent.vnode;
					setScopeId(el, parentVNode, parentVNode.scopeId, parentVNode.slotScopeIds, parentComponent.parent);
				}
			}
		};
		const mountChildren = (children, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, start = 0) => {
			for (let i = start; i < children.length; i++) {
				const child = children[i] = optimized ? cloneIfMounted(children[i]) : normalizeVNode(children[i]);
				patch(null, child, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			}
		};
		const patchElement = (n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
			const el = n2.el = n1.el;
			let { patchFlag, dynamicChildren, dirs } = n2;
			patchFlag |= n1.patchFlag & 16;
			const oldProps = n1.props || EMPTY_OBJ;
			const newProps = n2.props || EMPTY_OBJ;
			let vnodeHook;
			parentComponent && toggleRecurse(parentComponent, false);
			if (vnodeHook = newProps.onVnodeBeforeUpdate) invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
			if (dirs) invokeDirectiveHook(n2, n1, parentComponent, "beforeUpdate");
			parentComponent && toggleRecurse(parentComponent, true);
			if (dynamicChildren && (!n1.dynamicChildren || n1.dynamicChildren.length !== dynamicChildren.length)) {
				patchFlag = 0;
				optimized = false;
				dynamicChildren = null;
			}
			if (oldProps.innerHTML && newProps.innerHTML == null || oldProps.textContent && newProps.textContent == null) hostSetElementText(el, "");
			if (dynamicChildren) patchBlockChildren(n1.dynamicChildren, dynamicChildren, el, parentComponent, parentSuspense, resolveChildrenNamespace(n2, namespace), slotScopeIds);
			else if (!optimized) patchChildren(n1, n2, el, null, parentComponent, parentSuspense, resolveChildrenNamespace(n2, namespace), slotScopeIds, false);
			if (patchFlag > 0) {
				if (patchFlag & 16) patchProps(el, oldProps, newProps, parentComponent, namespace);
				else {
					if (patchFlag & 2) {
						if (oldProps.class !== newProps.class) hostPatchProp(el, "class", null, newProps.class, namespace);
					}
					if (patchFlag & 4) hostPatchProp(el, "style", oldProps.style, newProps.style, namespace);
					if (patchFlag & 8) {
						const propsToUpdate = n2.dynamicProps;
						for (let i = 0; i < propsToUpdate.length; i++) {
							const key = propsToUpdate[i];
							const prev = oldProps[key];
							const next = newProps[key];
							if (next !== prev || key === "value") hostPatchProp(el, key, prev, next, namespace, parentComponent);
						}
					}
				}
				if (patchFlag & 1) {
					if (n1.children !== n2.children) hostSetElementText(el, n2.children);
				}
			} else if (!optimized && dynamicChildren == null) patchProps(el, oldProps, newProps, parentComponent, namespace);
			if ((vnodeHook = newProps.onVnodeUpdated) || dirs) queuePostRenderEffect(() => {
				vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
				dirs && invokeDirectiveHook(n2, n1, parentComponent, "updated");
			}, parentSuspense);
		};
		const patchBlockChildren = (oldChildren, newChildren, fallbackContainer, parentComponent, parentSuspense, namespace, slotScopeIds) => {
			for (let i = 0; i < newChildren.length; i++) {
				const oldVNode = oldChildren[i];
				const newVNode = newChildren[i];
				const oldEl = oldVNode.el || resolveAsyncComponentPlaceholder(oldVNode);
				const container = oldEl && (oldVNode.type === Fragment || !isSameVNodeType(oldVNode, newVNode) || oldVNode.shapeFlag & 198) ? hostParentNode(oldEl) : fallbackContainer;
				patch(oldVNode, newVNode, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, true);
			}
		};
		const patchProps = (el, oldProps, newProps, parentComponent, namespace) => {
			if (oldProps !== newProps) {
				if (oldProps !== EMPTY_OBJ) {
					for (const key in oldProps) if (!isReservedProp(key) && !(key in newProps)) hostPatchProp(el, key, oldProps[key], null, namespace, parentComponent);
				}
				for (const key in newProps) {
					if (isReservedProp(key)) continue;
					const next = newProps[key];
					const prev = oldProps[key];
					if (next !== prev && key !== "value") hostPatchProp(el, key, prev, next, namespace, parentComponent);
				}
				if ("value" in newProps) hostPatchProp(el, "value", oldProps.value, newProps.value, namespace);
			}
		};
		const processFragment = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
			const fragmentStartAnchor = n2.el = n1 ? n1.el : hostCreateText("");
			const fragmentEndAnchor = n2.anchor = n1 ? n1.anchor : hostCreateText("");
			let { patchFlag, dynamicChildren, slotScopeIds: fragmentSlotScopeIds } = n2;
			if (fragmentSlotScopeIds) slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
			if (n1 == null) {
				hostInsert(fragmentStartAnchor, container, anchor);
				hostInsert(fragmentEndAnchor, container, anchor);
				mountChildren(n2.children || [], container, fragmentEndAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			} else if (patchFlag > 0 && patchFlag & 64 && dynamicChildren && n1.dynamicChildren && n1.dynamicChildren.length === dynamicChildren.length) {
				patchBlockChildren(n1.dynamicChildren, dynamicChildren, container, parentComponent, parentSuspense, namespace, slotScopeIds);
				if (n2.key != null || parentComponent && n2 === parentComponent.subTree) traverseStaticChildren(n1, n2, true);
			} else patchChildren(n1, n2, container, fragmentEndAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		};
		const processComponent = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
			n2.slotScopeIds = slotScopeIds;
			if (n1 == null) {
				if (n2.shapeFlag & 512) parentComponent.ctx.activate(n2, container, anchor, namespace, optimized);
				else mountComponent(n2, container, anchor, parentComponent, parentSuspense, namespace, optimized);
			} else updateComponent(n1, n2, optimized);
		};
		const mountComponent = (initialVNode, container, anchor, parentComponent, parentSuspense, namespace, optimized) => {
			const instance = initialVNode.component = createComponentInstance(initialVNode, parentComponent, parentSuspense);
			if (isKeepAlive(initialVNode)) instance.ctx.renderer = internals;
			setupComponent(instance, false, optimized);
			if (instance.asyncDep) {
				parentSuspense && parentSuspense.registerDep(instance, setupRenderEffect, optimized, namespace);
				if (!initialVNode.el) {
					const placeholder = instance.subTree = createVNode(Comment);
					processCommentNode(null, placeholder, container, anchor);
					initialVNode.placeholder = placeholder.el;
				}
			} else setupRenderEffect(instance, initialVNode, container, anchor, parentSuspense, namespace, optimized);
		};
		const updateComponent = (n1, n2, optimized) => {
			const instance = n2.component = n1.component;
			if (shouldUpdateComponent(n1, n2, optimized)) {
				if (instance.asyncDep && !instance.asyncResolved) {
					n2.el = n1.el;
					n2.placeholder = n1.placeholder;
					updateComponentPreRender(instance, n2, optimized);
					return;
				} else {
					instance.next = n2;
					instance.update();
				}
			} else {
				n2.el = n1.el;
				n2.placeholder = n1.placeholder;
				instance.vnode = n2;
			}
		};
		const setupRenderEffect = (instance, initialVNode, container, anchor, parentSuspense, namespace, optimized) => {
			const componentUpdateFn = () => {
				if (!instance.isMounted) {
					let vnodeHook;
					const { el, props } = initialVNode;
					const { bm, m, parent, root, type } = instance;
					const isAsyncWrapperVNode = isAsyncWrapper(initialVNode);
					toggleRecurse(instance, false);
					if (bm) invokeArrayFns(bm);
					if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeBeforeMount)) invokeVNodeHook(vnodeHook, parent, initialVNode);
					toggleRecurse(instance, true);
					if (el && hydrateNode) {
						const hydrateSubTree = () => {
							instance.subTree = renderComponentRoot(instance);
							hydrateNode(el, instance.subTree, instance, parentSuspense, null);
						};
						if (isAsyncWrapperVNode && type.__asyncHydrate) type.__asyncHydrate(el, instance, hydrateSubTree);
						else hydrateSubTree();
					} else {
						if (root.ce && root.ce._hasShadowRoot()) root.ce._injectChildStyle(type, instance.parent ? instance.parent.type : void 0);
						const subTree = instance.subTree = renderComponentRoot(instance);
						patch(null, subTree, container, anchor, instance, parentSuspense, namespace);
						initialVNode.el = subTree.el;
					}
					if (m) queuePostRenderEffect(m, parentSuspense);
					if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeMounted)) {
						const scopedInitialVNode = initialVNode;
						queuePostRenderEffect(() => invokeVNodeHook(vnodeHook, parent, scopedInitialVNode), parentSuspense);
					}
					if (initialVNode.shapeFlag & 256 || parent && isAsyncWrapper(parent.vnode) && parent.vnode.shapeFlag & 256) instance.a && queuePostRenderEffect(instance.a, parentSuspense);
					instance.isMounted = true;
					initialVNode = container = anchor = null;
				} else {
					let { next, bu, u, parent, vnode } = instance;
					{
						const nonHydratedAsyncRoot = locateNonHydratedAsyncRoot(instance);
						if (nonHydratedAsyncRoot) {
							if (next) {
								next.el = vnode.el;
								updateComponentPreRender(instance, next, optimized);
							}
							nonHydratedAsyncRoot.asyncDep.then(() => {
								queuePostRenderEffect(() => {
									if (!instance.isUnmounted) update();
								}, parentSuspense);
							});
							return;
						}
					}
					let originNext = next;
					let vnodeHook;
					toggleRecurse(instance, false);
					if (next) {
						next.el = vnode.el;
						updateComponentPreRender(instance, next, optimized);
					} else next = vnode;
					if (bu) invokeArrayFns(bu);
					if (vnodeHook = next.props && next.props.onVnodeBeforeUpdate) invokeVNodeHook(vnodeHook, parent, next, vnode);
					toggleRecurse(instance, true);
					const nextTree = renderComponentRoot(instance);
					const prevTree = instance.subTree;
					instance.subTree = nextTree;
					patch(prevTree, nextTree, hostParentNode(prevTree.el), getNextHostNode(prevTree), instance, parentSuspense, namespace);
					next.el = nextTree.el;
					if (originNext === null) updateHOCHostEl(instance, nextTree.el);
					if (u) queuePostRenderEffect(u, parentSuspense);
					if (vnodeHook = next.props && next.props.onVnodeUpdated) queuePostRenderEffect(() => invokeVNodeHook(vnodeHook, parent, next, vnode), parentSuspense);
				}
			};
			instance.scope.on();
			const effect = instance.effect = new ReactiveEffect(componentUpdateFn);
			instance.scope.off();
			const update = instance.update = effect.run.bind(effect);
			const job = instance.job = effect.runIfDirty.bind(effect);
			job.i = instance;
			job.id = instance.uid;
			effect.scheduler = () => queueJob(job);
			toggleRecurse(instance, true);
			update();
		};
		const updateComponentPreRender = (instance, nextVNode, optimized) => {
			nextVNode.component = instance;
			const prevProps = instance.vnode.props;
			instance.vnode = nextVNode;
			instance.next = null;
			updateProps(instance, nextVNode.props, prevProps, optimized);
			updateSlots(instance, nextVNode.children, optimized);
			pauseTracking();
			flushPreFlushCbs(instance);
			resetTracking();
		};
		const patchChildren = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized = false) => {
			const c1 = n1 && n1.children;
			const prevShapeFlag = n1 ? n1.shapeFlag : 0;
			const c2 = n2.children;
			const { patchFlag, shapeFlag } = n2;
			if (patchFlag > 0) {
				if (patchFlag & 128) {
					patchKeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
					return;
				} else if (patchFlag & 256) {
					patchUnkeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
					return;
				}
			}
			if (shapeFlag & 8) {
				if (prevShapeFlag & 16) unmountChildren(c1, parentComponent, parentSuspense);
				if (c2 !== c1) hostSetElementText(container, c2);
			} else if (prevShapeFlag & 16) {
				if (shapeFlag & 16) patchKeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				else unmountChildren(c1, parentComponent, parentSuspense, true);
			} else {
				if (prevShapeFlag & 8) hostSetElementText(container, "");
				if (shapeFlag & 16) mountChildren(c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			}
		};
		const patchUnkeyedChildren = (c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
			c1 = c1 || EMPTY_ARR;
			c2 = c2 || EMPTY_ARR;
			const oldLength = c1.length;
			const newLength = c2.length;
			const commonLength = Math.min(oldLength, newLength);
			let i = 0;
			for (; i < commonLength; i++) {
				const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
				patch(c1[i], nextChild, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			}
			if (oldLength > newLength) unmountChildren(c1, parentComponent, parentSuspense, true, false, commonLength);
			else mountChildren(c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, commonLength);
		};
		const patchKeyedChildren = (c1, c2, container, parentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
			let i = 0;
			const l2 = c2.length;
			let e1 = c1.length - 1;
			let e2 = l2 - 1;
			while (i <= e1 && i <= e2) {
				const n1 = c1[i];
				const n2 = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
				if (isSameVNodeType(n1, n2)) patch(n1, n2, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				else break;
				i++;
			}
			while (i <= e1 && i <= e2) {
				const n1 = c1[e1];
				const n2 = c2[e2] = optimized ? cloneIfMounted(c2[e2]) : normalizeVNode(c2[e2]);
				if (isSameVNodeType(n1, n2)) patch(n1, n2, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				else break;
				e1--;
				e2--;
			}
			if (i > e1) {
				if (i <= e2) {
					const nextPos = e2 + 1;
					const anchor = nextPos < l2 ? c2[nextPos].el : parentAnchor;
					while (i <= e2) {
						patch(null, c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]), container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
						i++;
					}
				}
			} else if (i > e2) while (i <= e1) {
				unmount(c1[i], parentComponent, parentSuspense, true);
				i++;
			}
			else {
				const s1 = i;
				const s2 = i;
				const keyToNewIndexMap = new Map();
				for (i = s2; i <= e2; i++) {
					const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
					if (nextChild.key != null) keyToNewIndexMap.set(nextChild.key, i);
				}
				let j;
				let patched = 0;
				const toBePatched = e2 - s2 + 1;
				let moved = false;
				let maxNewIndexSoFar = 0;
				const newIndexToOldIndexMap = new Array(toBePatched);
				for (i = 0; i < toBePatched; i++) newIndexToOldIndexMap[i] = 0;
				for (i = s1; i <= e1; i++) {
					const prevChild = c1[i];
					if (patched >= toBePatched) {
						unmount(prevChild, parentComponent, parentSuspense, true);
						continue;
					}
					let newIndex;
					if (prevChild.key != null) newIndex = keyToNewIndexMap.get(prevChild.key);
					else for (j = s2; j <= e2; j++) if (newIndexToOldIndexMap[j - s2] === 0 && isSameVNodeType(prevChild, c2[j])) {
						newIndex = j;
						break;
					}
					if (newIndex === void 0) unmount(prevChild, parentComponent, parentSuspense, true);
					else {
						newIndexToOldIndexMap[newIndex - s2] = i + 1;
						if (newIndex >= maxNewIndexSoFar) maxNewIndexSoFar = newIndex;
						else moved = true;
						patch(prevChild, c2[newIndex], container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
						patched++;
					}
				}
				const increasingNewIndexSequence = moved ? getSequence(newIndexToOldIndexMap) : EMPTY_ARR;
				j = increasingNewIndexSequence.length - 1;
				for (i = toBePatched - 1; i >= 0; i--) {
					const nextIndex = s2 + i;
					const nextChild = c2[nextIndex];
					const anchorVNode = c2[nextIndex + 1];
					const anchor = nextIndex + 1 < l2 ? anchorVNode.el || resolveAsyncComponentPlaceholder(anchorVNode) : parentAnchor;
					if (newIndexToOldIndexMap[i] === 0) patch(null, nextChild, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
					else if (moved) {
						if (j < 0 || i !== increasingNewIndexSequence[j]) move(nextChild, container, anchor, 2);
						else j--;
					}
				}
			}
		};
		const move = (vnode, container, anchor, moveType, parentSuspense = null) => {
			const { el, type, transition, children, shapeFlag } = vnode;
			if (shapeFlag & 6) {
				move(vnode.component.subTree, container, anchor, moveType);
				return;
			}
			if (shapeFlag & 128) {
				vnode.suspense.move(container, anchor, moveType);
				return;
			}
			if (shapeFlag & 64) {
				type.move(vnode, container, anchor, internals);
				return;
			}
			if (type === Fragment) {
				hostInsert(el, container, anchor);
				for (let i = 0; i < children.length; i++) move(children[i], container, anchor, moveType);
				hostInsert(vnode.anchor, container, anchor);
				return;
			}
			if (type === Static) {
				moveStaticNode(vnode, container, anchor);
				return;
			}
			if (moveType !== 2 && shapeFlag & 1 && transition) {
				if (moveType === 0) {
					if (transition.persisted && !el[leaveCbKey]) hostInsert(el, container, anchor);
					else {
						transition.beforeEnter(el);
						hostInsert(el, container, anchor);
						queuePostRenderEffect(() => transition.enter(el), parentSuspense);
					}
				} else {
					const { leave, delayLeave, afterLeave } = transition;
					const remove2 = () => {
						if (vnode.ctx.isUnmounted) hostRemove(el);
						else hostInsert(el, container, anchor);
					};
					const performLeave = () => {
						const wasLeaving = el._isLeaving || !!el[leaveCbKey];
						if (el._isLeaving) el[leaveCbKey](true);
						if (transition.persisted && !wasLeaving) remove2();
						else leave(el, () => {
							remove2();
							afterLeave && afterLeave();
						});
					};
					if (delayLeave) delayLeave(el, remove2, performLeave);
					else performLeave();
				}
			} else hostInsert(el, container, anchor);
		};
		const unmount = (vnode, parentComponent, parentSuspense, doRemove = false, optimized = false) => {
			const { type, props, ref, children, dynamicChildren, shapeFlag, patchFlag, dirs, cacheIndex, memo } = vnode;
			if (patchFlag === -2 || dynamicChildren && dynamicChildren.hasOnce) optimized = false;
			if (ref != null) {
				pauseTracking();
				setRef(ref, null, parentSuspense, vnode, true);
				resetTracking();
			}
			if (cacheIndex != null && (!vnode.ctx || vnode.ctx === parentComponent)) parentComponent.renderCache[cacheIndex] = void 0;
			if (shapeFlag & 256) {
				parentComponent.ctx.deactivate(vnode);
				return;
			}
			const shouldInvokeDirs = shapeFlag & 1 && dirs;
			const shouldInvokeVnodeHook = !isAsyncWrapper(vnode);
			let vnodeHook;
			if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeBeforeUnmount)) invokeVNodeHook(vnodeHook, parentComponent, vnode);
			if (shapeFlag & 6) unmountComponent(vnode.component, parentSuspense, doRemove);
			else {
				if (shapeFlag & 128) {
					vnode.suspense.unmount(parentSuspense, doRemove);
					return;
				}
				if (shouldInvokeDirs) invokeDirectiveHook(vnode, null, parentComponent, "beforeUnmount");
				if (shapeFlag & 64) vnode.type.remove(vnode, parentComponent, parentSuspense, internals, doRemove);
				else if (dynamicChildren && !dynamicChildren.hasOnce && (type !== Fragment || patchFlag > 0 && patchFlag & 64)) unmountChildren(dynamicChildren, parentComponent, parentSuspense, false, true);
				else if (type === Fragment && patchFlag & 384 || !optimized && shapeFlag & 16) unmountChildren(children, parentComponent, parentSuspense);
				if (doRemove) remove(vnode);
			}
			const shouldInvalidateMemo = memo != null && cacheIndex == null;
			if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeUnmounted) || shouldInvokeDirs || shouldInvalidateMemo) queuePostRenderEffect(() => {
				vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
				shouldInvokeDirs && invokeDirectiveHook(vnode, null, parentComponent, "unmounted");
				if (shouldInvalidateMemo) vnode.el = null;
			}, parentSuspense);
		};
		const remove = (vnode) => {
			const { type, el, anchor, transition } = vnode;
			const isFragment = type === Fragment;
			if (isFragment && !transition) {
				removeFragment(el, anchor);
				return;
			}
			if (type === Static) {
				removeStaticNode(vnode);
				if (transition && !transition.persisted && transition.afterLeave) transition.afterLeave();
				return;
			}
			const leavingNode = isFragment ? getTransitionRoot(vnode) : vnode;
			const performRemove = () => {
				if (isFragment) {
					if (hostParentNode(el)) removeFragment(el, anchor);
				} else hostRemove(el);
				if (transition && !transition.persisted && transition.afterLeave) transition.afterLeave();
			};
			if (leavingNode && leavingNode.shapeFlag & 1 && transition && !transition.persisted) {
				const { leave, delayLeave } = transition;
				const leavingEl = leavingNode.el;
				const performLeave = () => leave(leavingEl, performRemove);
				if (delayLeave) delayLeave(leavingEl, performRemove, performLeave);
				else performLeave();
			} else performRemove();
		};
		const removeFragment = (cur, end) => {
			let next;
			while (cur !== end) {
				next = hostNextSibling(cur);
				hostRemove(cur);
				cur = next;
			}
			hostRemove(end);
		};
		const unmountComponent = (instance, parentSuspense, doRemove) => {
			const { bum, scope, job, subTree, um, m, a } = instance;
			invalidateMount(m);
			invalidateMount(a);
			if (bum) invokeArrayFns(bum);
			scope.stop();
			if (job) {
				job.flags |= 8;
				unmount(subTree, instance, parentSuspense, doRemove);
			} else if (instance.vnode.el && subTree) {
				subTree.transition = instance.vnode.transition;
				unmount(subTree, instance, parentSuspense, doRemove);
			}
			if (um) queuePostRenderEffect(um, parentSuspense);
			queuePostRenderEffect(() => {
				instance.isUnmounted = true;
			}, parentSuspense);
		};
		const unmountChildren = (children, parentComponent, parentSuspense, doRemove = false, optimized = false, start = 0) => {
			for (let i = start; i < children.length; i++) unmount(children[i], parentComponent, parentSuspense, doRemove, optimized);
		};
		const getNextHostNode = (vnode) => {
			if (vnode.shapeFlag & 6) return getNextHostNode(vnode.component.subTree);
			if (vnode.shapeFlag & 128) return vnode.suspense.next();
			const el = hostNextSibling(vnode.anchor || vnode.el);
			const teleportEnd = el && el[TeleportEndKey];
			return teleportEnd ? hostNextSibling(teleportEnd) : el;
		};
		const render = (vnode, container, namespace) => {
			flushOnAppMount(() => {
				if (vnode == null) {
					if (container._vnode) unmount(container._vnode, null, null, true);
				} else patch(container._vnode || null, vnode, container, null, null, null, namespace);
				container._vnode = vnode;
			}, vnode && container._vnode ? void 0 : vnode && vnode.component ? vnode.component.uid : getNextUid());
		};
		const internals = {
			p: patch,
			um: unmount,
			m: move,
			r: remove,
			mt: mountComponent,
			mc: mountChildren,
			pc: patchChildren,
			pbc: patchBlockChildren,
			n: getNextHostNode,
			o: options
		};
		let hydrate;
		let hydrateNode;
		if (createHydrationFns) [hydrate, hydrateNode] = createHydrationFns(internals);
		return {
			render,
			hydrate,
			createApp: createAppAPI(render, hydrate)
		};
	}
	function resolveChildrenNamespace({ type, props }, currentNamespace) {
		return currentNamespace === "svg" && type === "foreignObject" || currentNamespace === "mathml" && type === "annotation-xml" && props && props.encoding && props.encoding.includes("html") ? void 0 : currentNamespace;
	}
	function toggleRecurse({ effect, job }, allowed) {
		if (allowed) {
			effect.flags |= 32;
			job.flags |= 4;
		} else {
			effect.flags &= -33;
			job.flags &= -5;
		}
	}
	function needTransition(parentSuspense, transition) {
		return (!parentSuspense || parentSuspense && !parentSuspense.pendingBranch) && transition && !transition.persisted;
	}
	function traverseStaticChildren(n1, n2, shallow = false) {
		const ch1 = n1.children;
		const ch2 = n2.children;
		if (isArray(ch1) && isArray(ch2)) for (let i = 0; i < ch1.length; i++) {
			const c1 = ch1[i];
			let c2 = ch2[i];
			if (c2.shapeFlag & 1 && !c2.dynamicChildren) {
				if (c2.patchFlag <= 0 || c2.patchFlag === 32) {
					c2 = ch2[i] = cloneIfMounted(ch2[i]);
					c2.el = c1.el;
				}
				if (!shallow && c2.patchFlag !== -2) traverseStaticChildren(c1, c2);
			}
			if (c2.type === Text) {
				if (c2.patchFlag === -1) c2 = ch2[i] = cloneIfMounted(c2);
				c2.el = c1.el;
			}
			if (c2.type === Comment && !c2.el) c2.el = c1.el;
		}
	}
	function getSequence(arr) {
		const p = arr.slice();
		const result = [0];
		let i, j, u, v, c;
		const len = arr.length;
		for (i = 0; i < len; i++) {
			const arrI = arr[i];
			if (arrI !== 0) {
				j = result[result.length - 1];
				if (arr[j] < arrI) {
					p[i] = j;
					result.push(i);
					continue;
				}
				u = 0;
				v = result.length - 1;
				while (u < v) {
					c = u + v >> 1;
					if (arr[result[c]] < arrI) u = c + 1;
					else v = c;
				}
				if (arrI < arr[result[u]]) {
					if (u > 0) p[i] = result[u - 1];
					result[u] = i;
				}
			}
		}
		u = result.length;
		v = result[u - 1];
		while (u-- > 0) {
			result[u] = v;
			v = p[v];
		}
		return result;
	}
	function locateNonHydratedAsyncRoot(instance) {
		const subComponent = instance.subTree.component;
		if (subComponent) {
			if (subComponent.asyncDep && !subComponent.asyncResolved) return subComponent;
			else return locateNonHydratedAsyncRoot(subComponent);
		}
	}
	function invalidateMount(hooks) {
		if (hooks) for (let i = 0; i < hooks.length; i++) hooks[i].flags |= 8;
	}
	function resolveAsyncComponentPlaceholder(anchorVnode) {
		if (anchorVnode.placeholder) return anchorVnode.placeholder;
		const instance = anchorVnode.component;
		if (instance) return resolveAsyncComponentPlaceholder(instance.subTree);
		return null;
	}
	var isSuspense = (type) => type.__isSuspense;
	var suspenseId = 0;
	var Suspense = {
		name: "Suspense",
		__isSuspense: true,
		process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
			if (n1 == null) mountSuspense(n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals);
			else {
				if (parentSuspense && parentSuspense.deps > 0 && !n1.suspense.isInFallback && !parentSuspense.isHydrating) {
					n2.suspense = n1.suspense;
					n2.suspense.vnode = n2;
					n2.el = n1.el;
					return;
				}
				patchSuspense(n1, n2, container, anchor, parentComponent, namespace, slotScopeIds, optimized, rendererInternals);
			}
		},
		hydrate: hydrateSuspense,
		normalize: normalizeSuspenseChildren
	};
	function triggerEvent(vnode, name) {
		const eventListener = vnode.props && vnode.props[name];
		if (isFunction(eventListener)) eventListener();
	}
	function mountSuspense(vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
		const { p: patch, o: { createElement } } = rendererInternals;
		const hiddenContainer = createElement("div");
		const suspense = vnode.suspense = createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, namespace, slotScopeIds, optimized, rendererInternals);
		patch(null, suspense.pendingBranch = vnode.ssContent, hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds);
		if (suspense.deps > 0) {
			triggerEvent(vnode, "onPending");
			triggerEvent(vnode, "onFallback");
			patch(null, vnode.ssFallback, container, anchor, parentComponent, null, namespace, slotScopeIds);
			setActiveBranch(suspense, vnode.ssFallback);
		} else suspense.resolve(false, true);
	}
	function patchSuspense(n1, n2, container, anchor, parentComponent, namespace, slotScopeIds, optimized, { p: patch, um: unmount, o: { createElement } }) {
		const suspense = n2.suspense = n1.suspense;
		suspense.vnode = n2;
		n2.el = n1.el;
		const newBranch = n2.ssContent;
		const newFallback = n2.ssFallback;
		const { activeBranch, pendingBranch, isInFallback, isHydrating } = suspense;
		if (pendingBranch) {
			suspense.pendingBranch = newBranch;
			if (isSameVNodeType(pendingBranch, newBranch)) {
				suspense.deps++;
				patch(pendingBranch, newBranch, isHydrating ? container : suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
				suspense.deps--;
				if (suspense.deps <= 0) suspense.resolve();
				else if (isInFallback) {
					if (!isHydrating && !suspense.isFallbackMountPending) {
						patch(activeBranch, newFallback, container, anchor, parentComponent, null, namespace, slotScopeIds, optimized);
						setActiveBranch(suspense, newFallback);
					}
				}
			} else {
				suspense.pendingId = suspenseId++;
				if (isHydrating) {
					suspense.isHydrating = false;
					suspense.activeBranch = pendingBranch;
				} else unmount(pendingBranch, parentComponent, suspense);
				suspense.deps = 0;
				suspense.effects.length = 0;
				suspense.hiddenContainer = createElement("div");
				if (isInFallback) {
					patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
					if (suspense.deps <= 0) suspense.resolve();
					else if (!suspense.isFallbackMountPending) {
						patch(activeBranch, newFallback, container, anchor, parentComponent, null, namespace, slotScopeIds, optimized);
						setActiveBranch(suspense, newFallback);
					}
				} else if (activeBranch && isSameVNodeType(activeBranch, newBranch)) {
					patch(activeBranch, newBranch, container, anchor, parentComponent, suspense, namespace, slotScopeIds, optimized);
					suspense.resolve(true);
				} else {
					patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
					if (suspense.deps <= 0) suspense.resolve();
				}
			}
		} else if (activeBranch && isSameVNodeType(activeBranch, newBranch)) {
			patch(activeBranch, newBranch, container, anchor, parentComponent, suspense, namespace, slotScopeIds, optimized);
			setActiveBranch(suspense, newBranch);
		} else {
			triggerEvent(n2, "onPending");
			suspense.pendingBranch = newBranch;
			if (newBranch.shapeFlag & 512) suspense.pendingId = newBranch.component.suspenseId;
			else suspense.pendingId = suspenseId++;
			patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
			if (suspense.deps <= 0) suspense.resolve();
			else {
				const { timeout, pendingId } = suspense;
				if (timeout > 0) setTimeout(() => {
					if (suspense.pendingId === pendingId) suspense.fallback(newFallback);
				}, timeout);
				else if (timeout === 0) suspense.fallback(newFallback);
			}
		}
	}
	function createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, namespace, slotScopeIds, optimized, rendererInternals, isHydrating = false) {
		const { p: patch, m: move, um: unmount, n: next, o: { parentNode, remove } } = rendererInternals;
		let parentSuspenseId;
		const isSuspensible = isVNodeSuspensible(vnode);
		if (isSuspensible) {
			if (parentSuspense && parentSuspense.pendingBranch) {
				parentSuspenseId = parentSuspense.pendingId;
				parentSuspense.deps++;
			}
		}
		const timeout = vnode.props ? toNumber(vnode.props.timeout) : void 0;
		const initialAnchor = anchor;
		const suspense = {
			vnode,
			parent: parentSuspense,
			parentComponent,
			namespace,
			container,
			hiddenContainer,
			deps: 0,
			pendingId: suspenseId++,
			timeout: typeof timeout === "number" ? timeout : -1,
			activeBranch: null,
			isFallbackMountPending: false,
			pendingBranch: null,
			isInFallback: !isHydrating,
			isHydrating,
			isUnmounted: false,
			effects: [],
			resolve(resume = false, sync = false) {
				const { vnode: vnode2, activeBranch, pendingBranch, pendingId, effects, parentComponent: parentComponent2, container: container2, isInFallback } = suspense;
				let delayEnter = false;
				if (suspense.isHydrating) suspense.isHydrating = false;
				else if (!resume) {
					delayEnter = activeBranch && pendingBranch.transition && pendingBranch.transition.mode === "out-in";
					let hasUpdatedAnchor = false;
					if (delayEnter) activeBranch.transition.afterLeave = () => {
						if (pendingId === suspense.pendingId) {
							move(pendingBranch, container2, anchor === initialAnchor && !hasUpdatedAnchor ? next(activeBranch) : anchor, 0);
							queuePostFlushCb(effects);
							if (isInFallback && vnode2.ssFallback) vnode2.ssFallback.el = null;
						}
					};
					if (activeBranch && !suspense.isFallbackMountPending) {
						if (parentNode(activeBranch.el) === container2) {
							anchor = next(activeBranch);
							hasUpdatedAnchor = true;
						}
						unmount(activeBranch, parentComponent2, suspense, true);
						if (!delayEnter && isInFallback && vnode2.ssFallback) queuePostRenderEffect(() => vnode2.ssFallback.el = null, suspense);
					}
					if (!delayEnter) move(pendingBranch, container2, anchor, 0);
				}
				suspense.isFallbackMountPending = false;
				setActiveBranch(suspense, pendingBranch);
				suspense.pendingBranch = null;
				suspense.isInFallback = false;
				let parent = suspense.parent;
				let hasUnresolvedAncestor = false;
				while (parent) {
					if (parent.pendingBranch) {
						for (let i = 0; i < effects.length; i++) parent.effects.push(effects[i]);
						hasUnresolvedAncestor = true;
						break;
					}
					parent = parent.parent;
				}
				if (!hasUnresolvedAncestor && !delayEnter) queuePostFlushCb(effects);
				suspense.effects = [];
				if (isSuspensible) {
					if (parentSuspense && parentSuspense.pendingBranch && parentSuspenseId === parentSuspense.pendingId) {
						parentSuspenseId = void 0;
						parentSuspense.deps--;
						if (parentSuspense.deps === 0 && !sync) parentSuspense.resolve();
					}
				}
				triggerEvent(vnode2, "onResolve");
			},
			fallback(fallbackVNode) {
				if (!suspense.pendingBranch) return;
				const { vnode: vnode2, activeBranch, parentComponent: parentComponent2, container: container2, namespace: namespace2 } = suspense;
				triggerEvent(vnode2, "onFallback");
				const anchor2 = next(activeBranch);
				const mountFallback = () => {
					suspense.isFallbackMountPending = false;
					if (!suspense.isInFallback) return;
					const latestFallback = suspense.vnode.ssFallback;
					patch(null, latestFallback, container2, anchor2, parentComponent2, null, namespace2, slotScopeIds, optimized);
					setActiveBranch(suspense, latestFallback);
				};
				const delayEnter = fallbackVNode.transition && fallbackVNode.transition.mode === "out-in";
				if (delayEnter) {
					suspense.isFallbackMountPending = true;
					activeBranch.transition.afterLeave = mountFallback;
				}
				suspense.isInFallback = true;
				unmount(activeBranch, parentComponent2, null, true);
				if (!delayEnter) mountFallback();
			},
			move(container2, anchor2, type) {
				suspense.activeBranch && move(suspense.activeBranch, container2, anchor2, type);
				suspense.container = container2;
			},
			next() {
				return suspense.activeBranch && next(suspense.activeBranch);
			},
			registerDep(instance, setupRenderEffect, optimized2, namespace2) {
				const isInPendingSuspense = !!suspense.pendingBranch;
				if (isInPendingSuspense) suspense.deps++;
				const hydratedEl = instance.vnode.el;
				instance.asyncDep.catch((err) => {
					handleError(err, instance, 0);
				}).then((asyncSetupResult) => {
					if (instance.isUnmounted || suspense.isUnmounted || suspense.pendingId !== instance.suspenseId) return;
					unsetCurrentInstance();
					if (!instance.scope.active) {
						if (isInPendingSuspense && --suspense.deps === 0) suspense.resolve();
						return;
					}
					instance.asyncResolved = true;
					const { vnode: vnode2 } = instance;
					handleSetupResult(instance, asyncSetupResult, false);
					if (hydratedEl) vnode2.el = hydratedEl;
					const placeholder = !hydratedEl && instance.subTree.el;
					setupRenderEffect(instance, vnode2, parentNode(hydratedEl || instance.subTree.el), hydratedEl ? null : next(instance.subTree), suspense, namespace2, optimized2);
					if (placeholder) {
						vnode2.placeholder = null;
						remove(placeholder);
					}
					updateHOCHostEl(instance, vnode2.el);
					if (isInPendingSuspense && --suspense.deps === 0) suspense.resolve();
				});
			},
			unmount(parentSuspense2, doRemove) {
				suspense.isUnmounted = true;
				if (suspense.activeBranch) unmount(suspense.activeBranch, parentComponent, parentSuspense2, doRemove);
				if (suspense.pendingBranch) unmount(suspense.pendingBranch, parentComponent, parentSuspense2, doRemove);
			}
		};
		return suspense;
	}
	function hydrateSuspense(node, vnode, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals, hydrateNode) {
		const suspense = vnode.suspense = createSuspenseBoundary(vnode, parentSuspense, parentComponent, node.parentNode, document.createElement("div"), null, namespace, slotScopeIds, optimized, rendererInternals, true);
		const result = hydrateNode(node, suspense.pendingBranch = vnode.ssContent, parentComponent, suspense, slotScopeIds, optimized);
		if (suspense.deps === 0) suspense.resolve(false, true);
		return result;
	}
	function normalizeSuspenseChildren(vnode) {
		const { shapeFlag, children } = vnode;
		const isSlotChildren = shapeFlag & 32;
		vnode.ssContent = normalizeSuspenseSlot(isSlotChildren ? children.default : children);
		vnode.ssFallback = isSlotChildren ? normalizeSuspenseSlot(children.fallback) : createVNode(Comment);
	}
	function normalizeSuspenseSlot(s) {
		let block;
		if (isFunction(s)) {
			const trackBlock = isBlockTreeEnabled && s._c;
			if (trackBlock) {
				s._d = false;
				openBlock();
			}
			s = s();
			if (trackBlock) {
				s._d = true;
				block = currentBlock;
				closeBlock();
			}
		}
		if (isArray(s)) s = filterSingleRoot(s);
		s = normalizeVNode(s);
		if (block && !s.dynamicChildren) s.dynamicChildren = block.filter((c) => c !== s);
		return s;
	}
	function queueEffectWithSuspense(fn, suspense) {
		if (suspense && suspense.pendingBranch) {
			if (isArray(fn)) suspense.effects.push(...fn);
			else suspense.effects.push(fn);
		} else queuePostFlushCb(fn);
	}
	function setActiveBranch(suspense, branch) {
		suspense.activeBranch = branch;
		const { vnode, parentComponent } = suspense;
		let el = branch.el;
		while (!el && branch.component) {
			branch = branch.component.subTree;
			el = branch.el;
		}
		vnode.el = el;
		if (parentComponent && parentComponent.subTree === vnode) {
			parentComponent.vnode.el = el;
			updateHOCHostEl(parentComponent, el);
		}
	}
	function isVNodeSuspensible(vnode) {
		const suspensible = vnode.props && vnode.props.suspensible;
		return suspensible != null && suspensible !== false;
	}
	var Fragment = Symbol.for("v-fgt");
	var Text = Symbol.for("v-txt");
	var Comment = Symbol.for("v-cmt");
	var Static = Symbol.for("v-stc");
	var blockStack = [];
	var currentBlock = null;
	function openBlock(disableTracking = false) {
		blockStack.push(currentBlock = disableTracking ? null : []);
	}
	function closeBlock() {
		blockStack.pop();
		currentBlock = blockStack[blockStack.length - 1] || null;
	}
	var isBlockTreeEnabled = 1;
	function setBlockTracking(value, inVOnce = false) {
		isBlockTreeEnabled += value;
		if (value < 0 && currentBlock && inVOnce) currentBlock.hasOnce = true;
	}
	function setupBlock(vnode) {
		vnode.dynamicChildren = isBlockTreeEnabled > 0 ? currentBlock || EMPTY_ARR : null;
		closeBlock();
		if (isBlockTreeEnabled > 0 && currentBlock) currentBlock.push(vnode);
		return vnode;
	}
	function createElementBlock(type, props, children, patchFlag, dynamicProps, shapeFlag) {
		return setupBlock(createBaseVNode(type, props, children, patchFlag, dynamicProps, shapeFlag, true));
	}
	function createBlock(type, props, children, patchFlag, dynamicProps) {
		return setupBlock(createVNode(type, props, children, patchFlag, dynamicProps, true));
	}
	function isVNode(value) {
		return value ? value.__v_isVNode === true : false;
	}
	function isSameVNodeType(n1, n2) {
		return n1.type === n2.type && n1.key === n2.key;
	}
	function transformVNodeArgs(transformer) {}
	var normalizeKey = ({ key }) => key != null ? key : null;
	var normalizeRef = ({ ref, ref_key, ref_for }) => {
		if (typeof ref === "number") ref = "" + ref;
		return ref != null ? isString(ref) || isRef(ref) || isFunction(ref) ? {
			i: currentRenderingInstance,
			r: ref,
			k: ref_key,
			f: !!ref_for
		} : ref : null;
	};
	function createBaseVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, shapeFlag = type === Fragment ? 0 : 1, isBlockNode = false, needFullChildrenNormalization = false) {
		const vnode = {
			__v_isVNode: true,
			__v_skip: true,
			type,
			props,
			key: props && normalizeKey(props),
			ref: props && normalizeRef(props),
			scopeId: currentScopeId,
			slotScopeIds: null,
			children,
			component: null,
			suspense: null,
			ssContent: null,
			ssFallback: null,
			dirs: null,
			transition: null,
			el: null,
			anchor: null,
			target: null,
			targetStart: null,
			targetAnchor: null,
			staticCount: 0,
			shapeFlag,
			patchFlag,
			dynamicProps,
			dynamicChildren: null,
			appContext: null,
			ctx: currentRenderingInstance
		};
		if (needFullChildrenNormalization) {
			normalizeChildren(vnode, children);
			if (shapeFlag & 128) type.normalize(vnode);
		} else if (children) vnode.shapeFlag |= isString(children) ? 8 : 16;
		if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock && (vnode.patchFlag > 0 || shapeFlag & 6) && vnode.patchFlag !== 32) currentBlock.push(vnode);
		return vnode;
	}
	var createVNode = _createVNode;
	function _createVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, isBlockNode = false) {
		if (!type || type === NULL_DYNAMIC_COMPONENT) type = Comment;
		if (isVNode(type)) {
			const cloned = cloneVNode(type, props, true);
			if (children) normalizeChildren(cloned, children);
			if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock) {
				if (cloned.shapeFlag & 6) currentBlock[currentBlock.indexOf(type)] = cloned;
				else currentBlock.push(cloned);
			}
			cloned.patchFlag = -2;
			return cloned;
		}
		if (isClassComponent(type)) type = type.__vccOpts;
		if (props) {
			props = guardReactiveProps(props);
			let { class: klass, style } = props;
			if (klass && !isString(klass)) props.class = normalizeClass(klass);
			if (isObject$1(style)) {
				if (isProxy(style) && !isArray(style)) style = extend({}, style);
				props.style = normalizeStyle(style);
			}
		}
		const shapeFlag = isString(type) ? 1 : isSuspense(type) ? 128 : isTeleport(type) ? 64 : isObject$1(type) ? 4 : isFunction(type) ? 2 : 0;
		return createBaseVNode(type, props, children, patchFlag, dynamicProps, shapeFlag, isBlockNode, true);
	}
	function guardReactiveProps(props) {
		if (!props) return null;
		return isProxy(props) || isInternalObject(props) ? extend({}, props) : props;
	}
	function cloneVNode(vnode, extraProps, mergeRef = false, cloneTransition = false) {
		const { props, ref, patchFlag, children, transition } = vnode;
		const mergedProps = extraProps ? mergeProps(props || {}, extraProps) : props;
		const cloned = {
			__v_isVNode: true,
			__v_skip: true,
			type: vnode.type,
			props: mergedProps,
			key: mergedProps && normalizeKey(mergedProps),
			ref: extraProps && extraProps.ref ? mergeRef && ref ? isArray(ref) ? ref.concat(normalizeRef(extraProps)) : [ref, normalizeRef(extraProps)] : normalizeRef(extraProps) : ref,
			scopeId: vnode.scopeId,
			slotScopeIds: vnode.slotScopeIds,
			children,
			target: vnode.target,
			targetStart: vnode.targetStart,
			targetAnchor: vnode.targetAnchor,
			staticCount: vnode.staticCount,
			shapeFlag: vnode.shapeFlag,
			patchFlag: extraProps && vnode.type !== Fragment ? patchFlag === -1 ? 16 : patchFlag | 16 : patchFlag,
			dynamicProps: vnode.dynamicProps,
			dynamicChildren: vnode.dynamicChildren,
			appContext: vnode.appContext,
			dirs: vnode.dirs,
			transition,
			component: vnode.component,
			suspense: vnode.suspense,
			ssContent: vnode.ssContent && cloneVNode(vnode.ssContent),
			ssFallback: vnode.ssFallback && cloneVNode(vnode.ssFallback),
			placeholder: vnode.placeholder,
			el: vnode.el,
			anchor: vnode.anchor,
			ctx: vnode.ctx,
			ce: vnode.ce,
			cacheIndex: vnode.cacheIndex
		};
		if (transition && cloneTransition) setTransitionHooks(cloned, transition.clone(cloned));
		return cloned;
	}
	function createTextVNode(text = " ", flag = 0) {
		return createVNode(Text, null, text, flag);
	}
	function createStaticVNode(content, numberOfNodes) {
		const vnode = createVNode(Static, null, content);
		vnode.staticCount = numberOfNodes;
		return vnode;
	}
	function createCommentVNode(text = "", asBlock = false) {
		return asBlock ? (openBlock(), createBlock(Comment, null, text)) : createVNode(Comment, null, text);
	}
	function normalizeVNode(child) {
		if (child == null || typeof child === "boolean") return createVNode(Comment);
		else if (isArray(child)) return createVNode(Fragment, null, child.slice());
		else if (isVNode(child)) return cloneIfMounted(child);
		else return createVNode(Text, null, String(child));
	}
	function cloneIfMounted(child) {
		return child.el === null && child.patchFlag !== -1 || child.memo ? child : cloneVNode(child);
	}
	function normalizeChildren(vnode, children) {
		let type = 0;
		const { shapeFlag } = vnode;
		if (children == null) children = null;
		else if (isArray(children)) type = 16;
		else if (typeof children === "object") {
			if (shapeFlag & 65) {
				const slot = children.default;
				if (slot) {
					slot._c && (slot._d = false);
					normalizeChildren(vnode, slot());
					slot._c && (slot._d = true);
				}
				return;
			} else {
				type = 32;
				const slotFlag = children._;
				if (!slotFlag && !isInternalObject(children)) children._ctx = currentRenderingInstance;
				else if (slotFlag === 3 && currentRenderingInstance) {
					if (currentRenderingInstance.slots._ === 1) children._ = 1;
					else {
						children._ = 2;
						vnode.patchFlag |= 1024;
					}
				}
			}
		} else if (isFunction(children)) {
			if (shapeFlag & 65) {
				normalizeChildren(vnode, { default: children });
				return;
			}
			children = {
				default: children,
				_ctx: currentRenderingInstance
			};
			type = 32;
		} else {
			children = String(children);
			if (shapeFlag & 64) {
				type = 16;
				children = [createTextVNode(children)];
			} else type = 8;
		}
		vnode.children = children;
		vnode.shapeFlag |= type;
	}
	function mergeProps(...args) {
		const ret = {};
		for (let i = 0; i < args.length; i++) {
			const toMerge = args[i];
			for (const key in toMerge) if (key === "class") {
				if (ret.class !== toMerge.class) ret.class = normalizeClass([ret.class, toMerge.class]);
			} else if (key === "style") ret.style = normalizeStyle([ret.style, toMerge.style]);
			else if (isOn(key)) {
				const existing = ret[key];
				const incoming = toMerge[key];
				if (incoming && existing !== incoming && !(isArray(existing) && existing.includes(incoming))) ret[key] = existing ? [].concat(existing, incoming) : incoming;
				else if (incoming == null && existing == null && !isModelListener(key)) ret[key] = incoming;
			} else if (key !== "") ret[key] = toMerge[key];
		}
		return ret;
	}
	function invokeVNodeHook(hook, instance, vnode, prevVNode = null) {
		callWithAsyncErrorHandling(hook, instance, 7, [vnode, prevVNode]);
	}
	var emptyAppContext = createAppContext();
	var uid = 0;
	function getNextUid() {
		return uid;
	}
	function createComponentInstance(vnode, parent, suspense) {
		const type = vnode.type;
		const appContext = (parent ? parent.appContext : vnode.appContext) || emptyAppContext;
		const instance = {
			uid: uid++,
			vnode,
			type,
			parent,
			appContext,
			root: null,
			next: null,
			subTree: null,
			effect: null,
			update: null,
			job: null,
			scope: new EffectScope(true),
			render: null,
			proxy: null,
			exposed: null,
			exposeProxy: null,
			withProxy: null,
			provides: parent ? parent.provides : Object.create(appContext.provides),
			ids: parent ? parent.ids : [
				"",
				0,
				0
			],
			accessCache: null,
			renderCache: [],
			components: null,
			directives: null,
			propsOptions: normalizePropsOptions(type, appContext),
			emitsOptions: normalizeEmitsOptions(type, appContext),
			emit: null,
			emitted: null,
			propsDefaults: EMPTY_OBJ,
			inheritAttrs: type.inheritAttrs,
			ctx: EMPTY_OBJ,
			data: EMPTY_OBJ,
			props: EMPTY_OBJ,
			attrs: EMPTY_OBJ,
			slots: EMPTY_OBJ,
			refs: EMPTY_OBJ,
			setupState: EMPTY_OBJ,
			setupContext: null,
			suspense,
			suspenseId: suspense ? suspense.pendingId : 0,
			asyncDep: null,
			asyncResolved: false,
			isMounted: false,
			isUnmounted: false,
			isDeactivated: false,
			bc: null,
			c: null,
			bm: null,
			m: null,
			bu: null,
			u: null,
			um: null,
			bum: null,
			da: null,
			a: null,
			rtg: null,
			rtc: null,
			ec: null,
			sp: null
		};
		instance.ctx = { _: instance };
		instance.root = parent ? parent.root : instance;
		instance.emit = emit.bind(null, instance);
		if (vnode.ce) vnode.ce(instance);
		return instance;
	}
	var currentInstance = null;
	var getCurrentInstance = () => currentInstance || currentRenderingInstance;
	var internalSetCurrentInstance;
	var setInSSRSetupState;
	{
		const g = getGlobalThis();
		const registerGlobalSetter = (key, setter) => {
			let setters;
			if (!(setters = g[key])) setters = g[key] = [];
			setters.push(setter);
			return (v) => {
				if (setters.length > 1) setters.forEach((set) => set(v));
				else setters[0](v);
			};
		};
		internalSetCurrentInstance = registerGlobalSetter(`__VUE_INSTANCE_SETTERS__`, (v) => currentInstance = v);
		setInSSRSetupState = registerGlobalSetter(`__VUE_SSR_SETTERS__`, (v) => isInSSRComponentSetup = v);
	}
	var setCurrentInstance = (instance) => {
		const prev = currentInstance;
		internalSetCurrentInstance(instance);
		instance.scope.on();
		return () => {
			instance.scope.off();
			internalSetCurrentInstance(prev);
		};
	};
	var unsetCurrentInstance = () => {
		currentInstance && currentInstance.scope.off();
		internalSetCurrentInstance(null);
	};
	function isStatefulComponent(instance) {
		return instance.vnode.shapeFlag & 4;
	}
	var isInSSRComponentSetup = false;
	function setupComponent(instance, isSSR = false, optimized = false) {
		isSSR && setInSSRSetupState(isSSR);
		const { props, children } = instance.vnode;
		const isStateful = isStatefulComponent(instance);
		initProps(instance, props, isStateful, isSSR);
		initSlots(instance, children, optimized || isSSR);
		const setupResult = isStateful ? setupStatefulComponent(instance, isSSR) : void 0;
		isSSR && setInSSRSetupState(false);
		return setupResult;
	}
	function setupStatefulComponent(instance, isSSR) {
		const Component = instance.type;
		instance.accessCache = Object.create(null);
		instance.proxy = new Proxy(instance.ctx, PublicInstanceProxyHandlers);
		const { setup } = Component;
		if (setup) {
			pauseTracking();
			const setupContext = instance.setupContext = setup.length > 1 ? createSetupContext(instance) : null;
			const reset = setCurrentInstance(instance);
			const setupResult = callWithErrorHandling(setup, instance, 0, [instance.props, setupContext]);
			const isAsyncSetup = isPromise(setupResult);
			resetTracking();
			reset();
			if ((isAsyncSetup || instance.sp) && !isAsyncWrapper(instance)) markAsyncBoundary(instance);
			if (isAsyncSetup) {
				setupResult.then(unsetCurrentInstance, unsetCurrentInstance);
				if (isSSR) return setupResult.then((resolvedResult) => {
					setInSSRSetupState(true);
					try {
						handleSetupResult(instance, resolvedResult, isSSR);
					} finally {
						setInSSRSetupState(false);
					}
				}).catch((e) => {
					handleError(e, instance, 0);
				});
				else instance.asyncDep = setupResult;
			} else handleSetupResult(instance, setupResult, isSSR);
		} else finishComponentSetup(instance, isSSR);
	}
	function handleSetupResult(instance, setupResult, isSSR) {
		if (isFunction(setupResult)) {
			if (instance.type.__ssrInlineRender) instance.ssrRender = setupResult;
			else instance.render = setupResult;
		} else if (isObject$1(setupResult)) instance.setupState = proxyRefs(setupResult);
		finishComponentSetup(instance, isSSR);
	}
	var compile$1;
	var installWithProxy;
	function registerRuntimeCompiler(_compile) {
		compile$1 = _compile;
		installWithProxy = (i) => {
			if (i.render._rc) i.withProxy = new Proxy(i.ctx, RuntimeCompiledPublicInstanceProxyHandlers);
		};
	}
	var isRuntimeOnly = () => !compile$1;
	function finishComponentSetup(instance, isSSR, skipOptions) {
		const Component = instance.type;
		if (!instance.render) {
			if (!isSSR && compile$1 && !Component.render) {
				const template = Component.template || resolveMergedOptions(instance).template;
				if (template) {
					const { isCustomElement, compilerOptions } = instance.appContext.config;
					const { delimiters, compilerOptions: componentCompilerOptions } = Component;
					const finalCompilerOptions = extend(extend({
						isCustomElement,
						delimiters
					}, compilerOptions), componentCompilerOptions);
					Component.render = compile$1(template, finalCompilerOptions);
				}
			}
			instance.render = Component.render || NOOP;
			if (installWithProxy) installWithProxy(instance);
		}
		{
			const reset = setCurrentInstance(instance);
			pauseTracking();
			try {
				applyOptions(instance);
			} finally {
				resetTracking();
				reset();
			}
		}
	}
	var attrsProxyHandlers = { get(target, key) {
		track(target, "get", "");
		return target[key];
	} };
	function createSetupContext(instance) {
		const expose = (exposed) => {
			instance.exposed = exposed || {};
		};
		return {
			attrs: new Proxy(instance.attrs, attrsProxyHandlers),
			slots: instance.slots,
			emit: instance.emit,
			expose
		};
	}
	function getComponentPublicInstance(instance) {
		if (instance.exposed) return instance.exposeProxy || (instance.exposeProxy = new Proxy(proxyRefs(markRaw(instance.exposed)), {
			get(target, key) {
				if (key in target) return target[key];
				else if (key in publicPropertiesMap) return publicPropertiesMap[key](instance);
			},
			has(target, key) {
				return key in target || key in publicPropertiesMap;
			}
		}));
		else return instance.proxy;
	}
	function getComponentName(Component, includeInferred = true) {
		return isFunction(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
	}
	function isClassComponent(value) {
		return isFunction(value) && "__vccOpts" in value;
	}
	var computed = (getterOrOptions, debugOptions) => {
		return computed$1(getterOrOptions, debugOptions, isInSSRComponentSetup);
	};
	function h(type, propsOrChildren, children) {
		try {
			setBlockTracking(-1);
			const l = arguments.length;
			if (l === 2) {
				if (isObject$1(propsOrChildren) && !isArray(propsOrChildren)) {
					if (isVNode(propsOrChildren)) return createVNode(type, null, [propsOrChildren]);
					return createVNode(type, propsOrChildren);
				} else return createVNode(type, null, propsOrChildren);
			} else {
				if (l > 3) children = Array.prototype.slice.call(arguments, 2);
				else if (l === 3 && isVNode(children)) children = [children];
				return createVNode(type, propsOrChildren, children);
			}
		} finally {
			setBlockTracking(1);
		}
	}
	function initCustomFormatter() {}
	function withMemo(memo, render, cache, index) {
		const cached = cache[index];
		if (cached && isMemoSame(cached, memo)) return cached;
		const ret = render();
		ret.memo = memo.slice();
		ret.cacheIndex = index;
		return cache[index] = ret;
	}
	function isMemoSame(cached, memo) {
		const prev = cached.memo;
		if (prev.length != memo.length) return false;
		for (let i = 0; i < prev.length; i++) if (hasChanged(prev[i], memo[i])) return false;
		if (isBlockTreeEnabled > 0 && currentBlock) currentBlock.push(cached);
		return true;
	}
	var version = "3.5.44";
	var warn = NOOP;
	var ErrorTypeStrings = ErrorTypeStrings$1;
	var devtools = devtools$1;
	var setDevtoolsHook = setDevtoolsHook$1;
	var ssrUtils = {
		createComponentInstance,
		setupComponent,
		renderComponentRoot,
		setCurrentRenderingInstance,
		isVNode,
		normalizeVNode,
		getComponentPublicInstance,
		ensureValidVNode,
		pushWarningContext,
		popWarningContext
	};
	var policy = void 0;
	var tt = typeof window !== "undefined" && window.trustedTypes;
	if (tt) try {
		policy = tt.createPolicy("vue", { createHTML: (val) => val });
	} catch (e) {}
	var unsafeToTrustedHTML = policy ? (val) => policy.createHTML(val) : (val) => val;
	var svgNS = "http://www.w3.org/2000/svg";
	var mathmlNS = "http://www.w3.org/1998/Math/MathML";
	var doc = typeof document !== "undefined" ? document : null;
	var templateContainer = doc && doc.createElement("template");
	var nodeOps = {
		insert: (child, parent, anchor) => {
			parent.insertBefore(child, anchor || null);
		},
		remove: (child) => {
			const parent = child.parentNode;
			if (parent) parent.removeChild(child);
		},
		createElement: (tag, namespace, is, props) => {
			const el = namespace === "svg" ? doc.createElementNS(svgNS, tag) : namespace === "mathml" ? doc.createElementNS(mathmlNS, tag) : is ? doc.createElement(tag, { is }) : doc.createElement(tag);
			if (tag === "select" && props && props.multiple != null) el.setAttribute("multiple", props.multiple);
			return el;
		},
		createText: (text) => doc.createTextNode(text),
		createComment: (text) => doc.createComment(text),
		setText: (node, text) => {
			node.nodeValue = text;
		},
		setElementText: (el, text) => {
			el.textContent = text;
		},
		parentNode: (node) => node.parentNode,
		nextSibling: (node) => node.nextSibling,
		querySelector: (selector) => doc.querySelector(selector),
		setScopeId(el, id) {
			el.setAttribute(id, "");
		},
		insertStaticContent(content, parent, anchor, namespace, start, end) {
			const before = anchor ? anchor.previousSibling : parent.lastChild;
			if (start && (start === end || start.nextSibling)) while (true) {
				parent.insertBefore(start.cloneNode(true), anchor);
				if (start === end || !(start = start.nextSibling)) break;
			}
			else {
				templateContainer.innerHTML = unsafeToTrustedHTML(namespace === "svg" ? `<svg>${content}</svg>` : namespace === "mathml" ? `<math>${content}</math>` : content);
				const template = templateContainer.content;
				if (namespace === "svg" || namespace === "mathml") {
					const wrapper = template.firstChild;
					while (wrapper.firstChild) template.appendChild(wrapper.firstChild);
					template.removeChild(wrapper);
				}
				parent.insertBefore(template, anchor);
			}
			return [before ? before.nextSibling : parent.firstChild, anchor ? anchor.previousSibling : parent.lastChild];
		}
	};
	var TRANSITION = "transition";
	var ANIMATION = "animation";
	var vtcKey = Symbol("_vtc");
	var DOMTransitionPropsValidators = {
		name: String,
		type: String,
		css: {
			type: Boolean,
			default: true
		},
		duration: [
			String,
			Number,
			Object
		],
		enterFromClass: String,
		enterActiveClass: String,
		enterToClass: String,
		appearFromClass: String,
		appearActiveClass: String,
		appearToClass: String,
		leaveFromClass: String,
		leaveActiveClass: String,
		leaveToClass: String
	};
	var TransitionPropsValidators = extend({}, BaseTransitionPropsValidators, DOMTransitionPropsValidators);
	var decorate$1 = (t) => {
		t.displayName = "Transition";
		t.props = TransitionPropsValidators;
		return t;
	};
	var Transition = decorate$1((props, { slots }) => h(BaseTransition, resolveTransitionProps(props), slots));
	var callHook = (hook, args = []) => {
		if (isArray(hook)) hook.forEach((h2) => h2(...args));
		else if (hook) hook(...args);
	};
	var hasExplicitCallback = (hook) => {
		return hook ? isArray(hook) ? hook.some((h2) => h2.length > 1) : hook.length > 1 : false;
	};
	function resolveTransitionProps(rawProps) {
		const baseProps = {};
		for (const key in rawProps) if (!(key in DOMTransitionPropsValidators)) baseProps[key] = rawProps[key];
		if (rawProps.css === false) return baseProps;
		const { name = "v", type, duration, enterFromClass = `${name}-enter-from`, enterActiveClass = `${name}-enter-active`, enterToClass = `${name}-enter-to`, appearFromClass = enterFromClass, appearActiveClass = enterActiveClass, appearToClass = enterToClass, leaveFromClass = `${name}-leave-from`, leaveActiveClass = `${name}-leave-active`, leaveToClass = `${name}-leave-to` } = rawProps;
		const durations = normalizeDuration(duration);
		const enterDuration = durations && durations[0];
		const leaveDuration = durations && durations[1];
		const { onBeforeEnter, onEnter, onEnterCancelled, onLeave, onLeaveCancelled, onBeforeAppear = onBeforeEnter, onAppear = onEnter, onAppearCancelled = onEnterCancelled } = baseProps;
		const finishEnter = (el, isAppear, done, isCancelled) => {
			el._enterCancelled = isCancelled;
			removeTransitionClass(el, isAppear ? appearToClass : enterToClass);
			removeTransitionClass(el, isAppear ? appearActiveClass : enterActiveClass);
			done && done();
		};
		const finishLeave = (el, done) => {
			el._isLeaving = false;
			removeTransitionClass(el, leaveFromClass);
			removeTransitionClass(el, leaveToClass);
			removeTransitionClass(el, leaveActiveClass);
			done && done();
		};
		const makeEnterHook = (isAppear) => {
			return (el, done) => {
				const hook = isAppear ? onAppear : onEnter;
				const resolve = () => finishEnter(el, isAppear, done);
				callHook(hook, [el, resolve]);
				nextFrame(() => {
					removeTransitionClass(el, isAppear ? appearFromClass : enterFromClass);
					addTransitionClass(el, isAppear ? appearToClass : enterToClass);
					if (!hasExplicitCallback(hook)) whenTransitionEnds(el, type, enterDuration, resolve);
				});
			};
		};
		return extend(baseProps, {
			onBeforeEnter(el) {
				callHook(onBeforeEnter, [el]);
				addTransitionClass(el, enterFromClass);
				addTransitionClass(el, enterActiveClass);
			},
			onBeforeAppear(el) {
				callHook(onBeforeAppear, [el]);
				addTransitionClass(el, appearFromClass);
				addTransitionClass(el, appearActiveClass);
			},
			onEnter: makeEnterHook(false),
			onAppear: makeEnterHook(true),
			onLeave(el, done) {
				el._isLeaving = true;
				const resolve = () => finishLeave(el, done);
				addTransitionClass(el, leaveFromClass);
				if (!el._enterCancelled) {
					forceReflow(el);
					addTransitionClass(el, leaveActiveClass);
				} else {
					addTransitionClass(el, leaveActiveClass);
					forceReflow(el);
				}
				nextFrame(() => {
					if (!el._isLeaving) return;
					removeTransitionClass(el, leaveFromClass);
					addTransitionClass(el, leaveToClass);
					if (!hasExplicitCallback(onLeave)) whenTransitionEnds(el, type, leaveDuration, resolve);
				});
				callHook(onLeave, [el, resolve]);
			},
			onEnterCancelled(el) {
				finishEnter(el, false, void 0, true);
				callHook(onEnterCancelled, [el]);
			},
			onAppearCancelled(el) {
				finishEnter(el, true, void 0, true);
				callHook(onAppearCancelled, [el]);
			},
			onLeaveCancelled(el) {
				finishLeave(el);
				callHook(onLeaveCancelled, [el]);
			}
		});
	}
	function normalizeDuration(duration) {
		if (duration == null) return null;
		else if (isObject$1(duration)) return [NumberOf(duration.enter), NumberOf(duration.leave)];
		else {
			const n = NumberOf(duration);
			return [n, n];
		}
	}
	function NumberOf(val) {
		return toNumber(val);
	}
	function addTransitionClass(el, cls) {
		cls.split(/\s+/).forEach((c) => c && el.classList.add(c));
		(el[vtcKey] || (el[vtcKey] = new Set())).add(cls);
	}
	function removeTransitionClass(el, cls) {
		cls.split(/\s+/).forEach((c) => c && el.classList.remove(c));
		const _vtc = el[vtcKey];
		if (_vtc) {
			_vtc.delete(cls);
			if (!_vtc.size) el[vtcKey] = void 0;
		}
	}
	function nextFrame(cb) {
		requestAnimationFrame(() => {
			requestAnimationFrame(cb);
		});
	}
	var endId = 0;
	function whenTransitionEnds(el, expectedType, explicitTimeout, resolve) {
		const id = el._endId = ++endId;
		const resolveIfNotStale = () => {
			if (id === el._endId) resolve();
		};
		if (explicitTimeout != null) return setTimeout(resolveIfNotStale, explicitTimeout);
		const { type, timeout, propCount } = getTransitionInfo(el, expectedType);
		if (!type) return resolve();
		const endEvent = type + "end";
		let ended = 0;
		const end = () => {
			el.removeEventListener(endEvent, onEnd);
			resolveIfNotStale();
		};
		const onEnd = (e) => {
			if (e.target === el && ++ended >= propCount) end();
		};
		setTimeout(() => {
			if (ended < propCount) end();
		}, timeout + 1);
		el.addEventListener(endEvent, onEnd);
	}
	function getTransitionInfo(el, expectedType) {
		const styles = window.getComputedStyle(el);
		const getStyleProperties = (key) => (styles[key] || "").split(", ");
		const transitionDelays = getStyleProperties(`${TRANSITION}Delay`);
		const transitionDurations = getStyleProperties(`${TRANSITION}Duration`);
		const transitionTimeout = getTimeout(transitionDelays, transitionDurations);
		const animationDelays = getStyleProperties(`${ANIMATION}Delay`);
		const animationDurations = getStyleProperties(`${ANIMATION}Duration`);
		const animationTimeout = getTimeout(animationDelays, animationDurations);
		let type = null;
		let timeout = 0;
		let propCount = 0;
		if (expectedType === TRANSITION) {
			if (transitionTimeout > 0) {
				type = TRANSITION;
				timeout = transitionTimeout;
				propCount = transitionDurations.length;
			}
		} else if (expectedType === ANIMATION) {
			if (animationTimeout > 0) {
				type = ANIMATION;
				timeout = animationTimeout;
				propCount = animationDurations.length;
			}
		} else {
			timeout = Math.max(transitionTimeout, animationTimeout);
			type = timeout > 0 ? transitionTimeout > animationTimeout ? TRANSITION : ANIMATION : null;
			propCount = type ? type === TRANSITION ? transitionDurations.length : animationDurations.length : 0;
		}
		const hasTransform = type === TRANSITION && /\b(?:transform|all)(?:,|$)/.test(getStyleProperties(`${TRANSITION}Property`).toString());
		return {
			type,
			timeout,
			propCount,
			hasTransform
		};
	}
	function getTimeout(delays, durations) {
		while (delays.length < durations.length) delays = delays.concat(delays);
		return Math.max(...durations.map((d, i) => toMs(d) + toMs(delays[i])));
	}
	function toMs(s) {
		if (s === "auto") return 0;
		return Number(s.slice(0, -1).replace(",", ".")) * 1e3;
	}
	function forceReflow(el) {
		return (el ? el.ownerDocument : document).body.offsetHeight;
	}
	function patchClass(el, value, isSVG) {
		const transitionClasses = el[vtcKey];
		if (transitionClasses) value = (value ? [value, ...transitionClasses] : [...transitionClasses]).join(" ");
		if (value == null) el.removeAttribute("class");
		else if (isSVG) el.setAttribute("class", value);
		else el.className = value;
	}
	var vShowOriginalDisplay = Symbol("_vod");
	var vShowHidden = Symbol("_vsh");
	var vShow = {
		name: "show",
		beforeMount(el, { value }, { transition }) {
			el[vShowOriginalDisplay] = el.style.display === "none" ? "" : el.style.display;
			if (transition && value) transition.beforeEnter(el);
			else setDisplay(el, value);
		},
		mounted(el, { value }, { transition }) {
			if (transition && value) transition.enter(el);
		},
		updated(el, { value, oldValue }, { transition }) {
			if (!value === !oldValue) return;
			if (transition) {
				if (value) {
					transition.beforeEnter(el);
					setDisplay(el, true);
					transition.enter(el);
				} else transition.leave(el, () => {
					setDisplay(el, false);
				});
			} else setDisplay(el, value);
		},
		beforeUnmount(el, { value }) {
			setDisplay(el, value);
		}
	};
	function setDisplay(el, value) {
		el.style.display = value ? el[vShowOriginalDisplay] : "none";
		el[vShowHidden] = !value;
	}
	function initVShowForSSR() {
		vShow.getSSRProps = ({ value }) => {
			if (!value) return { style: { display: "none" } };
		};
	}
	var CSS_VAR_TEXT = Symbol("");
	function useCssVars(getter) {
		const instance = getCurrentInstance();
		if (!instance) return;
		const updateTeleports = instance.ut = (vars = getter(instance.proxy)) => {
			Array.from(document.querySelectorAll(`[data-v-owner="${instance.uid}"]`)).forEach((node) => setVarsOnNode(node, vars));
		};
		const setVars = () => {
			const vars = getter(instance.proxy);
			if (instance.ce) setVarsOnNode(instance.ce, vars);
			else setVarsOnVNode(instance.subTree, vars);
			updateTeleports(vars);
		};
		onBeforeUpdate(() => {
			queuePostFlushCb(setVars);
		});
		onMounted(() => {
			watch(setVars, NOOP, { flush: "post" });
			const ob = new MutationObserver(setVars);
			ob.observe(instance.subTree.el.parentNode, { childList: true });
			onUnmounted(() => ob.disconnect());
		});
	}
	function setVarsOnVNode(vnode, vars) {
		if (vnode.shapeFlag & 128) {
			const suspense = vnode.suspense;
			vnode = suspense.activeBranch;
			if (suspense.pendingBranch && !suspense.isHydrating) suspense.effects.push(() => {
				setVarsOnVNode(suspense.activeBranch, vars);
			});
		}
		while (vnode.component) vnode = vnode.component.subTree;
		if (vnode.shapeFlag & 1 && vnode.el) setVarsOnNode(vnode.el, vars);
		else if (vnode.type === Fragment) vnode.children.forEach((c) => setVarsOnVNode(c, vars));
		else if (vnode.type === Static) {
			let { el, anchor } = vnode;
			while (el) {
				setVarsOnNode(el, vars);
				if (el === anchor) break;
				el = el.nextSibling;
			}
		}
	}
	function setVarsOnNode(el, vars) {
		if (el.nodeType === 1) {
			const style = el.style;
			let cssText = "";
			for (const key in vars) {
				const value = normalizeCssVarValue(vars[key]);
				style.setProperty(`--${key}`, value);
				cssText += `--${key}: ${value};`;
			}
			style[CSS_VAR_TEXT] = cssText;
		}
	}
	var displayRE = /(?:^|;)\s*display\s*:/;
	function patchStyle(el, prev, next) {
		const style = el.style;
		const isCssString = isString(next);
		let hasControlledDisplay = false;
		if (next && !isCssString) {
			if (prev) {
				if (!isString(prev)) {
					for (const key in prev) if (next[key] == null) setStyle(style, key, "");
				} else for (const prevStyle of prev.split(";")) {
					const key = prevStyle.slice(0, prevStyle.indexOf(":")).trim();
					if (next[key] == null) setStyle(style, key, "");
				}
			}
			for (const key in next) {
				if (key === "display") hasControlledDisplay = true;
				const value = next[key];
				if (value != null) {
					if (!shouldPreserveTextareaResizeStyle(el, key, !isString(prev) && prev ? prev[key] : void 0, value)) setStyle(style, key, value);
				} else setStyle(style, key, "");
			}
		} else if (isCssString) {
			if (prev !== next) {
				const cssVarText = style[CSS_VAR_TEXT];
				if (cssVarText) next += ";" + cssVarText;
				style.cssText = next;
				hasControlledDisplay = displayRE.test(next);
			}
		} else if (prev) el.removeAttribute("style");
		if (vShowOriginalDisplay in el) {
			if (!isCssString || prev !== next) el[vShowOriginalDisplay] = hasControlledDisplay ? style.display : "";
			if (el[vShowHidden]) style.display = "none";
		}
	}
	var importantRE = /\s*!important$/;
	function setStyle(style, name, val) {
		if (isArray(val)) val.forEach((v) => setStyle(style, name, v));
		else {
			if (val == null) val = "";
			if (name.startsWith("--")) {
				if (importantRE.test(val)) style.setProperty(name, val.replace(importantRE, ""), "important");
				else style.setProperty(name, val);
			} else {
				const prefixed = autoPrefix(style, name);
				if (importantRE.test(val)) style.setProperty(hyphenate$1(prefixed), val.replace(importantRE, ""), "important");
				else style[prefixed] = val;
			}
		}
	}
	var prefixes = [
		"Webkit",
		"Moz",
		"ms"
	];
	var prefixCache = {};
	function autoPrefix(style, rawName) {
		const cached = prefixCache[rawName];
		if (cached) return cached;
		let name = camelize$1(rawName);
		if (name !== "filter" && name in style) return prefixCache[rawName] = name;
		name = capitalize(name);
		for (let i = 0; i < prefixes.length; i++) {
			const prefixed = prefixes[i] + name;
			if (prefixed in style) return prefixCache[rawName] = prefixed;
		}
		return rawName;
	}
	function shouldPreserveTextareaResizeStyle(el, key, prev, next) {
		return el.tagName === "TEXTAREA" && (key === "width" || key === "height") && isString(next) && prev === next;
	}
	var xlinkNS = "http://www.w3.org/1999/xlink";
	function patchAttr(el, key, value, isSVG, instance, isBoolean = isSpecialBooleanAttr(key)) {
		if (isSVG && key.startsWith("xlink:")) {
			if (value == null) el.removeAttributeNS(xlinkNS, key.slice(6, key.length));
			else el.setAttributeNS(xlinkNS, key, value);
		} else if (value == null || isBoolean && !includeBooleanAttr(value)) el.removeAttribute(key);
		else el.setAttribute(key, isBoolean ? "" : isSymbol(value) ? String(value) : value);
	}
	function patchDOMProp(el, key, value, parentComponent, attrName) {
		if (key === "innerHTML" || key === "textContent") {
			if (value != null) el[key] = key === "innerHTML" ? unsafeToTrustedHTML(value) : value;
			return;
		}
		const tag = el.tagName;
		if (key === "value" && tag !== "PROGRESS" && !tag.includes("-")) {
			const oldValue = tag === "OPTION" ? el.getAttribute("value") || "" : el.value;
			const newValue = value == null ? el.type === "checkbox" ? "on" : "" : String(value);
			if (oldValue !== newValue || !("_value" in el)) el.value = newValue;
			if (value == null) el.removeAttribute(key);
			el._value = value;
			return;
		}
		let needRemove = false;
		if (value === "" || value == null) {
			const type = typeof el[key];
			if (type === "boolean") value = includeBooleanAttr(value);
			else if (value == null && type === "string") {
				value = "";
				needRemove = true;
			} else if (type === "number") {
				value = 0;
				needRemove = true;
			}
		}
		try {
			el[key] = value;
		} catch (e) {}
		needRemove && el.removeAttribute(attrName || key);
	}
	function addEventListener(el, event, handler, options) {
		el.addEventListener(event, handler, options);
	}
	function removeEventListener(el, event, handler, options) {
		el.removeEventListener(event, handler, options);
	}
	var veiKey = Symbol("_vei");
	function patchEvent(el, rawName, prevValue, nextValue, instance = null) {
		const invokers = el[veiKey] || (el[veiKey] = {});
		const existingInvoker = invokers[rawName];
		if (nextValue && existingInvoker) existingInvoker.value = nextValue;
		else {
			const [name, options] = parseName(rawName);
			if (nextValue) addEventListener(el, name, invokers[rawName] = createInvoker(nextValue, instance), options);
			else if (existingInvoker) {
				removeEventListener(el, name, existingInvoker, options);
				invokers[rawName] = void 0;
			}
		}
	}
	var optionsModifierRE = /(Once|Passive|Capture)$/;
	var optionsModifierEventRE = /^on:?(?:Once|Passive|Capture)$/;
	function parseName(name) {
		let options;
		let m;
		while ((m = name.match(optionsModifierRE)) && !optionsModifierEventRE.test(name)) {
			if (!options) options = {};
			name = name.slice(0, name.length - m[1].length);
			options[m[1].toLowerCase()] = true;
		}
		return [name[2] === ":" ? name.slice(3) : hyphenate$1(name.slice(2)), options];
	}
	var cachedNow = 0;
	var p = Promise.resolve();
	var getNow = () => cachedNow || (p.then(() => cachedNow = 0), cachedNow = Date.now());
	function createInvoker(initialValue, instance) {
		const invoker = (e) => {
			if (!e._vts) e._vts = Date.now();
			else if (e._vts <= invoker.attached) return;
			const value = invoker.value;
			if (isArray(value)) {
				const originalStop = e.stopImmediatePropagation;
				e.stopImmediatePropagation = () => {
					originalStop.call(e);
					e._stopped = true;
				};
				const handlers = value.slice();
				const args = [e];
				for (let i = 0; i < handlers.length; i++) {
					if (e._stopped) break;
					const handler = handlers[i];
					if (handler) callWithAsyncErrorHandling(handler, instance, 5, args);
				}
			} else callWithAsyncErrorHandling(value, instance, 5, [e]);
		};
		invoker.value = initialValue;
		invoker.attached = getNow();
		return invoker;
	}
	var isNativeOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && key.charCodeAt(2) > 96 && key.charCodeAt(2) < 123;
	var patchProp = (el, key, prevValue, nextValue, namespace, parentComponent) => {
		const isSVG = namespace === "svg";
		if (key === "class") patchClass(el, nextValue, isSVG);
		else if (key === "style") patchStyle(el, prevValue, nextValue);
		else if (isOn(key)) {
			if (!isModelListener(key)) patchEvent(el, key, prevValue, nextValue, parentComponent);
		} else if (key[0] === "." ? (key = key.slice(1), true) : key[0] === "^" ? (key = key.slice(1), false) : shouldSetAsProp(el, key, nextValue, isSVG)) {
			patchDOMProp(el, key, nextValue);
			if (!el.tagName.includes("-") && (key === "value" || key === "checked" || key === "selected")) patchAttr(el, key, nextValue, isSVG, parentComponent, key !== "value");
		} else if (el._isVueCE && (shouldSetAsPropForVueCE(el, key) || el._def.__asyncLoader && (/[A-Z]/.test(key) || !isString(nextValue)))) patchDOMProp(el, camelize$1(key), nextValue, parentComponent, key);
		else {
			if (key === "true-value") el._trueValue = nextValue;
			else if (key === "false-value") el._falseValue = nextValue;
			patchAttr(el, key, nextValue, isSVG);
		}
	};
	function shouldSetAsProp(el, key, value, isSVG) {
		if (isSVG) {
			if (key === "innerHTML" || key === "textContent") return true;
			if (key in el && isNativeOn(key) && isFunction(value)) return true;
			return false;
		}
		if (key === "spellcheck" || key === "draggable" || key === "translate" || key === "autocorrect") return false;
		if (key === "sandbox" && el.tagName === "IFRAME") return false;
		if (key === "form") return false;
		if (key === "list" && el.tagName === "INPUT") return false;
		if (key === "type" && el.tagName === "TEXTAREA") return false;
		if (key === "width" || key === "height") {
			const tag = el.tagName;
			if (tag === "IMG" || tag === "VIDEO" || tag === "CANVAS" || tag === "SOURCE") return false;
		}
		if (isNativeOn(key) && isString(value)) return false;
		return key in el;
	}
	function shouldSetAsPropForVueCE(el, key) {
		const props = el._def.props;
		if (!props) return false;
		const camelKey = camelize$1(key);
		return Array.isArray(props) ? props.some((prop) => camelize$1(prop) === camelKey) : Object.keys(props).some((prop) => camelize$1(prop) === camelKey);
	}
	var REMOVAL = {};
	function defineCustomElement(options, extraOptions, _createApp) {
		let Comp = defineComponent(options, extraOptions);
		if (isPlainObject$1(Comp)) Comp = extend({}, Comp, extraOptions);
		class VueCustomElement extends VueElement {
			constructor(initialProps) {
				super(Comp, initialProps, _createApp);
			}
		}
		VueCustomElement.def = Comp;
		return VueCustomElement;
	}
	var defineSSRCustomElement = ((options, extraOptions) => {
		return defineCustomElement(options, extraOptions, createSSRApp);
	});
	var BaseClass = typeof HTMLElement !== "undefined" ? HTMLElement : class {};
	var VueElement = class VueElement extends BaseClass {
		constructor(_def, _props = {}, _createApp = createApp) {
			super();
			this._def = _def;
			this._props = _props;
			this._createApp = _createApp;
			this._isVueCE = true;
			this._instance = null;
			this._app = null;
			this._nonce = this._def.nonce;
			this._connected = false;
			this._resolved = false;
			this._patching = false;
			this._dirty = false;
			this._numberProps = null;
			this._styleChildren = new WeakSet();
			this._styleAnchors = new WeakMap();
			this._ob = null;
			if (this.shadowRoot && _createApp !== createApp) this._root = this.shadowRoot;
			else if (_def.shadowRoot !== false) {
				this.attachShadow(extend({}, _def.shadowRootOptions, { mode: "open" }));
				this._root = this.shadowRoot;
			} else this._root = this;
		}
		connectedCallback() {
			if (!this.isConnected) return;
			if (!this.shadowRoot && !this._resolved) this._parseSlots();
			this._connected = true;
			let parent = this;
			while (parent = parent && (parent.assignedSlot || parent.parentNode || parent.host)) if (parent instanceof VueElement) {
				this._parent = parent;
				break;
			}
			if (!this._instance) {
				if (this._resolved) this._mount(this._def);
				else if (parent && parent._pendingResolve) this._pendingResolve = parent._pendingResolve.then(() => {
					this._pendingResolve = void 0;
					if (this.isConnected) return this._resolveDef();
				});
				else this._resolveDef();
			}
		}
		_setParent(parent = this._parent) {
			if (parent) {
				this._instance.parent = parent._instance;
				this._inheritParentContext(parent);
			}
		}
		_inheritParentContext(parent = this._parent) {
			if (parent && this._app) Object.setPrototypeOf(this._app._context.provides, parent._instance.provides);
		}
		disconnectedCallback() {
			this._connected = false;
			nextTick(() => {
				if (!this._connected) {
					if (this._ob) {
						this._ob.disconnect();
						this._ob = null;
					}
					this._app && this._app.unmount();
					if (this._instance) this._instance.ce = void 0;
					this._app = this._instance = null;
					if (this._teleportTargets) {
						this._teleportTargets.clear();
						this._teleportTargets = void 0;
					}
				}
			});
		}
		_processMutations(mutations) {
			for (const m of mutations) this._setAttr(m.attributeName);
		}
		_resolveDef() {
			if (this._pendingResolve) return this._pendingResolve;
			for (let i = 0; i < this.attributes.length; i++) this._setAttr(this.attributes[i].name);
			this._ob = new MutationObserver(this._processMutations.bind(this));
			this._ob.observe(this, { attributes: true });
			const resolve = (def, isAsync = false) => {
				this._resolved = true;
				this._pendingResolve = void 0;
				const { props, styles } = def;
				let numberProps;
				if (props && !isArray(props)) for (const key in props) {
					const opt = props[key];
					if (opt === Number || opt && opt.type === Number) {
						if (key in this._props) this._props[key] = toNumber(this._props[key]);
						(numberProps || (numberProps = Object.create(null)))[camelize$1(key)] = true;
					}
				}
				this._numberProps = numberProps;
				this._resolveProps(def);
				if (this.shadowRoot) this._applyStyles(styles);
				if (this._connected) this._mount(def);
			};
			const asyncDef = this._def.__asyncLoader;
			if (asyncDef) {
				this._pendingResolve = asyncDef().then((def) => {
					def.configureApp = this._def.configureApp;
					resolve(this._def = def, true);
				});
				return this._pendingResolve;
			} else resolve(this._def);
		}
		_mount(def) {
			this._app = this._createApp(def);
			this._inheritParentContext();
			if (def.configureApp) def.configureApp(this._app);
			this._app._ceVNode = this._createVNode();
			this._app.mount(this._root);
			const exposed = this._instance && this._instance.exposed;
			if (!exposed) return;
			for (const key in exposed) if (!hasOwn(this, key)) Object.defineProperty(this, key, { get: () => unref(exposed[key]) });
		}
		_resolveProps(def) {
			const { props } = def;
			const declaredPropKeys = isArray(props) ? props : Object.keys(props || {});
			for (const key of Object.keys(this)) if (key[0] !== "_" && declaredPropKeys.includes(key)) this._setProp(key, this[key]);
			for (const key of declaredPropKeys.map(camelize$1)) Object.defineProperty(this, key, {
				get() {
					return this._getProp(key);
				},
				set(val) {
					this._setProp(key, val, true, !this._patching);
				}
			});
		}
		_setAttr(key) {
			if (key.startsWith("data-v-")) return;
			const has = this.hasAttribute(key);
			let value = has ? this.getAttribute(key) : REMOVAL;
			const camelKey = camelize$1(key);
			if (has && this._numberProps && this._numberProps[camelKey]) value = toNumber(value);
			this._setProp(camelKey, value, false, true);
		}
		_getProp(key) {
			return this._props[key];
		}
		_setProp(key, val, shouldReflect = true, shouldUpdate = false) {
			if (val !== this._props[key]) {
				this._dirty = true;
				if (val === REMOVAL) delete this._props[key];
				else {
					this._props[key] = val;
					if (key === "key" && this._app) this._app._ceVNode.key = val;
				}
				if (shouldUpdate && this._instance) this._update();
				if (shouldReflect) {
					const ob = this._ob;
					if (ob) {
						this._processMutations(ob.takeRecords());
						ob.disconnect();
					}
					if (val === true) this.setAttribute(hyphenate$1(key), "");
					else if (typeof val === "string" || typeof val === "number") this.setAttribute(hyphenate$1(key), val + "");
					else if (!val) this.removeAttribute(hyphenate$1(key));
					ob && ob.observe(this, { attributes: true });
				}
			}
		}
		_update() {
			const vnode = this._createVNode();
			if (this._app) vnode.appContext = this._app._context;
			render$1(vnode, this._root);
		}
		_createVNode() {
			const baseProps = {};
			if (!this.shadowRoot) baseProps.onVnodeMounted = baseProps.onVnodeUpdated = this._renderSlots.bind(this);
			const vnode = createVNode(this._def, extend(baseProps, this._props));
			if (!this._instance) vnode.ce = (instance) => {
				this._instance = instance;
				instance.ce = this;
				instance.isCE = true;
				const dispatch = (event, args) => {
					this.dispatchEvent(new CustomEvent(event, isPlainObject$1(args[0]) ? extend({ detail: args }, args[0]) : { detail: args }));
				};
				instance.emit = (event, ...args) => {
					dispatch(event, args);
					if (hyphenate$1(event) !== event) dispatch(hyphenate$1(event), args);
				};
				this._setParent();
			};
			return vnode;
		}
		_applyStyles(styles, owner, parentComp) {
			if (!styles) return;
			if (owner) {
				if (owner === this._def || this._styleChildren.has(owner)) return;
				this._styleChildren.add(owner);
			}
			const nonce = this._nonce;
			const root = this.shadowRoot;
			const insertionAnchor = parentComp ? this._getStyleAnchor(parentComp) || this._getStyleAnchor(this._def) : this._getRootStyleInsertionAnchor(root);
			let last = null;
			for (let i = styles.length - 1; i >= 0; i--) {
				const s = document.createElement("style");
				if (nonce) s.setAttribute("nonce", nonce);
				s.textContent = styles[i];
				root.insertBefore(s, last || insertionAnchor);
				last = s;
				if (i === 0) {
					if (!parentComp) this._styleAnchors.set(this._def, s);
					if (owner) this._styleAnchors.set(owner, s);
				}
			}
		}
		_getStyleAnchor(comp) {
			if (!comp) return null;
			const anchor = this._styleAnchors.get(comp);
			if (anchor && anchor.parentNode === this.shadowRoot) return anchor;
			if (anchor) this._styleAnchors.delete(comp);
			return null;
		}
		_getRootStyleInsertionAnchor(root) {
			for (let i = 0; i < root.childNodes.length; i++) {
				const node = root.childNodes[i];
				if (!(node instanceof HTMLStyleElement)) return node;
			}
			return null;
		}
		_parseSlots() {
			const slots = this._slots = {};
			let n;
			while (n = this.firstChild) {
				const slotName = n.nodeType === 1 && n.getAttribute("slot") || "default";
				(slots[slotName] || (slots[slotName] = [])).push(n);
				this.removeChild(n);
			}
		}
		_renderSlots() {
			const outlets = this._getSlots();
			const scopeId = this._instance.type.__scopeId;
			for (let i = 0; i < outlets.length; i++) {
				const o = outlets[i];
				const slotName = o.getAttribute("name") || "default";
				const content = this._slots[slotName];
				const parent = o.parentNode;
				if (content) for (const n of content) {
					if (scopeId && n.nodeType === 1) {
						const id = scopeId + "-s";
						const walker = document.createTreeWalker(n, 1);
						n.setAttribute(id, "");
						let child;
						while (child = walker.nextNode()) child.setAttribute(id, "");
					}
					parent.insertBefore(n, o);
				}
				else while (o.firstChild) parent.insertBefore(o.firstChild, o);
				parent.removeChild(o);
			}
		}
		_getSlots() {
			const roots = [this];
			if (this._teleportTargets) roots.push(...this._teleportTargets);
			const slots = new Set();
			for (const root of roots) {
				const found = root.querySelectorAll("slot");
				for (let i = 0; i < found.length; i++) slots.add(found[i]);
			}
			return Array.from(slots);
		}
		_injectChildStyle(comp, parentComp) {
			this._applyStyles(comp.styles, comp, parentComp);
		}
		_beginPatch() {
			this._patching = true;
			this._dirty = false;
		}
		_endPatch() {
			this._patching = false;
			if (this._dirty && this._instance) this._update();
		}
		_hasShadowRoot() {
			return this._def.shadowRoot !== false;
		}
		_removeChildStyle(comp) {}
	};
	function useHost(caller) {
		const instance = getCurrentInstance();
		const el = instance && instance.ce;
		if (el) return el;
		return null;
	}
	function useShadowRoot() {
		const el = useHost();
		return el && el.shadowRoot;
	}
	function useCssModule(name = "$style") {
		{
			const instance = getCurrentInstance();
			if (!instance) return EMPTY_OBJ;
			const modules = instance.type.__cssModules;
			if (!modules) return EMPTY_OBJ;
			const mod = modules[name];
			if (!mod) return EMPTY_OBJ;
			return mod;
		}
	}
	var positionMap = new WeakMap();
	var newPositionMap = new WeakMap();
	var moveCbKey = Symbol("_moveCb");
	var enterCbKey = Symbol("_enterCb");
	var pendingGroups = new WeakMap();
	var decorate = (t) => {
		delete t.props.mode;
		return t;
	};
	var TransitionGroup = decorate({
		name: "TransitionGroup",
		props: extend({}, TransitionPropsValidators, {
			tag: String,
			moveClass: String
		}),
		setup(props, { slots }) {
			const instance = getCurrentInstance();
			const state = useTransitionState();
			let prevChildren;
			let children;
			let origins;
			let moves;
			const willMove = () => {
				if (moves === void 0) moves = prevChildren.length > 0 && hasCSSTransform(prevChildren[0].el, instance.vnode.el, resolveMoveClass(props));
				return moves;
			};
			onUpdated(() => {
				pendingGroups.delete(instance);
				if (!willMove()) {
					prevChildren = [];
					origins = void 0;
					return;
				}
				const moveClass = resolveMoveClass(props);
				prevChildren.forEach(callPendingCbs);
				const shift = origins && getOriginShift(origins, instance.vnode.el);
				origins = void 0;
				prevChildren.forEach((c) => recordPosition(c, shift));
				const movedChildren = prevChildren.filter(applyTranslation);
				forceReflow(instance.vnode.el);
				movedChildren.forEach((c) => {
					const el = c.el;
					const style = el.style;
					addTransitionClass(el, moveClass);
					style.transform = style.webkitTransform = style.transitionDuration = "";
					const cb = el[moveCbKey] = (e) => {
						if (e && e.target !== el) return;
						if (!e || e.propertyName.endsWith("transform")) {
							el.removeEventListener("transitionend", cb);
							el[moveCbKey] = null;
							removeTransitionClass(el, moveClass);
						}
					};
					el.addEventListener("transitionend", cb);
				});
				prevChildren = [];
			});
			return () => {
				const rawProps = toRaw(props);
				const cssTransitionProps = resolveTransitionProps(rawProps);
				let tag = rawProps.tag || Fragment;
				prevChildren = [];
				moves = void 0;
				if (children) for (let i = 0; i < children.length; i++) {
					const child = children[i];
					if (child.el && child.el instanceof Element && !child.el[vShowHidden]) {
						prevChildren.push(child);
						setTransitionHooks(child, resolveTransitionHooks(child, cssTransitionProps, state, instance));
						positionMap.set(child, getPosition(child.el));
					}
				}
				children = slots.default ? getTransitionRawChildren(slots.default()) : [];
				for (let i = 0; i < children.length; i++) {
					const child = children[i];
					if (child.key != null) setTransitionHooks(child, resolveTransitionHooks(child, cssTransitionProps, state, instance));
				}
				if (prevChildren.length) {
					origins = getOrigins(instance);
					pendingGroups.set(instance, willMove);
				}
				return createVNode(tag, null, children);
			};
		}
	});
	function callPendingCbs(c) {
		const el = c.el;
		if (el[moveCbKey]) el[moveCbKey]();
		if (el[enterCbKey]) el[enterCbKey]();
	}
	function resolveMoveClass(props) {
		return props.moveClass || `${props.name || "v"}-move`;
	}
	function recordPosition(c, shift) {
		newPositionMap.set(c, getPosition(c.el, shift));
	}
	function applyTranslation(c) {
		const oldPos = positionMap.get(c);
		const newPos = newPositionMap.get(c);
		const dx = oldPos.left - newPos.left;
		const dy = oldPos.top - newPos.top;
		if (dx || dy) {
			const el = c.el;
			const s = el.style;
			const rect = el.getBoundingClientRect();
			let scaleX = 1;
			let scaleY = 1;
			if (el.offsetWidth) scaleX = rect.width / el.offsetWidth;
			if (el.offsetHeight) scaleY = rect.height / el.offsetHeight;
			if (!Number.isFinite(scaleX) || scaleX === 0) scaleX = 1;
			if (!Number.isFinite(scaleY) || scaleY === 0) scaleY = 1;
			if (Math.abs(scaleX - 1) < .01) scaleX = 1;
			if (Math.abs(scaleY - 1) < .01) scaleY = 1;
			s.transform = s.webkitTransform = `translate(${dx / scaleX}px,${dy / scaleY}px)`;
			s.transitionDuration = "0s";
			return c;
		}
	}
	function getPosition(el, shift) {
		const rect = el.getBoundingClientRect();
		return {
			left: rect.left - (shift ? shift.left : 0),
			top: rect.top - (shift ? shift.top : 0)
		};
	}
	function getOrigins(instance) {
		let origins;
		for (let group = instance.parent; group; group = group.parent) {
			const willMove = pendingGroups.get(group);
			if (willMove) {
				const item = findItem(group.vnode.el, instance.vnode.el);
				if (item) (origins || (origins = [])).push(extend(getPosition(item), {
					item,
					willMove
				}));
			}
		}
		return origins;
	}
	function findItem(root, node) {
		const container = root.nodeType === 1 ? root : root.parentNode;
		while (node && node.parentNode !== container) node = node.parentNode;
		if (node && node.nodeType === 1) return node;
	}
	function getOriginShift(origins, root) {
		const origin = origins.find((o) => o.willMove() && o.item.contains(root));
		return origin && getPosition(origin.item, origin);
	}
	function hasCSSTransform(el, root, moveClass) {
		const clone = el.cloneNode();
		const _vtc = el[vtcKey];
		if (_vtc) _vtc.forEach((cls) => {
			cls.split(/\s+/).forEach((c) => c && clone.classList.remove(c));
		});
		moveClass.split(/\s+/).forEach((c) => c && clone.classList.add(c));
		clone.style.display = "none";
		const container = root.nodeType === 1 ? root : root.parentNode;
		container.appendChild(clone);
		const { hasTransform } = getTransitionInfo(clone);
		container.removeChild(clone);
		return hasTransform;
	}
	var getModelAssigner = (vnode) => {
		const fn = vnode.props["onUpdate:modelValue"] || false;
		return isArray(fn) ? (value) => invokeArrayFns(fn, value) : fn;
	};
	function onCompositionStart(e) {
		e.target.composing = true;
	}
	function onCompositionEnd(e) {
		const target = e.target;
		if (target.composing) {
			target.composing = false;
			target.dispatchEvent(new Event("input"));
		}
	}
	var assignKey = Symbol("_assign");
	var initialValueKey = Symbol("_initialValue");
	function castValue(value, trim, number) {
		if (trim) value = value.trim();
		if (number) value = looseToNumber(value);
		return value;
	}
	var vModelText = {
		created(el, { modifiers: { lazy, trim, number } }, vnode) {
			if (el.parentNode) {
				if (el.type === "text") el[initialValueKey] = el.defaultValue.replace(/[\r\n]/g, "");
				else if (el.type === "textarea") el[initialValueKey] = el.defaultValue.replace(/\r\n?/g, "\n");
			}
			el[assignKey] = getModelAssigner(vnode);
			const castToNumber = number || vnode.props && vnode.props.type === "number";
			addEventListener(el, lazy ? "change" : "input", (e) => {
				if (e.target.composing) return;
				el[assignKey](castValue(el.value, trim, castToNumber));
			});
			if (trim || castToNumber) addEventListener(el, "change", () => {
				el.value = castValue(el.value, trim, castToNumber);
			});
			if (!lazy) {
				addEventListener(el, "compositionstart", onCompositionStart);
				addEventListener(el, "compositionend", onCompositionEnd);
				addEventListener(el, "change", onCompositionEnd);
			}
		},
		mounted(el, { value, modifiers: { trim, number } }) {
			const newValue = value == null ? "" : value;
			const initialValue = el[initialValueKey];
			delete el[initialValueKey];
			if (initialValue !== void 0 && (el.type === "text" || el.type === "textarea") && el.value !== initialValue) el[assignKey](castValue(el.value, trim, number));
			else el.value = newValue;
		},
		beforeUpdate(el, { value, oldValue, modifiers: { lazy, trim, number } }, vnode) {
			el[assignKey] = getModelAssigner(vnode);
			if (el.composing) return;
			const elValue = (number || el.type === "number") && !/^0\d/.test(el.value) ? looseToNumber(el.value) : el.value;
			const newValue = value == null ? "" : value;
			if (elValue === newValue) return;
			const rootNode = el.getRootNode();
			if ((rootNode instanceof Document || rootNode instanceof ShadowRoot) && rootNode.activeElement === el && el.type !== "range") {
				if (lazy && value === oldValue) return;
				if (trim && el.value.trim() === newValue) return;
			}
			el.value = newValue;
		}
	};
	var vModelCheckbox = {
		deep: true,
		created(el, _, vnode) {
			el[assignKey] = getModelAssigner(vnode);
			addEventListener(el, "change", () => {
				const modelValue = el._modelValue;
				const elementValue = getValue(el);
				const checked = el.checked;
				const assign = el[assignKey];
				if (isArray(modelValue)) {
					const index = looseIndexOf(modelValue, elementValue);
					const found = index !== -1;
					if (checked && !found) assign(modelValue.concat(elementValue));
					else if (!checked && found) {
						const filtered = [...modelValue];
						filtered.splice(index, 1);
						assign(filtered);
					}
				} else if (isSet(modelValue)) {
					const cloned = new Set(modelValue);
					if (checked) cloned.add(elementValue);
					else cloned.delete(elementValue);
					assign(cloned);
				} else assign(getCheckboxValue(el, checked));
			});
		},
		mounted: setChecked,
		beforeUpdate(el, binding, vnode) {
			el[assignKey] = getModelAssigner(vnode);
			setChecked(el, binding, vnode);
		}
	};
	function setChecked(el, { value, oldValue }, vnode) {
		el._modelValue = value;
		let checked;
		if (isArray(value)) checked = looseIndexOf(value, vnode.props.value) > -1;
		else if (isSet(value)) checked = value.has(vnode.props.value);
		else {
			if (value === oldValue) return;
			checked = looseEqual(value, getCheckboxValue(el, true));
		}
		if (el.checked !== checked) el.checked = checked;
	}
	var vModelRadio = {
		created(el, { value }, vnode) {
			el.checked = looseEqual(value, vnode.props.value);
			el[assignKey] = getModelAssigner(vnode);
			addEventListener(el, "change", () => {
				el[assignKey](getValue(el));
			});
		},
		beforeUpdate(el, { value, oldValue }, vnode) {
			el[assignKey] = getModelAssigner(vnode);
			if (value !== oldValue) el.checked = looseEqual(value, vnode.props.value);
		}
	};
	var vModelSelect = {
		deep: true,
		created(el, { value, modifiers: { number } }, vnode) {
			el._modelValue = value;
			addEventListener(el, "change", () => {
				const selectedVal = Array.prototype.filter.call(el.options, (o) => o.selected).map((o) => number ? looseToNumber(getValue(o)) : getValue(o));
				const multiple = el.multiple;
				const assignedValue = multiple ? isSet(el._modelValue) ? new Set(selectedVal) : selectedVal : selectedVal[0];
				const pending = el._pendingValue = [multiple, multiple ? isArray(assignedValue) ? selectedVal.slice() : selectedVal : assignedValue];
				try {
					el[assignKey](assignedValue);
				} finally {
					nextTick(() => {
						if (el._pendingValue === pending) el._pendingValue = void 0;
					});
				}
			});
			el[assignKey] = getModelAssigner(vnode);
		},
		mounted(el, { value }) {
			setSelected(el, value);
		},
		beforeUpdate(el, { value }, vnode) {
			el._modelValue = value;
			el[assignKey] = getModelAssigner(vnode);
		},
		updated(el, { value }) {
			const pending = el._pendingValue;
			el._pendingValue = void 0;
			if (!pending || pending[0] !== el.multiple || !isSameSelectValue(value, pending[1], pending[0])) setSelected(el, value);
		}
	};
	function isSameSelectValue(value, assignedValue, multiple) {
		if (!multiple) return looseEqual(value, assignedValue);
		if (isArray(value)) return looseEqual(value, assignedValue);
		if (isSet(value)) {
			if (value.size !== assignedValue.length) return false;
			for (const item of assignedValue) if (!value.has(item)) return false;
			return true;
		}
		return false;
	}
	function setSelected(el, value) {
		const isMultiple = el.multiple;
		const isArrayValue = isArray(value);
		if (isMultiple && !isArrayValue && !isSet(value)) return;
		for (let i = 0, l = el.options.length; i < l; i++) {
			const option = el.options[i];
			const optionValue = getValue(option);
			if (isMultiple) {
				if (isArrayValue) {
					const optionType = typeof optionValue;
					if (optionType === "string" || optionType === "number") option.selected = value.some((v) => String(v) === String(optionValue));
					else option.selected = looseIndexOf(value, optionValue) > -1;
				} else option.selected = value.has(optionValue);
			} else if (looseEqual(getValue(option), value)) {
				if (el.selectedIndex !== i) el.selectedIndex = i;
				return;
			}
		}
		if (!isMultiple && el.selectedIndex !== -1) el.selectedIndex = -1;
	}
	function getValue(el) {
		return "_value" in el ? el._value : el.value;
	}
	function getCheckboxValue(el, checked) {
		const key = checked ? "_trueValue" : "_falseValue";
		return key in el ? el[key] : checked;
	}
	var vModelDynamic = {
		created(el, binding, vnode) {
			callModelHook(el, binding, vnode, null, "created");
		},
		mounted(el, binding, vnode) {
			callModelHook(el, binding, vnode, null, "mounted");
		},
		beforeUpdate(el, binding, vnode, prevVNode) {
			callModelHook(el, binding, vnode, prevVNode, "beforeUpdate");
		},
		updated(el, binding, vnode, prevVNode) {
			callModelHook(el, binding, vnode, prevVNode, "updated");
		}
	};
	function resolveDynamicModel(tagName, type) {
		switch (tagName) {
			case "SELECT": return vModelSelect;
			case "TEXTAREA": return vModelText;
			default: switch (type) {
				case "checkbox": return vModelCheckbox;
				case "radio": return vModelRadio;
				default: return vModelText;
			}
		}
	}
	function callModelHook(el, binding, vnode, prevVNode, hook) {
		const fn = resolveDynamicModel(el.tagName, vnode.props && vnode.props.type)[hook];
		fn && fn(el, binding, vnode, prevVNode);
	}
	function initVModelForSSR() {
		vModelText.getSSRProps = ({ value }) => ({ value });
		vModelRadio.getSSRProps = ({ value }, vnode) => {
			if (vnode.props && looseEqual(vnode.props.value, value)) return { checked: true };
		};
		vModelCheckbox.getSSRProps = ({ value }, vnode) => {
			if (isArray(value)) {
				if (vnode.props && looseIndexOf(value, vnode.props.value) > -1) return { checked: true };
			} else if (isSet(value)) {
				if (vnode.props && value.has(vnode.props.value)) return { checked: true };
			} else if (value) return { checked: true };
		};
		vModelDynamic.getSSRProps = (binding, vnode) => {
			if (typeof vnode.type !== "string") return;
			const modelToUse = resolveDynamicModel(vnode.type.toUpperCase(), vnode.props && vnode.props.type);
			if (modelToUse.getSSRProps) return modelToUse.getSSRProps(binding, vnode);
		};
	}
	var systemModifiers = [
		"ctrl",
		"shift",
		"alt",
		"meta"
	];
	var modifierGuards = {
		stop: (e) => e.stopPropagation(),
		prevent: (e) => e.preventDefault(),
		self: (e) => e.target !== e.currentTarget,
		ctrl: (e) => !e.ctrlKey,
		shift: (e) => !e.shiftKey,
		alt: (e) => !e.altKey,
		meta: (e) => !e.metaKey,
		left: (e) => "button" in e && e.button !== 0,
		middle: (e) => "button" in e && e.button !== 1,
		right: (e) => "button" in e && e.button !== 2,
		exact: (e, modifiers) => systemModifiers.some((m) => e[`${m}Key`] && !modifiers.includes(m))
	};
	var withModifiers = (fn, modifiers) => {
		if (!fn) return fn;
		const cache = fn._withMods || (fn._withMods = {});
		const cacheKey = modifiers.join(".");
		return cache[cacheKey] || (cache[cacheKey] = ((event, ...args) => {
			for (let i = 0; i < modifiers.length; i++) {
				const guard = modifierGuards[modifiers[i]];
				if (guard && guard(event, modifiers)) return;
			}
			return fn(event, ...args);
		}));
	};
	var keyNames = {
		esc: "escape",
		space: " ",
		up: "arrow-up",
		left: "arrow-left",
		right: "arrow-right",
		down: "arrow-down",
		delete: "backspace"
	};
	var withKeys = (fn, modifiers) => {
		const cache = fn._withKeys || (fn._withKeys = {});
		const cacheKey = modifiers.join(".");
		return cache[cacheKey] || (cache[cacheKey] = ((event) => {
			if (!("key" in event)) return;
			const eventKey = hyphenate$1(event.key);
			if (modifiers.some((k) => k === eventKey || keyNames[k] === eventKey)) return fn(event);
		}));
	};
	var rendererOptions = extend({ patchProp }, nodeOps);
	var renderer;
	var enabledHydration = false;
	function ensureRenderer() {
		return renderer || (renderer = createRenderer(rendererOptions));
	}
	function ensureHydrationRenderer() {
		renderer = enabledHydration ? renderer : createHydrationRenderer(rendererOptions);
		enabledHydration = true;
		return renderer;
	}
	var render$1 = ((...args) => {
		ensureRenderer().render(...args);
	});
	var hydrate = ((...args) => {
		ensureHydrationRenderer().hydrate(...args);
	});
	var createApp = ((...args) => {
		const app = ensureRenderer().createApp(...args);
		const { mount } = app;
		app.mount = (containerOrSelector) => {
			const container = normalizeContainer(containerOrSelector);
			if (!container) return;
			const component = app._component;
			if (!isFunction(component) && !component.render && !component.template) component.template = container.innerHTML;
			if (container.nodeType === 1) container.textContent = "";
			const proxy = mount(container, false, resolveRootNamespace(container));
			if (container instanceof Element) {
				container.removeAttribute("v-cloak");
				container.setAttribute("data-v-app", "");
			}
			return proxy;
		};
		return app;
	});
	var createSSRApp = ((...args) => {
		const app = ensureHydrationRenderer().createApp(...args);
		const { mount } = app;
		app.mount = (containerOrSelector) => {
			const container = normalizeContainer(containerOrSelector);
			if (container) return mount(container, true, resolveRootNamespace(container));
		};
		return app;
	});
	function resolveRootNamespace(container) {
		if (container instanceof SVGElement) return "svg";
		if (typeof MathMLElement === "function" && container instanceof MathMLElement) return "mathml";
	}
	function normalizeContainer(container) {
		if (isString(container)) return document.querySelector(container);
		return container;
	}
	var ssrDirectiveInitialized = false;
	var initDirectivesForSSR = () => {
		if (!ssrDirectiveInitialized) {
			ssrDirectiveInitialized = true;
			initVModelForSSR();
			initVShowForSSR();
		}
	};
	var vue_runtime_esm_bundler_exports = __exportAll({
		BaseTransition: () => BaseTransition,
		BaseTransitionPropsValidators: () => BaseTransitionPropsValidators,
		Comment: () => Comment,
		DeprecationTypes: () => null,
		EffectScope: () => EffectScope,
		ErrorCodes: () => ErrorCodes,
		ErrorTypeStrings: () => ErrorTypeStrings,
		Fragment: () => Fragment,
		KeepAlive: () => KeepAlive,
		ReactiveEffect: () => ReactiveEffect,
		Static: () => Static,
		Suspense: () => Suspense,
		Teleport: () => Teleport,
		Text: () => Text,
		TrackOpTypes: () => TrackOpTypes,
		Transition: () => Transition,
		TransitionGroup: () => TransitionGroup,
		TriggerOpTypes: () => TriggerOpTypes,
		VueElement: () => VueElement,
		assertNumber: () => assertNumber,
		callWithAsyncErrorHandling: () => callWithAsyncErrorHandling,
		callWithErrorHandling: () => callWithErrorHandling,
		camelize: () => camelize$1,
		capitalize: () => capitalize,
		cloneVNode: () => cloneVNode,
		compatUtils: () => null,
		compile: () => compile,
		computed: () => computed,
		createApp: () => createApp,
		createBlock: () => createBlock,
		createCommentVNode: () => createCommentVNode,
		createElementBlock: () => createElementBlock,
		createElementVNode: () => createBaseVNode,
		createHydrationRenderer: () => createHydrationRenderer,
		createPropsRestProxy: () => createPropsRestProxy,
		createRenderer: () => createRenderer,
		createSSRApp: () => createSSRApp,
		createSlots: () => createSlots,
		createStaticVNode: () => createStaticVNode,
		createTextVNode: () => createTextVNode,
		createVNode: () => createVNode,
		customRef: () => customRef,
		defineAsyncComponent: () => defineAsyncComponent,
		defineComponent: () => defineComponent,
		defineCustomElement: () => defineCustomElement,
		defineEmits: () => defineEmits,
		defineExpose: () => defineExpose,
		defineModel: () => defineModel,
		defineOptions: () => defineOptions,
		defineProps: () => defineProps,
		defineSSRCustomElement: () => defineSSRCustomElement,
		defineSlots: () => defineSlots,
		devtools: () => devtools,
		effect: () => effect,
		effectScope: () => effectScope,
		getCurrentInstance: () => getCurrentInstance,
		getCurrentScope: () => getCurrentScope,
		getCurrentWatcher: () => getCurrentWatcher,
		getTransitionRawChildren: () => getTransitionRawChildren,
		guardReactiveProps: () => guardReactiveProps,
		h: () => h,
		handleError: () => handleError,
		hasInjectionContext: () => hasInjectionContext,
		hydrate: () => hydrate,
		hydrateOnIdle: () => hydrateOnIdle,
		hydrateOnInteraction: () => hydrateOnInteraction,
		hydrateOnMediaQuery: () => hydrateOnMediaQuery,
		hydrateOnVisible: () => hydrateOnVisible,
		initCustomFormatter: () => initCustomFormatter,
		initDirectivesForSSR: () => initDirectivesForSSR,
		inject: () => inject,
		isMemoSame: () => isMemoSame,
		isProxy: () => isProxy,
		isReactive: () => isReactive,
		isReadonly: () => isReadonly,
		isRef: () => isRef,
		isRuntimeOnly: () => isRuntimeOnly,
		isShallow: () => isShallow,
		isVNode: () => isVNode,
		markRaw: () => markRaw,
		mergeDefaults: () => mergeDefaults,
		mergeModels: () => mergeModels,
		mergeProps: () => mergeProps,
		nextTick: () => nextTick,
		nodeOps: () => nodeOps,
		normalizeClass: () => normalizeClass,
		normalizeProps: () => normalizeProps,
		normalizeStyle: () => normalizeStyle,
		onActivated: () => onActivated,
		onBeforeMount: () => onBeforeMount,
		onBeforeUnmount: () => onBeforeUnmount,
		onBeforeUpdate: () => onBeforeUpdate,
		onDeactivated: () => onDeactivated,
		onErrorCaptured: () => onErrorCaptured,
		onMounted: () => onMounted,
		onRenderTracked: () => onRenderTracked,
		onRenderTriggered: () => onRenderTriggered,
		onScopeDispose: () => onScopeDispose,
		onServerPrefetch: () => onServerPrefetch,
		onUnmounted: () => onUnmounted,
		onUpdated: () => onUpdated,
		onWatcherCleanup: () => onWatcherCleanup,
		openBlock: () => openBlock,
		patchProp: () => patchProp,
		popScopeId: () => popScopeId,
		provide: () => provide,
		proxyRefs: () => proxyRefs,
		pushScopeId: () => pushScopeId,
		queuePostFlushCb: () => queuePostFlushCb,
		reactive: () => reactive,
		readonly: () => readonly,
		ref: () => ref,
		registerRuntimeCompiler: () => registerRuntimeCompiler,
		render: () => render$1,
		renderList: () => renderList,
		renderSlot: () => renderSlot,
		resolveComponent: () => resolveComponent,
		resolveDirective: () => resolveDirective,
		resolveDynamicComponent: () => resolveDynamicComponent,
		resolveFilter: () => null,
		resolveTransitionHooks: () => resolveTransitionHooks,
		setBlockTracking: () => setBlockTracking,
		setDevtoolsHook: () => setDevtoolsHook,
		setTransitionHooks: () => setTransitionHooks,
		shallowReactive: () => shallowReactive,
		shallowReadonly: () => shallowReadonly,
		shallowRef: () => shallowRef,
		ssrContextKey: () => ssrContextKey,
		ssrUtils: () => ssrUtils,
		stop: () => stop$1,
		toDisplayString: () => toDisplayString,
		toHandlerKey: () => toHandlerKey,
		toHandlers: () => toHandlers,
		toRaw: () => toRaw,
		toRef: () => toRef,
		toRefs: () => toRefs,
		toValue: () => toValue,
		transformVNodeArgs: () => transformVNodeArgs,
		triggerRef: () => triggerRef,
		unref: () => unref,
		useAttrs: () => useAttrs,
		useCssModule: () => useCssModule,
		useCssVars: () => useCssVars,
		useHost: () => useHost,
		useId: () => useId$1,
		useModel: () => useModel,
		useSSRContext: () => useSSRContext,
		useShadowRoot: () => useShadowRoot,
		useSlots: () => useSlots,
		useTemplateRef: () => useTemplateRef,
		useTransitionState: () => useTransitionState,
		vModelCheckbox: () => vModelCheckbox,
		vModelDynamic: () => vModelDynamic,
		vModelRadio: () => vModelRadio,
		vModelSelect: () => vModelSelect,
		vModelText: () => vModelText,
		vShow: () => vShow,
		version: () => version,
		warn: () => warn,
		watch: () => watch,
		watchEffect: () => watchEffect,
		watchPostEffect: () => watchPostEffect,
		watchSyncEffect: () => watchSyncEffect,
		withAsyncContext: () => withAsyncContext,
		withCtx: () => withCtx,
		withDefaults: () => withDefaults,
		withDirectives: () => withDirectives,
		withKeys: () => withKeys,
		withMemo: () => withMemo,
		withModifiers: () => withModifiers,
		withScopeId: () => withScopeId
	});
	var compile = () => {};
	function fileFailure(response) {
		const encoding = response.bytes[0] === 255 && response.bytes[1] === 254 ? "utf-16le" : response.bytes[0] === 254 && response.bytes[1] === 255 ? "utf-16be" : "utf-8";
		const sample = new TextDecoder(encoding).decode(response.bytes.subarray(0, 16384));
		const html = /(?:text\/html|application\/xhtml\+xml)/i.test(response.contentType) || /^\s*</.test(sample);
		if (response.status === 401 || html && /loginform|name=["']?password|请先登录|尚未登录/i.test(sample)) return {
			kind: "login",
			message: "The forum returned a login page instead of a file. Sign in through the native forum, then try again."
		};
		if (html && /captcha|security verification|验证码|安全验证|challenge/i.test(sample)) return {
			kind: "challenge",
			message: "The forum returned a verification challenge instead of a file. Complete it in the native forum."
		};
		if (html && /需要付费|付费后下载|购买|payment required/i.test(sample)) return {
			kind: "permission",
			message: "The forum requires payment before download. No purchase was attempted and no file is ready to save."
		};
		if (response.status === 403 || html && /没有权限|无权|权限不足|permission|拒绝访问/i.test(sample)) return {
			kind: "permission",
			message: "The forum refused download permission. No file is ready to save."
		};
		if (response.status === 404 || response.status === 410 || html && /附件不存在|文件不存在|file not found/i.test(sample)) return {
			kind: "missing",
			message: "The attachment file is missing. No file is ready to save."
		};
		if (html) return {
			kind: "invalid",
			message: "The forum returned an HTML page instead of a confirmed file. Nothing is ready to save."
		};
		if (/(?:application\/(?:json|[^;]+\+json)|text\/xml)/i.test(response.contentType)) return {
			kind: "invalid",
			message: "The forum returned a response document instead of a confirmed file. Nothing is ready to save."
		};
		if (response.status !== 200 || response.redirected) return {
			kind: "invalid",
			message: "The forum did not return a complete file. Nothing is ready to save."
		};
		if (!response.bytes.length || response.contentLength !== null && !response.contentEncoding && (!/^\d+$/.test(response.contentLength) || Number(response.contentLength) !== response.bytes.length)) return {
			kind: "invalid",
			message: "The file response was empty or incomplete. Nothing is ready to save."
		};
		return null;
	}
	var UNDEFINED_CODE_POINTS = new Set([
		65534,
		65535,
		131070,
		131071,
		196606,
		196607,
		262142,
		262143,
		327678,
		327679,
		393214,
		393215,
		458750,
		458751,
		524286,
		524287,
		589822,
		589823,
		655358,
		655359,
		720894,
		720895,
		786430,
		786431,
		851966,
		851967,
		917502,
		917503,
		983038,
		983039,
		1048574,
		1048575,
		1114110,
		1114111
	]);
	var CODE_POINTS;
	(function(CODE_POINTS) {
		CODE_POINTS[CODE_POINTS["EOF"] = -1] = "EOF";
		CODE_POINTS[CODE_POINTS["NULL"] = 0] = "NULL";
		CODE_POINTS[CODE_POINTS["TABULATION"] = 9] = "TABULATION";
		CODE_POINTS[CODE_POINTS["CARRIAGE_RETURN"] = 13] = "CARRIAGE_RETURN";
		CODE_POINTS[CODE_POINTS["LINE_FEED"] = 10] = "LINE_FEED";
		CODE_POINTS[CODE_POINTS["FORM_FEED"] = 12] = "FORM_FEED";
		CODE_POINTS[CODE_POINTS["SPACE"] = 32] = "SPACE";
		CODE_POINTS[CODE_POINTS["EXCLAMATION_MARK"] = 33] = "EXCLAMATION_MARK";
		CODE_POINTS[CODE_POINTS["QUOTATION_MARK"] = 34] = "QUOTATION_MARK";
		CODE_POINTS[CODE_POINTS["AMPERSAND"] = 38] = "AMPERSAND";
		CODE_POINTS[CODE_POINTS["APOSTROPHE"] = 39] = "APOSTROPHE";
		CODE_POINTS[CODE_POINTS["HYPHEN_MINUS"] = 45] = "HYPHEN_MINUS";
		CODE_POINTS[CODE_POINTS["SOLIDUS"] = 47] = "SOLIDUS";
		CODE_POINTS[CODE_POINTS["DIGIT_0"] = 48] = "DIGIT_0";
		CODE_POINTS[CODE_POINTS["DIGIT_9"] = 57] = "DIGIT_9";
		CODE_POINTS[CODE_POINTS["SEMICOLON"] = 59] = "SEMICOLON";
		CODE_POINTS[CODE_POINTS["LESS_THAN_SIGN"] = 60] = "LESS_THAN_SIGN";
		CODE_POINTS[CODE_POINTS["EQUALS_SIGN"] = 61] = "EQUALS_SIGN";
		CODE_POINTS[CODE_POINTS["GREATER_THAN_SIGN"] = 62] = "GREATER_THAN_SIGN";
		CODE_POINTS[CODE_POINTS["QUESTION_MARK"] = 63] = "QUESTION_MARK";
		CODE_POINTS[CODE_POINTS["LATIN_CAPITAL_A"] = 65] = "LATIN_CAPITAL_A";
		CODE_POINTS[CODE_POINTS["LATIN_CAPITAL_Z"] = 90] = "LATIN_CAPITAL_Z";
		CODE_POINTS[CODE_POINTS["RIGHT_SQUARE_BRACKET"] = 93] = "RIGHT_SQUARE_BRACKET";
		CODE_POINTS[CODE_POINTS["GRAVE_ACCENT"] = 96] = "GRAVE_ACCENT";
		CODE_POINTS[CODE_POINTS["LATIN_SMALL_A"] = 97] = "LATIN_SMALL_A";
		CODE_POINTS[CODE_POINTS["LATIN_SMALL_Z"] = 122] = "LATIN_SMALL_Z";
	})(CODE_POINTS || (CODE_POINTS = {}));
	var SEQUENCES = {
		DASH_DASH: "--",
		CDATA_START: "[CDATA[",
		DOCTYPE: "doctype",
		SCRIPT: "script",
		PUBLIC: "public",
		SYSTEM: "system"
	};
	function isSurrogate(cp) {
		return cp >= 55296 && cp <= 57343;
	}
	function isSurrogatePair(cp) {
		return cp >= 56320 && cp <= 57343;
	}
	function getSurrogatePairCodePoint(cp1, cp2) {
		return (cp1 - 55296) * 1024 + 9216 + cp2;
	}
	function isControlCodePoint(cp) {
		return cp !== 32 && cp !== 10 && cp !== 13 && cp !== 9 && cp !== 12 && cp >= 1 && cp <= 31 || cp >= 127 && cp <= 159;
	}
	function isUndefinedCodePoint(cp) {
		return cp >= 64976 && cp <= 65007 || UNDEFINED_CODE_POINTS.has(cp);
	}
	var ERR;
	(function(ERR) {
		ERR["controlCharacterInInputStream"] = "control-character-in-input-stream";
		ERR["noncharacterInInputStream"] = "noncharacter-in-input-stream";
		ERR["surrogateInInputStream"] = "surrogate-in-input-stream";
		ERR["nonVoidHtmlElementStartTagWithTrailingSolidus"] = "non-void-html-element-start-tag-with-trailing-solidus";
		ERR["endTagWithAttributes"] = "end-tag-with-attributes";
		ERR["endTagWithTrailingSolidus"] = "end-tag-with-trailing-solidus";
		ERR["unexpectedSolidusInTag"] = "unexpected-solidus-in-tag";
		ERR["unexpectedNullCharacter"] = "unexpected-null-character";
		ERR["unexpectedQuestionMarkInsteadOfTagName"] = "unexpected-question-mark-instead-of-tag-name";
		ERR["invalidFirstCharacterOfTagName"] = "invalid-first-character-of-tag-name";
		ERR["unexpectedEqualsSignBeforeAttributeName"] = "unexpected-equals-sign-before-attribute-name";
		ERR["missingEndTagName"] = "missing-end-tag-name";
		ERR["unexpectedCharacterInAttributeName"] = "unexpected-character-in-attribute-name";
		ERR["unknownNamedCharacterReference"] = "unknown-named-character-reference";
		ERR["missingSemicolonAfterCharacterReference"] = "missing-semicolon-after-character-reference";
		ERR["unexpectedCharacterAfterDoctypeSystemIdentifier"] = "unexpected-character-after-doctype-system-identifier";
		ERR["unexpectedCharacterInUnquotedAttributeValue"] = "unexpected-character-in-unquoted-attribute-value";
		ERR["eofBeforeTagName"] = "eof-before-tag-name";
		ERR["eofInTag"] = "eof-in-tag";
		ERR["missingAttributeValue"] = "missing-attribute-value";
		ERR["missingWhitespaceBetweenAttributes"] = "missing-whitespace-between-attributes";
		ERR["missingWhitespaceAfterDoctypePublicKeyword"] = "missing-whitespace-after-doctype-public-keyword";
		ERR["missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers"] = "missing-whitespace-between-doctype-public-and-system-identifiers";
		ERR["missingWhitespaceAfterDoctypeSystemKeyword"] = "missing-whitespace-after-doctype-system-keyword";
		ERR["missingQuoteBeforeDoctypePublicIdentifier"] = "missing-quote-before-doctype-public-identifier";
		ERR["missingQuoteBeforeDoctypeSystemIdentifier"] = "missing-quote-before-doctype-system-identifier";
		ERR["missingDoctypePublicIdentifier"] = "missing-doctype-public-identifier";
		ERR["missingDoctypeSystemIdentifier"] = "missing-doctype-system-identifier";
		ERR["abruptDoctypePublicIdentifier"] = "abrupt-doctype-public-identifier";
		ERR["abruptDoctypeSystemIdentifier"] = "abrupt-doctype-system-identifier";
		ERR["cdataInHtmlContent"] = "cdata-in-html-content";
		ERR["incorrectlyOpenedComment"] = "incorrectly-opened-comment";
		ERR["eofInScriptHtmlCommentLikeText"] = "eof-in-script-html-comment-like-text";
		ERR["eofInDoctype"] = "eof-in-doctype";
		ERR["nestedComment"] = "nested-comment";
		ERR["abruptClosingOfEmptyComment"] = "abrupt-closing-of-empty-comment";
		ERR["eofInComment"] = "eof-in-comment";
		ERR["incorrectlyClosedComment"] = "incorrectly-closed-comment";
		ERR["eofInCdata"] = "eof-in-cdata";
		ERR["absenceOfDigitsInNumericCharacterReference"] = "absence-of-digits-in-numeric-character-reference";
		ERR["nullCharacterReference"] = "null-character-reference";
		ERR["surrogateCharacterReference"] = "surrogate-character-reference";
		ERR["characterReferenceOutsideUnicodeRange"] = "character-reference-outside-unicode-range";
		ERR["controlCharacterReference"] = "control-character-reference";
		ERR["noncharacterCharacterReference"] = "noncharacter-character-reference";
		ERR["missingWhitespaceBeforeDoctypeName"] = "missing-whitespace-before-doctype-name";
		ERR["missingDoctypeName"] = "missing-doctype-name";
		ERR["invalidCharacterSequenceAfterDoctypeName"] = "invalid-character-sequence-after-doctype-name";
		ERR["duplicateAttribute"] = "duplicate-attribute";
		ERR["nonConformingDoctype"] = "non-conforming-doctype";
		ERR["missingDoctype"] = "missing-doctype";
		ERR["misplacedDoctype"] = "misplaced-doctype";
		ERR["endTagWithoutMatchingOpenElement"] = "end-tag-without-matching-open-element";
		ERR["closingOfElementWithOpenChildElements"] = "closing-of-element-with-open-child-elements";
		ERR["disallowedContentInNoscriptInHead"] = "disallowed-content-in-noscript-in-head";
		ERR["openElementsLeftAfterEof"] = "open-elements-left-after-eof";
		ERR["abandonedHeadElementChild"] = "abandoned-head-element-child";
		ERR["misplacedStartTagForHeadElement"] = "misplaced-start-tag-for-head-element";
		ERR["nestedNoscriptInHead"] = "nested-noscript-in-head";
		ERR["eofInElementThatCanContainOnlyText"] = "eof-in-element-that-can-contain-only-text";
	})(ERR || (ERR = {}));
	var DEFAULT_BUFFER_WATERLINE = 65536;
	var Preprocessor = class {
		constructor(handler) {
			this.handler = handler;
			this.html = "";
			this.pos = -1;
			this.lastGapPos = -2;
			this.gapStack = [];
			this.skipNextNewLine = false;
			this.lastChunkWritten = false;
			this.endOfChunkHit = false;
			this.bufferWaterline = DEFAULT_BUFFER_WATERLINE;
			this.isEol = false;
			this.lineStartPos = 0;
			this.droppedBufferSize = 0;
			this.line = 1;
			this.lastErrOffset = -1;
		}
		get col() {
			return this.pos - this.lineStartPos + Number(this.lastGapPos !== this.pos);
		}
		get offset() {
			return this.droppedBufferSize + this.pos;
		}
		getError(code, cpOffset) {
			const { line, col, offset } = this;
			const startCol = col + cpOffset;
			const startOffset = offset + cpOffset;
			return {
				code,
				startLine: line,
				endLine: line,
				startCol,
				endCol: startCol,
				startOffset,
				endOffset: startOffset
			};
		}
		_err(code) {
			if (this.handler.onParseError && this.lastErrOffset !== this.offset) {
				this.lastErrOffset = this.offset;
				this.handler.onParseError(this.getError(code, 0));
			}
		}
		_addGap() {
			this.gapStack.push(this.lastGapPos);
			this.lastGapPos = this.pos;
		}
		_processSurrogate(cp) {
			if (this.pos !== this.html.length - 1) {
				const nextCp = this.html.charCodeAt(this.pos + 1);
				if (isSurrogatePair(nextCp)) {
					this.pos++;
					this._addGap();
					return getSurrogatePairCodePoint(cp, nextCp);
				}
			} else if (!this.lastChunkWritten) {
				this.endOfChunkHit = true;
				return CODE_POINTS.EOF;
			}
			this._err(ERR.surrogateInInputStream);
			return cp;
		}
		willDropParsedChunk() {
			return this.pos > this.bufferWaterline;
		}
		dropParsedChunk() {
			if (this.willDropParsedChunk()) {
				this.html = this.html.substring(this.pos);
				this.lineStartPos -= this.pos;
				this.droppedBufferSize += this.pos;
				this.pos = 0;
				this.lastGapPos = -2;
				this.gapStack.length = 0;
			}
		}
		write(chunk, isLastChunk) {
			if (this.html.length > 0) this.html += chunk;
			else this.html = chunk;
			this.endOfChunkHit = false;
			this.lastChunkWritten = isLastChunk;
		}
		insertHtmlAtCurrentPos(chunk) {
			this.html = this.html.substring(0, this.pos + 1) + chunk + this.html.substring(this.pos + 1);
			this.endOfChunkHit = false;
		}
		startsWith(pattern, caseSensitive) {
			if (this.pos + pattern.length > this.html.length) {
				this.endOfChunkHit = !this.lastChunkWritten;
				return false;
			}
			if (caseSensitive) return this.html.startsWith(pattern, this.pos);
			for (let i = 0; i < pattern.length; i++) if ((this.html.charCodeAt(this.pos + i) | 32) !== pattern.charCodeAt(i)) return false;
			return true;
		}
		peek(offset) {
			const pos = this.pos + offset;
			if (pos >= this.html.length) {
				this.endOfChunkHit = !this.lastChunkWritten;
				return CODE_POINTS.EOF;
			}
			const code = this.html.charCodeAt(pos);
			return code === CODE_POINTS.CARRIAGE_RETURN ? CODE_POINTS.LINE_FEED : code;
		}
		advance() {
			this.pos++;
			if (this.isEol) {
				this.isEol = false;
				this.line++;
				this.lineStartPos = this.pos;
			}
			if (this.pos >= this.html.length) {
				this.endOfChunkHit = !this.lastChunkWritten;
				return CODE_POINTS.EOF;
			}
			let cp = this.html.charCodeAt(this.pos);
			if (cp === CODE_POINTS.CARRIAGE_RETURN) {
				this.isEol = true;
				this.skipNextNewLine = true;
				return CODE_POINTS.LINE_FEED;
			}
			if (cp === CODE_POINTS.LINE_FEED) {
				this.isEol = true;
				if (this.skipNextNewLine) {
					this.line--;
					this.skipNextNewLine = false;
					this._addGap();
					return this.advance();
				}
			}
			this.skipNextNewLine = false;
			if (isSurrogate(cp)) cp = this._processSurrogate(cp);
			if (!(this.handler.onParseError === null || cp > 31 && cp < 127 || cp === CODE_POINTS.LINE_FEED || cp === CODE_POINTS.CARRIAGE_RETURN || cp > 159 && cp < 64976)) this._checkForProblematicCharacters(cp);
			return cp;
		}
		_checkForProblematicCharacters(cp) {
			if (isControlCodePoint(cp)) this._err(ERR.controlCharacterInInputStream);
			else if (isUndefinedCodePoint(cp)) this._err(ERR.noncharacterInInputStream);
		}
		retreat(count) {
			this.pos -= count;
			while (this.pos < this.lastGapPos) {
				this.lastGapPos = this.gapStack.pop();
				this.pos--;
			}
			this.isEol = false;
		}
	};
	var TokenType;
	(function(TokenType) {
		TokenType[TokenType["CHARACTER"] = 0] = "CHARACTER";
		TokenType[TokenType["NULL_CHARACTER"] = 1] = "NULL_CHARACTER";
		TokenType[TokenType["WHITESPACE_CHARACTER"] = 2] = "WHITESPACE_CHARACTER";
		TokenType[TokenType["START_TAG"] = 3] = "START_TAG";
		TokenType[TokenType["END_TAG"] = 4] = "END_TAG";
		TokenType[TokenType["COMMENT"] = 5] = "COMMENT";
		TokenType[TokenType["DOCTYPE"] = 6] = "DOCTYPE";
		TokenType[TokenType["EOF"] = 7] = "EOF";
		TokenType[TokenType["HIBERNATION"] = 8] = "HIBERNATION";
	})(TokenType || (TokenType = {}));
	function getTokenAttr(token, attrName) {
		for (let i = token.attrs.length - 1; i >= 0; i--) if (token.attrs[i].name === attrName) return token.attrs[i].value;
		return null;
	}
	var c1 = [
		8364,
		0,
		8218,
		402,
		8222,
		8230,
		8224,
		8225,
		710,
		8240,
		352,
		8249,
		338,
		0,
		381,
		0,
		0,
		8216,
		8217,
		8220,
		8221,
		8226,
		8211,
		8212,
		732,
		8482,
		353,
		8250,
		339,
		0,
		382,
		376
	];
	function isInvalidCodePoint(codePoint) {
		return codePoint === 0 || codePoint >= 55296 && codePoint <= 57343 || codePoint > 1114111;
	}
	function replaceCodePoint(codePoint) {
		if (isInvalidCodePoint(codePoint)) return 65533;
		if (codePoint >= 128 && codePoint <= 159) return c1[codePoint - 128] || codePoint;
		return codePoint;
	}
	function replaceCodePointXML(codePoint) {
		return isInvalidCodePoint(codePoint) ? 65533 : codePoint;
	}
	var BASE91_INVERSE = (() => {
		const table = new Uint8Array(127);
		let code = 0;
		for (let char = 33; char <= 126; char++) if (char !== 34 && char !== 36 && char !== 92) table[char] = code++;
		return table;
	})();
	function decodeTrieDict(input, resultLength, atomCount, dict1AtomCount, ngramCount, dictSize) {
		const base = 91;
		const inputLength = input.length;
		const twoCharBias = dictSize * 90;
		let pos = 0;
		const readSlotCode = () => {
			const c1 = BASE91_INVERSE[input.charCodeAt(pos++)];
			return c1 < dictSize ? c1 : c1 * base - twoCharBias + BASE91_INVERSE[input.charCodeAt(pos++)];
		};
		const dict2AtomCount = atomCount - dict1AtomCount;
		const slotCount = atomCount + ngramCount;
		const single = new Int32Array(slotCount);
		single.fill(-1, dict1AtomCount, dictSize);
		single.fill(-1, dictSize + dict2AtomCount, slotCount);
		const start = new Int32Array(slotCount);
		const length = new Int32Array(slotCount);
		function decodeDelta(count, off) {
			let previous = 0;
			let slot = off;
			const end = off + count;
			while (slot < end) {
				const code = BASE91_INVERSE[input.charCodeAt(pos++)];
				if (code < 89) {
					previous += code;
					single[slot++] = previous;
				} else if (code === 89) {
					let runLength = BASE91_INVERSE[input.charCodeAt(pos++)] + 2;
					while (runLength--) single[slot++] = ++previous;
				} else {
					const next = BASE91_INVERSE[input.charCodeAt(pos++)];
					previous += 89 + (next < 90 ? next * base + BASE91_INVERSE[input.charCodeAt(pos++)] : BASE91_INVERSE[input.charCodeAt(pos++)] * 8281 + BASE91_INVERSE[input.charCodeAt(pos++)] * base + BASE91_INVERSE[input.charCodeAt(pos++)]);
					single[slot++] = previous;
				}
			}
		}
		decodeDelta(dict1AtomCount, 0);
		decodeDelta(dict2AtomCount, dictSize);
		const references = new Int32Array(ngramCount * 2);
		let poolSize = 0;
		let ngramIndex = 0;
		function readNgramReferences(count, startSlot) {
			for (let index = 0; index < count; index++) {
				const slot = startSlot + index;
				const a = readSlotCode();
				const b = readSlotCode();
				references[ngramIndex * 2] = a;
				references[ngramIndex * 2 + 1] = b;
				ngramIndex += 1;
				start[slot] = poolSize;
				const entryLength = (single[a] < 0 ? length[a] : 1) + (single[b] < 0 ? length[b] : 1);
				length[slot] = entryLength;
				poolSize += entryLength;
			}
		}
		readNgramReferences(ngramCount - dictSize + dict1AtomCount, dictSize + dict2AtomCount);
		readNgramReferences(dictSize - dict1AtomCount, dict1AtomCount);
		const pool = new Uint16Array(poolSize);
		let write = 0;
		for (let index = 0; index < ngramIndex; index++) for (let half = 0; half < 2; half++) {
			const source = references[index * 2 + half];
			const value = single[source];
			if (value < 0) {
				let read = start[source];
				const readEnd = read + length[source];
				while (read < readEnd) pool[write++] = pool[read++];
			} else pool[write++] = value;
		}
		const out = new Uint16Array(resultLength);
		let outIndex = 0;
		while (pos < inputLength) {
			let slot = BASE91_INVERSE[input.charCodeAt(pos++)];
			if (slot >= dictSize) slot = slot * base - twoCharBias + BASE91_INVERSE[input.charCodeAt(pos++)];
			const value = single[slot];
			if (value < 0) {
				let read = start[slot];
				const readEnd = read + length[slot];
				while (read < readEnd) out[outIndex++] = pool[read++];
			} else out[outIndex++] = value;
		}
		return out;
	}
	var htmlDecodeTree = decodeTrieDict("!}.&u%}'&}*'~!6*)%&,~!J~!J~%L~y<~!R,~~%Lu~~#GD~~#|)1#%}^%}2%+#.##%##%}&%##%'#%##&%#%#'%#&#%#&#'#%%#&#%##%#)%''%&%#%#'%#%%#%%}%%%#%#&(23#%%#&-%0%('1#(##%#'##+%'*.:1}#%#6-+(%'%%#%%%}#L'2351&('%}&/N'(0(/*-%(%%}#'+&T%7.2}#&%&#%#36/5##%&%%#&#%%#))2%%##%&&'0~!#*+&'%1~!%).'3q?&%'1~!.##%6(~!+%%%(Gw'rT~!E#<nA%#jZ~!H%(~!42##~!*31&~!G%U~#)5~#`3~!J~!Z~%]~%Y~%C~!q~!u~#kz~%#~!6'~!D~!U~!?~#T~!c%~!G#'~%7|~!G~!J~!G&~#pb~(Df}#%}*&}#%##%##%##&#-}&'#'&%#.++}%mI,#,@&(}*%}*'%&##&#%##%}&0}#.},U},%}+%}&%}#%##&}B%(}(%}+%)})%##%#&}&%##%&}<%}>%#%&}*%}(%}9%}/%})%}*%}*%}?&}&%}3%}&*#%})%#%#)}#&#-#+*%E%%'%'#%}#*V##&##I}#&&##%&%#&&Qf%%))w/0+&%#(#.%-''''++++7}>%4'',##1,#%#&%##&#'##&#*#9)%&%}#*}%,#+P(%A&%#'&##wSD',9E00#y#@}(+}&%&>~!#~!X}#*}(&&}(&}(,%}%&#+&}#&}I%#%}%)#(},'%#*}4%%#%}(''}#/##(##),%-##%%)#&}(.}&%#&}%%}*&#%},&&}&%}#%*'#%})%}D&}&%}-&}6&#&}-,%}#%})-(~+`~,=?~I9'9%~!,#%})%})%}@%}?%}(~!?~#<~#pP~#BG~#=1#%K+~#?#~%;)~#A~#mF1~#A'~'X%'~#lR~#N~'N~#r~#m#-~#i'?%#'%~#B%##%,%#~#_%#0%~#]732~,w~2+#:&#%&'0%&>%}#>##F+)#%&&#(+_}4&}-%}(&}@&}O7Fdf0@+/v4}&WU##&/0#&'('B#%}.%}'+#%}#%%&#&%#%##+#&#)#6#'#.},%}c%},%#%##%&#&%#&~#>'*-.%##%##%}#%%}%'~#)D1}#%*&~#_%%'(~#S2%'.}#~#=##*'*-%}&'%'##&&~'E%.#&~#M4}%%##&'%#~#O1##%&#'+~#<B%##%%'%+~#;#@%}#&%#&&%#(~#H1}'%'##&&~#?A}&'~#D#%32}'&&&&~#[}'(#%}'~#;C})&}%%#%~#=&%,3}%'(#%%~#^'#&&)#%'~#Y%-~#d-%'~#^%%&#&&&}#~#b~2t*&'~&(~&@~0%~e~3}%*''0})&}+~!9##-}#%-hD*)1fC#%/&/fB#40~!+#)*4~!+~!K'&:~!/*7~!.#~!H~!L':~%x&~!H#~!*~%1~!I#~!+A~#p'~!F~~#-#~,,(~.Z~!V~%;'B'mq-W~!N~%I%#&&#&}#%},%%}'%}+X#%}#&}(%}'%}<%}#%}%%'}'%}:~![)9@~%>~#UA%-%##&~!C%~!-.9:~!1~!-^2/:a~!y,D*J#-5)/4~%23,~#G~!L1~!0X3`~!2+~!!0-~&E~!W~!o,>Y&]~%cZx_&~#O*9#A#'#+I'%#)~!0B*-5A+-((F&*M#)(-7-5+'-3a5Vi~!Y~!?+[)%3),ERHm~!+:D,VG.+)?fB%%*(%)'(#&80%1'8`K8?`+'Z#&O&'H5#*9)A%%5&3))0%39+.*7#()&&*=4@**L)<'_&*+..;(#*+)./&0#3)%')-8(4ixD(&.}%,('aI:,)%,k2231T)I'#/-W7,/'Q#.'Y24+h')37</31&83##&0#),H(?'&?/1##%#&&#%''-%&&&#(&''&#.-'%#%%(,')*'&#&#'##%(%(#%('#&##%%%%('%#%#%%#%#&%##h>w+v<ayvyvcg.uuhKr}g/v|g>u9i[~>g5uI~=RvdwEg;v/g;uk!!TTSx]@RT!U!#!@VBRUU!'UTe-d0c`e&gSdicedFcrdTaqb.kYcAohdYd@a3e+d}dMdtd.aJ#bqcK`dle/e.e'dwdPdodddjbEb}ogd^ofdpduc6j?l%d{drdqc)d7bacOdQ%T#Y)X.sR[yH>6Vyv3[xwLu>vo'!*.[yBacahoj>6Rew3[xqdZa#!a&#^(X-[yG>6Vyu3[xvg3sEr|g.u/Ri9db0T#^(Xa)!-[y;>6Vylg4wKs{JwNZt3@3r=c4Z([xlg;wKt!cpq's@v7A'*a(a+!-a#[y<3Dt?3Dt'>6Vym3[xmg9rxsNJwLZt4~?r?db1T#`-!(Xa,!0[yS>6Vz%NuQs.g4wKtnJwNZtS@3r>c4Z([y%g;wKtrdga8!a(!#&T*Y-Xa#!a0<or[yc3Dtq>6Vz43[y3JwNZtf@3s!Ju}!%Dti:pm3c_%X#tjB5pkd6q!r]u?voC'*-a.a2!0a&a+[yI3DtI3Ds~3DtH>6Vyw3[xx;:s#~<5pKJwNZtE@3r~d`a)!a2T#a.(!+U.X1[yT3Dt`3Dtv>6Vz&3[y&g9rxwzcxstPu.<rAJwLZtT~?r@dZa%!a.&^*Za(/Reu[ya>6Vz23[y1g3sEr}wkg{NuQRg{ci(U#5@b`~,cg#U(2WnH5wugcRh7dX#T(Y,a'Ta!!a,[yZ<]mj>6Vz,3[y+Pv#5ReZKu+=,%!H}7ABwkaS?Rh:BcW(X#<]mrj:ubv/ARekdg%!(!a.*Ta(Y.X1!#sP>Rl*Dt6[y>>6Vyo3Wf*jOvuumvuRgRJuq*!:9<B@bX~3jVv&v@s@5Re[d/rQt{uAvo&a&a*)a2!,0Wf!3Dt0=Bs'>6Re}3[xy~<5s%JwJZt1~Gs)c;&!#2sJkNuXvzq7rxu,Re8dka4!a8(aEZ+a@Y.X1Xa)[yd=Bs(3DtP>6Vz53[y4cX#X&Re:avRe9~<5s&JwJZtQ~Gs*i^rzvdRg+Jv{%!2sbB@bX}kdga,!Za?&^*T1/!a'Dt+[y6>6Vyf3Wf%g/u;s4hGu6?Rh-JvZ,!c%#&RoX54Rivj7uyvf8RgTKvZB%*!2sGh<vu5Rgq<=C::9bb~#dZ#T&Ta6Y.X*Dt>[y93Wf)coZ(T,6VyifluvRgC@95@B@bX~/hFu34cC#T,k/unq8w8Q5RkUklwQuzunq8w8Q5Rk8d/rJu?v8w9)-&!a0a;a&aIWejg3sEr/h1s<DtDJvyZqY5aws3Jvy!&Wei~Hr1:au5@Bag>23E~5c:Z&bX};kKv?w&unuVu5Rjc;>bs)#~@:Rh.=ay<a]C;b`}Vd6s/t{uAvoaxa()!a,a7%-a#a2Dt,[yF2Wo[>6Vyt3[xuNuPRi&NuPwpi#RoWh?vf8Ri%Jv]!%Ri:KvxD!.'2WeAjZu`q9rxu,Re7woeAg-unLq(qA_/*2Wg_g3u5q^9:4E}/jTrxrzv=Wkkd~0UX#^^Xa-a1a5T&a=U1a'*aEa]!a*aPaA-adok[y54Rn>;:p3~Dp5g9rpsFNvZqjg3uJp4~<5p0Pw;5qlJwNZt*@3p1Pw:5p/Ou!5p2JvG'!6Vye=<qnJvh_[xhg3v,Rh3kOwOw-sDuev/Re^dha[a%!%!a+#Ta7)-5TaCaO!aka!a)sf[yb2>Rl!9ARiq5E}Qg=ucRkBE|oJrJ_@Wk~@Wk{JrJ_@Wk|@WkyJrJ_@Wk}@WkzJvO_[y2g-vMRmiKuYC!)&>Ri;>Ri<@3RkNc](X#@9Rk=g5vuRmhKvDB!+'=]meg3u4Rmgd)#Y'Vz3CARmfd`a+!%T'!+#Ta1Ta6TaM-sTDt9[yA9sYd'%Y#s[[xpj:ueunaXRgEjRq,v-vuqdd2'`#6Rev<32@5>:2<E}5xIo9a*X#Y(;5RePJvD_g>vyRgNj8w)v8<wggs:RgXiZt|vjx,hSq3ah!-(~@:Ro/Ou!5RhWj^v(pyw8unRhUdx-UY#^Ua.a3a70!)%UX1TaDa)'omRiRRhE[y:3Dsz=Br,>6Vyj3[xkg6ruwjcqsrPw;5r*Ku]D'Zt-@3r(~?r.i[vwv]dU1a--U#`a4(g/vsRhPOu!5RhLj:rmu9Wo!~@:wdh@g/vsRiTjXuvvNr}:RhBj^v(pyw8unRn]dz1UYa'a+^Y(!aETZalaRY.Ta?a4[yDJw1!#qLsW>6Vyrfzq-pLflpwRe|Js>%!Dt@3Dt&Jvy_[xs~HrnjMuwpsw'RecKu+D#'!t<~Grl~?rjg5u-x,gwp{ah!-(~@:Rg~Ou!5Rh'jXuvvNr}:Rh#cW#X/c;&!#2sLi[v7u7RgpJv)(!iLrxu,Re6j7v@s@5Se[e7d`aW!Za(a`T.a#!a3!&aDa-!9)Dt_=6s+3[x~~DR|h~DS6avhGun5RkZj3w)v-]mkKunB!&*]kb97R|i<ARk<c:Z(6Vy}Juh'!wziMRoS:F|vkLuauJv5vtvQRh1d='T+Y#VyO~DR|jcF#T'7R|g97R|kJv3'!ay<Rj,Jvh&!:ReXcsa6*a+#a#_aIRf9aLRf?c,Z&Rf5Rf7c.Z&Rf;Rf>cQ#%T'p-Rf8Rf=ct#%'(*!,p,Rf4p+Rf6Rf:Rf<d~'Ua%U*^UYa(!a,-!#a4YaTalaEX0a8a<Weo3Dt/3Dsx=Br93Wen~Dr;~<5p<JwNZt2@3p=Pw:5p;Ou!5r3c7&!#:p>3Ds}KvGB)_6Vyk2sM=<r7x'eovA(!hFu1ARf}cV#X&@r5j6rvwQa^Rf3c=Za'wkghJv__g;unRggA53B9=b^}%j6uduo5Jq;!(hIv%2Re`Ou4ARe_e%a#^^^Xa&!a*a2!&a6YaP!*ad!#a:aE/5Rn?[y@>6Vyp;:pE~DrY~<5pBJwNZt8@3pCh=rt3rWPw:5pAJup_[xoNuPpF9c!#'45pD5ARn)d8#X'X*3@rU72s]h>v<<sSjJpqvewOJq/(!hNw'5ReBk0s2u3w/w'5ReE5@Jq.!a+JQ!&WeU23d(#Y&RjG5]jBk!u7w&u0udARjEe#+^^^Ub#!a2/a`Z(agT1!a-a;|@TaG!aS[yV=Re~fow'RguNuPRe?bz#'>RoUWeL>:Cbb|?JwPZtVg6ruRmzJvD'!6Vz(g/vmRh~Jvy_[y(g9voRgyx*cy(#2>Ri2B9b]~9kIw9u7rluJu3Rg]dI#a%UY'@=p%CAx.gQZ&RhwwygtRm{x5g_Z'+ABqR9Woa=Bp&dV#^*Xa'!&@o{g4v]Rk;Jv{!%Rk[wkkiA5RkiwwfUB=x,fUuqC&*!>RfTg8v0RfV~ARfSd;rJsAuAv9wR'ae+/aO!a@aza/a#[yQ@Wg!2Wemg3sEr0JvB_g>uvReWg2v+Re=KupB_+[y!2AbY~-~Hr2AJwD!(h<~El>h<~El?Kun@+_:9b`}Kg-v/Ri3g;vtwyk_9]k_d=&T#*U.6qh@Ab`|K9:H|CJv[!&3Dtex'fDwC%!Rf[9WlMd[(^X,!a%Z06Vz!@WgBg=v~Rgvg,QRe@awd,#Y+jTv|Q~EfWj]uNr|~FRfXdy#Y&^Ua%!aO.!(a)Ua;=!a@aKap!a-,a!Ta]a[rSa]p?[y82sK=Bq~;:p:~<5p8Pw:5p7d'#Y'Wf(;RnRi[u4w&RgJJvG'!6Vyh=<r#ijuuv/sIKuYD'ZtG@3p9~Gr&d2#`(g<vtRgFj`u5w&rqpxRf2CJuY!+:wfnTOu!5Rg}jNs1ucv&RfwJvA!&3@q|BDcC#T,k/unq8w8Q5RkTklwQuzunq8w8Q5Rk9dga#!a'!a=#a0!:+Tb*b@aO.a4!aba8aFJv^}?!VyR~Dr<g;u%Rn.~<5p[x'e`wNZtR@3p]Pw:5pZhNvjBp.woe_g5u-r4JwF!%DtO3:ooc7&!#:p^3DtpLuGw(!+%)Dtk6Vz#2sd=<r8d'#Y([y#<x3gJt`w@!)%}MRiowzikRij=]ilxAf3,U(#B2Rf#g0v-Rm[ck{`U#]giKv3>)!&6Ri154s,KuGB_%@r68r:dJ|t`#X(9<E|u2@H|rx3gJu?w'!+'1Nu7Reg4=H~+9<wxgY95Rm]xLggZ-`(X}U2:Ri4h<uOawRmsJv__5@bb{jbV~3dka#a'a]!,#a+U=a>b6a3b%!/aKa/)!arwve^VyJ;:pR~DpTg3uJpS~<5pOPw;5qmPw:5pNOu!5pQJvG'!6Vyx=<qoJvA!{~Jup!%@qk7Rn/KvyD!}''[xz;>wkh'?Rh,x8gyt`w5D!&),(SgyccRgztJ@3pPB5p#d'(Y#<]mmifubw&RgoJvE&!82s^JvF&!8Rf,ADb]~;x=h'rNu]vK!,%'*0RnORh)4Rh*AqQg-vaRnNg;wHwkh'ba~4cE#Ta*x3gctyw@'!+%RnFRnD<4Rn@hFvK5RnCxWg[#`&a0Ua()`1Rm75Rg[c]%X#qi8Rg^NvdRj>BwzgZauwji7Rm6A4wgg]d1#&(*,.0a#Rm;Rm<Rm=Rm>Rm?Rm@RmARmBe%#^^^Xaea?aC/b+(,!a+a#!a/!>a&Ta<aKbD!2wphBRnk[yPw}hE|.=Br-3Dtm>6Vy~g6urRf.x,hPrNav!%'RnqRo%Ro#Nu;q[Pw;5r+JwNZtM@3r)d'#Y'Weh;xChL#`&RnmRnoKu}>%(!Rne~Bs-;2wjcussJv+'!aYSO}6@B<5?ba~8LrNvj!.%*ROwungw~ng~:9;Ri^>wtnig;wHRnixDh@|(UZ.x1h@|)!#:2<H|*xHn]#-UX'3Ro)z=iT}6ARns=Bwsn_wpnaRncw]aR(#UXa&Ua*a/=]iPd'#Y&Ro'WnXf{QRm2hNvj]nZd`'T~&1`{|`#9b]{}c:'!#Wl{>@=be}]?cl{{U#:5Abb}Jds#^YaF!a*b4a#a3aPa>&Tb!bH!*a_!Eau?/a&RjY<]gj>6Vz*;:pe~DrZg,QRj1JwNZtX@wihspcJvZ&!VyX9WmOJu|!|N2WmHJvh&!]ht~Bpbcn&T(!#RmQ<s7Nu;padH#X'`+WmJ@>RmKCARhnKup=!)&Wf+:RhqNuPpf9c!#'45pd5AwghpARn(Ls@w!%,)!RmP@Wfe<E|IJva!&WmNg8vsRmLd`*.`#Y'Xa!axRn*]hrA8Rhug5s@rXg8u!RmMd8#X'X*3@rV72smdI*#UY&RmICARho~GsgxVgd)Ta'U-Y&Xa!T#RnEWnA@Wffg1uDRi0hFvK5RnBxGnG&#`%owp)@wsf+bX}Ze-*1!a*^^^Ua|!#a.aq&Ya2!a>.a6!a:aO`aJDtL[y`@Wg#>6Vz12@wzoYRoZNuPRi!NuPRhzg=ucRi,@=b`{Yg=ucRi-ACJvB!&Sh[ebSh]ebi`wUuFRm4Jw2_[y0JvB!.<Ju(!&SoG}6Shd}6<Ju(!&SoH}6She}6Kur@._g5vHRieJvx!{L2G{Kx6gd'T#?Rh82Wi5cZ#X(g1w)Rm5dW-Y(Ta#!a)!#aYa=wnfE=su2>>bU{0j9udv:<svj8uQv-7RgHdE%#^'sq9sp=>Bb_{TJv`!&g/r|snj6v(us5d,#Y(56H}[978H}]Jw5!&g1rushJvB!+j;v{u5?zDhd}6}bj;v{u5?zDhe}6}ce*#`(^^^a[aea!=!a6a*aoXb1a.!aAbL!b>,b'aL!aV@Wf|2Wlg3[y/JwNZt^@3piPw:5pgJunZou3@rsJva&!Vy_g<v~Rm#JvG'!6Vz0=<r{Ju{%!:pj@WfsiXuJu3Rm:JvZ&!WfA~Bph@c4Z&Dtwax5rubx(#:awRk1@d,#Y&RfjRfid1#,Y(@Wfp2Wlrg5s@ryKu[@!,'=]ig9wlk?Rk>g5u-rqJvy'!@9RkQcH(T#=>Ri~@<wkj(Wj(KuZB*!&<7rw@9RkRcH(T#=>Ri}@<wkj)Wj)dg(Ta2Xa9X#`-!a*CARhg@@=I}d9x;c~#X%so=<sj>2@@=aybb}XjWv0Q~EfEj3vLv;<d,#Y(56H}`978H}_dgaPaFa'a/!#a3Y0a_a;a|!1(a7-[yE3[xt;:pJNvZrrg3uJrvJwNZt=@3pIh=rt3rxPw:5pGOu!5rpJvG'!6Vys=<rz@c4Z&Dt(ax5rtJvZ!&~BpH@wsfNg-vaRlNci*U#=<wei<F}a5@Jq.!a*JQ!%@qZ23d(#Y&RjH5]jCk!u7w&u0udARjFd/prq=tyvpaEa(a:.!a1aZ(@@=I}:9wpd%=<sX55w_h}@@=I{t=ay<aU@@=I}T=ay<2@@=I})?C9:9au@9Cb]}DP~=x-fAZ(2Wl1=ay<aU@@=I}>5@d##Y+jTv|vV~EfFj]uNpn~FRfGdgaK!Z2&!a8a-Tb({E!acTbM*!a(DtY[yYd'%Y#sl[y*hHvh>Re5x2c{Z}.j4uCvcawRiMd+#X+_x&d!},<5RkX;2Hzw@x,gavfB-!{CcF&T#Roe;RodwWbBg5urRgaKvHC*_6Vz+<4opieuew&Rmq@d]&Y)X,T#X0Rh}<BqP=4qS9:ReMg/ujReNJw0!/<Jui%!bd{kawwnemRelAxUa?a3#*.&UX(Ya+a/RhvRnQ<o}9Wmtd-#Y&RgSRmw9;Rmxay=Rmyg-vaRmuxEhSrNu,v-voC!%(aR.a(a7+1Ro1>Ro5CE{A9b]{@;5x#eO{:g;urRi+KrNA!%(Ro3>Ro79;Ri_Ku@>{;&!x%gX|{KunA_+g5QRj/g3u5Rj#g>uERj%wio/xRhS&!,!#^1U}wba{8>>@=be}qC@:D5ba{7Ku+A&!}x?ba}t>>@=be}se(aA^^^Uat!b0#{pa+awUazbGa#aLb9bgaWac'a5TbS=Br!d1#`%scp_Jvl!#rT>Re0JvX&!VyN=H{Fcm#U&:pY=ReaJv2&!]h0=]nUJvG'!6Vy|=<r%JrM_=]h2@Wlud'#)U'Wf'b]{i=]h/Jvh!&~BpWg=v]RnMx+ny#'Nu;pVwjnu=]nwxJnx,T#`&Reqwjnt=]nvieu9vrRjLLuYwP(#+!th@wih5pX~Gr'g5v/Rh4KunA'!-CARnP@wwiN:Rm_9x'cvw>!|l=<saKvAA!0&3@q}>w^e1bp#&Re2Re3BDx7gH#T|f5H|eKuZ>!%(:qNAH{]Jv6!+3B2B9=b^{X<5<B92:E{ZLvhwA(a;a%!igQuyRmad+#Y}m@3Rh5d8#X'X*:AqUAHzmaxwbh<aXRnVcF}RT#Nw&cj#U(BWnug/vsRntdka)(a3+.Zb7aYYan1!bVa@Xa}[y^@b[{G=H{+hFu73Rj&Pv#5ReQcK%T#sig1v{Rj'Ku+D#'!t]~Grm~?rkKuMB!01d5#`'Vy.ta3Dtu~Hroc8#'{^45s85AwZbP&!#Rn!wghxWn#KvEA!)&2RlA2RlBx:h|#(T,=]j09Wobz>x]z/@awRoTd+#Y(az]hFhCrm4d,#Y+jTv|Q~EfMj]uNr|~FRfOdCa!Xa9_X#@<plJvf!%b`{(9;Rgwc;.!#2x7cw#T|UDb]|T5Ju={(!=@E{&Jv)&!Ab`{'awJvf!~*>>@=be{#KuY>!+&4Ezyi[ugv&RjIdea+T)#UXa&T-T&a!Rh9auRmW=]kLg5vuRn+g3u4Rn-Ow6ARn,hHus5xNk?#UX(U~)/g8v0RkD~AwkkF?Ri.OuNBwkkA?Ri/d|a2`a*^UYa.!aBTZaTa'Xa;!(!2!-a#b2[yC>6Vyq3[xr2Wi?g1rusVh%s?DtF~<5rbJs;%!DtBfswKtCj[uvuSsEu3RgVx3o:u+wN'*Zt;@3rd~Grh~?rfg8w)Lq)qE&-a%!>bI|`jWv0vV~EfCjTv|vV~Ef@j]uNpn~FRfBcK#T']gWNu7x,k7q4ai(0!hHv8<RhmkMu9vrsBuev/RhlCJvB!,g<v{wchh~@:Rhji[vrv{wchi~@:RhkdS&a5UY#Ta!RgPwwiI5BwciI~@:Rh`x'iJvj'!5]iJPu8Bwch]~@:Rhach)U#h3rp]gLh@t|Ax,hTq3ah!-(~@:Ro0Ou!5RhXj^v(pyw8unRhVd|)`,^UYas!a?/a2Z'a^Ta{Tb7Ta(a#!a,Wf&9sZ3DtAadamov=Bqt3[xig8vsRm~>waiL2b`{QJv*_Ouv2qgj<v]v2BqfdR'X*X#Y-@3qr~Gqv~?p6hHv-]glPup5Lq+q?_%*b_{qF{n9b^{rOu4ARhpKvCD!+&~Bqp:5Dbb}nwoiKl&unuTuBv]v+ueunaXRf0=Jvh!0nKufu8v1w&w7q%w&uHrz:Rgnj5w,uxDJq/(!hNw'5ReCk0s2u3w/w'5ReFd>Za&!*UaA=<wkgsRnSJv^!%Refifw3vyRgOKu_B'!,<]gkiiu:w&Rh<=C@a^<B57@2F{[<B5@aW:=3away9A5aW=<B=C@a^<B57@2F{Ie-#`(^^^bCara.b8aza6!/bZ,!adTbnTbOb+aFaS!aAT9@Wf~2Wli3Dtl2@d,#Y&RfnRfmJwJZtN~GqyJva&!VyMg<v~Rm%iXuJu3Rm9Jv[_=]ih9wlkDRkCd1#`(@Wg>2Wls3cH#T(@<Rj*=>Ri|b~'#23s9h<~El.d'#Y&Dtxi^rzvdRl#d*#U%(o|B2s`hJwSaxRmDKv4B&!1:Rmdd5#`'Vx}to~Hq{x'f1v3(!BA5ba|bJv_&!Wfug1v]ReIdO+U/Y#&G}-8wze=Rh{g1v]ReHg/uQRf/by#)ibQwERl/cH#T(@<Rj+=>Ri{cNu+vlax-!(#a0qa9<Rii2;;bU{H;x<i=&X#Rk`<4wwi=C9H~8xAI(Y#<azRi@45wXI<B9;5bb~7dL(X#Xa(+!aL6Vy{g5QqOau:5au2@ay547EzbxOcU(UX-T#Ta#:Cbb|A?wjh/b_|SOw6ARgtihr}u7Rhy<d1#T)X1@@=I|~=ay<2@@=aybb}Sj3vLv;<d,#Y(56H}A978H}@dGpvs@uAu`vcw9*!aFa+ai%(b!aXa8.a?a[ozWey=sU2@G}Nch&U#Rf_WexKu+D#'!t:~Gr`~?r^j]uNr|~FRg*j^psurwJt|RmcKv)@&!)7Rkv~Br[@wxfO:Rl3co#U'6Rezj_q#vIuavjRltwzeyh@vr5JqD0!>aY?C9:9au@9Cb]}9cl#U*5;5<H||jbuus1ucv&Rfvg1v~d/pppzqFr^a--a~!aMat1(hFv;Wiz@@=Izoj5uuv-7Rix~Cw`fk2WlVcZ#X,k)u3vWs@u2]ktg;wEx'fBq(_2Wg/jTv|vV~EfoJv]!15x'hzqG!(P~EfU~CRl_j6v(us5x4i-#T(2WmZ?C2F|d>Kq<aj1!*jTqIsBv=Wl`~Cw`fi2WlWj`v0u*~>RlR=c>Z,k#u3vWs@u2]kr<c1Z+jTqIsBv=Wla~Cw`fm2WlXdmb3!a{(arZa`bkTa%TbQTa-a9+c'!aM!/[yL=Bqug.w'RifhFvyDRj.g>vgwyk^9]k^Jv3_@WfbAARkhJw2_[x|JvB_wkoIRoKwkoJRoLd'(Y#<]gm=<9<H|yd'%_X#skDtb3awwqkgNulRkgdB#^',9:p'hJwSaxRmEBwVb8@4=H|qLu+w50&!)@3qs~?pU>Awwn;;Rn=c:Z'ARn<=<qwKvC@!/&~BqqJv6!&]eVb^z^xRge'/a%+^`#Sge}6<4Rn3=]n0Pw2>Rn8Jw0!&>Rn:>Rn6cY#a7+!a&=<wkaNw~h3z_c5Z{=wjh#=]nLKv^D!&)Vyz=bW|swYb<WetcG#T(2wxa@qVx@gD#Y&b^|V5JwG&!5bb|pg/w&RgD@x=kHs=uAvn!a%%/'+RmSRh694Ro`g-vaRmRhHv-]mlxCcS#`&ba~.5cD#Ta)P~=d,#Y(56H{>978H{Dd_#{2^Y%_+qbbb{6g3sERhsbU{?dfa.,`a(Xa<!aiX#(55RiG54RiHcI#T'WiU3RiVNvdwtfcRlKNvdd,#Y&RlHRlExQgf.1*^T'X#Sgf}6Wn4=]hfPrk>Rn7Jw0!&>Rn5>Rn9Lunw?&a2!,5<oq@@wqfdRlJj5Q~=d,#Y(~ARfcOuN]fdDKw;ay(}i!547E}j?cI#T(@5bV}iCbV}hdv(^^Tb?a40,b##Tbo!a*bR!a<b|a/!aKai!aU[yK=]o^g:v>ReGJwPZtK<7Rh+h<~El,Pv#5ReR@awwxjCg,ulRjDJv6&!]j!z?aQeeg>w=Sh<eeJw;!&axEzOg,Qosc!#*:wkeJ]eJ>x'h-u(!%Ro.w~h.zPdNZ(X,Ya![x{;9ReY;wkgxRiF:x?ap#Y&RmUg<s2Rkod]+UY0TZ'!a&A9sw<=bczLNvuw{gqzNhJwSaxRmCKuLay!#&s_Rf-55b^{uJvZa!!c%#(55Ri654wmiu5RiuawLu,vp!+}^%b_}Y9;wkgxba}o>A9:=b^}zKuh=a''!3awRk3c*'!#aHRk6c+Z&Rk5Rk4Jv)&!awRjSawd9*`#0?C2@EzMj8u<uJ5RmbjQrquJu3x,k>uq@_+=ayb^|W~ARkEOuN]k@7dhzV^X/X&a-#zRzSb`zXcJzTT#2WkVKvDBzW!%FzY9;5bbzWjQrquJu3Jw3%!b`zU=ayb^zQd:#X(T-a!6Vyywxh}=b]{Jg=u1RiAdGp~qHtzv!w(wA+a+a;<!aJaYai'anasb(=azRmV:Cbb{MLq2vb!%')RjuRjrRjtRjqx3jnqCw3!%')Rk(Rk+Rk&Rk)Lq2vb!%')Rj{RjxRjzRjwLq2vb!%')RjsRjpRjfRjex3jcqCw3!%')Rk'Rk*RjkRjl9<CbbzfOu4ARhxLq2vb!%')RjyRjvRjhRjgx=joq*uKvb!%')+-Rk.Rk%Rj~Rk-Rk#Rj}x=jdq*uKvb!%')+-Rk,Rk!Rj|RjmRjjRjidAq&qKs@uAv8Aa.'*-a@a&0!aM@a5[y73Dsy3Ds|3Dt):wxgI2sHJwJZt.~Gqxwsf0ikrzt}Rl0Jvy_[xj~HqzKv_A|D!&WfP8axRoVcf,U#k(v]v+ueunaXRf1Ju}'!g8u#Ri=jQw!sCunLprq>!,')~<5qeGzq9F{W=c##%s5au:5aU3CBE|;d4#X(D!a&6Vygx(b;#(=]ed?C2F{N<capoq2r[a&!aPa9,'Pw;5s:@@=I|,55w_h|@@=IzcP~=x'fCqB_2Wl2>aU@@=I|1OuNBc1Z+jTqIsBv=Wlc~Cw`fl2WlZ~AcTa%!Z+jTqIsBv=Wlb~Cw`fh2WlYk+uNqJsBv=WlSg,u3dca3#UXaMYa)TaB-=cM|7T#<bI}l5@B932:aV2G{BOuNBJq:|M!5Ezt=<B=C@a^<B57@2F{v>cB{/T#=ay<bI{3Jv6!a.6BKq0ah&+!5E}HP~Ef{978BaU@@=Iza<7d#.Y#978BaU@@=IzH~AJq0!(@@=IzG978BaU@@=IzFe,aU*Y&^^^bvJb,b:bFad!a,c2Ta>aL.bo6!a#CbTa'T#Re{2Wlh2@G{yg6t~Ro_NvdRfticuRQRllJv3&!x&c|zs@Jw3!%RflwpfkRlpKuL;%(!Re<@G|C2GzdhIvuBwgjAg-u0RjAKQB%!(GzZ@G|5NuuRl7d='T+Y#Vy[g<v~Rm!==G|>JvA!)@wma=]m1ifuaw&RmnLs@vT'!|/+[y,g:v>ReTJw1!#qX=x!eC{bLu+wT&)ZtZauq_~Graci&U#F|89:r_Lupvq!.)&2RlG8RfaC=x!eF{_h?rpWlmd&'!#X|&]k::xJey#`'T|+<E|&2@H|%dE#(^,g;u.RiEg6vjRiC9xCkA{O|zY#g=ucRmXKs0@!&*@G|m@awRknJuh!,3d(}gY}eJvj!%Rm):Jw3!%Rm+Rm-Ls0w(&!a(a#@b[|6cZ#X'7RkxWgAOu4ARn'dH'U#Y*Vz-Wm'CARm}d]*#a%^a*T'aK!a<9bV{PC=p*Jw4!&SgxcbB5r]idw(wBRmF7xFkt#&`(Rm/Rm8E|!JuY_9:Rl5=wrgr2:bbxd@xXfB(a*#T+!.X0X1Ta/a'T&RlDRfL>RlyARl9b[z[>RfZ:RlL:RfRwlg/ARl;9;RlxKv,A/!%7s69<74=BA5ba{-8Bde#`a<XaKYa1,a'P~=wxfB2bZ}}?C972@@=I}r8@55B9;5bb}G978B2@@=aybb}3j3vLv;<Jw3&!>Rfk=ayb^}4~Ad1#`*@@=aybb{w2@>==<bbz]dx+UY#^UaF!a9!bB'Ya1.!ajXa#%olRhD[y=3Dt#Ov5BrHKuMB%!(Rf^Wep~HrJwkiQjKr|~FRg)Ku+D#'!t5~GrF~?rDdV)UY,Z/_7RkuG{<~BrBg,rlsO:235B@bX}|d?a1!#`(6Vyn5@d##Y+jTv|vV~EfIj]uNpn~FRfH7Lq2vb1!a9-978BaU@@=Iz9978BbU}#~AJq0!(@@=Iz8978BaU@@=Iz7~AJQ|}!978BbU}!JvkaK!AdUa21-U#`a+(g/vsRn~Ou!5RPj:rmu9WhOjXuvvNr}:RhAj^v(pyw8unRn[kPr}p|u7vwv]RiSBd;pppzq@qHQa?(b.!a.a`@.|xa(hFv;Wiyj5uuv-7Riw~Cw`fg2WlU978BbU|wOuNBJqG!(P~EfD~CRlQcZ#X,k)u3vWs@u2]ksg;wEx'f@q1_2Wg.j]uNpn~FRfqJv]!15x'h{qG!(@@=IzK~CRl^j6v(us5x4i,#T(2WmY?C2F{1>Kq<aj1!*jTqIsBv=Wld~Cw`fj2Wl[j`v0u*~>RlT=c>Z,k#u3vWs@u2]kq<c1Z+jTqIsBv=Wle~Cw`fn2Wl]dn1#c(a(b^a2!b/bAT(bj!aDa7bu,a_a{c0!2T0g:v>ReD2@G{42@G{5~DpM~<5rc=Bx6i>{RT#RnI@zCx]y]z:2Jv[!zr5Awyk]9]k]dD(Y+X#6Vz.g=wKtgwhaCwgmTWj2Lu,w%_+/[y-B;b^xeg3u3Rj-2@bX{*KrJ<!+'@Wg(g?QRlC@Jv`!%b[zIwsfII}8JQ_@w|kW|=Jv(%!AqcOuNBJvEzh!bYzjLs@wP#(0!oy@>RkdJwMZtc3Dtd@BcG#T'9bWxg2@2Fznd*#Y+;2x'c}w<zizixNgwa#Z'U+!/!a'!a+w~g~z6wcn{Rn}wcnzRn|5Rh%=]nJg5vuRmvNvdRlvcprJu}w*az*a#!%.a.'Bot9qT]kj@Wg'ay2Gzv@Jv`!%b[zEwsfHI}1;ck#Ux`<Cbbx_Lu+w!a&0*!wko*wwo,So,}6Juqxf!E}PigQuyRm`d3(`#8>Rn%:A5B;bZ~%KvhCa!a2!x>k7#Uxb@b{#xaRk7Jw0!)>wwhlShl}6>wwhmShm}6CJvB!.x'hhvj{!!5Bwkhhbaz}x'hivjz~!5Bwkhibaz|xEhTrNu,v-vpD!a%&/)a3a.,%Ro2t[CE{)@3re9b]{%wjo09:rgc:Z&Ro6=<riifuaw&RmoKrNA!%(Ro4>Ro89;Ri`dSaL'UYzxZb)7Rka3xRhT&!,!#^1U}vbaz{>>@=be}yC@:D5bazzKu+A&!}{?ba}y>>@=be}wxBh[t`u~vJvr!%a!a()a,a0a4RoC=]o;Ju(!%RoGRhdwjh`=]oAg>w#Ro?g5vuRo=NvdRl|Ku]C.!&;RoEJvB!%RoORoMBx'h[v+_?w~h`}~5?w~hd~!xKh]oiptu-utv.vp!#%&a30a@a'a+(a/aOp(o~p!RoDJu(!%RoHRhewjha=]oBNvdRl}g>w#Ro@g5vuRo>c[#X']o<CauRoRAd-#Y':RkpauRoQKu]C.!&;RoFJvB!%RoNRoPBx'h]v+_?w~ha}t5?w~he}ue!/UbhYacXaW^Tc&a;b:a-c/#b&aja1(!cL+!bKbt!bmcRc9aIc?8[yW3Dtt94Rg`Jv}!&SiRMzBhEebShEMNuPRe>x7gL#TzuwjirRipc<Z&>on;>z=h-MSh.Mwqczx'a7vj&!>Re4@=ResJt__NuPRi*NuPRi)j]uNr|~FRfzKrJ>_+@Wfy@Wf]2WocKrJ<!+'@Wg%g/QRl@@Jv`!&awRl<wsfFIzgLu(w*!.*&ShBMwvhIRhI9;RhNx1hK'!#Sn]Mx1hK~0!#:2<H~7cNu+w7D*'1ZtW>Rn1~?rOc:Z&Rn2=<rQ<7wjh&=BSnLMc]#X(6Vz)w[b=a!U#9wzgMc3#&(RgMRitRis<x,gKt`ax!&+SioM=BSilMc3#&(RgKRinRimKurB,!&SiQMzBhDebShDM6BJQ!(P~Efx978B2@@=I}WLrJw!!,a*&@G}O@9wkibRid@@x'fKwC!&SlDMSfLMjUv~Q~EfKKv3@a+!(hFv-]mpx/hYZ(C5RiWz<o/MwkhY?So/M@x,gbvfB*&!SgEM:SoeeehFu3:Rgbda(,^TZa)X/7Sg[eb:2RgI~BrMC@wgkc:wwkcRerx3h(uUvK!&*,SnOM4Sh*MArRg;wHRh(x=h;rJvPwI!a4',a'0@Wg&=BSh/Mg>w=Rh=g3w*wwgGRgGcW(X#;Sg}M2Gzk@Jv`!&awRl=wsfGIz`dKZ*T'Y-:RhR7RhQg5u-p`j6v(us5d,#Y+~Awkia?RicOuNBwkibba}Ld6p~tyu_vbAa'a+!a/'a3aEa8a!>Sh,ebJv{!&Sh@ebSaReb9;SgwebNuPRi(NvdRl)NuPRi'hHu^<Rm^Jvv_@Wl(g;u1Si/ebKu'B&!*Sh?eb@Wl'z@aPeb95Si.ebcpputyvjB)!,&a+0a%ShAMWeK@G}C@WfJ9;RhMwvhH9w{ia}ix,hJvRA1(!zAn[MRhHx1hJ~*!#hFv(BSn[MBJQ!(@@=I~'978B2@@=I}2db.Ua<'X}+T#a0XaG2G}E;wkg|wuh!Rh!x,hZu,@)!&So0MVy)C5RiXACJvB!&5RiY5RiZg8w)cG}*T#2@bU}=KsA>(!a.3wkhZba~(x,h^u(A!&(SoCMRhb5Bz=h[eb?w~hb~6x,h_u(A!&(SoDMRhc5Bz=h]eb?w~hc~6e)aA1T#T,^^^c-bMb&blcPaP(a/!0!bA=b5c@a(!bfbrc#2afwmhARnjwchORnp2Wlf3DtsNvdRl-2@wpa<]m0bx(#:awRk2@Jw3!%RfhwpfgRlnKQB%!(G{V@G|'NuuRl6d='T+Y#VyUg<v~Rl~==G|<Jv+'!aYShC}6@B<5?ba~8@Jw3'!g2QRljhLrpWlOd+#Y'g.w'rIg>w*wgj@g-u0Rj@Lu+wT&)ZtUauq]~GrGci&U#F|39:rELrNvj!.%*RhCwunfw~nf~:9;Ri]>wtnhg;wHRnhx3hDs@v~!/+'@Wfr@9RkSNu&Rlo=@<5GzoKs0@_+@Wl+@awRkmJuh!-3d(}pY#qWJvj!%Rm(:Jw3!%Rm,Rm*de&!1U-U#`)Re;@G|.@9Ri82@wjfvRlq=@<5GzpLvOvr!).&2RlF8Rf`C=x!eE{.Jw3_g2QRlkhLrpWlPde(!#U{s,UXa*Ta'[y'g:v>ReS;x0PZ&RnlRnn~HrKJw1}f!=x!eB|2w]aP(#Xa&a*Ta.Ua2a7=]iOd'#Y&Ro&WnWg;u.RiDg6vjRiBNvdRlzhNvj]nYJuW_2Wm3x)kFze{9d])!a.!,Y01!#&aC!a3RndC=ox~BrC@2b^{pg,rlse7x'ksuq!%Rm.E{xidw(wBRmGx9o+)X#wwo-So-}69:Rl4@xSf@a#XZ'X)X,Ta(/ARl8b[xc>RfY:RlI:RfQwlg.ARl:9;Rlwdn'#^XafaQa1X1TaHTa)@b[{zcZ#X'7RkwWg@Ou4ARn&x)kG#{,g7u/RkGdH'U#Y*Vz'Wm&CARm|bx#(A]gUbUzJj9Q~=d,#Y(56H}l978H{U7d,0#U*2>ABb_xZ978BbU{e~AJQ{g!978BbU{hxMh?ad{oUYZ.x1h?{l!#:2<H{mx3n[t{vl!,&a%3Ro(z=iS}6ARnr=Bwsn^wvn`Rnbd`*T}B0!#^X'BG{c9b]{a>>@=be}F?JvS!&BG{d7BG}(Bde#`a1X,Ya@!a'P~=wxf@2bZ}I56B2@@=aybb}08@55B9;5bb}<j3vLv;<Jw3&!>Rfg=ayb^}&OuNBKuLA!)a!P~=x#fD{f2@>==<bbzl?C972@@=Ix^d6rSu,v7w*C(0a)a6#B+a%!sQ[y?3Dt%3[xn~<5rLOu!5p@Ku+D#'!t7~GrP~?rNKvlaya7'!h+v-5qMg=t|cd,U#5AAaa5Abb{S@52B5@a[@52B5Gx[iXueu;d<#`a(!/549C;ag>23ExY5@Dah89b^~689Jv)!~2b[~1Lv'w(%*!a#bX|aPrmawRe]keu7uhv-q6rxu,q`xTo]/a5aU!bNaDXbi!b-!ao!b<bwA!#5@B932:aV2G|:d-)Y#hJrL>RhG<7@C5<H|_=Cau:5aj5@B932:bJ|ng>vIbs)#?C2F|9jPv0w.vISh-MKvUaz(.!9ABbb|[5;5<H|Eg>unwfh;9:4E|YjQsBt|vjx'hYq3!(?C2F|J:2<BaY?C2F|GOu!5x,g|p{ah!-(?C2F|c9:4E|OjXuvvNr}:Rh&i[w*t|cd+U#jJvsu)vsSn~Mkfrmu9p}u7vwv]So!McW#Xa!ax5@A5aY:5;5<H|>kJv~vYrquJu3x4ib#T)2@SmZM?C2F|Bj:rmu9@xPhI(a*a#U#`a3-5Abb|L~@:RhK9:4E|0@52B5G|#C::aY?C2F|-:2<BaY?C2F|.5Jvk!a)javYrquJu3x4ia#T)2@SmYM?C2F|HAxPhH(!a#U#`a*-5Abb|4~@:RhJ9:4E|R@52B5G|F:2<BaY?C2F|Sc^#Xa2j=Qq5CJvB!-g<v{z;hhM?C2F|Zi[vrv{z;hiM?C2F|XKsA>!a)-g<v{z;h[eb?C2F|]i[vrv{z;h]eb?C2F|^iZu.vix,hZq3ah!.(?C2F|QOu!5ShXM:2<BaY?C2F|P", 13494, 2713, 49, 25, 61);
	var xmlDecodeTree = new Uint16Array([
		512,
		26465,
		29036,
		7,
		0,
		2,
		4,
		116,
		24638,
		116,
		24636,
		8693,
		29807,
		24610,
		621,
		1,
		0,
		0,
		3,
		112,
		24614,
		111,
		115,
		24615
	]);
	var BinTrieFlags;
	(function(BinTrieFlags) {
		BinTrieFlags[BinTrieFlags["VALUE_LENGTH"] = 49152] = "VALUE_LENGTH";
		BinTrieFlags[BinTrieFlags["FLAG13"] = 8192] = "FLAG13";
		BinTrieFlags[BinTrieFlags["BRANCH_LENGTH"] = 8064] = "BRANCH_LENGTH";
		BinTrieFlags[BinTrieFlags["JUMP_TABLE"] = 127] = "JUMP_TABLE";
		BinTrieFlags[BinTrieFlags["VALUE_MASK"] = 8191] = "VALUE_MASK";
	})(BinTrieFlags || (BinTrieFlags = {}));
	var CharCodes;
	(function(CharCodes) {
		CharCodes[CharCodes["AMP"] = 38] = "AMP";
		CharCodes[CharCodes["NUM"] = 35] = "NUM";
		CharCodes[CharCodes["SEMI"] = 59] = "SEMI";
		CharCodes[CharCodes["EQUALS"] = 61] = "EQUALS";
		CharCodes[CharCodes["ZERO"] = 48] = "ZERO";
		CharCodes[CharCodes["NINE"] = 57] = "NINE";
		CharCodes[CharCodes["LOWER_A"] = 97] = "LOWER_A";
		CharCodes[CharCodes["LOWER_X"] = 120] = "LOWER_X";
	})(CharCodes || (CharCodes = {}));
	var TO_LOWER_BIT = 32;
	function isNumber(code) {
		return code - CharCodes.ZERO >>> 0 <= 9;
	}
	function isHexadecimalCharacter(code) {
		return (code | TO_LOWER_BIT) - CharCodes.LOWER_A >>> 0 <= 5;
	}
	function isAlpha(code) {
		return (code | TO_LOWER_BIT) - CharCodes.LOWER_A >>> 0 <= 25;
	}
	function isEntityInAttributeInvalidEnd(code) {
		return code === CharCodes.EQUALS || isAlpha(code) || isNumber(code);
	}
	var EntityDecoderState;
	(function(EntityDecoderState) {
		EntityDecoderState[EntityDecoderState["EntityStart"] = 0] = "EntityStart";
		EntityDecoderState[EntityDecoderState["NumericStart"] = 1] = "NumericStart";
		EntityDecoderState[EntityDecoderState["NumericDecimal"] = 2] = "NumericDecimal";
		EntityDecoderState[EntityDecoderState["NumericHex"] = 3] = "NumericHex";
		EntityDecoderState[EntityDecoderState["NamedEntity"] = 4] = "NamedEntity";
	})(EntityDecoderState || (EntityDecoderState = {}));
	var DecodingMode;
	(function(DecodingMode) {
		DecodingMode[DecodingMode["Legacy"] = 0] = "Legacy";
		DecodingMode[DecodingMode["Strict"] = 1] = "Strict";
		DecodingMode[DecodingMode["Attribute"] = 2] = "Attribute";
	})(DecodingMode || (DecodingMode = {}));
	var EntityDecoder = class {
		decodeTree;
		emitCodePoint;
		errors;
		state = EntityDecoderState.EntityStart;
		consumed = 1;
		result = 0;
		treeIndex = 0;
		excess = 1;
		decodeMode = DecodingMode.Strict;
		runConsumed = 0;
		constructor(decodeTree, emitCodePoint, errors) {
			this.decodeTree = decodeTree;
			this.emitCodePoint = emitCodePoint;
			this.errors = errors;
		}
		startEntity(decodeMode) {
			this.decodeMode = decodeMode;
			this.state = EntityDecoderState.EntityStart;
			this.result = 0;
			this.treeIndex = 0;
			this.excess = 1;
			this.consumed = 1;
			this.runConsumed = 0;
		}
		write(input, offset) {
			switch (this.state) {
				case EntityDecoderState.EntityStart:
					if (input.charCodeAt(offset) === CharCodes.NUM) {
						this.state = EntityDecoderState.NumericStart;
						this.consumed += 1;
						return this.stateNumericStart(input, offset + 1);
					}
					this.state = EntityDecoderState.NamedEntity;
					return this.stateNamedEntity(input, offset);
				case EntityDecoderState.NumericStart: return this.stateNumericStart(input, offset);
				case EntityDecoderState.NumericDecimal: return this.stateNumericDecimal(input, offset);
				case EntityDecoderState.NumericHex: return this.stateNumericHex(input, offset);
				default: return this.stateNamedEntity(input, offset);
			}
		}
		stateNumericStart(input, offset) {
			if (offset >= input.length) return -1;
			if ((input.charCodeAt(offset) | TO_LOWER_BIT) === CharCodes.LOWER_X) {
				this.state = EntityDecoderState.NumericHex;
				this.consumed += 1;
				return this.stateNumericHex(input, offset + 1);
			}
			this.state = EntityDecoderState.NumericDecimal;
			return this.stateNumericDecimal(input, offset);
		}
		stateNumericHex(input, offset) {
			const inputLength = input.length;
			let { result } = this;
			let { consumed } = this;
			while (offset < inputLength) {
				const char = input.charCodeAt(offset);
				if (isNumber(char) || isHexadecimalCharacter(char)) {
					const digit = char <= CharCodes.NINE ? char - CharCodes.ZERO : (char | TO_LOWER_BIT) - CharCodes.LOWER_A + 10;
					result = result * 16 + digit;
					consumed += 1;
					offset += 1;
				} else {
					this.result = result;
					this.consumed = consumed;
					return this.emitNumericEntity(char, 3);
				}
			}
			this.result = result;
			this.consumed = consumed;
			return -1;
		}
		stateNumericDecimal(input, offset) {
			const inputLength = input.length;
			let { result } = this;
			let { consumed } = this;
			while (offset < inputLength) {
				const digit = input.charCodeAt(offset) - CharCodes.ZERO;
				if (digit >>> 0 > 9) {
					this.result = result;
					this.consumed = consumed;
					return this.emitNumericEntity(digit + CharCodes.ZERO, 2);
				}
				result = result * 10 + digit;
				consumed += 1;
				offset += 1;
			}
			this.result = result;
			this.consumed = consumed;
			return -1;
		}
		emitNumericEntity(lastCp, expectedLength) {
			if (this.consumed <= expectedLength) {
				this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed);
				return 0;
			}
			if (lastCp === CharCodes.SEMI) this.consumed += 1;
			else if (this.decodeMode === DecodingMode.Strict) return 0;
			this.emitCodePoint((this.decodeTree === xmlDecodeTree ? replaceCodePointXML : replaceCodePoint)(this.result), this.consumed);
			if (this.errors) {
				if (lastCp !== CharCodes.SEMI) this.errors.missingSemicolonAfterCharacterReference();
				this.errors.validateNumericCharacterReference(this.result);
			}
			return this.consumed;
		}
		flushAndEmitLegacyOrReject(consumed, excess, char, valueLength) {
			this.consumed = consumed;
			this.excess = excess;
			return this.result === 0 || this.decodeMode === DecodingMode.Attribute && (valueLength === 0 || excess > 1 || isEntityInAttributeInvalidEnd(char)) ? 0 : this.emitNotTerminatedNamedEntity();
		}
		stateNamedEntity(input, offset) {
			const { decodeTree } = this;
			const inputLength = input.length;
			const isStrict = this.decodeMode === DecodingMode.Strict;
			let { treeIndex } = this;
			let { excess } = this;
			let { consumed } = this;
			let current = decodeTree[treeIndex];
			while (offset < inputLength) {
				while ((current & (BinTrieFlags.VALUE_LENGTH | BinTrieFlags.FLAG13)) === 0 && (current & BinTrieFlags.JUMP_TABLE) !== 0) {
					const char = input.charCodeAt(offset);
					const jumpOffset = current & BinTrieFlags.JUMP_TABLE;
					const branchCount = (current & BinTrieFlags.BRANCH_LENGTH) >> 7;
					if (branchCount === 0) {
						if (char !== jumpOffset) return this.flushAndEmitLegacyOrReject(consumed, excess, char, 0);
						treeIndex += 1;
					} else {
						const slot = char - jumpOffset;
						if (slot >>> 0 >= branchCount) return this.flushAndEmitLegacyOrReject(consumed, excess, char, 0);
						const stored = decodeTree[treeIndex + 1 + slot];
						if (stored === 0) return this.flushAndEmitLegacyOrReject(consumed, excess, char, 0);
						treeIndex = treeIndex + branchCount + stored & 65535;
					}
					current = decodeTree[treeIndex];
					offset += 1;
					excess += 1;
					if (offset >= inputLength) break;
				}
				if (offset >= inputLength) break;
				if ((current & (BinTrieFlags.VALUE_LENGTH | BinTrieFlags.FLAG13)) === BinTrieFlags.FLAG13) {
					const runLength = (current & BinTrieFlags.BRANCH_LENGTH) >> 7;
					let { runConsumed } = this;
					if (runConsumed === 0) {
						const char = input.charCodeAt(offset);
						if (char !== (current & BinTrieFlags.JUMP_TABLE)) return this.flushAndEmitLegacyOrReject(consumed, excess, char, 0);
						offset += 1;
						excess += 1;
						runConsumed = 1;
					}
					while (runConsumed < runLength) {
						if (offset >= inputLength) {
							this.treeIndex = treeIndex;
							this.excess = excess;
							this.consumed = consumed;
							this.runConsumed = runConsumed;
							return -1;
						}
						const charIndexInPacked = runConsumed - 1;
						const expectedChar = decodeTree[treeIndex + 1 + (charIndexInPacked >> 1)] >> ((charIndexInPacked & 1) << 3) & 255;
						const char = input.charCodeAt(offset);
						if (char !== expectedChar) {
							this.runConsumed = 0;
							return this.flushAndEmitLegacyOrReject(consumed, excess, char, 0);
						}
						offset += 1;
						excess += 1;
						runConsumed += 1;
					}
					this.runConsumed = 0;
					treeIndex += 1 + (runLength >> 1);
					current = decodeTree[treeIndex];
					continue;
				}
				const valueLength = current >>> 14;
				const char = input.charCodeAt(offset);
				if (valueLength !== 0) {
					if (!isStrict && (current & BinTrieFlags.FLAG13) === 0) {
						this.result = treeIndex;
						consumed += excess - 1;
						excess = 1;
					}
					if (char === CharCodes.SEMI) return this.emitNamedEntityData(treeIndex, valueLength, consumed + excess);
					if (valueLength === 1) return this.flushAndEmitLegacyOrReject(consumed, excess, char, valueLength);
				}
				const next = determineBranch(decodeTree, current, treeIndex + (valueLength || 1), char);
				if (next < 0) return this.flushAndEmitLegacyOrReject(consumed, excess, char, valueLength);
				treeIndex = next;
				current = decodeTree[treeIndex];
				offset += 1;
				excess += 1;
			}
			if (!isStrict && current >>> 14 !== 0 && (current & BinTrieFlags.FLAG13) === 0) {
				this.result = treeIndex;
				consumed += excess - 1;
				excess = 1;
			}
			this.treeIndex = treeIndex;
			this.excess = excess;
			this.consumed = consumed;
			return -1;
		}
		emitNotTerminatedNamedEntity() {
			const { result, decodeTree } = this;
			const valueLength = decodeTree[result] >>> 14;
			this.emitNamedEntityData(result, valueLength, this.consumed);
			this.errors?.missingSemicolonAfterCharacterReference();
			return this.consumed;
		}
		emitNamedEntityData(result, valueLength, consumed) {
			const { decodeTree } = this;
			this.emitCodePoint(valueLength === 1 ? decodeTree[result] & BinTrieFlags.VALUE_MASK : decodeTree[result + 1], consumed);
			if (valueLength === 3) this.emitCodePoint(decodeTree[result + 2], consumed);
			return consumed;
		}
		end() {
			switch (this.state) {
				case EntityDecoderState.NamedEntity: return this.result !== 0 && (this.decodeMode !== DecodingMode.Attribute || this.result === this.treeIndex) ? this.emitNotTerminatedNamedEntity() : 0;
				case EntityDecoderState.NumericDecimal: return this.emitNumericEntity(0, 2);
				case EntityDecoderState.NumericHex: return this.emitNumericEntity(0, 3);
				case EntityDecoderState.NumericStart:
					this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed);
					return 0;
				default: return 0;
			}
		}
	};
	function determineBranch(decodeTree, current, nodeIndex, char) {
		const branchCount = (current & BinTrieFlags.BRANCH_LENGTH) >> 7;
		const jumpOffset = current & BinTrieFlags.JUMP_TABLE;
		if (jumpOffset) {
			if (branchCount === 0) return char === jumpOffset ? nodeIndex : -1;
			const slot = char - jumpOffset;
			if (slot >>> 0 >= branchCount) return -1;
			const stored = decodeTree[nodeIndex + slot];
			return stored === 0 ? -1 : nodeIndex + branchCount + stored - 1 & 65535;
		}
		if (branchCount === 0) return -1;
		const packedKeySlots = branchCount + 1 >> 1;
		const branchEnd = nodeIndex + packedKeySlots + branchCount;
		for (let index = 0; index < branchCount; index++) {
			const key = decodeTree[nodeIndex + (index >> 1)] >> ((index & 1) << 3) & 255;
			if (key === char) return branchEnd + decodeTree[nodeIndex + packedKeySlots + index] & 65535;
			if (key > char) return -1;
		}
		return -1;
	}
	var NS;
	(function(NS) {
		NS["HTML"] = "http://www.w3.org/1999/xhtml";
		NS["MATHML"] = "http://www.w3.org/1998/Math/MathML";
		NS["SVG"] = "http://www.w3.org/2000/svg";
		NS["XLINK"] = "http://www.w3.org/1999/xlink";
		NS["XML"] = "http://www.w3.org/XML/1998/namespace";
		NS["XMLNS"] = "http://www.w3.org/2000/xmlns/";
	})(NS || (NS = {}));
	var ATTRS;
	(function(ATTRS) {
		ATTRS["TYPE"] = "type";
		ATTRS["ACTION"] = "action";
		ATTRS["ENCODING"] = "encoding";
		ATTRS["PROMPT"] = "prompt";
		ATTRS["NAME"] = "name";
		ATTRS["COLOR"] = "color";
		ATTRS["FACE"] = "face";
		ATTRS["SIZE"] = "size";
	})(ATTRS || (ATTRS = {}));
	var DOCUMENT_MODE;
	(function(DOCUMENT_MODE) {
		DOCUMENT_MODE["NO_QUIRKS"] = "no-quirks";
		DOCUMENT_MODE["QUIRKS"] = "quirks";
		DOCUMENT_MODE["LIMITED_QUIRKS"] = "limited-quirks";
	})(DOCUMENT_MODE || (DOCUMENT_MODE = {}));
	var TAG_NAMES;
	(function(TAG_NAMES) {
		TAG_NAMES["A"] = "a";
		TAG_NAMES["ADDRESS"] = "address";
		TAG_NAMES["ANNOTATION_XML"] = "annotation-xml";
		TAG_NAMES["APPLET"] = "applet";
		TAG_NAMES["AREA"] = "area";
		TAG_NAMES["ARTICLE"] = "article";
		TAG_NAMES["ASIDE"] = "aside";
		TAG_NAMES["B"] = "b";
		TAG_NAMES["BASE"] = "base";
		TAG_NAMES["BASEFONT"] = "basefont";
		TAG_NAMES["BGSOUND"] = "bgsound";
		TAG_NAMES["BIG"] = "big";
		TAG_NAMES["BLOCKQUOTE"] = "blockquote";
		TAG_NAMES["BODY"] = "body";
		TAG_NAMES["BR"] = "br";
		TAG_NAMES["BUTTON"] = "button";
		TAG_NAMES["CAPTION"] = "caption";
		TAG_NAMES["CENTER"] = "center";
		TAG_NAMES["CODE"] = "code";
		TAG_NAMES["COL"] = "col";
		TAG_NAMES["COLGROUP"] = "colgroup";
		TAG_NAMES["DD"] = "dd";
		TAG_NAMES["DESC"] = "desc";
		TAG_NAMES["DETAILS"] = "details";
		TAG_NAMES["DIALOG"] = "dialog";
		TAG_NAMES["DIR"] = "dir";
		TAG_NAMES["DIV"] = "div";
		TAG_NAMES["DL"] = "dl";
		TAG_NAMES["DT"] = "dt";
		TAG_NAMES["EM"] = "em";
		TAG_NAMES["EMBED"] = "embed";
		TAG_NAMES["FIELDSET"] = "fieldset";
		TAG_NAMES["FIGCAPTION"] = "figcaption";
		TAG_NAMES["FIGURE"] = "figure";
		TAG_NAMES["FONT"] = "font";
		TAG_NAMES["FOOTER"] = "footer";
		TAG_NAMES["FOREIGN_OBJECT"] = "foreignObject";
		TAG_NAMES["FORM"] = "form";
		TAG_NAMES["FRAME"] = "frame";
		TAG_NAMES["FRAMESET"] = "frameset";
		TAG_NAMES["H1"] = "h1";
		TAG_NAMES["H2"] = "h2";
		TAG_NAMES["H3"] = "h3";
		TAG_NAMES["H4"] = "h4";
		TAG_NAMES["H5"] = "h5";
		TAG_NAMES["H6"] = "h6";
		TAG_NAMES["HEAD"] = "head";
		TAG_NAMES["HEADER"] = "header";
		TAG_NAMES["HGROUP"] = "hgroup";
		TAG_NAMES["HR"] = "hr";
		TAG_NAMES["HTML"] = "html";
		TAG_NAMES["I"] = "i";
		TAG_NAMES["IMG"] = "img";
		TAG_NAMES["IMAGE"] = "image";
		TAG_NAMES["INPUT"] = "input";
		TAG_NAMES["IFRAME"] = "iframe";
		TAG_NAMES["KEYGEN"] = "keygen";
		TAG_NAMES["LABEL"] = "label";
		TAG_NAMES["LI"] = "li";
		TAG_NAMES["LINK"] = "link";
		TAG_NAMES["LISTING"] = "listing";
		TAG_NAMES["MAIN"] = "main";
		TAG_NAMES["MALIGNMARK"] = "malignmark";
		TAG_NAMES["MARQUEE"] = "marquee";
		TAG_NAMES["MATH"] = "math";
		TAG_NAMES["MENU"] = "menu";
		TAG_NAMES["META"] = "meta";
		TAG_NAMES["MGLYPH"] = "mglyph";
		TAG_NAMES["MI"] = "mi";
		TAG_NAMES["MO"] = "mo";
		TAG_NAMES["MN"] = "mn";
		TAG_NAMES["MS"] = "ms";
		TAG_NAMES["MTEXT"] = "mtext";
		TAG_NAMES["NAV"] = "nav";
		TAG_NAMES["NOBR"] = "nobr";
		TAG_NAMES["NOFRAMES"] = "noframes";
		TAG_NAMES["NOEMBED"] = "noembed";
		TAG_NAMES["NOSCRIPT"] = "noscript";
		TAG_NAMES["OBJECT"] = "object";
		TAG_NAMES["OL"] = "ol";
		TAG_NAMES["OPTGROUP"] = "optgroup";
		TAG_NAMES["OPTION"] = "option";
		TAG_NAMES["P"] = "p";
		TAG_NAMES["PARAM"] = "param";
		TAG_NAMES["PLAINTEXT"] = "plaintext";
		TAG_NAMES["PRE"] = "pre";
		TAG_NAMES["RB"] = "rb";
		TAG_NAMES["RP"] = "rp";
		TAG_NAMES["RT"] = "rt";
		TAG_NAMES["RTC"] = "rtc";
		TAG_NAMES["RUBY"] = "ruby";
		TAG_NAMES["S"] = "s";
		TAG_NAMES["SCRIPT"] = "script";
		TAG_NAMES["SEARCH"] = "search";
		TAG_NAMES["SECTION"] = "section";
		TAG_NAMES["SELECT"] = "select";
		TAG_NAMES["SOURCE"] = "source";
		TAG_NAMES["SMALL"] = "small";
		TAG_NAMES["SPAN"] = "span";
		TAG_NAMES["STRIKE"] = "strike";
		TAG_NAMES["STRONG"] = "strong";
		TAG_NAMES["STYLE"] = "style";
		TAG_NAMES["SUB"] = "sub";
		TAG_NAMES["SUMMARY"] = "summary";
		TAG_NAMES["SUP"] = "sup";
		TAG_NAMES["TABLE"] = "table";
		TAG_NAMES["TBODY"] = "tbody";
		TAG_NAMES["TEMPLATE"] = "template";
		TAG_NAMES["TEXTAREA"] = "textarea";
		TAG_NAMES["TFOOT"] = "tfoot";
		TAG_NAMES["TD"] = "td";
		TAG_NAMES["TH"] = "th";
		TAG_NAMES["THEAD"] = "thead";
		TAG_NAMES["TITLE"] = "title";
		TAG_NAMES["TR"] = "tr";
		TAG_NAMES["TRACK"] = "track";
		TAG_NAMES["TT"] = "tt";
		TAG_NAMES["U"] = "u";
		TAG_NAMES["UL"] = "ul";
		TAG_NAMES["SVG"] = "svg";
		TAG_NAMES["VAR"] = "var";
		TAG_NAMES["WBR"] = "wbr";
		TAG_NAMES["XMP"] = "xmp";
	})(TAG_NAMES || (TAG_NAMES = {}));
	var TAG_ID;
	(function(TAG_ID) {
		TAG_ID[TAG_ID["UNKNOWN"] = 0] = "UNKNOWN";
		TAG_ID[TAG_ID["A"] = 1] = "A";
		TAG_ID[TAG_ID["ADDRESS"] = 2] = "ADDRESS";
		TAG_ID[TAG_ID["ANNOTATION_XML"] = 3] = "ANNOTATION_XML";
		TAG_ID[TAG_ID["APPLET"] = 4] = "APPLET";
		TAG_ID[TAG_ID["AREA"] = 5] = "AREA";
		TAG_ID[TAG_ID["ARTICLE"] = 6] = "ARTICLE";
		TAG_ID[TAG_ID["ASIDE"] = 7] = "ASIDE";
		TAG_ID[TAG_ID["B"] = 8] = "B";
		TAG_ID[TAG_ID["BASE"] = 9] = "BASE";
		TAG_ID[TAG_ID["BASEFONT"] = 10] = "BASEFONT";
		TAG_ID[TAG_ID["BGSOUND"] = 11] = "BGSOUND";
		TAG_ID[TAG_ID["BIG"] = 12] = "BIG";
		TAG_ID[TAG_ID["BLOCKQUOTE"] = 13] = "BLOCKQUOTE";
		TAG_ID[TAG_ID["BODY"] = 14] = "BODY";
		TAG_ID[TAG_ID["BR"] = 15] = "BR";
		TAG_ID[TAG_ID["BUTTON"] = 16] = "BUTTON";
		TAG_ID[TAG_ID["CAPTION"] = 17] = "CAPTION";
		TAG_ID[TAG_ID["CENTER"] = 18] = "CENTER";
		TAG_ID[TAG_ID["CODE"] = 19] = "CODE";
		TAG_ID[TAG_ID["COL"] = 20] = "COL";
		TAG_ID[TAG_ID["COLGROUP"] = 21] = "COLGROUP";
		TAG_ID[TAG_ID["DD"] = 22] = "DD";
		TAG_ID[TAG_ID["DESC"] = 23] = "DESC";
		TAG_ID[TAG_ID["DETAILS"] = 24] = "DETAILS";
		TAG_ID[TAG_ID["DIALOG"] = 25] = "DIALOG";
		TAG_ID[TAG_ID["DIR"] = 26] = "DIR";
		TAG_ID[TAG_ID["DIV"] = 27] = "DIV";
		TAG_ID[TAG_ID["DL"] = 28] = "DL";
		TAG_ID[TAG_ID["DT"] = 29] = "DT";
		TAG_ID[TAG_ID["EM"] = 30] = "EM";
		TAG_ID[TAG_ID["EMBED"] = 31] = "EMBED";
		TAG_ID[TAG_ID["FIELDSET"] = 32] = "FIELDSET";
		TAG_ID[TAG_ID["FIGCAPTION"] = 33] = "FIGCAPTION";
		TAG_ID[TAG_ID["FIGURE"] = 34] = "FIGURE";
		TAG_ID[TAG_ID["FONT"] = 35] = "FONT";
		TAG_ID[TAG_ID["FOOTER"] = 36] = "FOOTER";
		TAG_ID[TAG_ID["FOREIGN_OBJECT"] = 37] = "FOREIGN_OBJECT";
		TAG_ID[TAG_ID["FORM"] = 38] = "FORM";
		TAG_ID[TAG_ID["FRAME"] = 39] = "FRAME";
		TAG_ID[TAG_ID["FRAMESET"] = 40] = "FRAMESET";
		TAG_ID[TAG_ID["H1"] = 41] = "H1";
		TAG_ID[TAG_ID["H2"] = 42] = "H2";
		TAG_ID[TAG_ID["H3"] = 43] = "H3";
		TAG_ID[TAG_ID["H4"] = 44] = "H4";
		TAG_ID[TAG_ID["H5"] = 45] = "H5";
		TAG_ID[TAG_ID["H6"] = 46] = "H6";
		TAG_ID[TAG_ID["HEAD"] = 47] = "HEAD";
		TAG_ID[TAG_ID["HEADER"] = 48] = "HEADER";
		TAG_ID[TAG_ID["HGROUP"] = 49] = "HGROUP";
		TAG_ID[TAG_ID["HR"] = 50] = "HR";
		TAG_ID[TAG_ID["HTML"] = 51] = "HTML";
		TAG_ID[TAG_ID["I"] = 52] = "I";
		TAG_ID[TAG_ID["IMG"] = 53] = "IMG";
		TAG_ID[TAG_ID["IMAGE"] = 54] = "IMAGE";
		TAG_ID[TAG_ID["INPUT"] = 55] = "INPUT";
		TAG_ID[TAG_ID["IFRAME"] = 56] = "IFRAME";
		TAG_ID[TAG_ID["KEYGEN"] = 57] = "KEYGEN";
		TAG_ID[TAG_ID["LABEL"] = 58] = "LABEL";
		TAG_ID[TAG_ID["LI"] = 59] = "LI";
		TAG_ID[TAG_ID["LINK"] = 60] = "LINK";
		TAG_ID[TAG_ID["LISTING"] = 61] = "LISTING";
		TAG_ID[TAG_ID["MAIN"] = 62] = "MAIN";
		TAG_ID[TAG_ID["MALIGNMARK"] = 63] = "MALIGNMARK";
		TAG_ID[TAG_ID["MARQUEE"] = 64] = "MARQUEE";
		TAG_ID[TAG_ID["MATH"] = 65] = "MATH";
		TAG_ID[TAG_ID["MENU"] = 66] = "MENU";
		TAG_ID[TAG_ID["META"] = 67] = "META";
		TAG_ID[TAG_ID["MGLYPH"] = 68] = "MGLYPH";
		TAG_ID[TAG_ID["MI"] = 69] = "MI";
		TAG_ID[TAG_ID["MO"] = 70] = "MO";
		TAG_ID[TAG_ID["MN"] = 71] = "MN";
		TAG_ID[TAG_ID["MS"] = 72] = "MS";
		TAG_ID[TAG_ID["MTEXT"] = 73] = "MTEXT";
		TAG_ID[TAG_ID["NAV"] = 74] = "NAV";
		TAG_ID[TAG_ID["NOBR"] = 75] = "NOBR";
		TAG_ID[TAG_ID["NOFRAMES"] = 76] = "NOFRAMES";
		TAG_ID[TAG_ID["NOEMBED"] = 77] = "NOEMBED";
		TAG_ID[TAG_ID["NOSCRIPT"] = 78] = "NOSCRIPT";
		TAG_ID[TAG_ID["OBJECT"] = 79] = "OBJECT";
		TAG_ID[TAG_ID["OL"] = 80] = "OL";
		TAG_ID[TAG_ID["OPTGROUP"] = 81] = "OPTGROUP";
		TAG_ID[TAG_ID["OPTION"] = 82] = "OPTION";
		TAG_ID[TAG_ID["P"] = 83] = "P";
		TAG_ID[TAG_ID["PARAM"] = 84] = "PARAM";
		TAG_ID[TAG_ID["PLAINTEXT"] = 85] = "PLAINTEXT";
		TAG_ID[TAG_ID["PRE"] = 86] = "PRE";
		TAG_ID[TAG_ID["RB"] = 87] = "RB";
		TAG_ID[TAG_ID["RP"] = 88] = "RP";
		TAG_ID[TAG_ID["RT"] = 89] = "RT";
		TAG_ID[TAG_ID["RTC"] = 90] = "RTC";
		TAG_ID[TAG_ID["RUBY"] = 91] = "RUBY";
		TAG_ID[TAG_ID["S"] = 92] = "S";
		TAG_ID[TAG_ID["SCRIPT"] = 93] = "SCRIPT";
		TAG_ID[TAG_ID["SEARCH"] = 94] = "SEARCH";
		TAG_ID[TAG_ID["SECTION"] = 95] = "SECTION";
		TAG_ID[TAG_ID["SELECT"] = 96] = "SELECT";
		TAG_ID[TAG_ID["SOURCE"] = 97] = "SOURCE";
		TAG_ID[TAG_ID["SMALL"] = 98] = "SMALL";
		TAG_ID[TAG_ID["SPAN"] = 99] = "SPAN";
		TAG_ID[TAG_ID["STRIKE"] = 100] = "STRIKE";
		TAG_ID[TAG_ID["STRONG"] = 101] = "STRONG";
		TAG_ID[TAG_ID["STYLE"] = 102] = "STYLE";
		TAG_ID[TAG_ID["SUB"] = 103] = "SUB";
		TAG_ID[TAG_ID["SUMMARY"] = 104] = "SUMMARY";
		TAG_ID[TAG_ID["SUP"] = 105] = "SUP";
		TAG_ID[TAG_ID["TABLE"] = 106] = "TABLE";
		TAG_ID[TAG_ID["TBODY"] = 107] = "TBODY";
		TAG_ID[TAG_ID["TEMPLATE"] = 108] = "TEMPLATE";
		TAG_ID[TAG_ID["TEXTAREA"] = 109] = "TEXTAREA";
		TAG_ID[TAG_ID["TFOOT"] = 110] = "TFOOT";
		TAG_ID[TAG_ID["TD"] = 111] = "TD";
		TAG_ID[TAG_ID["TH"] = 112] = "TH";
		TAG_ID[TAG_ID["THEAD"] = 113] = "THEAD";
		TAG_ID[TAG_ID["TITLE"] = 114] = "TITLE";
		TAG_ID[TAG_ID["TR"] = 115] = "TR";
		TAG_ID[TAG_ID["TRACK"] = 116] = "TRACK";
		TAG_ID[TAG_ID["TT"] = 117] = "TT";
		TAG_ID[TAG_ID["U"] = 118] = "U";
		TAG_ID[TAG_ID["UL"] = 119] = "UL";
		TAG_ID[TAG_ID["SVG"] = 120] = "SVG";
		TAG_ID[TAG_ID["VAR"] = 121] = "VAR";
		TAG_ID[TAG_ID["WBR"] = 122] = "WBR";
		TAG_ID[TAG_ID["XMP"] = 123] = "XMP";
	})(TAG_ID || (TAG_ID = {}));
	var TAG_NAME_TO_ID = new Map([
		[TAG_NAMES.A, TAG_ID.A],
		[TAG_NAMES.ADDRESS, TAG_ID.ADDRESS],
		[TAG_NAMES.ANNOTATION_XML, TAG_ID.ANNOTATION_XML],
		[TAG_NAMES.APPLET, TAG_ID.APPLET],
		[TAG_NAMES.AREA, TAG_ID.AREA],
		[TAG_NAMES.ARTICLE, TAG_ID.ARTICLE],
		[TAG_NAMES.ASIDE, TAG_ID.ASIDE],
		[TAG_NAMES.B, TAG_ID.B],
		[TAG_NAMES.BASE, TAG_ID.BASE],
		[TAG_NAMES.BASEFONT, TAG_ID.BASEFONT],
		[TAG_NAMES.BGSOUND, TAG_ID.BGSOUND],
		[TAG_NAMES.BIG, TAG_ID.BIG],
		[TAG_NAMES.BLOCKQUOTE, TAG_ID.BLOCKQUOTE],
		[TAG_NAMES.BODY, TAG_ID.BODY],
		[TAG_NAMES.BR, TAG_ID.BR],
		[TAG_NAMES.BUTTON, TAG_ID.BUTTON],
		[TAG_NAMES.CAPTION, TAG_ID.CAPTION],
		[TAG_NAMES.CENTER, TAG_ID.CENTER],
		[TAG_NAMES.CODE, TAG_ID.CODE],
		[TAG_NAMES.COL, TAG_ID.COL],
		[TAG_NAMES.COLGROUP, TAG_ID.COLGROUP],
		[TAG_NAMES.DD, TAG_ID.DD],
		[TAG_NAMES.DESC, TAG_ID.DESC],
		[TAG_NAMES.DETAILS, TAG_ID.DETAILS],
		[TAG_NAMES.DIALOG, TAG_ID.DIALOG],
		[TAG_NAMES.DIR, TAG_ID.DIR],
		[TAG_NAMES.DIV, TAG_ID.DIV],
		[TAG_NAMES.DL, TAG_ID.DL],
		[TAG_NAMES.DT, TAG_ID.DT],
		[TAG_NAMES.EM, TAG_ID.EM],
		[TAG_NAMES.EMBED, TAG_ID.EMBED],
		[TAG_NAMES.FIELDSET, TAG_ID.FIELDSET],
		[TAG_NAMES.FIGCAPTION, TAG_ID.FIGCAPTION],
		[TAG_NAMES.FIGURE, TAG_ID.FIGURE],
		[TAG_NAMES.FONT, TAG_ID.FONT],
		[TAG_NAMES.FOOTER, TAG_ID.FOOTER],
		[TAG_NAMES.FOREIGN_OBJECT, TAG_ID.FOREIGN_OBJECT],
		[TAG_NAMES.FORM, TAG_ID.FORM],
		[TAG_NAMES.FRAME, TAG_ID.FRAME],
		[TAG_NAMES.FRAMESET, TAG_ID.FRAMESET],
		[TAG_NAMES.H1, TAG_ID.H1],
		[TAG_NAMES.H2, TAG_ID.H2],
		[TAG_NAMES.H3, TAG_ID.H3],
		[TAG_NAMES.H4, TAG_ID.H4],
		[TAG_NAMES.H5, TAG_ID.H5],
		[TAG_NAMES.H6, TAG_ID.H6],
		[TAG_NAMES.HEAD, TAG_ID.HEAD],
		[TAG_NAMES.HEADER, TAG_ID.HEADER],
		[TAG_NAMES.HGROUP, TAG_ID.HGROUP],
		[TAG_NAMES.HR, TAG_ID.HR],
		[TAG_NAMES.HTML, TAG_ID.HTML],
		[TAG_NAMES.I, TAG_ID.I],
		[TAG_NAMES.IMG, TAG_ID.IMG],
		[TAG_NAMES.IMAGE, TAG_ID.IMAGE],
		[TAG_NAMES.INPUT, TAG_ID.INPUT],
		[TAG_NAMES.IFRAME, TAG_ID.IFRAME],
		[TAG_NAMES.KEYGEN, TAG_ID.KEYGEN],
		[TAG_NAMES.LABEL, TAG_ID.LABEL],
		[TAG_NAMES.LI, TAG_ID.LI],
		[TAG_NAMES.LINK, TAG_ID.LINK],
		[TAG_NAMES.LISTING, TAG_ID.LISTING],
		[TAG_NAMES.MAIN, TAG_ID.MAIN],
		[TAG_NAMES.MALIGNMARK, TAG_ID.MALIGNMARK],
		[TAG_NAMES.MARQUEE, TAG_ID.MARQUEE],
		[TAG_NAMES.MATH, TAG_ID.MATH],
		[TAG_NAMES.MENU, TAG_ID.MENU],
		[TAG_NAMES.META, TAG_ID.META],
		[TAG_NAMES.MGLYPH, TAG_ID.MGLYPH],
		[TAG_NAMES.MI, TAG_ID.MI],
		[TAG_NAMES.MO, TAG_ID.MO],
		[TAG_NAMES.MN, TAG_ID.MN],
		[TAG_NAMES.MS, TAG_ID.MS],
		[TAG_NAMES.MTEXT, TAG_ID.MTEXT],
		[TAG_NAMES.NAV, TAG_ID.NAV],
		[TAG_NAMES.NOBR, TAG_ID.NOBR],
		[TAG_NAMES.NOFRAMES, TAG_ID.NOFRAMES],
		[TAG_NAMES.NOEMBED, TAG_ID.NOEMBED],
		[TAG_NAMES.NOSCRIPT, TAG_ID.NOSCRIPT],
		[TAG_NAMES.OBJECT, TAG_ID.OBJECT],
		[TAG_NAMES.OL, TAG_ID.OL],
		[TAG_NAMES.OPTGROUP, TAG_ID.OPTGROUP],
		[TAG_NAMES.OPTION, TAG_ID.OPTION],
		[TAG_NAMES.P, TAG_ID.P],
		[TAG_NAMES.PARAM, TAG_ID.PARAM],
		[TAG_NAMES.PLAINTEXT, TAG_ID.PLAINTEXT],
		[TAG_NAMES.PRE, TAG_ID.PRE],
		[TAG_NAMES.RB, TAG_ID.RB],
		[TAG_NAMES.RP, TAG_ID.RP],
		[TAG_NAMES.RT, TAG_ID.RT],
		[TAG_NAMES.RTC, TAG_ID.RTC],
		[TAG_NAMES.RUBY, TAG_ID.RUBY],
		[TAG_NAMES.S, TAG_ID.S],
		[TAG_NAMES.SCRIPT, TAG_ID.SCRIPT],
		[TAG_NAMES.SEARCH, TAG_ID.SEARCH],
		[TAG_NAMES.SECTION, TAG_ID.SECTION],
		[TAG_NAMES.SELECT, TAG_ID.SELECT],
		[TAG_NAMES.SOURCE, TAG_ID.SOURCE],
		[TAG_NAMES.SMALL, TAG_ID.SMALL],
		[TAG_NAMES.SPAN, TAG_ID.SPAN],
		[TAG_NAMES.STRIKE, TAG_ID.STRIKE],
		[TAG_NAMES.STRONG, TAG_ID.STRONG],
		[TAG_NAMES.STYLE, TAG_ID.STYLE],
		[TAG_NAMES.SUB, TAG_ID.SUB],
		[TAG_NAMES.SUMMARY, TAG_ID.SUMMARY],
		[TAG_NAMES.SUP, TAG_ID.SUP],
		[TAG_NAMES.TABLE, TAG_ID.TABLE],
		[TAG_NAMES.TBODY, TAG_ID.TBODY],
		[TAG_NAMES.TEMPLATE, TAG_ID.TEMPLATE],
		[TAG_NAMES.TEXTAREA, TAG_ID.TEXTAREA],
		[TAG_NAMES.TFOOT, TAG_ID.TFOOT],
		[TAG_NAMES.TD, TAG_ID.TD],
		[TAG_NAMES.TH, TAG_ID.TH],
		[TAG_NAMES.THEAD, TAG_ID.THEAD],
		[TAG_NAMES.TITLE, TAG_ID.TITLE],
		[TAG_NAMES.TR, TAG_ID.TR],
		[TAG_NAMES.TRACK, TAG_ID.TRACK],
		[TAG_NAMES.TT, TAG_ID.TT],
		[TAG_NAMES.U, TAG_ID.U],
		[TAG_NAMES.UL, TAG_ID.UL],
		[TAG_NAMES.SVG, TAG_ID.SVG],
		[TAG_NAMES.VAR, TAG_ID.VAR],
		[TAG_NAMES.WBR, TAG_ID.WBR],
		[TAG_NAMES.XMP, TAG_ID.XMP]
	]);
	function getTagID(tagName) {
		var _a;
		return (_a = TAG_NAME_TO_ID.get(tagName)) !== null && _a !== void 0 ? _a : TAG_ID.UNKNOWN;
	}
	var $ = TAG_ID;
	var SPECIAL_ELEMENTS = {
		[NS.HTML]: new Set([
			$.ADDRESS,
			$.APPLET,
			$.AREA,
			$.ARTICLE,
			$.ASIDE,
			$.BASE,
			$.BASEFONT,
			$.BGSOUND,
			$.BLOCKQUOTE,
			$.BODY,
			$.BR,
			$.BUTTON,
			$.CAPTION,
			$.CENTER,
			$.COL,
			$.COLGROUP,
			$.DD,
			$.DETAILS,
			$.DIR,
			$.DIV,
			$.DL,
			$.DT,
			$.EMBED,
			$.FIELDSET,
			$.FIGCAPTION,
			$.FIGURE,
			$.FOOTER,
			$.FORM,
			$.FRAME,
			$.FRAMESET,
			$.H1,
			$.H2,
			$.H3,
			$.H4,
			$.H5,
			$.H6,
			$.HEAD,
			$.HEADER,
			$.HGROUP,
			$.HR,
			$.HTML,
			$.IFRAME,
			$.IMG,
			$.INPUT,
			$.LI,
			$.LINK,
			$.LISTING,
			$.MAIN,
			$.MARQUEE,
			$.MENU,
			$.META,
			$.NAV,
			$.NOEMBED,
			$.NOFRAMES,
			$.NOSCRIPT,
			$.OBJECT,
			$.OL,
			$.P,
			$.PARAM,
			$.PLAINTEXT,
			$.PRE,
			$.SCRIPT,
			$.SECTION,
			$.SELECT,
			$.SOURCE,
			$.STYLE,
			$.SUMMARY,
			$.TABLE,
			$.TBODY,
			$.TD,
			$.TEMPLATE,
			$.TEXTAREA,
			$.TFOOT,
			$.TH,
			$.THEAD,
			$.TITLE,
			$.TR,
			$.TRACK,
			$.UL,
			$.WBR,
			$.XMP
		]),
		[NS.MATHML]: new Set([
			$.MI,
			$.MO,
			$.MN,
			$.MS,
			$.MTEXT,
			$.ANNOTATION_XML
		]),
		[NS.SVG]: new Set([
			$.TITLE,
			$.FOREIGN_OBJECT,
			$.DESC
		]),
		[NS.XLINK]: new Set(),
		[NS.XML]: new Set(),
		[NS.XMLNS]: new Set()
	};
	var NUMBERED_HEADERS = new Set([
		$.H1,
		$.H2,
		$.H3,
		$.H4,
		$.H5,
		$.H6
	]);
	TAG_NAMES.STYLE, TAG_NAMES.SCRIPT, TAG_NAMES.XMP, TAG_NAMES.IFRAME, TAG_NAMES.NOEMBED, TAG_NAMES.NOFRAMES, TAG_NAMES.PLAINTEXT;
	var State;
	(function(State) {
		State[State["DATA"] = 0] = "DATA";
		State[State["RCDATA"] = 1] = "RCDATA";
		State[State["RAWTEXT"] = 2] = "RAWTEXT";
		State[State["SCRIPT_DATA"] = 3] = "SCRIPT_DATA";
		State[State["PLAINTEXT"] = 4] = "PLAINTEXT";
		State[State["TAG_OPEN"] = 5] = "TAG_OPEN";
		State[State["END_TAG_OPEN"] = 6] = "END_TAG_OPEN";
		State[State["TAG_NAME"] = 7] = "TAG_NAME";
		State[State["RCDATA_LESS_THAN_SIGN"] = 8] = "RCDATA_LESS_THAN_SIGN";
		State[State["RCDATA_END_TAG_OPEN"] = 9] = "RCDATA_END_TAG_OPEN";
		State[State["RCDATA_END_TAG_NAME"] = 10] = "RCDATA_END_TAG_NAME";
		State[State["RAWTEXT_LESS_THAN_SIGN"] = 11] = "RAWTEXT_LESS_THAN_SIGN";
		State[State["RAWTEXT_END_TAG_OPEN"] = 12] = "RAWTEXT_END_TAG_OPEN";
		State[State["RAWTEXT_END_TAG_NAME"] = 13] = "RAWTEXT_END_TAG_NAME";
		State[State["SCRIPT_DATA_LESS_THAN_SIGN"] = 14] = "SCRIPT_DATA_LESS_THAN_SIGN";
		State[State["SCRIPT_DATA_END_TAG_OPEN"] = 15] = "SCRIPT_DATA_END_TAG_OPEN";
		State[State["SCRIPT_DATA_END_TAG_NAME"] = 16] = "SCRIPT_DATA_END_TAG_NAME";
		State[State["SCRIPT_DATA_ESCAPE_START"] = 17] = "SCRIPT_DATA_ESCAPE_START";
		State[State["SCRIPT_DATA_ESCAPE_START_DASH"] = 18] = "SCRIPT_DATA_ESCAPE_START_DASH";
		State[State["SCRIPT_DATA_ESCAPED"] = 19] = "SCRIPT_DATA_ESCAPED";
		State[State["SCRIPT_DATA_ESCAPED_DASH"] = 20] = "SCRIPT_DATA_ESCAPED_DASH";
		State[State["SCRIPT_DATA_ESCAPED_DASH_DASH"] = 21] = "SCRIPT_DATA_ESCAPED_DASH_DASH";
		State[State["SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN"] = 22] = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN";
		State[State["SCRIPT_DATA_ESCAPED_END_TAG_OPEN"] = 23] = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN";
		State[State["SCRIPT_DATA_ESCAPED_END_TAG_NAME"] = 24] = "SCRIPT_DATA_ESCAPED_END_TAG_NAME";
		State[State["SCRIPT_DATA_DOUBLE_ESCAPE_START"] = 25] = "SCRIPT_DATA_DOUBLE_ESCAPE_START";
		State[State["SCRIPT_DATA_DOUBLE_ESCAPED"] = 26] = "SCRIPT_DATA_DOUBLE_ESCAPED";
		State[State["SCRIPT_DATA_DOUBLE_ESCAPED_DASH"] = 27] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH";
		State[State["SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH"] = 28] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH";
		State[State["SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN"] = 29] = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN";
		State[State["SCRIPT_DATA_DOUBLE_ESCAPE_END"] = 30] = "SCRIPT_DATA_DOUBLE_ESCAPE_END";
		State[State["BEFORE_ATTRIBUTE_NAME"] = 31] = "BEFORE_ATTRIBUTE_NAME";
		State[State["ATTRIBUTE_NAME"] = 32] = "ATTRIBUTE_NAME";
		State[State["AFTER_ATTRIBUTE_NAME"] = 33] = "AFTER_ATTRIBUTE_NAME";
		State[State["BEFORE_ATTRIBUTE_VALUE"] = 34] = "BEFORE_ATTRIBUTE_VALUE";
		State[State["ATTRIBUTE_VALUE_DOUBLE_QUOTED"] = 35] = "ATTRIBUTE_VALUE_DOUBLE_QUOTED";
		State[State["ATTRIBUTE_VALUE_SINGLE_QUOTED"] = 36] = "ATTRIBUTE_VALUE_SINGLE_QUOTED";
		State[State["ATTRIBUTE_VALUE_UNQUOTED"] = 37] = "ATTRIBUTE_VALUE_UNQUOTED";
		State[State["AFTER_ATTRIBUTE_VALUE_QUOTED"] = 38] = "AFTER_ATTRIBUTE_VALUE_QUOTED";
		State[State["SELF_CLOSING_START_TAG"] = 39] = "SELF_CLOSING_START_TAG";
		State[State["BOGUS_COMMENT"] = 40] = "BOGUS_COMMENT";
		State[State["MARKUP_DECLARATION_OPEN"] = 41] = "MARKUP_DECLARATION_OPEN";
		State[State["COMMENT_START"] = 42] = "COMMENT_START";
		State[State["COMMENT_START_DASH"] = 43] = "COMMENT_START_DASH";
		State[State["COMMENT"] = 44] = "COMMENT";
		State[State["COMMENT_LESS_THAN_SIGN"] = 45] = "COMMENT_LESS_THAN_SIGN";
		State[State["COMMENT_LESS_THAN_SIGN_BANG"] = 46] = "COMMENT_LESS_THAN_SIGN_BANG";
		State[State["COMMENT_LESS_THAN_SIGN_BANG_DASH"] = 47] = "COMMENT_LESS_THAN_SIGN_BANG_DASH";
		State[State["COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH"] = 48] = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH";
		State[State["COMMENT_END_DASH"] = 49] = "COMMENT_END_DASH";
		State[State["COMMENT_END"] = 50] = "COMMENT_END";
		State[State["COMMENT_END_BANG"] = 51] = "COMMENT_END_BANG";
		State[State["DOCTYPE"] = 52] = "DOCTYPE";
		State[State["BEFORE_DOCTYPE_NAME"] = 53] = "BEFORE_DOCTYPE_NAME";
		State[State["DOCTYPE_NAME"] = 54] = "DOCTYPE_NAME";
		State[State["AFTER_DOCTYPE_NAME"] = 55] = "AFTER_DOCTYPE_NAME";
		State[State["AFTER_DOCTYPE_PUBLIC_KEYWORD"] = 56] = "AFTER_DOCTYPE_PUBLIC_KEYWORD";
		State[State["BEFORE_DOCTYPE_PUBLIC_IDENTIFIER"] = 57] = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER";
		State[State["DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED"] = 58] = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED";
		State[State["DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED"] = 59] = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED";
		State[State["AFTER_DOCTYPE_PUBLIC_IDENTIFIER"] = 60] = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER";
		State[State["BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS"] = 61] = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS";
		State[State["AFTER_DOCTYPE_SYSTEM_KEYWORD"] = 62] = "AFTER_DOCTYPE_SYSTEM_KEYWORD";
		State[State["BEFORE_DOCTYPE_SYSTEM_IDENTIFIER"] = 63] = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER";
		State[State["DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED"] = 64] = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED";
		State[State["DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED"] = 65] = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED";
		State[State["AFTER_DOCTYPE_SYSTEM_IDENTIFIER"] = 66] = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER";
		State[State["BOGUS_DOCTYPE"] = 67] = "BOGUS_DOCTYPE";
		State[State["CDATA_SECTION"] = 68] = "CDATA_SECTION";
		State[State["CDATA_SECTION_BRACKET"] = 69] = "CDATA_SECTION_BRACKET";
		State[State["CDATA_SECTION_END"] = 70] = "CDATA_SECTION_END";
		State[State["CHARACTER_REFERENCE"] = 71] = "CHARACTER_REFERENCE";
		State[State["AMBIGUOUS_AMPERSAND"] = 72] = "AMBIGUOUS_AMPERSAND";
	})(State || (State = {}));
	var TokenizerMode = {
		DATA: State.DATA,
		RCDATA: State.RCDATA,
		RAWTEXT: State.RAWTEXT,
		SCRIPT_DATA: State.SCRIPT_DATA,
		PLAINTEXT: State.PLAINTEXT,
		CDATA_SECTION: State.CDATA_SECTION
	};
	function isAsciiDigit(cp) {
		return cp >= CODE_POINTS.DIGIT_0 && cp <= CODE_POINTS.DIGIT_9;
	}
	function isAsciiUpper(cp) {
		return cp >= CODE_POINTS.LATIN_CAPITAL_A && cp <= CODE_POINTS.LATIN_CAPITAL_Z;
	}
	function isAsciiLower(cp) {
		return cp >= CODE_POINTS.LATIN_SMALL_A && cp <= CODE_POINTS.LATIN_SMALL_Z;
	}
	function isAsciiLetter(cp) {
		return isAsciiLower(cp) || isAsciiUpper(cp);
	}
	function isAsciiAlphaNumeric(cp) {
		return isAsciiLetter(cp) || isAsciiDigit(cp);
	}
	function toAsciiLower(cp) {
		return cp + 32;
	}
	function isWhitespace(cp) {
		return cp === CODE_POINTS.SPACE || cp === CODE_POINTS.LINE_FEED || cp === CODE_POINTS.TABULATION || cp === CODE_POINTS.FORM_FEED;
	}
	function isScriptDataDoubleEscapeSequenceEnd(cp) {
		return isWhitespace(cp) || cp === CODE_POINTS.SOLIDUS || cp === CODE_POINTS.GREATER_THAN_SIGN;
	}
	function getErrorForNumericCharacterReference(code) {
		if (code === CODE_POINTS.NULL) return ERR.nullCharacterReference;
		else if (code > 1114111) return ERR.characterReferenceOutsideUnicodeRange;
		else if (isSurrogate(code)) return ERR.surrogateCharacterReference;
		else if (isUndefinedCodePoint(code)) return ERR.noncharacterCharacterReference;
		else if (isControlCodePoint(code) || code === CODE_POINTS.CARRIAGE_RETURN) return ERR.controlCharacterReference;
		return null;
	}
	var Tokenizer = class {
		constructor(options, handler) {
			this.options = options;
			this.handler = handler;
			this.paused = false;
			this.inLoop = false;
			this.inForeignNode = false;
			this.lastStartTagName = "";
			this.active = false;
			this.state = State.DATA;
			this.returnState = State.DATA;
			this.entityStartPos = 0;
			this.consumedAfterSnapshot = -1;
			this.currentCharacterToken = null;
			this.currentToken = null;
			this.currentAttr = {
				name: "",
				value: ""
			};
			this.preprocessor = new Preprocessor(handler);
			this.currentLocation = this.getCurrentLocation(-1);
			this.entityDecoder = new EntityDecoder(htmlDecodeTree, (cp, consumed) => {
				this.preprocessor.pos = this.entityStartPos + consumed - 1;
				this._flushCodePointConsumedAsCharacterReference(cp);
			}, handler.onParseError ? {
				missingSemicolonAfterCharacterReference: () => {
					this._err(ERR.missingSemicolonAfterCharacterReference, 1);
				},
				absenceOfDigitsInNumericCharacterReference: (consumed) => {
					this._err(ERR.absenceOfDigitsInNumericCharacterReference, this.entityStartPos - this.preprocessor.pos + consumed);
				},
				validateNumericCharacterReference: (code) => {
					const error = getErrorForNumericCharacterReference(code);
					if (error) this._err(error, 1);
				}
			} : void 0);
		}
		_err(code, cpOffset = 0) {
			var _a, _b;
			(_b = (_a = this.handler).onParseError) === null || _b === void 0 || _b.call(_a, this.preprocessor.getError(code, cpOffset));
		}
		getCurrentLocation(offset) {
			if (!this.options.sourceCodeLocationInfo) return null;
			return {
				startLine: this.preprocessor.line,
				startCol: this.preprocessor.col - offset,
				startOffset: this.preprocessor.offset - offset,
				endLine: -1,
				endCol: -1,
				endOffset: -1
			};
		}
		_runParsingLoop() {
			if (this.inLoop) return;
			this.inLoop = true;
			while (this.active && !this.paused) {
				this.consumedAfterSnapshot = 0;
				const cp = this._consume();
				if (!this._ensureHibernation()) this._callState(cp);
			}
			this.inLoop = false;
		}
		pause() {
			this.paused = true;
		}
		resume(writeCallback) {
			if (!this.paused) throw new Error("Parser was already resumed");
			this.paused = false;
			if (this.inLoop) return;
			this._runParsingLoop();
			if (!this.paused) writeCallback === null || writeCallback === void 0 || writeCallback();
		}
		write(chunk, isLastChunk, writeCallback) {
			this.active = true;
			this.preprocessor.write(chunk, isLastChunk);
			this._runParsingLoop();
			if (!this.paused) writeCallback === null || writeCallback === void 0 || writeCallback();
		}
		insertHtmlAtCurrentPos(chunk) {
			this.active = true;
			this.preprocessor.insertHtmlAtCurrentPos(chunk);
			this._runParsingLoop();
		}
		_ensureHibernation() {
			if (this.preprocessor.endOfChunkHit) {
				this.preprocessor.retreat(this.consumedAfterSnapshot);
				this.consumedAfterSnapshot = 0;
				this.active = false;
				return true;
			}
			return false;
		}
		_consume() {
			this.consumedAfterSnapshot++;
			return this.preprocessor.advance();
		}
		_advanceBy(count) {
			this.consumedAfterSnapshot += count;
			for (let i = 0; i < count; i++) this.preprocessor.advance();
		}
		_consumeSequenceIfMatch(pattern, caseSensitive) {
			if (this.preprocessor.startsWith(pattern, caseSensitive)) {
				this._advanceBy(pattern.length - 1);
				return true;
			}
			return false;
		}
		_createStartTagToken() {
			this.currentToken = {
				type: TokenType.START_TAG,
				tagName: "",
				tagID: TAG_ID.UNKNOWN,
				selfClosing: false,
				ackSelfClosing: false,
				attrs: [],
				location: this.getCurrentLocation(1)
			};
		}
		_createEndTagToken() {
			this.currentToken = {
				type: TokenType.END_TAG,
				tagName: "",
				tagID: TAG_ID.UNKNOWN,
				selfClosing: false,
				ackSelfClosing: false,
				attrs: [],
				location: this.getCurrentLocation(2)
			};
		}
		_createCommentToken(offset) {
			this.currentToken = {
				type: TokenType.COMMENT,
				data: "",
				location: this.getCurrentLocation(offset)
			};
		}
		_createDoctypeToken(initialName) {
			this.currentToken = {
				type: TokenType.DOCTYPE,
				name: initialName,
				forceQuirks: false,
				publicId: null,
				systemId: null,
				location: this.currentLocation
			};
		}
		_createCharacterToken(type, chars) {
			this.currentCharacterToken = {
				type,
				chars,
				location: this.currentLocation
			};
		}
		_createAttr(attrNameFirstCh) {
			this.currentAttr = {
				name: attrNameFirstCh,
				value: ""
			};
			this.currentLocation = this.getCurrentLocation(0);
		}
		_leaveAttrName() {
			var _a;
			var _b;
			const token = this.currentToken;
			if (getTokenAttr(token, this.currentAttr.name) === null) {
				token.attrs.push(this.currentAttr);
				if (token.location && this.currentLocation) {
					const attrLocations = (_a = (_b = token.location).attrs) !== null && _a !== void 0 ? _a : _b.attrs = Object.create(null);
					attrLocations[this.currentAttr.name] = this.currentLocation;
					this._leaveAttrValue();
				}
			} else this._err(ERR.duplicateAttribute);
		}
		_leaveAttrValue() {
			if (this.currentLocation) {
				this.currentLocation.endLine = this.preprocessor.line;
				this.currentLocation.endCol = this.preprocessor.col;
				this.currentLocation.endOffset = this.preprocessor.offset;
			}
		}
		prepareToken(ct) {
			this._emitCurrentCharacterToken(ct.location);
			this.currentToken = null;
			if (ct.location) {
				ct.location.endLine = this.preprocessor.line;
				ct.location.endCol = this.preprocessor.col + 1;
				ct.location.endOffset = this.preprocessor.offset + 1;
			}
			this.currentLocation = this.getCurrentLocation(-1);
		}
		emitCurrentTagToken() {
			const ct = this.currentToken;
			this.prepareToken(ct);
			ct.tagID = getTagID(ct.tagName);
			if (ct.type === TokenType.START_TAG) {
				this.lastStartTagName = ct.tagName;
				this.handler.onStartTag(ct);
			} else {
				if (ct.attrs.length > 0) this._err(ERR.endTagWithAttributes);
				if (ct.selfClosing) this._err(ERR.endTagWithTrailingSolidus);
				this.handler.onEndTag(ct);
			}
			this.preprocessor.dropParsedChunk();
		}
		emitCurrentComment(ct) {
			this.prepareToken(ct);
			this.handler.onComment(ct);
			this.preprocessor.dropParsedChunk();
		}
		emitCurrentDoctype(ct) {
			this.prepareToken(ct);
			this.handler.onDoctype(ct);
			this.preprocessor.dropParsedChunk();
		}
		_emitCurrentCharacterToken(nextLocation) {
			if (this.currentCharacterToken) {
				if (nextLocation && this.currentCharacterToken.location) {
					this.currentCharacterToken.location.endLine = nextLocation.startLine;
					this.currentCharacterToken.location.endCol = nextLocation.startCol;
					this.currentCharacterToken.location.endOffset = nextLocation.startOffset;
				}
				switch (this.currentCharacterToken.type) {
					case TokenType.CHARACTER:
						this.handler.onCharacter(this.currentCharacterToken);
						break;
					case TokenType.NULL_CHARACTER:
						this.handler.onNullCharacter(this.currentCharacterToken);
						break;
					case TokenType.WHITESPACE_CHARACTER: this.handler.onWhitespaceCharacter(this.currentCharacterToken);
				}
				this.currentCharacterToken = null;
			}
		}
		_emitEOFToken() {
			const location = this.getCurrentLocation(0);
			if (location) {
				location.endLine = location.startLine;
				location.endCol = location.startCol;
				location.endOffset = location.startOffset;
			}
			this._emitCurrentCharacterToken(location);
			this.handler.onEof({
				type: TokenType.EOF,
				location
			});
			this.active = false;
		}
		_appendCharToCurrentCharacterToken(type, ch) {
			if (this.currentCharacterToken) {
				if (this.currentCharacterToken.type === type) {
					this.currentCharacterToken.chars += ch;
					return;
				} else {
					this.currentLocation = this.getCurrentLocation(0);
					this._emitCurrentCharacterToken(this.currentLocation);
					this.preprocessor.dropParsedChunk();
				}
			}
			this._createCharacterToken(type, ch);
		}
		_emitCodePoint(cp) {
			const type = isWhitespace(cp) ? TokenType.WHITESPACE_CHARACTER : cp === CODE_POINTS.NULL ? TokenType.NULL_CHARACTER : TokenType.CHARACTER;
			this._appendCharToCurrentCharacterToken(type, cp < 65536 ? String.fromCharCode(cp) : String.fromCodePoint(cp));
		}
		_emitChars(ch) {
			this._appendCharToCurrentCharacterToken(TokenType.CHARACTER, ch);
		}
		_startCharacterReference() {
			this.returnState = this.state;
			this.state = State.CHARACTER_REFERENCE;
			this.entityStartPos = this.preprocessor.pos;
			this.entityDecoder.startEntity(this._isCharacterReferenceInAttribute() ? DecodingMode.Attribute : DecodingMode.Legacy);
		}
		_isCharacterReferenceInAttribute() {
			return this.returnState === State.ATTRIBUTE_VALUE_DOUBLE_QUOTED || this.returnState === State.ATTRIBUTE_VALUE_SINGLE_QUOTED || this.returnState === State.ATTRIBUTE_VALUE_UNQUOTED;
		}
		_flushCodePointConsumedAsCharacterReference(cp) {
			if (this._isCharacterReferenceInAttribute()) this.currentAttr.value += String.fromCodePoint(cp);
			else this._emitCodePoint(cp);
		}
		_callState(cp) {
			switch (this.state) {
				case State.DATA:
					this._stateData(cp);
					break;
				case State.RCDATA:
					this._stateRcdata(cp);
					break;
				case State.RAWTEXT:
					this._stateRawtext(cp);
					break;
				case State.SCRIPT_DATA:
					this._stateScriptData(cp);
					break;
				case State.PLAINTEXT:
					this._statePlaintext(cp);
					break;
				case State.TAG_OPEN:
					this._stateTagOpen(cp);
					break;
				case State.END_TAG_OPEN:
					this._stateEndTagOpen(cp);
					break;
				case State.TAG_NAME:
					this._stateTagName(cp);
					break;
				case State.RCDATA_LESS_THAN_SIGN:
					this._stateRcdataLessThanSign(cp);
					break;
				case State.RCDATA_END_TAG_OPEN:
					this._stateRcdataEndTagOpen(cp);
					break;
				case State.RCDATA_END_TAG_NAME:
					this._stateRcdataEndTagName(cp);
					break;
				case State.RAWTEXT_LESS_THAN_SIGN:
					this._stateRawtextLessThanSign(cp);
					break;
				case State.RAWTEXT_END_TAG_OPEN:
					this._stateRawtextEndTagOpen(cp);
					break;
				case State.RAWTEXT_END_TAG_NAME:
					this._stateRawtextEndTagName(cp);
					break;
				case State.SCRIPT_DATA_LESS_THAN_SIGN:
					this._stateScriptDataLessThanSign(cp);
					break;
				case State.SCRIPT_DATA_END_TAG_OPEN:
					this._stateScriptDataEndTagOpen(cp);
					break;
				case State.SCRIPT_DATA_END_TAG_NAME:
					this._stateScriptDataEndTagName(cp);
					break;
				case State.SCRIPT_DATA_ESCAPE_START:
					this._stateScriptDataEscapeStart(cp);
					break;
				case State.SCRIPT_DATA_ESCAPE_START_DASH:
					this._stateScriptDataEscapeStartDash(cp);
					break;
				case State.SCRIPT_DATA_ESCAPED:
					this._stateScriptDataEscaped(cp);
					break;
				case State.SCRIPT_DATA_ESCAPED_DASH:
					this._stateScriptDataEscapedDash(cp);
					break;
				case State.SCRIPT_DATA_ESCAPED_DASH_DASH:
					this._stateScriptDataEscapedDashDash(cp);
					break;
				case State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN:
					this._stateScriptDataEscapedLessThanSign(cp);
					break;
				case State.SCRIPT_DATA_ESCAPED_END_TAG_OPEN:
					this._stateScriptDataEscapedEndTagOpen(cp);
					break;
				case State.SCRIPT_DATA_ESCAPED_END_TAG_NAME:
					this._stateScriptDataEscapedEndTagName(cp);
					break;
				case State.SCRIPT_DATA_DOUBLE_ESCAPE_START:
					this._stateScriptDataDoubleEscapeStart(cp);
					break;
				case State.SCRIPT_DATA_DOUBLE_ESCAPED:
					this._stateScriptDataDoubleEscaped(cp);
					break;
				case State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH:
					this._stateScriptDataDoubleEscapedDash(cp);
					break;
				case State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH:
					this._stateScriptDataDoubleEscapedDashDash(cp);
					break;
				case State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN:
					this._stateScriptDataDoubleEscapedLessThanSign(cp);
					break;
				case State.SCRIPT_DATA_DOUBLE_ESCAPE_END:
					this._stateScriptDataDoubleEscapeEnd(cp);
					break;
				case State.BEFORE_ATTRIBUTE_NAME:
					this._stateBeforeAttributeName(cp);
					break;
				case State.ATTRIBUTE_NAME:
					this._stateAttributeName(cp);
					break;
				case State.AFTER_ATTRIBUTE_NAME:
					this._stateAfterAttributeName(cp);
					break;
				case State.BEFORE_ATTRIBUTE_VALUE:
					this._stateBeforeAttributeValue(cp);
					break;
				case State.ATTRIBUTE_VALUE_DOUBLE_QUOTED:
					this._stateAttributeValueDoubleQuoted(cp);
					break;
				case State.ATTRIBUTE_VALUE_SINGLE_QUOTED:
					this._stateAttributeValueSingleQuoted(cp);
					break;
				case State.ATTRIBUTE_VALUE_UNQUOTED:
					this._stateAttributeValueUnquoted(cp);
					break;
				case State.AFTER_ATTRIBUTE_VALUE_QUOTED:
					this._stateAfterAttributeValueQuoted(cp);
					break;
				case State.SELF_CLOSING_START_TAG:
					this._stateSelfClosingStartTag(cp);
					break;
				case State.BOGUS_COMMENT:
					this._stateBogusComment(cp);
					break;
				case State.MARKUP_DECLARATION_OPEN:
					this._stateMarkupDeclarationOpen(cp);
					break;
				case State.COMMENT_START:
					this._stateCommentStart(cp);
					break;
				case State.COMMENT_START_DASH:
					this._stateCommentStartDash(cp);
					break;
				case State.COMMENT:
					this._stateComment(cp);
					break;
				case State.COMMENT_LESS_THAN_SIGN:
					this._stateCommentLessThanSign(cp);
					break;
				case State.COMMENT_LESS_THAN_SIGN_BANG:
					this._stateCommentLessThanSignBang(cp);
					break;
				case State.COMMENT_LESS_THAN_SIGN_BANG_DASH:
					this._stateCommentLessThanSignBangDash(cp);
					break;
				case State.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH:
					this._stateCommentLessThanSignBangDashDash(cp);
					break;
				case State.COMMENT_END_DASH:
					this._stateCommentEndDash(cp);
					break;
				case State.COMMENT_END:
					this._stateCommentEnd(cp);
					break;
				case State.COMMENT_END_BANG:
					this._stateCommentEndBang(cp);
					break;
				case State.DOCTYPE:
					this._stateDoctype(cp);
					break;
				case State.BEFORE_DOCTYPE_NAME:
					this._stateBeforeDoctypeName(cp);
					break;
				case State.DOCTYPE_NAME:
					this._stateDoctypeName(cp);
					break;
				case State.AFTER_DOCTYPE_NAME:
					this._stateAfterDoctypeName(cp);
					break;
				case State.AFTER_DOCTYPE_PUBLIC_KEYWORD:
					this._stateAfterDoctypePublicKeyword(cp);
					break;
				case State.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER:
					this._stateBeforeDoctypePublicIdentifier(cp);
					break;
				case State.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED:
					this._stateDoctypePublicIdentifierDoubleQuoted(cp);
					break;
				case State.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED:
					this._stateDoctypePublicIdentifierSingleQuoted(cp);
					break;
				case State.AFTER_DOCTYPE_PUBLIC_IDENTIFIER:
					this._stateAfterDoctypePublicIdentifier(cp);
					break;
				case State.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS:
					this._stateBetweenDoctypePublicAndSystemIdentifiers(cp);
					break;
				case State.AFTER_DOCTYPE_SYSTEM_KEYWORD:
					this._stateAfterDoctypeSystemKeyword(cp);
					break;
				case State.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER:
					this._stateBeforeDoctypeSystemIdentifier(cp);
					break;
				case State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED:
					this._stateDoctypeSystemIdentifierDoubleQuoted(cp);
					break;
				case State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED:
					this._stateDoctypeSystemIdentifierSingleQuoted(cp);
					break;
				case State.AFTER_DOCTYPE_SYSTEM_IDENTIFIER:
					this._stateAfterDoctypeSystemIdentifier(cp);
					break;
				case State.BOGUS_DOCTYPE:
					this._stateBogusDoctype(cp);
					break;
				case State.CDATA_SECTION:
					this._stateCdataSection(cp);
					break;
				case State.CDATA_SECTION_BRACKET:
					this._stateCdataSectionBracket(cp);
					break;
				case State.CDATA_SECTION_END:
					this._stateCdataSectionEnd(cp);
					break;
				case State.CHARACTER_REFERENCE:
					this._stateCharacterReference();
					break;
				case State.AMBIGUOUS_AMPERSAND:
					this._stateAmbiguousAmpersand(cp);
					break;
				default: throw new Error("Unknown state");
			}
		}
		_stateData(cp) {
			switch (cp) {
				case CODE_POINTS.LESS_THAN_SIGN:
					this.state = State.TAG_OPEN;
					break;
				case CODE_POINTS.AMPERSAND:
					this._startCharacterReference();
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this._emitCodePoint(cp);
					break;
				case CODE_POINTS.EOF:
					this._emitEOFToken();
					break;
				default: this._emitCodePoint(cp);
			}
		}
		_stateRcdata(cp) {
			switch (cp) {
				case CODE_POINTS.AMPERSAND:
					this._startCharacterReference();
					break;
				case CODE_POINTS.LESS_THAN_SIGN:
					this.state = State.RCDATA_LESS_THAN_SIGN;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this._emitChars("�");
					break;
				case CODE_POINTS.EOF:
					this._emitEOFToken();
					break;
				default: this._emitCodePoint(cp);
			}
		}
		_stateRawtext(cp) {
			switch (cp) {
				case CODE_POINTS.LESS_THAN_SIGN:
					this.state = State.RAWTEXT_LESS_THAN_SIGN;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this._emitChars("�");
					break;
				case CODE_POINTS.EOF:
					this._emitEOFToken();
					break;
				default: this._emitCodePoint(cp);
			}
		}
		_stateScriptData(cp) {
			switch (cp) {
				case CODE_POINTS.LESS_THAN_SIGN:
					this.state = State.SCRIPT_DATA_LESS_THAN_SIGN;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this._emitChars("�");
					break;
				case CODE_POINTS.EOF:
					this._emitEOFToken();
					break;
				default: this._emitCodePoint(cp);
			}
		}
		_statePlaintext(cp) {
			switch (cp) {
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this._emitChars("�");
					break;
				case CODE_POINTS.EOF:
					this._emitEOFToken();
					break;
				default: this._emitCodePoint(cp);
			}
		}
		_stateTagOpen(cp) {
			if (isAsciiLetter(cp)) {
				this._createStartTagToken();
				this.state = State.TAG_NAME;
				this._stateTagName(cp);
			} else switch (cp) {
				case CODE_POINTS.EXCLAMATION_MARK:
					this.state = State.MARKUP_DECLARATION_OPEN;
					break;
				case CODE_POINTS.SOLIDUS:
					this.state = State.END_TAG_OPEN;
					break;
				case CODE_POINTS.QUESTION_MARK:
					this._err(ERR.unexpectedQuestionMarkInsteadOfTagName);
					this._createCommentToken(1);
					this.state = State.BOGUS_COMMENT;
					this._stateBogusComment(cp);
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofBeforeTagName);
					this._emitChars("<");
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.invalidFirstCharacterOfTagName);
					this._emitChars("<");
					this.state = State.DATA;
					this._stateData(cp);
			}
		}
		_stateEndTagOpen(cp) {
			if (isAsciiLetter(cp)) {
				this._createEndTagToken();
				this.state = State.TAG_NAME;
				this._stateTagName(cp);
			} else switch (cp) {
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.missingEndTagName);
					this.state = State.DATA;
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofBeforeTagName);
					this._emitChars("</");
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.invalidFirstCharacterOfTagName);
					this._createCommentToken(2);
					this.state = State.BOGUS_COMMENT;
					this._stateBogusComment(cp);
			}
		}
		_stateTagName(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED:
					this.state = State.BEFORE_ATTRIBUTE_NAME;
					break;
				case CODE_POINTS.SOLIDUS:
					this.state = State.SELF_CLOSING_START_TAG;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.DATA;
					this.emitCurrentTagToken();
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					token.tagName += "�";
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInTag);
					this._emitEOFToken();
					break;
				default: token.tagName += String.fromCodePoint(isAsciiUpper(cp) ? toAsciiLower(cp) : cp);
			}
		}
		_stateRcdataLessThanSign(cp) {
			if (cp === CODE_POINTS.SOLIDUS) this.state = State.RCDATA_END_TAG_OPEN;
			else {
				this._emitChars("<");
				this.state = State.RCDATA;
				this._stateRcdata(cp);
			}
		}
		_stateRcdataEndTagOpen(cp) {
			if (isAsciiLetter(cp)) {
				this.state = State.RCDATA_END_TAG_NAME;
				this._stateRcdataEndTagName(cp);
			} else {
				this._emitChars("</");
				this.state = State.RCDATA;
				this._stateRcdata(cp);
			}
		}
		handleSpecialEndTag(_cp) {
			if (!this.preprocessor.startsWith(this.lastStartTagName, false)) return !this._ensureHibernation();
			this._createEndTagToken();
			const token = this.currentToken;
			token.tagName = this.lastStartTagName;
			switch (this.preprocessor.peek(this.lastStartTagName.length)) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED:
					this._advanceBy(this.lastStartTagName.length);
					this.state = State.BEFORE_ATTRIBUTE_NAME;
					return false;
				case CODE_POINTS.SOLIDUS:
					this._advanceBy(this.lastStartTagName.length);
					this.state = State.SELF_CLOSING_START_TAG;
					return false;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._advanceBy(this.lastStartTagName.length);
					this.emitCurrentTagToken();
					this.state = State.DATA;
					return false;
				default: return !this._ensureHibernation();
			}
		}
		_stateRcdataEndTagName(cp) {
			if (this.handleSpecialEndTag(cp)) {
				this._emitChars("</");
				this.state = State.RCDATA;
				this._stateRcdata(cp);
			}
		}
		_stateRawtextLessThanSign(cp) {
			if (cp === CODE_POINTS.SOLIDUS) this.state = State.RAWTEXT_END_TAG_OPEN;
			else {
				this._emitChars("<");
				this.state = State.RAWTEXT;
				this._stateRawtext(cp);
			}
		}
		_stateRawtextEndTagOpen(cp) {
			if (isAsciiLetter(cp)) {
				this.state = State.RAWTEXT_END_TAG_NAME;
				this._stateRawtextEndTagName(cp);
			} else {
				this._emitChars("</");
				this.state = State.RAWTEXT;
				this._stateRawtext(cp);
			}
		}
		_stateRawtextEndTagName(cp) {
			if (this.handleSpecialEndTag(cp)) {
				this._emitChars("</");
				this.state = State.RAWTEXT;
				this._stateRawtext(cp);
			}
		}
		_stateScriptDataLessThanSign(cp) {
			switch (cp) {
				case CODE_POINTS.SOLIDUS:
					this.state = State.SCRIPT_DATA_END_TAG_OPEN;
					break;
				case CODE_POINTS.EXCLAMATION_MARK:
					this.state = State.SCRIPT_DATA_ESCAPE_START;
					this._emitChars("<!");
					break;
				default:
					this._emitChars("<");
					this.state = State.SCRIPT_DATA;
					this._stateScriptData(cp);
			}
		}
		_stateScriptDataEndTagOpen(cp) {
			if (isAsciiLetter(cp)) {
				this.state = State.SCRIPT_DATA_END_TAG_NAME;
				this._stateScriptDataEndTagName(cp);
			} else {
				this._emitChars("</");
				this.state = State.SCRIPT_DATA;
				this._stateScriptData(cp);
			}
		}
		_stateScriptDataEndTagName(cp) {
			if (this.handleSpecialEndTag(cp)) {
				this._emitChars("</");
				this.state = State.SCRIPT_DATA;
				this._stateScriptData(cp);
			}
		}
		_stateScriptDataEscapeStart(cp) {
			if (cp === CODE_POINTS.HYPHEN_MINUS) {
				this.state = State.SCRIPT_DATA_ESCAPE_START_DASH;
				this._emitChars("-");
			} else {
				this.state = State.SCRIPT_DATA;
				this._stateScriptData(cp);
			}
		}
		_stateScriptDataEscapeStartDash(cp) {
			if (cp === CODE_POINTS.HYPHEN_MINUS) {
				this.state = State.SCRIPT_DATA_ESCAPED_DASH_DASH;
				this._emitChars("-");
			} else {
				this.state = State.SCRIPT_DATA;
				this._stateScriptData(cp);
			}
		}
		_stateScriptDataEscaped(cp) {
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					this.state = State.SCRIPT_DATA_ESCAPED_DASH;
					this._emitChars("-");
					break;
				case CODE_POINTS.LESS_THAN_SIGN:
					this.state = State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this._emitChars("�");
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInScriptHtmlCommentLikeText);
					this._emitEOFToken();
					break;
				default: this._emitCodePoint(cp);
			}
		}
		_stateScriptDataEscapedDash(cp) {
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					this.state = State.SCRIPT_DATA_ESCAPED_DASH_DASH;
					this._emitChars("-");
					break;
				case CODE_POINTS.LESS_THAN_SIGN:
					this.state = State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this.state = State.SCRIPT_DATA_ESCAPED;
					this._emitChars("�");
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInScriptHtmlCommentLikeText);
					this._emitEOFToken();
					break;
				default:
					this.state = State.SCRIPT_DATA_ESCAPED;
					this._emitCodePoint(cp);
			}
		}
		_stateScriptDataEscapedDashDash(cp) {
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					this._emitChars("-");
					break;
				case CODE_POINTS.LESS_THAN_SIGN:
					this.state = State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.SCRIPT_DATA;
					this._emitChars(">");
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this.state = State.SCRIPT_DATA_ESCAPED;
					this._emitChars("�");
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInScriptHtmlCommentLikeText);
					this._emitEOFToken();
					break;
				default:
					this.state = State.SCRIPT_DATA_ESCAPED;
					this._emitCodePoint(cp);
			}
		}
		_stateScriptDataEscapedLessThanSign(cp) {
			if (cp === CODE_POINTS.SOLIDUS) this.state = State.SCRIPT_DATA_ESCAPED_END_TAG_OPEN;
			else if (isAsciiLetter(cp)) {
				this._emitChars("<");
				this.state = State.SCRIPT_DATA_DOUBLE_ESCAPE_START;
				this._stateScriptDataDoubleEscapeStart(cp);
			} else {
				this._emitChars("<");
				this.state = State.SCRIPT_DATA_ESCAPED;
				this._stateScriptDataEscaped(cp);
			}
		}
		_stateScriptDataEscapedEndTagOpen(cp) {
			if (isAsciiLetter(cp)) {
				this.state = State.SCRIPT_DATA_ESCAPED_END_TAG_NAME;
				this._stateScriptDataEscapedEndTagName(cp);
			} else {
				this._emitChars("</");
				this.state = State.SCRIPT_DATA_ESCAPED;
				this._stateScriptDataEscaped(cp);
			}
		}
		_stateScriptDataEscapedEndTagName(cp) {
			if (this.handleSpecialEndTag(cp)) {
				this._emitChars("</");
				this.state = State.SCRIPT_DATA_ESCAPED;
				this._stateScriptDataEscaped(cp);
			}
		}
		_stateScriptDataDoubleEscapeStart(cp) {
			if (this.preprocessor.startsWith(SEQUENCES.SCRIPT, false) && isScriptDataDoubleEscapeSequenceEnd(this.preprocessor.peek(SEQUENCES.SCRIPT.length))) {
				this._emitCodePoint(cp);
				for (let i = 0; i < SEQUENCES.SCRIPT.length; i++) this._emitCodePoint(this._consume());
				this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
			} else if (!this._ensureHibernation()) {
				this.state = State.SCRIPT_DATA_ESCAPED;
				this._stateScriptDataEscaped(cp);
			}
		}
		_stateScriptDataDoubleEscaped(cp) {
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH;
					this._emitChars("-");
					break;
				case CODE_POINTS.LESS_THAN_SIGN:
					this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN;
					this._emitChars("<");
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this._emitChars("�");
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInScriptHtmlCommentLikeText);
					this._emitEOFToken();
					break;
				default: this._emitCodePoint(cp);
			}
		}
		_stateScriptDataDoubleEscapedDash(cp) {
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH;
					this._emitChars("-");
					break;
				case CODE_POINTS.LESS_THAN_SIGN:
					this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN;
					this._emitChars("<");
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
					this._emitChars("�");
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInScriptHtmlCommentLikeText);
					this._emitEOFToken();
					break;
				default:
					this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
					this._emitCodePoint(cp);
			}
		}
		_stateScriptDataDoubleEscapedDashDash(cp) {
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					this._emitChars("-");
					break;
				case CODE_POINTS.LESS_THAN_SIGN:
					this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN;
					this._emitChars("<");
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.SCRIPT_DATA;
					this._emitChars(">");
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
					this._emitChars("�");
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInScriptHtmlCommentLikeText);
					this._emitEOFToken();
					break;
				default:
					this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
					this._emitCodePoint(cp);
			}
		}
		_stateScriptDataDoubleEscapedLessThanSign(cp) {
			if (cp === CODE_POINTS.SOLIDUS) {
				this.state = State.SCRIPT_DATA_DOUBLE_ESCAPE_END;
				this._emitChars("/");
			} else {
				this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
				this._stateScriptDataDoubleEscaped(cp);
			}
		}
		_stateScriptDataDoubleEscapeEnd(cp) {
			if (this.preprocessor.startsWith(SEQUENCES.SCRIPT, false) && isScriptDataDoubleEscapeSequenceEnd(this.preprocessor.peek(SEQUENCES.SCRIPT.length))) {
				this._emitCodePoint(cp);
				for (let i = 0; i < SEQUENCES.SCRIPT.length; i++) this._emitCodePoint(this._consume());
				this.state = State.SCRIPT_DATA_ESCAPED;
			} else if (!this._ensureHibernation()) {
				this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
				this._stateScriptDataDoubleEscaped(cp);
			}
		}
		_stateBeforeAttributeName(cp) {
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED: break;
				case CODE_POINTS.SOLIDUS:
				case CODE_POINTS.GREATER_THAN_SIGN:
				case CODE_POINTS.EOF:
					this.state = State.AFTER_ATTRIBUTE_NAME;
					this._stateAfterAttributeName(cp);
					break;
				case CODE_POINTS.EQUALS_SIGN:
					this._err(ERR.unexpectedEqualsSignBeforeAttributeName);
					this._createAttr("=");
					this.state = State.ATTRIBUTE_NAME;
					break;
				default:
					this._createAttr("");
					this.state = State.ATTRIBUTE_NAME;
					this._stateAttributeName(cp);
			}
		}
		_stateAttributeName(cp) {
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED:
				case CODE_POINTS.SOLIDUS:
				case CODE_POINTS.GREATER_THAN_SIGN:
				case CODE_POINTS.EOF:
					this._leaveAttrName();
					this.state = State.AFTER_ATTRIBUTE_NAME;
					this._stateAfterAttributeName(cp);
					break;
				case CODE_POINTS.EQUALS_SIGN:
					this._leaveAttrName();
					this.state = State.BEFORE_ATTRIBUTE_VALUE;
					break;
				case CODE_POINTS.QUOTATION_MARK:
				case CODE_POINTS.APOSTROPHE:
				case CODE_POINTS.LESS_THAN_SIGN:
					this._err(ERR.unexpectedCharacterInAttributeName);
					this.currentAttr.name += String.fromCodePoint(cp);
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this.currentAttr.name += "�";
					break;
				default: this.currentAttr.name += String.fromCodePoint(isAsciiUpper(cp) ? toAsciiLower(cp) : cp);
			}
		}
		_stateAfterAttributeName(cp) {
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED: break;
				case CODE_POINTS.SOLIDUS:
					this.state = State.SELF_CLOSING_START_TAG;
					break;
				case CODE_POINTS.EQUALS_SIGN:
					this.state = State.BEFORE_ATTRIBUTE_VALUE;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.DATA;
					this.emitCurrentTagToken();
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInTag);
					this._emitEOFToken();
					break;
				default:
					this._createAttr("");
					this.state = State.ATTRIBUTE_NAME;
					this._stateAttributeName(cp);
			}
		}
		_stateBeforeAttributeValue(cp) {
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED: break;
				case CODE_POINTS.QUOTATION_MARK:
					this.state = State.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
					break;
				case CODE_POINTS.APOSTROPHE:
					this.state = State.ATTRIBUTE_VALUE_SINGLE_QUOTED;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.missingAttributeValue);
					this.state = State.DATA;
					this.emitCurrentTagToken();
					break;
				default:
					this.state = State.ATTRIBUTE_VALUE_UNQUOTED;
					this._stateAttributeValueUnquoted(cp);
			}
		}
		_stateAttributeValueDoubleQuoted(cp) {
			switch (cp) {
				case CODE_POINTS.QUOTATION_MARK:
					this.state = State.AFTER_ATTRIBUTE_VALUE_QUOTED;
					break;
				case CODE_POINTS.AMPERSAND:
					this._startCharacterReference();
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this.currentAttr.value += "�";
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInTag);
					this._emitEOFToken();
					break;
				default: this.currentAttr.value += String.fromCodePoint(cp);
			}
		}
		_stateAttributeValueSingleQuoted(cp) {
			switch (cp) {
				case CODE_POINTS.APOSTROPHE:
					this.state = State.AFTER_ATTRIBUTE_VALUE_QUOTED;
					break;
				case CODE_POINTS.AMPERSAND:
					this._startCharacterReference();
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this.currentAttr.value += "�";
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInTag);
					this._emitEOFToken();
					break;
				default: this.currentAttr.value += String.fromCodePoint(cp);
			}
		}
		_stateAttributeValueUnquoted(cp) {
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED:
					this._leaveAttrValue();
					this.state = State.BEFORE_ATTRIBUTE_NAME;
					break;
				case CODE_POINTS.AMPERSAND:
					this._startCharacterReference();
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._leaveAttrValue();
					this.state = State.DATA;
					this.emitCurrentTagToken();
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this.currentAttr.value += "�";
					break;
				case CODE_POINTS.QUOTATION_MARK:
				case CODE_POINTS.APOSTROPHE:
				case CODE_POINTS.LESS_THAN_SIGN:
				case CODE_POINTS.EQUALS_SIGN:
				case CODE_POINTS.GRAVE_ACCENT:
					this._err(ERR.unexpectedCharacterInUnquotedAttributeValue);
					this.currentAttr.value += String.fromCodePoint(cp);
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInTag);
					this._emitEOFToken();
					break;
				default: this.currentAttr.value += String.fromCodePoint(cp);
			}
		}
		_stateAfterAttributeValueQuoted(cp) {
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED:
					this._leaveAttrValue();
					this.state = State.BEFORE_ATTRIBUTE_NAME;
					break;
				case CODE_POINTS.SOLIDUS:
					this._leaveAttrValue();
					this.state = State.SELF_CLOSING_START_TAG;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._leaveAttrValue();
					this.state = State.DATA;
					this.emitCurrentTagToken();
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInTag);
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.missingWhitespaceBetweenAttributes);
					this.state = State.BEFORE_ATTRIBUTE_NAME;
					this._stateBeforeAttributeName(cp);
			}
		}
		_stateSelfClosingStartTag(cp) {
			switch (cp) {
				case CODE_POINTS.GREATER_THAN_SIGN: {
					const token = this.currentToken;
					token.selfClosing = true;
					this.state = State.DATA;
					this.emitCurrentTagToken();
					break;
				}
				case CODE_POINTS.EOF:
					this._err(ERR.eofInTag);
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.unexpectedSolidusInTag);
					this.state = State.BEFORE_ATTRIBUTE_NAME;
					this._stateBeforeAttributeName(cp);
			}
		}
		_stateBogusComment(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.DATA;
					this.emitCurrentComment(token);
					break;
				case CODE_POINTS.EOF:
					this.emitCurrentComment(token);
					this._emitEOFToken();
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					token.data += "�";
					break;
				default: token.data += String.fromCodePoint(cp);
			}
		}
		_stateMarkupDeclarationOpen(cp) {
			if (this._consumeSequenceIfMatch(SEQUENCES.DASH_DASH, true)) {
				this._createCommentToken(SEQUENCES.DASH_DASH.length + 1);
				this.state = State.COMMENT_START;
			} else if (this._consumeSequenceIfMatch(SEQUENCES.DOCTYPE, false)) {
				this.currentLocation = this.getCurrentLocation(SEQUENCES.DOCTYPE.length + 1);
				this.state = State.DOCTYPE;
			} else if (this._consumeSequenceIfMatch(SEQUENCES.CDATA_START, true)) {
				if (this.inForeignNode) this.state = State.CDATA_SECTION;
				else {
					this._err(ERR.cdataInHtmlContent);
					this._createCommentToken(SEQUENCES.CDATA_START.length + 1);
					this.currentToken.data = "[CDATA[";
					this.state = State.BOGUS_COMMENT;
				}
			} else if (!this._ensureHibernation()) {
				this._err(ERR.incorrectlyOpenedComment);
				this._createCommentToken(2);
				this.state = State.BOGUS_COMMENT;
				this._stateBogusComment(cp);
			}
		}
		_stateCommentStart(cp) {
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					this.state = State.COMMENT_START_DASH;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN: {
					this._err(ERR.abruptClosingOfEmptyComment);
					this.state = State.DATA;
					const token = this.currentToken;
					this.emitCurrentComment(token);
					break;
				}
				default:
					this.state = State.COMMENT;
					this._stateComment(cp);
			}
		}
		_stateCommentStartDash(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					this.state = State.COMMENT_END;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.abruptClosingOfEmptyComment);
					this.state = State.DATA;
					this.emitCurrentComment(token);
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInComment);
					this.emitCurrentComment(token);
					this._emitEOFToken();
					break;
				default:
					token.data += "-";
					this.state = State.COMMENT;
					this._stateComment(cp);
			}
		}
		_stateComment(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					this.state = State.COMMENT_END_DASH;
					break;
				case CODE_POINTS.LESS_THAN_SIGN:
					token.data += "<";
					this.state = State.COMMENT_LESS_THAN_SIGN;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					token.data += "�";
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInComment);
					this.emitCurrentComment(token);
					this._emitEOFToken();
					break;
				default: token.data += String.fromCodePoint(cp);
			}
		}
		_stateCommentLessThanSign(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.EXCLAMATION_MARK:
					token.data += "!";
					this.state = State.COMMENT_LESS_THAN_SIGN_BANG;
					break;
				case CODE_POINTS.LESS_THAN_SIGN:
					token.data += "<";
					break;
				default:
					this.state = State.COMMENT;
					this._stateComment(cp);
			}
		}
		_stateCommentLessThanSignBang(cp) {
			if (cp === CODE_POINTS.HYPHEN_MINUS) this.state = State.COMMENT_LESS_THAN_SIGN_BANG_DASH;
			else {
				this.state = State.COMMENT;
				this._stateComment(cp);
			}
		}
		_stateCommentLessThanSignBangDash(cp) {
			if (cp === CODE_POINTS.HYPHEN_MINUS) this.state = State.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH;
			else {
				this.state = State.COMMENT_END_DASH;
				this._stateCommentEndDash(cp);
			}
		}
		_stateCommentLessThanSignBangDashDash(cp) {
			if (cp !== CODE_POINTS.GREATER_THAN_SIGN && cp !== CODE_POINTS.EOF) this._err(ERR.nestedComment);
			this.state = State.COMMENT_END;
			this._stateCommentEnd(cp);
		}
		_stateCommentEndDash(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					this.state = State.COMMENT_END;
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInComment);
					this.emitCurrentComment(token);
					this._emitEOFToken();
					break;
				default:
					token.data += "-";
					this.state = State.COMMENT;
					this._stateComment(cp);
			}
		}
		_stateCommentEnd(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.DATA;
					this.emitCurrentComment(token);
					break;
				case CODE_POINTS.EXCLAMATION_MARK:
					this.state = State.COMMENT_END_BANG;
					break;
				case CODE_POINTS.HYPHEN_MINUS:
					token.data += "-";
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInComment);
					this.emitCurrentComment(token);
					this._emitEOFToken();
					break;
				default:
					token.data += "--";
					this.state = State.COMMENT;
					this._stateComment(cp);
			}
		}
		_stateCommentEndBang(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.HYPHEN_MINUS:
					token.data += "--!";
					this.state = State.COMMENT_END_DASH;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.incorrectlyClosedComment);
					this.state = State.DATA;
					this.emitCurrentComment(token);
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInComment);
					this.emitCurrentComment(token);
					this._emitEOFToken();
					break;
				default:
					token.data += "--!";
					this.state = State.COMMENT;
					this._stateComment(cp);
			}
		}
		_stateDoctype(cp) {
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED:
					this.state = State.BEFORE_DOCTYPE_NAME;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.BEFORE_DOCTYPE_NAME;
					this._stateBeforeDoctypeName(cp);
					break;
				case CODE_POINTS.EOF: {
					this._err(ERR.eofInDoctype);
					this._createDoctypeToken(null);
					const token = this.currentToken;
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				}
				default:
					this._err(ERR.missingWhitespaceBeforeDoctypeName);
					this.state = State.BEFORE_DOCTYPE_NAME;
					this._stateBeforeDoctypeName(cp);
			}
		}
		_stateBeforeDoctypeName(cp) {
			if (isAsciiUpper(cp)) {
				this._createDoctypeToken(String.fromCharCode(toAsciiLower(cp)));
				this.state = State.DOCTYPE_NAME;
			} else switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED: break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					this._createDoctypeToken("�");
					this.state = State.DOCTYPE_NAME;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN: {
					this._err(ERR.missingDoctypeName);
					this._createDoctypeToken(null);
					const token = this.currentToken;
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this.state = State.DATA;
					break;
				}
				case CODE_POINTS.EOF: {
					this._err(ERR.eofInDoctype);
					this._createDoctypeToken(null);
					const token = this.currentToken;
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				}
				default:
					this._createDoctypeToken(String.fromCodePoint(cp));
					this.state = State.DOCTYPE_NAME;
			}
		}
		_stateDoctypeName(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED:
					this.state = State.AFTER_DOCTYPE_NAME;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.DATA;
					this.emitCurrentDoctype(token);
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					token.name += "�";
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default: token.name += String.fromCodePoint(isAsciiUpper(cp) ? toAsciiLower(cp) : cp);
			}
		}
		_stateAfterDoctypeName(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED: break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.DATA;
					this.emitCurrentDoctype(token);
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default: if (this._consumeSequenceIfMatch(SEQUENCES.PUBLIC, false)) this.state = State.AFTER_DOCTYPE_PUBLIC_KEYWORD;
				else if (this._consumeSequenceIfMatch(SEQUENCES.SYSTEM, false)) this.state = State.AFTER_DOCTYPE_SYSTEM_KEYWORD;
				else if (!this._ensureHibernation()) {
					this._err(ERR.invalidCharacterSequenceAfterDoctypeName);
					token.forceQuirks = true;
					this.state = State.BOGUS_DOCTYPE;
					this._stateBogusDoctype(cp);
				}
			}
		}
		_stateAfterDoctypePublicKeyword(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED:
					this.state = State.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER;
					break;
				case CODE_POINTS.QUOTATION_MARK:
					this._err(ERR.missingWhitespaceAfterDoctypePublicKeyword);
					token.publicId = "";
					this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
					break;
				case CODE_POINTS.APOSTROPHE:
					this._err(ERR.missingWhitespaceAfterDoctypePublicKeyword);
					token.publicId = "";
					this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.missingDoctypePublicIdentifier);
					token.forceQuirks = true;
					this.state = State.DATA;
					this.emitCurrentDoctype(token);
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.missingQuoteBeforeDoctypePublicIdentifier);
					token.forceQuirks = true;
					this.state = State.BOGUS_DOCTYPE;
					this._stateBogusDoctype(cp);
			}
		}
		_stateBeforeDoctypePublicIdentifier(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED: break;
				case CODE_POINTS.QUOTATION_MARK:
					token.publicId = "";
					this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
					break;
				case CODE_POINTS.APOSTROPHE:
					token.publicId = "";
					this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.missingDoctypePublicIdentifier);
					token.forceQuirks = true;
					this.state = State.DATA;
					this.emitCurrentDoctype(token);
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.missingQuoteBeforeDoctypePublicIdentifier);
					token.forceQuirks = true;
					this.state = State.BOGUS_DOCTYPE;
					this._stateBogusDoctype(cp);
			}
		}
		_stateDoctypePublicIdentifierDoubleQuoted(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.QUOTATION_MARK:
					this.state = State.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					token.publicId += "�";
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.abruptDoctypePublicIdentifier);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this.state = State.DATA;
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default: token.publicId += String.fromCodePoint(cp);
			}
		}
		_stateDoctypePublicIdentifierSingleQuoted(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.APOSTROPHE:
					this.state = State.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					token.publicId += "�";
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.abruptDoctypePublicIdentifier);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this.state = State.DATA;
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default: token.publicId += String.fromCodePoint(cp);
			}
		}
		_stateAfterDoctypePublicIdentifier(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED:
					this.state = State.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.DATA;
					this.emitCurrentDoctype(token);
					break;
				case CODE_POINTS.QUOTATION_MARK:
					this._err(ERR.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers);
					token.systemId = "";
					this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
					break;
				case CODE_POINTS.APOSTROPHE:
					this._err(ERR.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers);
					token.systemId = "";
					this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
					token.forceQuirks = true;
					this.state = State.BOGUS_DOCTYPE;
					this._stateBogusDoctype(cp);
			}
		}
		_stateBetweenDoctypePublicAndSystemIdentifiers(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED: break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.emitCurrentDoctype(token);
					this.state = State.DATA;
					break;
				case CODE_POINTS.QUOTATION_MARK:
					token.systemId = "";
					this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
					break;
				case CODE_POINTS.APOSTROPHE:
					token.systemId = "";
					this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
					token.forceQuirks = true;
					this.state = State.BOGUS_DOCTYPE;
					this._stateBogusDoctype(cp);
			}
		}
		_stateAfterDoctypeSystemKeyword(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED:
					this.state = State.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER;
					break;
				case CODE_POINTS.QUOTATION_MARK:
					this._err(ERR.missingWhitespaceAfterDoctypeSystemKeyword);
					token.systemId = "";
					this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
					break;
				case CODE_POINTS.APOSTROPHE:
					this._err(ERR.missingWhitespaceAfterDoctypeSystemKeyword);
					token.systemId = "";
					this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.missingDoctypeSystemIdentifier);
					token.forceQuirks = true;
					this.state = State.DATA;
					this.emitCurrentDoctype(token);
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
					token.forceQuirks = true;
					this.state = State.BOGUS_DOCTYPE;
					this._stateBogusDoctype(cp);
			}
		}
		_stateBeforeDoctypeSystemIdentifier(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED: break;
				case CODE_POINTS.QUOTATION_MARK:
					token.systemId = "";
					this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
					break;
				case CODE_POINTS.APOSTROPHE:
					token.systemId = "";
					this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.missingDoctypeSystemIdentifier);
					token.forceQuirks = true;
					this.state = State.DATA;
					this.emitCurrentDoctype(token);
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
					token.forceQuirks = true;
					this.state = State.BOGUS_DOCTYPE;
					this._stateBogusDoctype(cp);
			}
		}
		_stateDoctypeSystemIdentifierDoubleQuoted(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.QUOTATION_MARK:
					this.state = State.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					token.systemId += "�";
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.abruptDoctypeSystemIdentifier);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this.state = State.DATA;
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default: token.systemId += String.fromCodePoint(cp);
			}
		}
		_stateDoctypeSystemIdentifierSingleQuoted(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.APOSTROPHE:
					this.state = State.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					token.systemId += "�";
					break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this._err(ERR.abruptDoctypeSystemIdentifier);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this.state = State.DATA;
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default: token.systemId += String.fromCodePoint(cp);
			}
		}
		_stateAfterDoctypeSystemIdentifier(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.SPACE:
				case CODE_POINTS.LINE_FEED:
				case CODE_POINTS.TABULATION:
				case CODE_POINTS.FORM_FEED: break;
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.emitCurrentDoctype(token);
					this.state = State.DATA;
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInDoctype);
					token.forceQuirks = true;
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
					break;
				default:
					this._err(ERR.unexpectedCharacterAfterDoctypeSystemIdentifier);
					this.state = State.BOGUS_DOCTYPE;
					this._stateBogusDoctype(cp);
			}
		}
		_stateBogusDoctype(cp) {
			const token = this.currentToken;
			switch (cp) {
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.emitCurrentDoctype(token);
					this.state = State.DATA;
					break;
				case CODE_POINTS.NULL:
					this._err(ERR.unexpectedNullCharacter);
					break;
				case CODE_POINTS.EOF:
					this.emitCurrentDoctype(token);
					this._emitEOFToken();
			}
		}
		_stateCdataSection(cp) {
			switch (cp) {
				case CODE_POINTS.RIGHT_SQUARE_BRACKET:
					this.state = State.CDATA_SECTION_BRACKET;
					break;
				case CODE_POINTS.EOF:
					this._err(ERR.eofInCdata);
					this._emitEOFToken();
					break;
				default: this._emitCodePoint(cp);
			}
		}
		_stateCdataSectionBracket(cp) {
			if (cp === CODE_POINTS.RIGHT_SQUARE_BRACKET) this.state = State.CDATA_SECTION_END;
			else {
				this._emitChars("]");
				this.state = State.CDATA_SECTION;
				this._stateCdataSection(cp);
			}
		}
		_stateCdataSectionEnd(cp) {
			switch (cp) {
				case CODE_POINTS.GREATER_THAN_SIGN:
					this.state = State.DATA;
					break;
				case CODE_POINTS.RIGHT_SQUARE_BRACKET:
					this._emitChars("]");
					break;
				default:
					this._emitChars("]]");
					this.state = State.CDATA_SECTION;
					this._stateCdataSection(cp);
			}
		}
		_stateCharacterReference() {
			let length = this.entityDecoder.write(this.preprocessor.html, this.preprocessor.pos);
			if (length < 0) {
				if (this.preprocessor.lastChunkWritten) length = this.entityDecoder.end();
				else {
					this.active = false;
					this.preprocessor.pos = this.preprocessor.html.length - 1;
					this.consumedAfterSnapshot = 0;
					this.preprocessor.endOfChunkHit = true;
					return;
				}
			}
			if (length === 0) {
				this.preprocessor.pos = this.entityStartPos;
				this._flushCodePointConsumedAsCharacterReference(CODE_POINTS.AMPERSAND);
				this.state = !this._isCharacterReferenceInAttribute() && isAsciiAlphaNumeric(this.preprocessor.peek(1)) ? State.AMBIGUOUS_AMPERSAND : this.returnState;
			} else this.state = this.returnState;
		}
		_stateAmbiguousAmpersand(cp) {
			if (isAsciiAlphaNumeric(cp)) this._flushCodePointConsumedAsCharacterReference(cp);
			else {
				if (cp === CODE_POINTS.SEMICOLON) this._err(ERR.unknownNamedCharacterReference);
				this.state = this.returnState;
				this._callState(cp);
			}
		}
	};
	var IMPLICIT_END_TAG_REQUIRED = new Set([
		TAG_ID.DD,
		TAG_ID.DT,
		TAG_ID.LI,
		TAG_ID.OPTGROUP,
		TAG_ID.OPTION,
		TAG_ID.P,
		TAG_ID.RB,
		TAG_ID.RP,
		TAG_ID.RT,
		TAG_ID.RTC
	]);
	var IMPLICIT_END_TAG_REQUIRED_THOROUGHLY = new Set([
		...IMPLICIT_END_TAG_REQUIRED,
		TAG_ID.CAPTION,
		TAG_ID.COLGROUP,
		TAG_ID.TBODY,
		TAG_ID.TD,
		TAG_ID.TFOOT,
		TAG_ID.TH,
		TAG_ID.THEAD,
		TAG_ID.TR
	]);
	var SCOPING_ELEMENTS_HTML = new Set([
		TAG_ID.APPLET,
		TAG_ID.CAPTION,
		TAG_ID.HTML,
		TAG_ID.MARQUEE,
		TAG_ID.OBJECT,
		TAG_ID.TABLE,
		TAG_ID.TD,
		TAG_ID.TEMPLATE,
		TAG_ID.TH
	]);
	var SCOPING_ELEMENTS_HTML_LIST = new Set([
		...SCOPING_ELEMENTS_HTML,
		TAG_ID.OL,
		TAG_ID.UL
	]);
	var SCOPING_ELEMENTS_HTML_BUTTON = new Set([...SCOPING_ELEMENTS_HTML, TAG_ID.BUTTON]);
	var SCOPING_ELEMENTS_MATHML = new Set([
		TAG_ID.ANNOTATION_XML,
		TAG_ID.MI,
		TAG_ID.MN,
		TAG_ID.MO,
		TAG_ID.MS,
		TAG_ID.MTEXT
	]);
	var SCOPING_ELEMENTS_SVG = new Set([
		TAG_ID.DESC,
		TAG_ID.FOREIGN_OBJECT,
		TAG_ID.TITLE
	]);
	var TABLE_ROW_CONTEXT = new Set([
		TAG_ID.TR,
		TAG_ID.TEMPLATE,
		TAG_ID.HTML
	]);
	var TABLE_BODY_CONTEXT = new Set([
		TAG_ID.TBODY,
		TAG_ID.TFOOT,
		TAG_ID.THEAD,
		TAG_ID.TEMPLATE,
		TAG_ID.HTML
	]);
	var TABLE_CONTEXT = new Set([
		TAG_ID.TABLE,
		TAG_ID.TEMPLATE,
		TAG_ID.HTML
	]);
	var TABLE_CELLS = new Set([TAG_ID.TD, TAG_ID.TH]);
	var OpenElementStack = class {
		get currentTmplContentOrNode() {
			return this._isInTemplate() ? this.treeAdapter.getTemplateContent(this.current) : this.current;
		}
		constructor(document, treeAdapter, handler) {
			this.treeAdapter = treeAdapter;
			this.handler = handler;
			this.items = [];
			this.tagIDs = [];
			this.stackTop = -1;
			this.tmplCount = 0;
			this.currentTagId = TAG_ID.UNKNOWN;
			this.current = document;
		}
		_indexOf(element) {
			return this.items.lastIndexOf(element, this.stackTop);
		}
		_isInTemplate() {
			return this.currentTagId === TAG_ID.TEMPLATE && this.treeAdapter.getNamespaceURI(this.current) === NS.HTML;
		}
		_updateCurrentElement() {
			this.current = this.items[this.stackTop];
			this.currentTagId = this.tagIDs[this.stackTop];
		}
		push(element, tagID) {
			this.stackTop++;
			this.items[this.stackTop] = element;
			this.current = element;
			this.tagIDs[this.stackTop] = tagID;
			this.currentTagId = tagID;
			if (this._isInTemplate()) this.tmplCount++;
			this.handler.onItemPush(element, tagID, true);
		}
		pop() {
			const popped = this.current;
			if (this.tmplCount > 0 && this._isInTemplate()) this.tmplCount--;
			this.stackTop--;
			this._updateCurrentElement();
			this.handler.onItemPop(popped, true);
		}
		replace(oldElement, newElement) {
			const idx = this._indexOf(oldElement);
			this.items[idx] = newElement;
			if (idx === this.stackTop) this.current = newElement;
		}
		insertAfter(referenceElement, newElement, newElementID) {
			const insertionIdx = this._indexOf(referenceElement) + 1;
			this.items.splice(insertionIdx, 0, newElement);
			this.tagIDs.splice(insertionIdx, 0, newElementID);
			this.stackTop++;
			if (insertionIdx === this.stackTop) this._updateCurrentElement();
			if (this.current && this.currentTagId !== void 0) this.handler.onItemPush(this.current, this.currentTagId, insertionIdx === this.stackTop);
		}
		popUntilTagNamePopped(tagName) {
			let targetIdx = this.stackTop + 1;
			do
				targetIdx = this.tagIDs.lastIndexOf(tagName, targetIdx - 1);
			while (targetIdx > 0 && this.treeAdapter.getNamespaceURI(this.items[targetIdx]) !== NS.HTML);
			this.shortenToLength(Math.max(targetIdx, 0));
		}
		shortenToLength(idx) {
			while (this.stackTop >= idx) {
				const popped = this.current;
				if (this.tmplCount > 0 && this._isInTemplate()) this.tmplCount -= 1;
				this.stackTop--;
				this._updateCurrentElement();
				this.handler.onItemPop(popped, this.stackTop < idx);
			}
		}
		popUntilElementPopped(element) {
			const idx = this._indexOf(element);
			this.shortenToLength(Math.max(idx, 0));
		}
		popUntilPopped(tagNames, targetNS) {
			const idx = this._indexOfTagNames(tagNames, targetNS);
			this.shortenToLength(Math.max(idx, 0));
		}
		popUntilNumberedHeaderPopped() {
			this.popUntilPopped(NUMBERED_HEADERS, NS.HTML);
		}
		popUntilTableCellPopped() {
			this.popUntilPopped(TABLE_CELLS, NS.HTML);
		}
		popAllUpToHtmlElement() {
			this.tmplCount = 0;
			this.shortenToLength(1);
		}
		_indexOfTagNames(tagNames, namespace) {
			for (let i = this.stackTop; i >= 0; i--) if (tagNames.has(this.tagIDs[i]) && this.treeAdapter.getNamespaceURI(this.items[i]) === namespace) return i;
			return -1;
		}
		clearBackTo(tagNames, targetNS) {
			const idx = this._indexOfTagNames(tagNames, targetNS);
			this.shortenToLength(idx + 1);
		}
		clearBackToTableContext() {
			this.clearBackTo(TABLE_CONTEXT, NS.HTML);
		}
		clearBackToTableBodyContext() {
			this.clearBackTo(TABLE_BODY_CONTEXT, NS.HTML);
		}
		clearBackToTableRowContext() {
			this.clearBackTo(TABLE_ROW_CONTEXT, NS.HTML);
		}
		remove(element) {
			const idx = this._indexOf(element);
			if (idx >= 0) {
				if (idx === this.stackTop) this.pop();
				else {
					this.items.splice(idx, 1);
					this.tagIDs.splice(idx, 1);
					this.stackTop--;
					this._updateCurrentElement();
					this.handler.onItemPop(element, false);
				}
			}
		}
		tryPeekProperlyNestedBodyElement() {
			return this.stackTop >= 1 && this.tagIDs[1] === TAG_ID.BODY ? this.items[1] : null;
		}
		contains(element) {
			return this._indexOf(element) > -1;
		}
		getCommonAncestor(element) {
			const elementIdx = this._indexOf(element) - 1;
			return elementIdx >= 0 ? this.items[elementIdx] : null;
		}
		isRootHtmlElementCurrent() {
			return this.stackTop === 0 && this.tagIDs[0] === TAG_ID.HTML;
		}
		hasInDynamicScope(tagName, htmlScope) {
			for (let i = this.stackTop; i >= 0; i--) {
				const tn = this.tagIDs[i];
				switch (this.treeAdapter.getNamespaceURI(this.items[i])) {
					case NS.HTML:
						if (tn === tagName) return true;
						if (htmlScope.has(tn)) return false;
						break;
					case NS.SVG:
						if (SCOPING_ELEMENTS_SVG.has(tn)) return false;
						break;
					case NS.MATHML: if (SCOPING_ELEMENTS_MATHML.has(tn)) return false;
				}
			}
			return true;
		}
		hasInScope(tagName) {
			return this.hasInDynamicScope(tagName, SCOPING_ELEMENTS_HTML);
		}
		hasInListItemScope(tagName) {
			return this.hasInDynamicScope(tagName, SCOPING_ELEMENTS_HTML_LIST);
		}
		hasInButtonScope(tagName) {
			return this.hasInDynamicScope(tagName, SCOPING_ELEMENTS_HTML_BUTTON);
		}
		hasNumberedHeaderInScope() {
			for (let i = this.stackTop; i >= 0; i--) {
				const tn = this.tagIDs[i];
				switch (this.treeAdapter.getNamespaceURI(this.items[i])) {
					case NS.HTML:
						if (NUMBERED_HEADERS.has(tn)) return true;
						if (SCOPING_ELEMENTS_HTML.has(tn)) return false;
						break;
					case NS.SVG:
						if (SCOPING_ELEMENTS_SVG.has(tn)) return false;
						break;
					case NS.MATHML: if (SCOPING_ELEMENTS_MATHML.has(tn)) return false;
				}
			}
			return true;
		}
		hasInTableScope(tagName) {
			for (let i = this.stackTop; i >= 0; i--) {
				if (this.treeAdapter.getNamespaceURI(this.items[i]) !== NS.HTML) continue;
				switch (this.tagIDs[i]) {
					case tagName: return true;
					case TAG_ID.TABLE:
					case TAG_ID.HTML: return false;
				}
			}
			return true;
		}
		hasTableBodyContextInTableScope() {
			for (let i = this.stackTop; i >= 0; i--) {
				if (this.treeAdapter.getNamespaceURI(this.items[i]) !== NS.HTML) continue;
				switch (this.tagIDs[i]) {
					case TAG_ID.TBODY:
					case TAG_ID.THEAD:
					case TAG_ID.TFOOT: return true;
					case TAG_ID.TABLE:
					case TAG_ID.HTML: return false;
				}
			}
			return true;
		}
		hasInSelectScope(tagName) {
			for (let i = this.stackTop; i >= 0; i--) {
				if (this.treeAdapter.getNamespaceURI(this.items[i]) !== NS.HTML) continue;
				switch (this.tagIDs[i]) {
					case tagName: return true;
					case TAG_ID.OPTION:
					case TAG_ID.OPTGROUP: break;
					default: return false;
				}
			}
			return true;
		}
		generateImpliedEndTags() {
			while (this.currentTagId !== void 0 && IMPLICIT_END_TAG_REQUIRED.has(this.currentTagId)) this.pop();
		}
		generateImpliedEndTagsThoroughly() {
			while (this.currentTagId !== void 0 && IMPLICIT_END_TAG_REQUIRED_THOROUGHLY.has(this.currentTagId)) this.pop();
		}
		generateImpliedEndTagsWithExclusion(exclusionId) {
			while (this.currentTagId !== void 0 && this.currentTagId !== exclusionId && IMPLICIT_END_TAG_REQUIRED_THOROUGHLY.has(this.currentTagId)) this.pop();
		}
	};
	var NOAH_ARK_CAPACITY = 3;
	var EntryType;
	(function(EntryType) {
		EntryType[EntryType["Marker"] = 0] = "Marker";
		EntryType[EntryType["Element"] = 1] = "Element";
	})(EntryType || (EntryType = {}));
	var MARKER = { type: EntryType.Marker };
	var FormattingElementList = class {
		constructor(treeAdapter) {
			this.treeAdapter = treeAdapter;
			this.entries = [];
			this.bookmark = null;
		}
		_getNoahArkConditionCandidates(newElement, neAttrs) {
			const candidates = [];
			const neAttrsLength = neAttrs.length;
			const neTagName = this.treeAdapter.getTagName(newElement);
			const neNamespaceURI = this.treeAdapter.getNamespaceURI(newElement);
			for (let i = 0; i < this.entries.length; i++) {
				const entry = this.entries[i];
				if (entry.type === EntryType.Marker) break;
				const { element } = entry;
				if (this.treeAdapter.getTagName(element) === neTagName && this.treeAdapter.getNamespaceURI(element) === neNamespaceURI) {
					const elementAttrs = this.treeAdapter.getAttrList(element);
					if (elementAttrs.length === neAttrsLength) candidates.push({
						idx: i,
						attrs: elementAttrs
					});
				}
			}
			return candidates;
		}
		_ensureNoahArkCondition(newElement) {
			if (this.entries.length < NOAH_ARK_CAPACITY) return;
			const neAttrs = this.treeAdapter.getAttrList(newElement);
			const candidates = this._getNoahArkConditionCandidates(newElement, neAttrs);
			if (candidates.length < NOAH_ARK_CAPACITY) return;
			const neAttrsMap = new Map(neAttrs.map((neAttr) => [neAttr.name, neAttr.value]));
			let validCandidates = 0;
			for (let i = 0; i < candidates.length; i++) {
				const candidate = candidates[i];
				if (candidate.attrs.every((cAttr) => neAttrsMap.get(cAttr.name) === cAttr.value)) {
					validCandidates += 1;
					if (validCandidates >= NOAH_ARK_CAPACITY) this.entries.splice(candidate.idx, 1);
				}
			}
		}
		insertMarker() {
			this.entries.unshift(MARKER);
		}
		pushElement(element, token) {
			this._ensureNoahArkCondition(element);
			this.entries.unshift({
				type: EntryType.Element,
				element,
				token
			});
		}
		insertElementAfterBookmark(element, token) {
			const bookmarkIdx = this.entries.indexOf(this.bookmark);
			this.entries.splice(bookmarkIdx, 0, {
				type: EntryType.Element,
				element,
				token
			});
		}
		removeEntry(entry) {
			const entryIndex = this.entries.indexOf(entry);
			if (entryIndex !== -1) this.entries.splice(entryIndex, 1);
		}
		clearToLastMarker() {
			const markerIdx = this.entries.indexOf(MARKER);
			if (markerIdx === -1) this.entries.length = 0;
			else this.entries.splice(0, markerIdx + 1);
		}
		getElementEntryInScopeWithTagName(tagName) {
			const entry = this.entries.find((entry) => entry.type === EntryType.Marker || this.treeAdapter.getTagName(entry.element) === tagName);
			return entry && entry.type === EntryType.Element ? entry : null;
		}
		getElementEntry(element) {
			return this.entries.find((entry) => entry.type === EntryType.Element && entry.element === element);
		}
	};
	var defaultTreeAdapter = {
		createDocument() {
			return {
				nodeName: "#document",
				mode: DOCUMENT_MODE.NO_QUIRKS,
				childNodes: []
			};
		},
		createDocumentFragment() {
			return {
				nodeName: "#document-fragment",
				childNodes: []
			};
		},
		createElement(tagName, namespaceURI, attrs) {
			return {
				nodeName: tagName,
				tagName,
				attrs,
				namespaceURI,
				childNodes: [],
				parentNode: null
			};
		},
		createCommentNode(data) {
			return {
				nodeName: "#comment",
				data,
				parentNode: null
			};
		},
		createTextNode(value) {
			return {
				nodeName: "#text",
				value,
				parentNode: null
			};
		},
		appendChild(parentNode, newNode) {
			parentNode.childNodes.push(newNode);
			newNode.parentNode = parentNode;
		},
		insertBefore(parentNode, newNode, referenceNode) {
			const insertionIdx = parentNode.childNodes.indexOf(referenceNode);
			parentNode.childNodes.splice(insertionIdx, 0, newNode);
			newNode.parentNode = parentNode;
		},
		setTemplateContent(templateElement, contentElement) {
			templateElement.content = contentElement;
		},
		getTemplateContent(templateElement) {
			return templateElement.content;
		},
		setDocumentType(document, name, publicId, systemId) {
			const doctypeNode = document.childNodes.find((node) => node.nodeName === "#documentType");
			if (doctypeNode) {
				doctypeNode.name = name;
				doctypeNode.publicId = publicId;
				doctypeNode.systemId = systemId;
			} else {
				const node = {
					nodeName: "#documentType",
					name,
					publicId,
					systemId,
					parentNode: null
				};
				defaultTreeAdapter.appendChild(document, node);
			}
		},
		setDocumentMode(document, mode) {
			document.mode = mode;
		},
		getDocumentMode(document) {
			return document.mode;
		},
		detachNode(node) {
			if (node.parentNode) {
				const idx = node.parentNode.childNodes.indexOf(node);
				node.parentNode.childNodes.splice(idx, 1);
				node.parentNode = null;
			}
		},
		insertText(parentNode, text) {
			if (parentNode.childNodes.length > 0) {
				const prevNode = parentNode.childNodes[parentNode.childNodes.length - 1];
				if (defaultTreeAdapter.isTextNode(prevNode)) {
					prevNode.value += text;
					return;
				}
			}
			defaultTreeAdapter.appendChild(parentNode, defaultTreeAdapter.createTextNode(text));
		},
		insertTextBefore(parentNode, text, referenceNode) {
			const prevNode = parentNode.childNodes[parentNode.childNodes.indexOf(referenceNode) - 1];
			if (prevNode && defaultTreeAdapter.isTextNode(prevNode)) prevNode.value += text;
			else defaultTreeAdapter.insertBefore(parentNode, defaultTreeAdapter.createTextNode(text), referenceNode);
		},
		adoptAttributes(recipient, attrs) {
			const recipientAttrsMap = new Set(recipient.attrs.map((attr) => attr.name));
			for (let j = 0; j < attrs.length; j++) if (!recipientAttrsMap.has(attrs[j].name)) recipient.attrs.push(attrs[j]);
		},
		getFirstChild(node) {
			return node.childNodes[0];
		},
		getChildNodes(node) {
			return node.childNodes;
		},
		getParentNode(node) {
			return node.parentNode;
		},
		getAttrList(element) {
			return element.attrs;
		},
		getTagName(element) {
			return element.tagName;
		},
		getNamespaceURI(element) {
			return element.namespaceURI;
		},
		getTextNodeContent(textNode) {
			return textNode.value;
		},
		getCommentNodeContent(commentNode) {
			return commentNode.data;
		},
		getDocumentTypeNodeName(doctypeNode) {
			return doctypeNode.name;
		},
		getDocumentTypeNodePublicId(doctypeNode) {
			return doctypeNode.publicId;
		},
		getDocumentTypeNodeSystemId(doctypeNode) {
			return doctypeNode.systemId;
		},
		isTextNode(node) {
			return node.nodeName === "#text";
		},
		isCommentNode(node) {
			return node.nodeName === "#comment";
		},
		isDocumentTypeNode(node) {
			return node.nodeName === "#documentType";
		},
		isElementNode(node) {
			return Object.prototype.hasOwnProperty.call(node, "tagName");
		},
		setNodeSourceCodeLocation(node, location) {
			node.sourceCodeLocation = location;
		},
		getNodeSourceCodeLocation(node) {
			return node.sourceCodeLocation;
		},
		updateNodeSourceCodeLocation(node, endLocation) {
			node.sourceCodeLocation = {
				...node.sourceCodeLocation,
				...endLocation
			};
		}
	};
	var VALID_DOCTYPE_NAME = "html";
	var VALID_SYSTEM_ID = "about:legacy-compat";
	var QUIRKS_MODE_SYSTEM_ID = "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd";
	var QUIRKS_MODE_PUBLIC_ID_PREFIXES = [
		"+//silmaril//dtd html pro v0r11 19970101//",
		"-//as//dtd html 3.0 aswedit + extensions//",
		"-//advasoft ltd//dtd html 3.0 aswedit + extensions//",
		"-//ietf//dtd html 2.0 level 1//",
		"-//ietf//dtd html 2.0 level 2//",
		"-//ietf//dtd html 2.0 strict level 1//",
		"-//ietf//dtd html 2.0 strict level 2//",
		"-//ietf//dtd html 2.0 strict//",
		"-//ietf//dtd html 2.0//",
		"-//ietf//dtd html 2.1e//",
		"-//ietf//dtd html 3.0//",
		"-//ietf//dtd html 3.2 final//",
		"-//ietf//dtd html 3.2//",
		"-//ietf//dtd html 3//",
		"-//ietf//dtd html level 0//",
		"-//ietf//dtd html level 1//",
		"-//ietf//dtd html level 2//",
		"-//ietf//dtd html level 3//",
		"-//ietf//dtd html strict level 0//",
		"-//ietf//dtd html strict level 1//",
		"-//ietf//dtd html strict level 2//",
		"-//ietf//dtd html strict level 3//",
		"-//ietf//dtd html strict//",
		"-//ietf//dtd html//",
		"-//metrius//dtd metrius presentational//",
		"-//microsoft//dtd internet explorer 2.0 html strict//",
		"-//microsoft//dtd internet explorer 2.0 html//",
		"-//microsoft//dtd internet explorer 2.0 tables//",
		"-//microsoft//dtd internet explorer 3.0 html strict//",
		"-//microsoft//dtd internet explorer 3.0 html//",
		"-//microsoft//dtd internet explorer 3.0 tables//",
		"-//netscape comm. corp.//dtd html//",
		"-//netscape comm. corp.//dtd strict html//",
		"-//o'reilly and associates//dtd html 2.0//",
		"-//o'reilly and associates//dtd html extended 1.0//",
		"-//o'reilly and associates//dtd html extended relaxed 1.0//",
		"-//sq//dtd html 2.0 hotmetal + extensions//",
		"-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//",
		"-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//",
		"-//spyglass//dtd html 2.0 extended//",
		"-//sun microsystems corp.//dtd hotjava html//",
		"-//sun microsystems corp.//dtd hotjava strict html//",
		"-//w3c//dtd html 3 1995-03-24//",
		"-//w3c//dtd html 3.2 draft//",
		"-//w3c//dtd html 3.2 final//",
		"-//w3c//dtd html 3.2//",
		"-//w3c//dtd html 3.2s draft//",
		"-//w3c//dtd html 4.0 frameset//",
		"-//w3c//dtd html 4.0 transitional//",
		"-//w3c//dtd html experimental 19960712//",
		"-//w3c//dtd html experimental 970421//",
		"-//w3c//dtd w3 html//",
		"-//w3o//dtd w3 html 3.0//",
		"-//webtechs//dtd mozilla html 2.0//",
		"-//webtechs//dtd mozilla html//"
	];
	var QUIRKS_MODE_NO_SYSTEM_ID_PUBLIC_ID_PREFIXES = [
		...QUIRKS_MODE_PUBLIC_ID_PREFIXES,
		"-//w3c//dtd html 4.01 frameset//",
		"-//w3c//dtd html 4.01 transitional//"
	];
	var QUIRKS_MODE_PUBLIC_IDS = new Set([
		"-//w3o//dtd w3 html strict 3.0//en//",
		"-/w3c/dtd html 4.0 transitional/en",
		"html"
	]);
	var LIMITED_QUIRKS_PUBLIC_ID_PREFIXES = ["-//w3c//dtd xhtml 1.0 frameset//", "-//w3c//dtd xhtml 1.0 transitional//"];
	var LIMITED_QUIRKS_WITH_SYSTEM_ID_PUBLIC_ID_PREFIXES = [
		...LIMITED_QUIRKS_PUBLIC_ID_PREFIXES,
		"-//w3c//dtd html 4.01 frameset//",
		"-//w3c//dtd html 4.01 transitional//"
	];
	function hasPrefix(publicId, prefixes) {
		return prefixes.some((prefix) => publicId.startsWith(prefix));
	}
	function isConforming(token) {
		return token.name === VALID_DOCTYPE_NAME && token.publicId === null && (token.systemId === null || token.systemId === VALID_SYSTEM_ID);
	}
	function getDocumentMode(token) {
		if (token.name !== VALID_DOCTYPE_NAME) return DOCUMENT_MODE.QUIRKS;
		const { systemId } = token;
		if (systemId && systemId.toLowerCase() === QUIRKS_MODE_SYSTEM_ID) return DOCUMENT_MODE.QUIRKS;
		let { publicId } = token;
		if (publicId !== null) {
			publicId = publicId.toLowerCase();
			if (QUIRKS_MODE_PUBLIC_IDS.has(publicId)) return DOCUMENT_MODE.QUIRKS;
			let prefixes = systemId === null ? QUIRKS_MODE_NO_SYSTEM_ID_PUBLIC_ID_PREFIXES : QUIRKS_MODE_PUBLIC_ID_PREFIXES;
			if (hasPrefix(publicId, prefixes)) return DOCUMENT_MODE.QUIRKS;
			prefixes = systemId === null ? LIMITED_QUIRKS_PUBLIC_ID_PREFIXES : LIMITED_QUIRKS_WITH_SYSTEM_ID_PUBLIC_ID_PREFIXES;
			if (hasPrefix(publicId, prefixes)) return DOCUMENT_MODE.LIMITED_QUIRKS;
		}
		return DOCUMENT_MODE.NO_QUIRKS;
	}
	var MIME_TYPES = {
		TEXT_HTML: "text/html",
		APPLICATION_XML: "application/xhtml+xml"
	};
	var DEFINITION_URL_ATTR = "definitionurl";
	var ADJUSTED_DEFINITION_URL_ATTR = "definitionURL";
	var SVG_ATTRS_ADJUSTMENT_MAP = new Map([
		"attributeName",
		"attributeType",
		"baseFrequency",
		"baseProfile",
		"calcMode",
		"clipPathUnits",
		"diffuseConstant",
		"edgeMode",
		"filterUnits",
		"glyphRef",
		"gradientTransform",
		"gradientUnits",
		"kernelMatrix",
		"kernelUnitLength",
		"keyPoints",
		"keySplines",
		"keyTimes",
		"lengthAdjust",
		"limitingConeAngle",
		"markerHeight",
		"markerUnits",
		"markerWidth",
		"maskContentUnits",
		"maskUnits",
		"numOctaves",
		"pathLength",
		"patternContentUnits",
		"patternTransform",
		"patternUnits",
		"pointsAtX",
		"pointsAtY",
		"pointsAtZ",
		"preserveAlpha",
		"preserveAspectRatio",
		"primitiveUnits",
		"refX",
		"refY",
		"repeatCount",
		"repeatDur",
		"requiredExtensions",
		"requiredFeatures",
		"specularConstant",
		"specularExponent",
		"spreadMethod",
		"startOffset",
		"stdDeviation",
		"stitchTiles",
		"surfaceScale",
		"systemLanguage",
		"tableValues",
		"targetX",
		"targetY",
		"textLength",
		"viewBox",
		"viewTarget",
		"xChannelSelector",
		"yChannelSelector",
		"zoomAndPan"
	].map((attr) => [attr.toLowerCase(), attr]));
	var XML_ATTRS_ADJUSTMENT_MAP = new Map([
		["xlink:actuate", {
			prefix: "xlink",
			name: "actuate",
			namespace: NS.XLINK
		}],
		["xlink:arcrole", {
			prefix: "xlink",
			name: "arcrole",
			namespace: NS.XLINK
		}],
		["xlink:href", {
			prefix: "xlink",
			name: "href",
			namespace: NS.XLINK
		}],
		["xlink:role", {
			prefix: "xlink",
			name: "role",
			namespace: NS.XLINK
		}],
		["xlink:show", {
			prefix: "xlink",
			name: "show",
			namespace: NS.XLINK
		}],
		["xlink:title", {
			prefix: "xlink",
			name: "title",
			namespace: NS.XLINK
		}],
		["xlink:type", {
			prefix: "xlink",
			name: "type",
			namespace: NS.XLINK
		}],
		["xml:lang", {
			prefix: "xml",
			name: "lang",
			namespace: NS.XML
		}],
		["xml:space", {
			prefix: "xml",
			name: "space",
			namespace: NS.XML
		}],
		["xmlns", {
			prefix: "",
			name: "xmlns",
			namespace: NS.XMLNS
		}],
		["xmlns:xlink", {
			prefix: "xmlns",
			name: "xlink",
			namespace: NS.XMLNS
		}]
	]);
	var SVG_TAG_NAMES_ADJUSTMENT_MAP = new Map([
		"altGlyph",
		"altGlyphDef",
		"altGlyphItem",
		"animateColor",
		"animateMotion",
		"animateTransform",
		"clipPath",
		"feBlend",
		"feColorMatrix",
		"feComponentTransfer",
		"feComposite",
		"feConvolveMatrix",
		"feDiffuseLighting",
		"feDisplacementMap",
		"feDistantLight",
		"feFlood",
		"feFuncA",
		"feFuncB",
		"feFuncG",
		"feFuncR",
		"feGaussianBlur",
		"feImage",
		"feMerge",
		"feMergeNode",
		"feMorphology",
		"feOffset",
		"fePointLight",
		"feSpecularLighting",
		"feSpotLight",
		"feTile",
		"feTurbulence",
		"foreignObject",
		"glyphRef",
		"linearGradient",
		"radialGradient",
		"textPath"
	].map((tn) => [tn.toLowerCase(), tn]));
	var EXITS_FOREIGN_CONTENT = new Set([
		TAG_ID.B,
		TAG_ID.BIG,
		TAG_ID.BLOCKQUOTE,
		TAG_ID.BODY,
		TAG_ID.BR,
		TAG_ID.CENTER,
		TAG_ID.CODE,
		TAG_ID.DD,
		TAG_ID.DIV,
		TAG_ID.DL,
		TAG_ID.DT,
		TAG_ID.EM,
		TAG_ID.EMBED,
		TAG_ID.H1,
		TAG_ID.H2,
		TAG_ID.H3,
		TAG_ID.H4,
		TAG_ID.H5,
		TAG_ID.H6,
		TAG_ID.HEAD,
		TAG_ID.HR,
		TAG_ID.I,
		TAG_ID.IMG,
		TAG_ID.LI,
		TAG_ID.LISTING,
		TAG_ID.MENU,
		TAG_ID.META,
		TAG_ID.NOBR,
		TAG_ID.OL,
		TAG_ID.P,
		TAG_ID.PRE,
		TAG_ID.RUBY,
		TAG_ID.S,
		TAG_ID.SMALL,
		TAG_ID.SPAN,
		TAG_ID.STRONG,
		TAG_ID.STRIKE,
		TAG_ID.SUB,
		TAG_ID.SUP,
		TAG_ID.TABLE,
		TAG_ID.TT,
		TAG_ID.U,
		TAG_ID.UL,
		TAG_ID.VAR
	]);
	function causesExit(startTagToken) {
		const tn = startTagToken.tagID;
		return tn === TAG_ID.FONT && startTagToken.attrs.some(({ name }) => name === ATTRS.COLOR || name === ATTRS.SIZE || name === ATTRS.FACE) || EXITS_FOREIGN_CONTENT.has(tn);
	}
	function adjustTokenMathMLAttrs(token) {
		for (let i = 0; i < token.attrs.length; i++) if (token.attrs[i].name === DEFINITION_URL_ATTR) {
			token.attrs[i].name = ADJUSTED_DEFINITION_URL_ATTR;
			break;
		}
	}
	function adjustTokenSVGAttrs(token) {
		for (let i = 0; i < token.attrs.length; i++) {
			const adjustedAttrName = SVG_ATTRS_ADJUSTMENT_MAP.get(token.attrs[i].name);
			if (adjustedAttrName != null) token.attrs[i].name = adjustedAttrName;
		}
	}
	function adjustTokenXMLAttrs(token) {
		for (let i = 0; i < token.attrs.length; i++) {
			const adjustedAttrEntry = XML_ATTRS_ADJUSTMENT_MAP.get(token.attrs[i].name);
			if (adjustedAttrEntry) {
				token.attrs[i].prefix = adjustedAttrEntry.prefix;
				token.attrs[i].name = adjustedAttrEntry.name;
				token.attrs[i].namespace = adjustedAttrEntry.namespace;
			}
		}
	}
	function adjustTokenSVGTagName(token) {
		const adjustedTagName = SVG_TAG_NAMES_ADJUSTMENT_MAP.get(token.tagName);
		if (adjustedTagName != null) {
			token.tagName = adjustedTagName;
			token.tagID = getTagID(token.tagName);
		}
	}
	function isMathMLTextIntegrationPoint(tn, ns) {
		return ns === NS.MATHML && (tn === TAG_ID.MI || tn === TAG_ID.MO || tn === TAG_ID.MN || tn === TAG_ID.MS || tn === TAG_ID.MTEXT);
	}
	function isHtmlIntegrationPoint(tn, ns, attrs) {
		if (ns === NS.MATHML && tn === TAG_ID.ANNOTATION_XML) {
			for (let i = 0; i < attrs.length; i++) if (attrs[i].name === ATTRS.ENCODING) {
				const value = attrs[i].value.toLowerCase();
				return value === MIME_TYPES.TEXT_HTML || value === MIME_TYPES.APPLICATION_XML;
			}
		}
		return ns === NS.SVG && (tn === TAG_ID.FOREIGN_OBJECT || tn === TAG_ID.DESC || tn === TAG_ID.TITLE);
	}
	function isIntegrationPoint(tn, ns, attrs, foreignNS) {
		return (!foreignNS || foreignNS === NS.HTML) && isHtmlIntegrationPoint(tn, ns, attrs) || (!foreignNS || foreignNS === NS.MATHML) && isMathMLTextIntegrationPoint(tn, ns);
	}
	var HIDDEN_INPUT_TYPE = "hidden";
	var AA_OUTER_LOOP_ITER = 8;
	var AA_INNER_LOOP_ITER = 3;
	var InsertionMode;
	(function(InsertionMode) {
		InsertionMode[InsertionMode["INITIAL"] = 0] = "INITIAL";
		InsertionMode[InsertionMode["BEFORE_HTML"] = 1] = "BEFORE_HTML";
		InsertionMode[InsertionMode["BEFORE_HEAD"] = 2] = "BEFORE_HEAD";
		InsertionMode[InsertionMode["IN_HEAD"] = 3] = "IN_HEAD";
		InsertionMode[InsertionMode["IN_HEAD_NO_SCRIPT"] = 4] = "IN_HEAD_NO_SCRIPT";
		InsertionMode[InsertionMode["AFTER_HEAD"] = 5] = "AFTER_HEAD";
		InsertionMode[InsertionMode["IN_BODY"] = 6] = "IN_BODY";
		InsertionMode[InsertionMode["TEXT"] = 7] = "TEXT";
		InsertionMode[InsertionMode["IN_TABLE"] = 8] = "IN_TABLE";
		InsertionMode[InsertionMode["IN_TABLE_TEXT"] = 9] = "IN_TABLE_TEXT";
		InsertionMode[InsertionMode["IN_CAPTION"] = 10] = "IN_CAPTION";
		InsertionMode[InsertionMode["IN_COLUMN_GROUP"] = 11] = "IN_COLUMN_GROUP";
		InsertionMode[InsertionMode["IN_TABLE_BODY"] = 12] = "IN_TABLE_BODY";
		InsertionMode[InsertionMode["IN_ROW"] = 13] = "IN_ROW";
		InsertionMode[InsertionMode["IN_CELL"] = 14] = "IN_CELL";
		InsertionMode[InsertionMode["IN_SELECT"] = 15] = "IN_SELECT";
		InsertionMode[InsertionMode["IN_SELECT_IN_TABLE"] = 16] = "IN_SELECT_IN_TABLE";
		InsertionMode[InsertionMode["IN_TEMPLATE"] = 17] = "IN_TEMPLATE";
		InsertionMode[InsertionMode["AFTER_BODY"] = 18] = "AFTER_BODY";
		InsertionMode[InsertionMode["IN_FRAMESET"] = 19] = "IN_FRAMESET";
		InsertionMode[InsertionMode["AFTER_FRAMESET"] = 20] = "AFTER_FRAMESET";
		InsertionMode[InsertionMode["AFTER_AFTER_BODY"] = 21] = "AFTER_AFTER_BODY";
		InsertionMode[InsertionMode["AFTER_AFTER_FRAMESET"] = 22] = "AFTER_AFTER_FRAMESET";
	})(InsertionMode || (InsertionMode = {}));
	var BASE_LOC = {
		startLine: -1,
		startCol: -1,
		startOffset: -1,
		endLine: -1,
		endCol: -1,
		endOffset: -1
	};
	var TABLE_STRUCTURE_TAGS = new Set([
		TAG_ID.TABLE,
		TAG_ID.TBODY,
		TAG_ID.TFOOT,
		TAG_ID.THEAD,
		TAG_ID.TR
	]);
	var defaultParserOptions = {
		scriptingEnabled: true,
		sourceCodeLocationInfo: false,
		treeAdapter: defaultTreeAdapter,
		onParseError: null
	};
	var Parser = class {
		constructor(options, document, fragmentContext = null, scriptHandler = null) {
			this.fragmentContext = fragmentContext;
			this.scriptHandler = scriptHandler;
			this.currentToken = null;
			this.stopped = false;
			this.insertionMode = InsertionMode.INITIAL;
			this.originalInsertionMode = InsertionMode.INITIAL;
			this.headElement = null;
			this.formElement = null;
			this.currentNotInHTML = false;
			this.tmplInsertionModeStack = [];
			this.pendingCharacterTokens = [];
			this.hasNonWhitespacePendingCharacterToken = false;
			this.framesetOk = true;
			this.skipNextNewLine = false;
			this.fosterParentingEnabled = false;
			this.options = {
				...defaultParserOptions,
				...options
			};
			this.treeAdapter = this.options.treeAdapter;
			this.onParseError = this.options.onParseError;
			if (this.onParseError) this.options.sourceCodeLocationInfo = true;
			this.document = document !== null && document !== void 0 ? document : this.treeAdapter.createDocument();
			this.tokenizer = new Tokenizer(this.options, this);
			this.activeFormattingElements = new FormattingElementList(this.treeAdapter);
			this.fragmentContextID = fragmentContext ? getTagID(this.treeAdapter.getTagName(fragmentContext)) : TAG_ID.UNKNOWN;
			this._setContextModes(fragmentContext !== null && fragmentContext !== void 0 ? fragmentContext : this.document, this.fragmentContextID);
			this.openElements = new OpenElementStack(this.document, this.treeAdapter, this);
		}
		static parse(html, options) {
			const parser = new this(options);
			parser.tokenizer.write(html, true);
			return parser.document;
		}
		static getFragmentParser(fragmentContext, options) {
			const opts = {
				...defaultParserOptions,
				...options
			};
			fragmentContext !== null && fragmentContext !== void 0 || (fragmentContext = opts.treeAdapter.createElement(TAG_NAMES.TEMPLATE, NS.HTML, []));
			const documentMock = opts.treeAdapter.createElement("documentmock", NS.HTML, []);
			const parser = new this(opts, documentMock, fragmentContext);
			if (parser.fragmentContextID === TAG_ID.TEMPLATE) parser.tmplInsertionModeStack.unshift(InsertionMode.IN_TEMPLATE);
			parser._initTokenizerForFragmentParsing();
			parser._insertFakeRootElement();
			parser._resetInsertionMode();
			parser._findFormInFragmentContext();
			return parser;
		}
		getFragment() {
			const rootElement = this.treeAdapter.getFirstChild(this.document);
			const fragment = this.treeAdapter.createDocumentFragment();
			this._adoptNodes(rootElement, fragment);
			return fragment;
		}
		_err(token, code, beforeToken) {
			var _a;
			if (!this.onParseError) return;
			const loc = (_a = token.location) !== null && _a !== void 0 ? _a : BASE_LOC;
			const err = {
				code,
				startLine: loc.startLine,
				startCol: loc.startCol,
				startOffset: loc.startOffset,
				endLine: beforeToken ? loc.startLine : loc.endLine,
				endCol: beforeToken ? loc.startCol : loc.endCol,
				endOffset: beforeToken ? loc.startOffset : loc.endOffset
			};
			this.onParseError(err);
		}
		onItemPush(node, tid, isTop) {
			var _a, _b;
			(_b = (_a = this.treeAdapter).onItemPush) === null || _b === void 0 || _b.call(_a, node);
			if (isTop && this.openElements.stackTop > 0) this._setContextModes(node, tid);
		}
		onItemPop(node, isTop) {
			var _a, _b;
			if (this.options.sourceCodeLocationInfo) this._setEndLocation(node, this.currentToken);
			(_b = (_a = this.treeAdapter).onItemPop) === null || _b === void 0 || _b.call(_a, node, this.openElements.current);
			if (isTop) {
				let current;
				let currentTagId;
				if (this.openElements.stackTop === 0 && this.fragmentContext) {
					current = this.fragmentContext;
					currentTagId = this.fragmentContextID;
				} else ({current, currentTagId} = this.openElements);
				this._setContextModes(current, currentTagId);
			}
		}
		_setContextModes(current, tid) {
			const isHTML = current === this.document || current && this.treeAdapter.getNamespaceURI(current) === NS.HTML;
			this.currentNotInHTML = !isHTML;
			this.tokenizer.inForeignNode = !isHTML && current !== void 0 && tid !== void 0 && !this._isIntegrationPoint(tid, current);
		}
		_switchToTextParsing(currentToken, nextTokenizerState) {
			this._insertElement(currentToken, NS.HTML);
			this.tokenizer.state = nextTokenizerState;
			this.originalInsertionMode = this.insertionMode;
			this.insertionMode = InsertionMode.TEXT;
		}
		switchToPlaintextParsing() {
			this.insertionMode = InsertionMode.TEXT;
			this.originalInsertionMode = InsertionMode.IN_BODY;
			this.tokenizer.state = TokenizerMode.PLAINTEXT;
		}
		_getAdjustedCurrentElement() {
			return this.openElements.stackTop === 0 && this.fragmentContext ? this.fragmentContext : this.openElements.current;
		}
		_findFormInFragmentContext() {
			let node = this.fragmentContext;
			while (node) {
				if (this.treeAdapter.getTagName(node) === TAG_NAMES.FORM) {
					this.formElement = node;
					break;
				}
				node = this.treeAdapter.getParentNode(node);
			}
		}
		_initTokenizerForFragmentParsing() {
			if (!this.fragmentContext || this.treeAdapter.getNamespaceURI(this.fragmentContext) !== NS.HTML) return;
			switch (this.fragmentContextID) {
				case TAG_ID.TITLE:
				case TAG_ID.TEXTAREA:
					this.tokenizer.state = TokenizerMode.RCDATA;
					break;
				case TAG_ID.STYLE:
				case TAG_ID.XMP:
				case TAG_ID.IFRAME:
				case TAG_ID.NOEMBED:
				case TAG_ID.NOFRAMES:
				case TAG_ID.NOSCRIPT:
					this.tokenizer.state = TokenizerMode.RAWTEXT;
					break;
				case TAG_ID.SCRIPT:
					this.tokenizer.state = TokenizerMode.SCRIPT_DATA;
					break;
				case TAG_ID.PLAINTEXT: this.tokenizer.state = TokenizerMode.PLAINTEXT;
			}
		}
		_setDocumentType(token) {
			const name = token.name || "";
			const publicId = token.publicId || "";
			const systemId = token.systemId || "";
			this.treeAdapter.setDocumentType(this.document, name, publicId, systemId);
			if (token.location) {
				const docTypeNode = this.treeAdapter.getChildNodes(this.document).find((node) => this.treeAdapter.isDocumentTypeNode(node));
				if (docTypeNode) this.treeAdapter.setNodeSourceCodeLocation(docTypeNode, token.location);
			}
		}
		_attachElementToTree(element, location) {
			if (this.options.sourceCodeLocationInfo) {
				const loc = location && {
					...location,
					startTag: location
				};
				this.treeAdapter.setNodeSourceCodeLocation(element, loc);
			}
			if (this._shouldFosterParentOnInsertion()) this._fosterParentElement(element);
			else {
				const parent = this.openElements.currentTmplContentOrNode;
				this.treeAdapter.appendChild(parent !== null && parent !== void 0 ? parent : this.document, element);
			}
		}
		_appendElement(token, namespaceURI) {
			const element = this.treeAdapter.createElement(token.tagName, namespaceURI, token.attrs);
			this._attachElementToTree(element, token.location);
		}
		_insertElement(token, namespaceURI) {
			const element = this.treeAdapter.createElement(token.tagName, namespaceURI, token.attrs);
			this._attachElementToTree(element, token.location);
			this.openElements.push(element, token.tagID);
		}
		_insertFakeElement(tagName, tagID) {
			const element = this.treeAdapter.createElement(tagName, NS.HTML, []);
			this._attachElementToTree(element, null);
			this.openElements.push(element, tagID);
		}
		_insertTemplate(token) {
			const tmpl = this.treeAdapter.createElement(token.tagName, NS.HTML, token.attrs);
			const content = this.treeAdapter.createDocumentFragment();
			this.treeAdapter.setTemplateContent(tmpl, content);
			this._attachElementToTree(tmpl, token.location);
			this.openElements.push(tmpl, token.tagID);
			if (this.options.sourceCodeLocationInfo) this.treeAdapter.setNodeSourceCodeLocation(content, null);
		}
		_insertFakeRootElement() {
			const element = this.treeAdapter.createElement(TAG_NAMES.HTML, NS.HTML, []);
			if (this.options.sourceCodeLocationInfo) this.treeAdapter.setNodeSourceCodeLocation(element, null);
			this.treeAdapter.appendChild(this.openElements.current, element);
			this.openElements.push(element, TAG_ID.HTML);
		}
		_appendCommentNode(token, parent) {
			const commentNode = this.treeAdapter.createCommentNode(token.data);
			this.treeAdapter.appendChild(parent, commentNode);
			if (this.options.sourceCodeLocationInfo) this.treeAdapter.setNodeSourceCodeLocation(commentNode, token.location);
		}
		_insertCharacters(token) {
			let parent;
			let beforeElement;
			if (this._shouldFosterParentOnInsertion()) {
				({parent, beforeElement} = this._findFosterParentingLocation());
				if (beforeElement) this.treeAdapter.insertTextBefore(parent, token.chars, beforeElement);
				else this.treeAdapter.insertText(parent, token.chars);
			} else {
				parent = this.openElements.currentTmplContentOrNode;
				this.treeAdapter.insertText(parent, token.chars);
			}
			if (!token.location) return;
			const siblings = this.treeAdapter.getChildNodes(parent);
			const textNode = siblings[(beforeElement ? siblings.lastIndexOf(beforeElement) : siblings.length) - 1];
			if (this.treeAdapter.getNodeSourceCodeLocation(textNode)) {
				const { endLine, endCol, endOffset } = token.location;
				this.treeAdapter.updateNodeSourceCodeLocation(textNode, {
					endLine,
					endCol,
					endOffset
				});
			} else if (this.options.sourceCodeLocationInfo) this.treeAdapter.setNodeSourceCodeLocation(textNode, token.location);
		}
		_adoptNodes(donor, recipient) {
			for (let child = this.treeAdapter.getFirstChild(donor); child; child = this.treeAdapter.getFirstChild(donor)) {
				this.treeAdapter.detachNode(child);
				this.treeAdapter.appendChild(recipient, child);
			}
		}
		_setEndLocation(element, closingToken) {
			if (this.treeAdapter.getNodeSourceCodeLocation(element) && closingToken.location) {
				const ctLoc = closingToken.location;
				const tn = this.treeAdapter.getTagName(element);
				const endLoc = closingToken.type === TokenType.END_TAG && tn === closingToken.tagName ? {
					endTag: { ...ctLoc },
					endLine: ctLoc.endLine,
					endCol: ctLoc.endCol,
					endOffset: ctLoc.endOffset
				} : {
					endLine: ctLoc.startLine,
					endCol: ctLoc.startCol,
					endOffset: ctLoc.startOffset
				};
				this.treeAdapter.updateNodeSourceCodeLocation(element, endLoc);
			}
		}
		shouldProcessStartTagTokenInForeignContent(token) {
			if (!this.currentNotInHTML) return false;
			let current;
			let currentTagId;
			if (this.openElements.stackTop === 0 && this.fragmentContext) {
				current = this.fragmentContext;
				currentTagId = this.fragmentContextID;
			} else ({current, currentTagId} = this.openElements);
			if (token.tagID === TAG_ID.SVG && this.treeAdapter.getTagName(current) === TAG_NAMES.ANNOTATION_XML && this.treeAdapter.getNamespaceURI(current) === NS.MATHML) return false;
			return this.tokenizer.inForeignNode || (token.tagID === TAG_ID.MGLYPH || token.tagID === TAG_ID.MALIGNMARK) && currentTagId !== void 0 && !this._isIntegrationPoint(currentTagId, current, NS.HTML);
		}
		_processToken(token) {
			switch (token.type) {
				case TokenType.CHARACTER:
					this.onCharacter(token);
					break;
				case TokenType.NULL_CHARACTER:
					this.onNullCharacter(token);
					break;
				case TokenType.COMMENT:
					this.onComment(token);
					break;
				case TokenType.DOCTYPE:
					this.onDoctype(token);
					break;
				case TokenType.START_TAG:
					this._processStartTag(token);
					break;
				case TokenType.END_TAG:
					this.onEndTag(token);
					break;
				case TokenType.EOF:
					this.onEof(token);
					break;
				case TokenType.WHITESPACE_CHARACTER: this.onWhitespaceCharacter(token);
			}
		}
		_isIntegrationPoint(tid, element, foreignNS) {
			return isIntegrationPoint(tid, this.treeAdapter.getNamespaceURI(element), this.treeAdapter.getAttrList(element), foreignNS);
		}
		_reconstructActiveFormattingElements() {
			const listLength = this.activeFormattingElements.entries.length;
			if (listLength) {
				const endIndex = this.activeFormattingElements.entries.findIndex((entry) => entry.type === EntryType.Marker || this.openElements.contains(entry.element));
				const unopenIdx = endIndex === -1 ? listLength - 1 : endIndex - 1;
				for (let i = unopenIdx; i >= 0; i--) {
					const entry = this.activeFormattingElements.entries[i];
					this._insertElement(entry.token, this.treeAdapter.getNamespaceURI(entry.element));
					entry.element = this.openElements.current;
				}
			}
		}
		_closeTableCell() {
			this.openElements.generateImpliedEndTags();
			this.openElements.popUntilTableCellPopped();
			this.activeFormattingElements.clearToLastMarker();
			this.insertionMode = InsertionMode.IN_ROW;
		}
		_closePElement() {
			this.openElements.generateImpliedEndTagsWithExclusion(TAG_ID.P);
			this.openElements.popUntilTagNamePopped(TAG_ID.P);
		}
		_resetInsertionMode() {
			for (let i = this.openElements.stackTop; i >= 0; i--) switch (i === 0 && this.fragmentContext ? this.fragmentContextID : this.openElements.tagIDs[i]) {
				case TAG_ID.TR:
					this.insertionMode = InsertionMode.IN_ROW;
					return;
				case TAG_ID.TBODY:
				case TAG_ID.THEAD:
				case TAG_ID.TFOOT:
					this.insertionMode = InsertionMode.IN_TABLE_BODY;
					return;
				case TAG_ID.CAPTION:
					this.insertionMode = InsertionMode.IN_CAPTION;
					return;
				case TAG_ID.COLGROUP:
					this.insertionMode = InsertionMode.IN_COLUMN_GROUP;
					return;
				case TAG_ID.TABLE:
					this.insertionMode = InsertionMode.IN_TABLE;
					return;
				case TAG_ID.BODY:
					this.insertionMode = InsertionMode.IN_BODY;
					return;
				case TAG_ID.FRAMESET:
					this.insertionMode = InsertionMode.IN_FRAMESET;
					return;
				case TAG_ID.SELECT:
					this._resetInsertionModeForSelect(i);
					return;
				case TAG_ID.TEMPLATE:
					this.insertionMode = this.tmplInsertionModeStack[0];
					return;
				case TAG_ID.HTML:
					this.insertionMode = this.headElement ? InsertionMode.AFTER_HEAD : InsertionMode.BEFORE_HEAD;
					return;
				case TAG_ID.TD:
				case TAG_ID.TH:
					if (i > 0) {
						this.insertionMode = InsertionMode.IN_CELL;
						return;
					}
					break;
				case TAG_ID.HEAD: if (i > 0) {
					this.insertionMode = InsertionMode.IN_HEAD;
					return;
				}
			}
			this.insertionMode = InsertionMode.IN_BODY;
		}
		_resetInsertionModeForSelect(selectIdx) {
			if (selectIdx > 0) for (let i = selectIdx - 1; i > 0; i--) {
				const tn = this.openElements.tagIDs[i];
				if (tn === TAG_ID.TEMPLATE) break;
				else if (tn === TAG_ID.TABLE) {
					this.insertionMode = InsertionMode.IN_SELECT_IN_TABLE;
					return;
				}
			}
			this.insertionMode = InsertionMode.IN_SELECT;
		}
		_isElementCausesFosterParenting(tn) {
			return TABLE_STRUCTURE_TAGS.has(tn);
		}
		_shouldFosterParentOnInsertion() {
			return this.fosterParentingEnabled && this.openElements.currentTagId !== void 0 && this._isElementCausesFosterParenting(this.openElements.currentTagId);
		}
		_findFosterParentingLocation() {
			for (let i = this.openElements.stackTop; i >= 0; i--) {
				const openElement = this.openElements.items[i];
				switch (this.openElements.tagIDs[i]) {
					case TAG_ID.TEMPLATE:
						if (this.treeAdapter.getNamespaceURI(openElement) === NS.HTML) return {
							parent: this.treeAdapter.getTemplateContent(openElement),
							beforeElement: null
						};
						break;
					case TAG_ID.TABLE: {
						const parent = this.treeAdapter.getParentNode(openElement);
						if (parent) return {
							parent,
							beforeElement: openElement
						};
						return {
							parent: this.openElements.items[i - 1],
							beforeElement: null
						};
					}
				}
			}
			return {
				parent: this.openElements.items[0],
				beforeElement: null
			};
		}
		_fosterParentElement(element) {
			const location = this._findFosterParentingLocation();
			if (location.beforeElement) this.treeAdapter.insertBefore(location.parent, element, location.beforeElement);
			else this.treeAdapter.appendChild(location.parent, element);
		}
		_isSpecialElement(element, id) {
			return SPECIAL_ELEMENTS[this.treeAdapter.getNamespaceURI(element)].has(id);
		}
		onCharacter(token) {
			this.skipNextNewLine = false;
			if (this.tokenizer.inForeignNode) {
				characterInForeignContent(this, token);
				return;
			}
			switch (this.insertionMode) {
				case InsertionMode.INITIAL:
					tokenInInitialMode(this, token);
					break;
				case InsertionMode.BEFORE_HTML:
					tokenBeforeHtml(this, token);
					break;
				case InsertionMode.BEFORE_HEAD:
					tokenBeforeHead(this, token);
					break;
				case InsertionMode.IN_HEAD:
					tokenInHead(this, token);
					break;
				case InsertionMode.IN_HEAD_NO_SCRIPT:
					tokenInHeadNoScript(this, token);
					break;
				case InsertionMode.AFTER_HEAD:
					tokenAfterHead(this, token);
					break;
				case InsertionMode.IN_BODY:
				case InsertionMode.IN_CAPTION:
				case InsertionMode.IN_CELL:
				case InsertionMode.IN_TEMPLATE:
					characterInBody(this, token);
					break;
				case InsertionMode.TEXT:
				case InsertionMode.IN_SELECT:
				case InsertionMode.IN_SELECT_IN_TABLE:
					this._insertCharacters(token);
					break;
				case InsertionMode.IN_TABLE:
				case InsertionMode.IN_TABLE_BODY:
				case InsertionMode.IN_ROW:
					characterInTable(this, token);
					break;
				case InsertionMode.IN_TABLE_TEXT:
					characterInTableText(this, token);
					break;
				case InsertionMode.IN_COLUMN_GROUP:
					tokenInColumnGroup(this, token);
					break;
				case InsertionMode.AFTER_BODY:
					tokenAfterBody(this, token);
					break;
				case InsertionMode.AFTER_AFTER_BODY: tokenAfterAfterBody(this, token);
			}
		}
		onNullCharacter(token) {
			this.skipNextNewLine = false;
			if (this.tokenizer.inForeignNode) {
				nullCharacterInForeignContent(this, token);
				return;
			}
			switch (this.insertionMode) {
				case InsertionMode.INITIAL:
					tokenInInitialMode(this, token);
					break;
				case InsertionMode.BEFORE_HTML:
					tokenBeforeHtml(this, token);
					break;
				case InsertionMode.BEFORE_HEAD:
					tokenBeforeHead(this, token);
					break;
				case InsertionMode.IN_HEAD:
					tokenInHead(this, token);
					break;
				case InsertionMode.IN_HEAD_NO_SCRIPT:
					tokenInHeadNoScript(this, token);
					break;
				case InsertionMode.AFTER_HEAD:
					tokenAfterHead(this, token);
					break;
				case InsertionMode.TEXT:
					this._insertCharacters(token);
					break;
				case InsertionMode.IN_TABLE:
				case InsertionMode.IN_TABLE_BODY:
				case InsertionMode.IN_ROW:
					characterInTable(this, token);
					break;
				case InsertionMode.IN_COLUMN_GROUP:
					tokenInColumnGroup(this, token);
					break;
				case InsertionMode.AFTER_BODY:
					tokenAfterBody(this, token);
					break;
				case InsertionMode.AFTER_AFTER_BODY: tokenAfterAfterBody(this, token);
			}
		}
		onComment(token) {
			this.skipNextNewLine = false;
			if (this.currentNotInHTML) {
				appendComment(this, token);
				return;
			}
			switch (this.insertionMode) {
				case InsertionMode.INITIAL:
				case InsertionMode.BEFORE_HTML:
				case InsertionMode.BEFORE_HEAD:
				case InsertionMode.IN_HEAD:
				case InsertionMode.IN_HEAD_NO_SCRIPT:
				case InsertionMode.AFTER_HEAD:
				case InsertionMode.IN_BODY:
				case InsertionMode.IN_TABLE:
				case InsertionMode.IN_CAPTION:
				case InsertionMode.IN_COLUMN_GROUP:
				case InsertionMode.IN_TABLE_BODY:
				case InsertionMode.IN_ROW:
				case InsertionMode.IN_CELL:
				case InsertionMode.IN_SELECT:
				case InsertionMode.IN_SELECT_IN_TABLE:
				case InsertionMode.IN_TEMPLATE:
				case InsertionMode.IN_FRAMESET:
				case InsertionMode.AFTER_FRAMESET:
					appendComment(this, token);
					break;
				case InsertionMode.IN_TABLE_TEXT:
					tokenInTableText(this, token);
					break;
				case InsertionMode.AFTER_BODY:
					appendCommentToRootHtmlElement(this, token);
					break;
				case InsertionMode.AFTER_AFTER_BODY:
				case InsertionMode.AFTER_AFTER_FRAMESET: appendCommentToDocument(this, token);
			}
		}
		onDoctype(token) {
			this.skipNextNewLine = false;
			switch (this.insertionMode) {
				case InsertionMode.INITIAL:
					doctypeInInitialMode(this, token);
					break;
				case InsertionMode.BEFORE_HEAD:
				case InsertionMode.IN_HEAD:
				case InsertionMode.IN_HEAD_NO_SCRIPT:
				case InsertionMode.AFTER_HEAD:
					this._err(token, ERR.misplacedDoctype);
					break;
				case InsertionMode.IN_TABLE_TEXT: tokenInTableText(this, token);
			}
		}
		onStartTag(token) {
			this.skipNextNewLine = false;
			this.currentToken = token;
			this._processStartTag(token);
			if (token.selfClosing && !token.ackSelfClosing) this._err(token, ERR.nonVoidHtmlElementStartTagWithTrailingSolidus);
		}
		_processStartTag(token) {
			if (this.shouldProcessStartTagTokenInForeignContent(token)) startTagInForeignContent(this, token);
			else this._startTagOutsideForeignContent(token);
		}
		_startTagOutsideForeignContent(token) {
			switch (this.insertionMode) {
				case InsertionMode.INITIAL:
					tokenInInitialMode(this, token);
					break;
				case InsertionMode.BEFORE_HTML:
					startTagBeforeHtml(this, token);
					break;
				case InsertionMode.BEFORE_HEAD:
					startTagBeforeHead(this, token);
					break;
				case InsertionMode.IN_HEAD:
					startTagInHead(this, token);
					break;
				case InsertionMode.IN_HEAD_NO_SCRIPT:
					startTagInHeadNoScript(this, token);
					break;
				case InsertionMode.AFTER_HEAD:
					startTagAfterHead(this, token);
					break;
				case InsertionMode.IN_BODY:
					startTagInBody(this, token);
					break;
				case InsertionMode.IN_TABLE:
					startTagInTable(this, token);
					break;
				case InsertionMode.IN_TABLE_TEXT:
					tokenInTableText(this, token);
					break;
				case InsertionMode.IN_CAPTION:
					startTagInCaption(this, token);
					break;
				case InsertionMode.IN_COLUMN_GROUP:
					startTagInColumnGroup(this, token);
					break;
				case InsertionMode.IN_TABLE_BODY:
					startTagInTableBody(this, token);
					break;
				case InsertionMode.IN_ROW:
					startTagInRow(this, token);
					break;
				case InsertionMode.IN_CELL:
					startTagInCell(this, token);
					break;
				case InsertionMode.IN_SELECT:
					startTagInSelect(this, token);
					break;
				case InsertionMode.IN_SELECT_IN_TABLE:
					startTagInSelectInTable(this, token);
					break;
				case InsertionMode.IN_TEMPLATE:
					startTagInTemplate(this, token);
					break;
				case InsertionMode.AFTER_BODY:
					startTagAfterBody(this, token);
					break;
				case InsertionMode.IN_FRAMESET:
					startTagInFrameset(this, token);
					break;
				case InsertionMode.AFTER_FRAMESET:
					startTagAfterFrameset(this, token);
					break;
				case InsertionMode.AFTER_AFTER_BODY:
					startTagAfterAfterBody(this, token);
					break;
				case InsertionMode.AFTER_AFTER_FRAMESET: startTagAfterAfterFrameset(this, token);
			}
		}
		onEndTag(token) {
			this.skipNextNewLine = false;
			this.currentToken = token;
			if (this.currentNotInHTML) endTagInForeignContent(this, token);
			else this._endTagOutsideForeignContent(token);
		}
		_endTagOutsideForeignContent(token) {
			switch (this.insertionMode) {
				case InsertionMode.INITIAL:
					tokenInInitialMode(this, token);
					break;
				case InsertionMode.BEFORE_HTML:
					endTagBeforeHtml(this, token);
					break;
				case InsertionMode.BEFORE_HEAD:
					endTagBeforeHead(this, token);
					break;
				case InsertionMode.IN_HEAD:
					endTagInHead(this, token);
					break;
				case InsertionMode.IN_HEAD_NO_SCRIPT:
					endTagInHeadNoScript(this, token);
					break;
				case InsertionMode.AFTER_HEAD:
					endTagAfterHead(this, token);
					break;
				case InsertionMode.IN_BODY:
					endTagInBody(this, token);
					break;
				case InsertionMode.TEXT:
					endTagInText(this, token);
					break;
				case InsertionMode.IN_TABLE:
					endTagInTable(this, token);
					break;
				case InsertionMode.IN_TABLE_TEXT:
					tokenInTableText(this, token);
					break;
				case InsertionMode.IN_CAPTION:
					endTagInCaption(this, token);
					break;
				case InsertionMode.IN_COLUMN_GROUP:
					endTagInColumnGroup(this, token);
					break;
				case InsertionMode.IN_TABLE_BODY:
					endTagInTableBody(this, token);
					break;
				case InsertionMode.IN_ROW:
					endTagInRow(this, token);
					break;
				case InsertionMode.IN_CELL:
					endTagInCell(this, token);
					break;
				case InsertionMode.IN_SELECT:
					endTagInSelect(this, token);
					break;
				case InsertionMode.IN_SELECT_IN_TABLE:
					endTagInSelectInTable(this, token);
					break;
				case InsertionMode.IN_TEMPLATE:
					endTagInTemplate(this, token);
					break;
				case InsertionMode.AFTER_BODY:
					endTagAfterBody(this, token);
					break;
				case InsertionMode.IN_FRAMESET:
					endTagInFrameset(this, token);
					break;
				case InsertionMode.AFTER_FRAMESET:
					endTagAfterFrameset(this, token);
					break;
				case InsertionMode.AFTER_AFTER_BODY: tokenAfterAfterBody(this, token);
			}
		}
		onEof(token) {
			switch (this.insertionMode) {
				case InsertionMode.INITIAL:
					tokenInInitialMode(this, token);
					break;
				case InsertionMode.BEFORE_HTML:
					tokenBeforeHtml(this, token);
					break;
				case InsertionMode.BEFORE_HEAD:
					tokenBeforeHead(this, token);
					break;
				case InsertionMode.IN_HEAD:
					tokenInHead(this, token);
					break;
				case InsertionMode.IN_HEAD_NO_SCRIPT:
					tokenInHeadNoScript(this, token);
					break;
				case InsertionMode.AFTER_HEAD:
					tokenAfterHead(this, token);
					break;
				case InsertionMode.IN_BODY:
				case InsertionMode.IN_TABLE:
				case InsertionMode.IN_CAPTION:
				case InsertionMode.IN_COLUMN_GROUP:
				case InsertionMode.IN_TABLE_BODY:
				case InsertionMode.IN_ROW:
				case InsertionMode.IN_CELL:
				case InsertionMode.IN_SELECT:
				case InsertionMode.IN_SELECT_IN_TABLE:
					eofInBody(this, token);
					break;
				case InsertionMode.TEXT:
					eofInText(this, token);
					break;
				case InsertionMode.IN_TABLE_TEXT:
					tokenInTableText(this, token);
					break;
				case InsertionMode.IN_TEMPLATE:
					eofInTemplate(this, token);
					break;
				case InsertionMode.AFTER_BODY:
				case InsertionMode.IN_FRAMESET:
				case InsertionMode.AFTER_FRAMESET:
				case InsertionMode.AFTER_AFTER_BODY:
				case InsertionMode.AFTER_AFTER_FRAMESET: stopParsing(this, token);
			}
		}
		onWhitespaceCharacter(token) {
			if (this.skipNextNewLine) {
				this.skipNextNewLine = false;
				if (token.chars.charCodeAt(0) === CODE_POINTS.LINE_FEED) {
					if (token.chars.length === 1) return;
					token.chars = token.chars.substr(1);
				}
			}
			if (this.tokenizer.inForeignNode) {
				this._insertCharacters(token);
				return;
			}
			switch (this.insertionMode) {
				case InsertionMode.IN_HEAD:
				case InsertionMode.IN_HEAD_NO_SCRIPT:
				case InsertionMode.AFTER_HEAD:
				case InsertionMode.TEXT:
				case InsertionMode.IN_COLUMN_GROUP:
				case InsertionMode.IN_SELECT:
				case InsertionMode.IN_SELECT_IN_TABLE:
				case InsertionMode.IN_FRAMESET:
				case InsertionMode.AFTER_FRAMESET:
					this._insertCharacters(token);
					break;
				case InsertionMode.IN_BODY:
				case InsertionMode.IN_CAPTION:
				case InsertionMode.IN_CELL:
				case InsertionMode.IN_TEMPLATE:
				case InsertionMode.AFTER_BODY:
				case InsertionMode.AFTER_AFTER_BODY:
				case InsertionMode.AFTER_AFTER_FRAMESET:
					whitespaceCharacterInBody(this, token);
					break;
				case InsertionMode.IN_TABLE:
				case InsertionMode.IN_TABLE_BODY:
				case InsertionMode.IN_ROW:
					characterInTable(this, token);
					break;
				case InsertionMode.IN_TABLE_TEXT: whitespaceCharacterInTableText(this, token);
			}
		}
	};
	function aaObtainFormattingElementEntry(p, token) {
		let formattingElementEntry = p.activeFormattingElements.getElementEntryInScopeWithTagName(token.tagName);
		if (formattingElementEntry) {
			if (!p.openElements.contains(formattingElementEntry.element)) {
				p.activeFormattingElements.removeEntry(formattingElementEntry);
				formattingElementEntry = null;
			} else if (!p.openElements.hasInScope(token.tagID)) formattingElementEntry = null;
		} else genericEndTagInBody(p, token);
		return formattingElementEntry;
	}
	function aaObtainFurthestBlock(p, formattingElementEntry) {
		let furthestBlock = null;
		let idx = p.openElements.stackTop;
		for (; idx >= 0; idx--) {
			const element = p.openElements.items[idx];
			if (element === formattingElementEntry.element) break;
			if (p._isSpecialElement(element, p.openElements.tagIDs[idx])) furthestBlock = element;
		}
		if (!furthestBlock) {
			p.openElements.shortenToLength(Math.max(idx, 0));
			p.activeFormattingElements.removeEntry(formattingElementEntry);
		}
		return furthestBlock;
	}
	function aaInnerLoop(p, furthestBlock, formattingElement) {
		let lastElement = furthestBlock;
		let nextElement = p.openElements.getCommonAncestor(furthestBlock);
		for (let i = 0, element = nextElement; element !== formattingElement; i++, element = nextElement) {
			nextElement = p.openElements.getCommonAncestor(element);
			const elementEntry = p.activeFormattingElements.getElementEntry(element);
			const counterOverflow = elementEntry && i >= AA_INNER_LOOP_ITER;
			if (!elementEntry || counterOverflow) {
				if (counterOverflow) p.activeFormattingElements.removeEntry(elementEntry);
				p.openElements.remove(element);
			} else {
				element = aaRecreateElementFromEntry(p, elementEntry);
				if (lastElement === furthestBlock) p.activeFormattingElements.bookmark = elementEntry;
				p.treeAdapter.detachNode(lastElement);
				p.treeAdapter.appendChild(element, lastElement);
				lastElement = element;
			}
		}
		return lastElement;
	}
	function aaRecreateElementFromEntry(p, elementEntry) {
		const ns = p.treeAdapter.getNamespaceURI(elementEntry.element);
		const newElement = p.treeAdapter.createElement(elementEntry.token.tagName, ns, elementEntry.token.attrs);
		p.openElements.replace(elementEntry.element, newElement);
		elementEntry.element = newElement;
		return newElement;
	}
	function aaInsertLastNodeInCommonAncestor(p, commonAncestor, lastElement) {
		const tid = getTagID(p.treeAdapter.getTagName(commonAncestor));
		if (p._isElementCausesFosterParenting(tid)) p._fosterParentElement(lastElement);
		else {
			const ns = p.treeAdapter.getNamespaceURI(commonAncestor);
			if (tid === TAG_ID.TEMPLATE && ns === NS.HTML) commonAncestor = p.treeAdapter.getTemplateContent(commonAncestor);
			p.treeAdapter.appendChild(commonAncestor, lastElement);
		}
	}
	function aaReplaceFormattingElement(p, furthestBlock, formattingElementEntry) {
		const ns = p.treeAdapter.getNamespaceURI(formattingElementEntry.element);
		const { token } = formattingElementEntry;
		const newElement = p.treeAdapter.createElement(token.tagName, ns, token.attrs);
		p._adoptNodes(furthestBlock, newElement);
		p.treeAdapter.appendChild(furthestBlock, newElement);
		p.activeFormattingElements.insertElementAfterBookmark(newElement, token);
		p.activeFormattingElements.removeEntry(formattingElementEntry);
		p.openElements.remove(formattingElementEntry.element);
		p.openElements.insertAfter(furthestBlock, newElement, token.tagID);
	}
	function callAdoptionAgency(p, token) {
		for (let i = 0; i < AA_OUTER_LOOP_ITER; i++) {
			const formattingElementEntry = aaObtainFormattingElementEntry(p, token);
			if (!formattingElementEntry) break;
			const furthestBlock = aaObtainFurthestBlock(p, formattingElementEntry);
			if (!furthestBlock) break;
			p.activeFormattingElements.bookmark = formattingElementEntry;
			const lastElement = aaInnerLoop(p, furthestBlock, formattingElementEntry.element);
			const commonAncestor = p.openElements.getCommonAncestor(formattingElementEntry.element);
			p.treeAdapter.detachNode(lastElement);
			if (commonAncestor) aaInsertLastNodeInCommonAncestor(p, commonAncestor, lastElement);
			aaReplaceFormattingElement(p, furthestBlock, formattingElementEntry);
		}
	}
	function appendComment(p, token) {
		p._appendCommentNode(token, p.openElements.currentTmplContentOrNode);
	}
	function appendCommentToRootHtmlElement(p, token) {
		p._appendCommentNode(token, p.openElements.items[0]);
	}
	function appendCommentToDocument(p, token) {
		p._appendCommentNode(token, p.document);
	}
	function stopParsing(p, token) {
		p.stopped = true;
		if (token.location) {
			const target = p.fragmentContext ? 0 : 2;
			for (let i = p.openElements.stackTop; i >= target; i--) p._setEndLocation(p.openElements.items[i], token);
			if (!p.fragmentContext && p.openElements.stackTop >= 0) {
				const htmlElement = p.openElements.items[0];
				const htmlLocation = p.treeAdapter.getNodeSourceCodeLocation(htmlElement);
				if (htmlLocation && !htmlLocation.endTag) {
					p._setEndLocation(htmlElement, token);
					if (p.openElements.stackTop >= 1) {
						const bodyElement = p.openElements.items[1];
						const bodyLocation = p.treeAdapter.getNodeSourceCodeLocation(bodyElement);
						if (bodyLocation && !bodyLocation.endTag) p._setEndLocation(bodyElement, token);
					}
				}
			}
		}
	}
	function doctypeInInitialMode(p, token) {
		p._setDocumentType(token);
		const mode = token.forceQuirks ? DOCUMENT_MODE.QUIRKS : getDocumentMode(token);
		if (!isConforming(token)) p._err(token, ERR.nonConformingDoctype);
		p.treeAdapter.setDocumentMode(p.document, mode);
		p.insertionMode = InsertionMode.BEFORE_HTML;
	}
	function tokenInInitialMode(p, token) {
		p._err(token, ERR.missingDoctype, true);
		p.treeAdapter.setDocumentMode(p.document, DOCUMENT_MODE.QUIRKS);
		p.insertionMode = InsertionMode.BEFORE_HTML;
		p._processToken(token);
	}
	function startTagBeforeHtml(p, token) {
		if (token.tagID === TAG_ID.HTML) {
			p._insertElement(token, NS.HTML);
			p.insertionMode = InsertionMode.BEFORE_HEAD;
		} else tokenBeforeHtml(p, token);
	}
	function endTagBeforeHtml(p, token) {
		const tn = token.tagID;
		if (tn === TAG_ID.HTML || tn === TAG_ID.HEAD || tn === TAG_ID.BODY || tn === TAG_ID.BR) tokenBeforeHtml(p, token);
	}
	function tokenBeforeHtml(p, token) {
		p._insertFakeRootElement();
		p.insertionMode = InsertionMode.BEFORE_HEAD;
		p._processToken(token);
	}
	function startTagBeforeHead(p, token) {
		switch (token.tagID) {
			case TAG_ID.HTML:
				startTagInBody(p, token);
				break;
			case TAG_ID.HEAD:
				p._insertElement(token, NS.HTML);
				p.headElement = p.openElements.current;
				p.insertionMode = InsertionMode.IN_HEAD;
				break;
			default: tokenBeforeHead(p, token);
		}
	}
	function endTagBeforeHead(p, token) {
		const tn = token.tagID;
		if (tn === TAG_ID.HEAD || tn === TAG_ID.BODY || tn === TAG_ID.HTML || tn === TAG_ID.BR) tokenBeforeHead(p, token);
		else p._err(token, ERR.endTagWithoutMatchingOpenElement);
	}
	function tokenBeforeHead(p, token) {
		p._insertFakeElement(TAG_NAMES.HEAD, TAG_ID.HEAD);
		p.headElement = p.openElements.current;
		p.insertionMode = InsertionMode.IN_HEAD;
		p._processToken(token);
	}
	function startTagInHead(p, token) {
		switch (token.tagID) {
			case TAG_ID.HTML:
				startTagInBody(p, token);
				break;
			case TAG_ID.BASE:
			case TAG_ID.BASEFONT:
			case TAG_ID.BGSOUND:
			case TAG_ID.LINK:
			case TAG_ID.META:
				p._appendElement(token, NS.HTML);
				token.ackSelfClosing = true;
				break;
			case TAG_ID.TITLE:
				p._switchToTextParsing(token, TokenizerMode.RCDATA);
				break;
			case TAG_ID.NOSCRIPT:
				if (p.options.scriptingEnabled) p._switchToTextParsing(token, TokenizerMode.RAWTEXT);
				else {
					p._insertElement(token, NS.HTML);
					p.insertionMode = InsertionMode.IN_HEAD_NO_SCRIPT;
				}
				break;
			case TAG_ID.NOFRAMES:
			case TAG_ID.STYLE:
				p._switchToTextParsing(token, TokenizerMode.RAWTEXT);
				break;
			case TAG_ID.SCRIPT:
				p._switchToTextParsing(token, TokenizerMode.SCRIPT_DATA);
				break;
			case TAG_ID.TEMPLATE:
				p._insertTemplate(token);
				p.activeFormattingElements.insertMarker();
				p.framesetOk = false;
				p.insertionMode = InsertionMode.IN_TEMPLATE;
				p.tmplInsertionModeStack.unshift(InsertionMode.IN_TEMPLATE);
				break;
			case TAG_ID.HEAD:
				p._err(token, ERR.misplacedStartTagForHeadElement);
				break;
			default: tokenInHead(p, token);
		}
	}
	function endTagInHead(p, token) {
		switch (token.tagID) {
			case TAG_ID.HEAD:
				p.openElements.pop();
				p.insertionMode = InsertionMode.AFTER_HEAD;
				break;
			case TAG_ID.BODY:
			case TAG_ID.BR:
			case TAG_ID.HTML:
				tokenInHead(p, token);
				break;
			case TAG_ID.TEMPLATE:
				templateEndTagInHead(p, token);
				break;
			default: p._err(token, ERR.endTagWithoutMatchingOpenElement);
		}
	}
	function templateEndTagInHead(p, token) {
		if (p.openElements.tmplCount > 0) {
			p.openElements.generateImpliedEndTagsThoroughly();
			if (p.openElements.currentTagId !== TAG_ID.TEMPLATE) p._err(token, ERR.closingOfElementWithOpenChildElements);
			p.openElements.popUntilTagNamePopped(TAG_ID.TEMPLATE);
			p.activeFormattingElements.clearToLastMarker();
			p.tmplInsertionModeStack.shift();
			p._resetInsertionMode();
		} else p._err(token, ERR.endTagWithoutMatchingOpenElement);
	}
	function tokenInHead(p, token) {
		p.openElements.pop();
		p.insertionMode = InsertionMode.AFTER_HEAD;
		p._processToken(token);
	}
	function startTagInHeadNoScript(p, token) {
		switch (token.tagID) {
			case TAG_ID.HTML:
				startTagInBody(p, token);
				break;
			case TAG_ID.BASEFONT:
			case TAG_ID.BGSOUND:
			case TAG_ID.HEAD:
			case TAG_ID.LINK:
			case TAG_ID.META:
			case TAG_ID.NOFRAMES:
			case TAG_ID.STYLE:
				startTagInHead(p, token);
				break;
			case TAG_ID.NOSCRIPT:
				p._err(token, ERR.nestedNoscriptInHead);
				break;
			default: tokenInHeadNoScript(p, token);
		}
	}
	function endTagInHeadNoScript(p, token) {
		switch (token.tagID) {
			case TAG_ID.NOSCRIPT:
				p.openElements.pop();
				p.insertionMode = InsertionMode.IN_HEAD;
				break;
			case TAG_ID.BR:
				tokenInHeadNoScript(p, token);
				break;
			default: p._err(token, ERR.endTagWithoutMatchingOpenElement);
		}
	}
	function tokenInHeadNoScript(p, token) {
		const errCode = token.type === TokenType.EOF ? ERR.openElementsLeftAfterEof : ERR.disallowedContentInNoscriptInHead;
		p._err(token, errCode);
		p.openElements.pop();
		p.insertionMode = InsertionMode.IN_HEAD;
		p._processToken(token);
	}
	function startTagAfterHead(p, token) {
		switch (token.tagID) {
			case TAG_ID.HTML:
				startTagInBody(p, token);
				break;
			case TAG_ID.BODY:
				p._insertElement(token, NS.HTML);
				p.framesetOk = false;
				p.insertionMode = InsertionMode.IN_BODY;
				break;
			case TAG_ID.FRAMESET:
				p._insertElement(token, NS.HTML);
				p.insertionMode = InsertionMode.IN_FRAMESET;
				break;
			case TAG_ID.BASE:
			case TAG_ID.BASEFONT:
			case TAG_ID.BGSOUND:
			case TAG_ID.LINK:
			case TAG_ID.META:
			case TAG_ID.NOFRAMES:
			case TAG_ID.SCRIPT:
			case TAG_ID.STYLE:
			case TAG_ID.TEMPLATE:
			case TAG_ID.TITLE:
				p._err(token, ERR.abandonedHeadElementChild);
				p.openElements.push(p.headElement, TAG_ID.HEAD);
				startTagInHead(p, token);
				p.openElements.remove(p.headElement);
				break;
			case TAG_ID.HEAD:
				p._err(token, ERR.misplacedStartTagForHeadElement);
				break;
			default: tokenAfterHead(p, token);
		}
	}
	function endTagAfterHead(p, token) {
		switch (token.tagID) {
			case TAG_ID.BODY:
			case TAG_ID.HTML:
			case TAG_ID.BR:
				tokenAfterHead(p, token);
				break;
			case TAG_ID.TEMPLATE:
				templateEndTagInHead(p, token);
				break;
			default: p._err(token, ERR.endTagWithoutMatchingOpenElement);
		}
	}
	function tokenAfterHead(p, token) {
		p._insertFakeElement(TAG_NAMES.BODY, TAG_ID.BODY);
		p.insertionMode = InsertionMode.IN_BODY;
		modeInBody(p, token);
	}
	function modeInBody(p, token) {
		switch (token.type) {
			case TokenType.CHARACTER:
				characterInBody(p, token);
				break;
			case TokenType.WHITESPACE_CHARACTER:
				whitespaceCharacterInBody(p, token);
				break;
			case TokenType.COMMENT:
				appendComment(p, token);
				break;
			case TokenType.START_TAG:
				startTagInBody(p, token);
				break;
			case TokenType.END_TAG:
				endTagInBody(p, token);
				break;
			case TokenType.EOF: eofInBody(p, token);
		}
	}
	function whitespaceCharacterInBody(p, token) {
		p._reconstructActiveFormattingElements();
		p._insertCharacters(token);
	}
	function characterInBody(p, token) {
		p._reconstructActiveFormattingElements();
		p._insertCharacters(token);
		p.framesetOk = false;
	}
	function htmlStartTagInBody(p, token) {
		if (p.openElements.tmplCount === 0) p.treeAdapter.adoptAttributes(p.openElements.items[0], token.attrs);
	}
	function bodyStartTagInBody(p, token) {
		const bodyElement = p.openElements.tryPeekProperlyNestedBodyElement();
		if (bodyElement && p.openElements.tmplCount === 0) {
			p.framesetOk = false;
			p.treeAdapter.adoptAttributes(bodyElement, token.attrs);
		}
	}
	function framesetStartTagInBody(p, token) {
		const bodyElement = p.openElements.tryPeekProperlyNestedBodyElement();
		if (p.framesetOk && bodyElement) {
			p.treeAdapter.detachNode(bodyElement);
			p.openElements.popAllUpToHtmlElement();
			p._insertElement(token, NS.HTML);
			p.insertionMode = InsertionMode.IN_FRAMESET;
		}
	}
	function addressStartTagInBody(p, token) {
		if (p.openElements.hasInButtonScope(TAG_ID.P)) p._closePElement();
		p._insertElement(token, NS.HTML);
	}
	function numberedHeaderStartTagInBody(p, token) {
		if (p.openElements.hasInButtonScope(TAG_ID.P)) p._closePElement();
		if (p.openElements.currentTagId !== void 0 && NUMBERED_HEADERS.has(p.openElements.currentTagId)) p.openElements.pop();
		p._insertElement(token, NS.HTML);
	}
	function preStartTagInBody(p, token) {
		if (p.openElements.hasInButtonScope(TAG_ID.P)) p._closePElement();
		p._insertElement(token, NS.HTML);
		p.skipNextNewLine = true;
		p.framesetOk = false;
	}
	function formStartTagInBody(p, token) {
		const inTemplate = p.openElements.tmplCount > 0;
		if (!p.formElement || inTemplate) {
			if (p.openElements.hasInButtonScope(TAG_ID.P)) p._closePElement();
			p._insertElement(token, NS.HTML);
			if (!inTemplate) p.formElement = p.openElements.current;
		}
	}
	function listItemStartTagInBody(p, token) {
		p.framesetOk = false;
		const tn = token.tagID;
		for (let i = p.openElements.stackTop; i >= 0; i--) {
			const elementId = p.openElements.tagIDs[i];
			if (tn === TAG_ID.LI && elementId === TAG_ID.LI || (tn === TAG_ID.DD || tn === TAG_ID.DT) && (elementId === TAG_ID.DD || elementId === TAG_ID.DT)) {
				p.openElements.generateImpliedEndTagsWithExclusion(elementId);
				p.openElements.popUntilTagNamePopped(elementId);
				break;
			}
			if (elementId !== TAG_ID.ADDRESS && elementId !== TAG_ID.DIV && elementId !== TAG_ID.P && p._isSpecialElement(p.openElements.items[i], elementId)) break;
		}
		if (p.openElements.hasInButtonScope(TAG_ID.P)) p._closePElement();
		p._insertElement(token, NS.HTML);
	}
	function plaintextStartTagInBody(p, token) {
		if (p.openElements.hasInButtonScope(TAG_ID.P)) p._closePElement();
		p._insertElement(token, NS.HTML);
		p.tokenizer.state = TokenizerMode.PLAINTEXT;
	}
	function buttonStartTagInBody(p, token) {
		if (p.openElements.hasInScope(TAG_ID.BUTTON)) {
			p.openElements.generateImpliedEndTags();
			p.openElements.popUntilTagNamePopped(TAG_ID.BUTTON);
		}
		p._reconstructActiveFormattingElements();
		p._insertElement(token, NS.HTML);
		p.framesetOk = false;
	}
	function aStartTagInBody(p, token) {
		const activeElementEntry = p.activeFormattingElements.getElementEntryInScopeWithTagName(TAG_NAMES.A);
		if (activeElementEntry) {
			callAdoptionAgency(p, token);
			p.openElements.remove(activeElementEntry.element);
			p.activeFormattingElements.removeEntry(activeElementEntry);
		}
		p._reconstructActiveFormattingElements();
		p._insertElement(token, NS.HTML);
		p.activeFormattingElements.pushElement(p.openElements.current, token);
	}
	function bStartTagInBody(p, token) {
		p._reconstructActiveFormattingElements();
		p._insertElement(token, NS.HTML);
		p.activeFormattingElements.pushElement(p.openElements.current, token);
	}
	function nobrStartTagInBody(p, token) {
		p._reconstructActiveFormattingElements();
		if (p.openElements.hasInScope(TAG_ID.NOBR)) {
			callAdoptionAgency(p, token);
			p._reconstructActiveFormattingElements();
		}
		p._insertElement(token, NS.HTML);
		p.activeFormattingElements.pushElement(p.openElements.current, token);
	}
	function appletStartTagInBody(p, token) {
		p._reconstructActiveFormattingElements();
		p._insertElement(token, NS.HTML);
		p.activeFormattingElements.insertMarker();
		p.framesetOk = false;
	}
	function tableStartTagInBody(p, token) {
		if (p.treeAdapter.getDocumentMode(p.document) !== DOCUMENT_MODE.QUIRKS && p.openElements.hasInButtonScope(TAG_ID.P)) p._closePElement();
		p._insertElement(token, NS.HTML);
		p.framesetOk = false;
		p.insertionMode = InsertionMode.IN_TABLE;
	}
	function areaStartTagInBody(p, token) {
		p._reconstructActiveFormattingElements();
		p._appendElement(token, NS.HTML);
		p.framesetOk = false;
		token.ackSelfClosing = true;
	}
	function isHiddenInput(token) {
		const inputType = getTokenAttr(token, ATTRS.TYPE);
		return inputType != null && inputType.toLowerCase() === HIDDEN_INPUT_TYPE;
	}
	function inputStartTagInBody(p, token) {
		p._reconstructActiveFormattingElements();
		p._appendElement(token, NS.HTML);
		if (!isHiddenInput(token)) p.framesetOk = false;
		token.ackSelfClosing = true;
	}
	function paramStartTagInBody(p, token) {
		p._appendElement(token, NS.HTML);
		token.ackSelfClosing = true;
	}
	function hrStartTagInBody(p, token) {
		if (p.openElements.hasInButtonScope(TAG_ID.P)) p._closePElement();
		p._appendElement(token, NS.HTML);
		p.framesetOk = false;
		token.ackSelfClosing = true;
	}
	function imageStartTagInBody(p, token) {
		token.tagName = TAG_NAMES.IMG;
		token.tagID = TAG_ID.IMG;
		areaStartTagInBody(p, token);
	}
	function textareaStartTagInBody(p, token) {
		p._insertElement(token, NS.HTML);
		p.skipNextNewLine = true;
		p.tokenizer.state = TokenizerMode.RCDATA;
		p.originalInsertionMode = p.insertionMode;
		p.framesetOk = false;
		p.insertionMode = InsertionMode.TEXT;
	}
	function xmpStartTagInBody(p, token) {
		if (p.openElements.hasInButtonScope(TAG_ID.P)) p._closePElement();
		p._reconstructActiveFormattingElements();
		p.framesetOk = false;
		p._switchToTextParsing(token, TokenizerMode.RAWTEXT);
	}
	function iframeStartTagInBody(p, token) {
		p.framesetOk = false;
		p._switchToTextParsing(token, TokenizerMode.RAWTEXT);
	}
	function rawTextStartTagInBody(p, token) {
		p._switchToTextParsing(token, TokenizerMode.RAWTEXT);
	}
	function selectStartTagInBody(p, token) {
		p._reconstructActiveFormattingElements();
		p._insertElement(token, NS.HTML);
		p.framesetOk = false;
		p.insertionMode = p.insertionMode === InsertionMode.IN_TABLE || p.insertionMode === InsertionMode.IN_CAPTION || p.insertionMode === InsertionMode.IN_TABLE_BODY || p.insertionMode === InsertionMode.IN_ROW || p.insertionMode === InsertionMode.IN_CELL ? InsertionMode.IN_SELECT_IN_TABLE : InsertionMode.IN_SELECT;
	}
	function optgroupStartTagInBody(p, token) {
		if (p.openElements.currentTagId === TAG_ID.OPTION) p.openElements.pop();
		p._reconstructActiveFormattingElements();
		p._insertElement(token, NS.HTML);
	}
	function rbStartTagInBody(p, token) {
		if (p.openElements.hasInScope(TAG_ID.RUBY)) p.openElements.generateImpliedEndTags();
		p._insertElement(token, NS.HTML);
	}
	function rtStartTagInBody(p, token) {
		if (p.openElements.hasInScope(TAG_ID.RUBY)) p.openElements.generateImpliedEndTagsWithExclusion(TAG_ID.RTC);
		p._insertElement(token, NS.HTML);
	}
	function mathStartTagInBody(p, token) {
		p._reconstructActiveFormattingElements();
		adjustTokenMathMLAttrs(token);
		adjustTokenXMLAttrs(token);
		if (token.selfClosing) p._appendElement(token, NS.MATHML);
		else p._insertElement(token, NS.MATHML);
		token.ackSelfClosing = true;
	}
	function svgStartTagInBody(p, token) {
		p._reconstructActiveFormattingElements();
		adjustTokenSVGAttrs(token);
		adjustTokenXMLAttrs(token);
		if (token.selfClosing) p._appendElement(token, NS.SVG);
		else p._insertElement(token, NS.SVG);
		token.ackSelfClosing = true;
	}
	function genericStartTagInBody(p, token) {
		p._reconstructActiveFormattingElements();
		p._insertElement(token, NS.HTML);
	}
	function startTagInBody(p, token) {
		switch (token.tagID) {
			case TAG_ID.I:
			case TAG_ID.S:
			case TAG_ID.B:
			case TAG_ID.U:
			case TAG_ID.EM:
			case TAG_ID.TT:
			case TAG_ID.BIG:
			case TAG_ID.CODE:
			case TAG_ID.FONT:
			case TAG_ID.SMALL:
			case TAG_ID.STRIKE:
			case TAG_ID.STRONG:
				bStartTagInBody(p, token);
				break;
			case TAG_ID.A:
				aStartTagInBody(p, token);
				break;
			case TAG_ID.H1:
			case TAG_ID.H2:
			case TAG_ID.H3:
			case TAG_ID.H4:
			case TAG_ID.H5:
			case TAG_ID.H6:
				numberedHeaderStartTagInBody(p, token);
				break;
			case TAG_ID.P:
			case TAG_ID.DL:
			case TAG_ID.OL:
			case TAG_ID.UL:
			case TAG_ID.DIV:
			case TAG_ID.DIR:
			case TAG_ID.NAV:
			case TAG_ID.MAIN:
			case TAG_ID.MENU:
			case TAG_ID.ASIDE:
			case TAG_ID.CENTER:
			case TAG_ID.FIGURE:
			case TAG_ID.FOOTER:
			case TAG_ID.HEADER:
			case TAG_ID.HGROUP:
			case TAG_ID.DIALOG:
			case TAG_ID.DETAILS:
			case TAG_ID.ADDRESS:
			case TAG_ID.ARTICLE:
			case TAG_ID.SEARCH:
			case TAG_ID.SECTION:
			case TAG_ID.SUMMARY:
			case TAG_ID.FIELDSET:
			case TAG_ID.BLOCKQUOTE:
			case TAG_ID.FIGCAPTION:
				addressStartTagInBody(p, token);
				break;
			case TAG_ID.LI:
			case TAG_ID.DD:
			case TAG_ID.DT:
				listItemStartTagInBody(p, token);
				break;
			case TAG_ID.BR:
			case TAG_ID.IMG:
			case TAG_ID.WBR:
			case TAG_ID.AREA:
			case TAG_ID.EMBED:
			case TAG_ID.KEYGEN:
				areaStartTagInBody(p, token);
				break;
			case TAG_ID.HR:
				hrStartTagInBody(p, token);
				break;
			case TAG_ID.RB:
			case TAG_ID.RTC:
				rbStartTagInBody(p, token);
				break;
			case TAG_ID.RT:
			case TAG_ID.RP:
				rtStartTagInBody(p, token);
				break;
			case TAG_ID.PRE:
			case TAG_ID.LISTING:
				preStartTagInBody(p, token);
				break;
			case TAG_ID.XMP:
				xmpStartTagInBody(p, token);
				break;
			case TAG_ID.SVG:
				svgStartTagInBody(p, token);
				break;
			case TAG_ID.HTML:
				htmlStartTagInBody(p, token);
				break;
			case TAG_ID.BASE:
			case TAG_ID.LINK:
			case TAG_ID.META:
			case TAG_ID.STYLE:
			case TAG_ID.TITLE:
			case TAG_ID.SCRIPT:
			case TAG_ID.BGSOUND:
			case TAG_ID.BASEFONT:
			case TAG_ID.TEMPLATE:
				startTagInHead(p, token);
				break;
			case TAG_ID.BODY:
				bodyStartTagInBody(p, token);
				break;
			case TAG_ID.FORM:
				formStartTagInBody(p, token);
				break;
			case TAG_ID.NOBR:
				nobrStartTagInBody(p, token);
				break;
			case TAG_ID.MATH:
				mathStartTagInBody(p, token);
				break;
			case TAG_ID.TABLE:
				tableStartTagInBody(p, token);
				break;
			case TAG_ID.INPUT:
				inputStartTagInBody(p, token);
				break;
			case TAG_ID.PARAM:
			case TAG_ID.TRACK:
			case TAG_ID.SOURCE:
				paramStartTagInBody(p, token);
				break;
			case TAG_ID.IMAGE:
				imageStartTagInBody(p, token);
				break;
			case TAG_ID.BUTTON:
				buttonStartTagInBody(p, token);
				break;
			case TAG_ID.APPLET:
			case TAG_ID.OBJECT:
			case TAG_ID.MARQUEE:
				appletStartTagInBody(p, token);
				break;
			case TAG_ID.IFRAME:
				iframeStartTagInBody(p, token);
				break;
			case TAG_ID.SELECT:
				selectStartTagInBody(p, token);
				break;
			case TAG_ID.OPTION:
			case TAG_ID.OPTGROUP:
				optgroupStartTagInBody(p, token);
				break;
			case TAG_ID.NOEMBED:
			case TAG_ID.NOFRAMES:
				rawTextStartTagInBody(p, token);
				break;
			case TAG_ID.FRAMESET:
				framesetStartTagInBody(p, token);
				break;
			case TAG_ID.TEXTAREA:
				textareaStartTagInBody(p, token);
				break;
			case TAG_ID.NOSCRIPT:
				if (p.options.scriptingEnabled) rawTextStartTagInBody(p, token);
				else genericStartTagInBody(p, token);
				break;
			case TAG_ID.PLAINTEXT:
				plaintextStartTagInBody(p, token);
				break;
			case TAG_ID.COL:
			case TAG_ID.TH:
			case TAG_ID.TD:
			case TAG_ID.TR:
			case TAG_ID.HEAD:
			case TAG_ID.FRAME:
			case TAG_ID.TBODY:
			case TAG_ID.TFOOT:
			case TAG_ID.THEAD:
			case TAG_ID.CAPTION:
			case TAG_ID.COLGROUP: break;
			default: genericStartTagInBody(p, token);
		}
	}
	function bodyEndTagInBody(p, token) {
		if (p.openElements.hasInScope(TAG_ID.BODY)) {
			p.insertionMode = InsertionMode.AFTER_BODY;
			if (p.options.sourceCodeLocationInfo) {
				const bodyElement = p.openElements.tryPeekProperlyNestedBodyElement();
				if (bodyElement) p._setEndLocation(bodyElement, token);
			}
		}
	}
	function htmlEndTagInBody(p, token) {
		if (p.openElements.hasInScope(TAG_ID.BODY)) {
			p.insertionMode = InsertionMode.AFTER_BODY;
			endTagAfterBody(p, token);
		}
	}
	function addressEndTagInBody(p, token) {
		const tn = token.tagID;
		if (p.openElements.hasInScope(tn)) {
			p.openElements.generateImpliedEndTags();
			p.openElements.popUntilTagNamePopped(tn);
		}
	}
	function formEndTagInBody(p) {
		const inTemplate = p.openElements.tmplCount > 0;
		const { formElement } = p;
		if (!inTemplate) p.formElement = null;
		if ((formElement || inTemplate) && p.openElements.hasInScope(TAG_ID.FORM)) {
			p.openElements.generateImpliedEndTags();
			if (inTemplate) p.openElements.popUntilTagNamePopped(TAG_ID.FORM);
			else if (formElement) p.openElements.remove(formElement);
		}
	}
	function pEndTagInBody(p) {
		if (!p.openElements.hasInButtonScope(TAG_ID.P)) p._insertFakeElement(TAG_NAMES.P, TAG_ID.P);
		p._closePElement();
	}
	function liEndTagInBody(p) {
		if (p.openElements.hasInListItemScope(TAG_ID.LI)) {
			p.openElements.generateImpliedEndTagsWithExclusion(TAG_ID.LI);
			p.openElements.popUntilTagNamePopped(TAG_ID.LI);
		}
	}
	function ddEndTagInBody(p, token) {
		const tn = token.tagID;
		if (p.openElements.hasInScope(tn)) {
			p.openElements.generateImpliedEndTagsWithExclusion(tn);
			p.openElements.popUntilTagNamePopped(tn);
		}
	}
	function numberedHeaderEndTagInBody(p) {
		if (p.openElements.hasNumberedHeaderInScope()) {
			p.openElements.generateImpliedEndTags();
			p.openElements.popUntilNumberedHeaderPopped();
		}
	}
	function appletEndTagInBody(p, token) {
		const tn = token.tagID;
		if (p.openElements.hasInScope(tn)) {
			p.openElements.generateImpliedEndTags();
			p.openElements.popUntilTagNamePopped(tn);
			p.activeFormattingElements.clearToLastMarker();
		}
	}
	function brEndTagInBody(p) {
		p._reconstructActiveFormattingElements();
		p._insertFakeElement(TAG_NAMES.BR, TAG_ID.BR);
		p.openElements.pop();
		p.framesetOk = false;
	}
	function genericEndTagInBody(p, token) {
		const tn = token.tagName;
		const tid = token.tagID;
		for (let i = p.openElements.stackTop; i > 0; i--) {
			const element = p.openElements.items[i];
			const elementId = p.openElements.tagIDs[i];
			if (tid === elementId && (tid !== TAG_ID.UNKNOWN || p.treeAdapter.getTagName(element) === tn)) {
				p.openElements.generateImpliedEndTagsWithExclusion(tid);
				if (p.openElements.stackTop >= i) p.openElements.shortenToLength(i);
				break;
			}
			if (p._isSpecialElement(element, elementId)) break;
		}
	}
	function endTagInBody(p, token) {
		switch (token.tagID) {
			case TAG_ID.A:
			case TAG_ID.B:
			case TAG_ID.I:
			case TAG_ID.S:
			case TAG_ID.U:
			case TAG_ID.EM:
			case TAG_ID.TT:
			case TAG_ID.BIG:
			case TAG_ID.CODE:
			case TAG_ID.FONT:
			case TAG_ID.NOBR:
			case TAG_ID.SMALL:
			case TAG_ID.STRIKE:
			case TAG_ID.STRONG:
				callAdoptionAgency(p, token);
				break;
			case TAG_ID.P:
				pEndTagInBody(p);
				break;
			case TAG_ID.DL:
			case TAG_ID.UL:
			case TAG_ID.OL:
			case TAG_ID.DIR:
			case TAG_ID.DIV:
			case TAG_ID.NAV:
			case TAG_ID.PRE:
			case TAG_ID.MAIN:
			case TAG_ID.MENU:
			case TAG_ID.ASIDE:
			case TAG_ID.BUTTON:
			case TAG_ID.CENTER:
			case TAG_ID.FIGURE:
			case TAG_ID.FOOTER:
			case TAG_ID.HEADER:
			case TAG_ID.HGROUP:
			case TAG_ID.DIALOG:
			case TAG_ID.ADDRESS:
			case TAG_ID.ARTICLE:
			case TAG_ID.DETAILS:
			case TAG_ID.SEARCH:
			case TAG_ID.SECTION:
			case TAG_ID.SUMMARY:
			case TAG_ID.LISTING:
			case TAG_ID.FIELDSET:
			case TAG_ID.BLOCKQUOTE:
			case TAG_ID.FIGCAPTION:
				addressEndTagInBody(p, token);
				break;
			case TAG_ID.LI:
				liEndTagInBody(p);
				break;
			case TAG_ID.DD:
			case TAG_ID.DT:
				ddEndTagInBody(p, token);
				break;
			case TAG_ID.H1:
			case TAG_ID.H2:
			case TAG_ID.H3:
			case TAG_ID.H4:
			case TAG_ID.H5:
			case TAG_ID.H6:
				numberedHeaderEndTagInBody(p);
				break;
			case TAG_ID.BR:
				brEndTagInBody(p);
				break;
			case TAG_ID.BODY:
				bodyEndTagInBody(p, token);
				break;
			case TAG_ID.HTML:
				htmlEndTagInBody(p, token);
				break;
			case TAG_ID.FORM:
				formEndTagInBody(p);
				break;
			case TAG_ID.APPLET:
			case TAG_ID.OBJECT:
			case TAG_ID.MARQUEE:
				appletEndTagInBody(p, token);
				break;
			case TAG_ID.TEMPLATE:
				templateEndTagInHead(p, token);
				break;
			default: genericEndTagInBody(p, token);
		}
	}
	function eofInBody(p, token) {
		if (p.tmplInsertionModeStack.length > 0) eofInTemplate(p, token);
		else stopParsing(p, token);
	}
	function endTagInText(p, token) {
		var _a;
		if (token.tagID === TAG_ID.SCRIPT) (_a = p.scriptHandler) === null || _a === void 0 || _a.call(p, p.openElements.current);
		p.openElements.pop();
		p.insertionMode = p.originalInsertionMode;
	}
	function eofInText(p, token) {
		p._err(token, ERR.eofInElementThatCanContainOnlyText);
		p.openElements.pop();
		p.insertionMode = p.originalInsertionMode;
		p.onEof(token);
	}
	function characterInTable(p, token) {
		if (p.openElements.currentTagId !== void 0 && TABLE_STRUCTURE_TAGS.has(p.openElements.currentTagId)) {
			p.pendingCharacterTokens.length = 0;
			p.hasNonWhitespacePendingCharacterToken = false;
			p.originalInsertionMode = p.insertionMode;
			p.insertionMode = InsertionMode.IN_TABLE_TEXT;
			switch (token.type) {
				case TokenType.CHARACTER:
					characterInTableText(p, token);
					break;
				case TokenType.WHITESPACE_CHARACTER: whitespaceCharacterInTableText(p, token);
			}
		} else tokenInTable(p, token);
	}
	function captionStartTagInTable(p, token) {
		p.openElements.clearBackToTableContext();
		p.activeFormattingElements.insertMarker();
		p._insertElement(token, NS.HTML);
		p.insertionMode = InsertionMode.IN_CAPTION;
	}
	function colgroupStartTagInTable(p, token) {
		p.openElements.clearBackToTableContext();
		p._insertElement(token, NS.HTML);
		p.insertionMode = InsertionMode.IN_COLUMN_GROUP;
	}
	function colStartTagInTable(p, token) {
		p.openElements.clearBackToTableContext();
		p._insertFakeElement(TAG_NAMES.COLGROUP, TAG_ID.COLGROUP);
		p.insertionMode = InsertionMode.IN_COLUMN_GROUP;
		startTagInColumnGroup(p, token);
	}
	function tbodyStartTagInTable(p, token) {
		p.openElements.clearBackToTableContext();
		p._insertElement(token, NS.HTML);
		p.insertionMode = InsertionMode.IN_TABLE_BODY;
	}
	function tdStartTagInTable(p, token) {
		p.openElements.clearBackToTableContext();
		p._insertFakeElement(TAG_NAMES.TBODY, TAG_ID.TBODY);
		p.insertionMode = InsertionMode.IN_TABLE_BODY;
		startTagInTableBody(p, token);
	}
	function tableStartTagInTable(p, token) {
		if (p.openElements.hasInTableScope(TAG_ID.TABLE)) {
			p.openElements.popUntilTagNamePopped(TAG_ID.TABLE);
			p._resetInsertionMode();
			p._processStartTag(token);
		}
	}
	function inputStartTagInTable(p, token) {
		if (isHiddenInput(token)) p._appendElement(token, NS.HTML);
		else tokenInTable(p, token);
		token.ackSelfClosing = true;
	}
	function formStartTagInTable(p, token) {
		if (!p.formElement && p.openElements.tmplCount === 0) {
			p._insertElement(token, NS.HTML);
			p.formElement = p.openElements.current;
			p.openElements.pop();
		}
	}
	function startTagInTable(p, token) {
		switch (token.tagID) {
			case TAG_ID.TD:
			case TAG_ID.TH:
			case TAG_ID.TR:
				tdStartTagInTable(p, token);
				break;
			case TAG_ID.STYLE:
			case TAG_ID.SCRIPT:
			case TAG_ID.TEMPLATE:
				startTagInHead(p, token);
				break;
			case TAG_ID.COL:
				colStartTagInTable(p, token);
				break;
			case TAG_ID.FORM:
				formStartTagInTable(p, token);
				break;
			case TAG_ID.TABLE:
				tableStartTagInTable(p, token);
				break;
			case TAG_ID.TBODY:
			case TAG_ID.TFOOT:
			case TAG_ID.THEAD:
				tbodyStartTagInTable(p, token);
				break;
			case TAG_ID.INPUT:
				inputStartTagInTable(p, token);
				break;
			case TAG_ID.CAPTION:
				captionStartTagInTable(p, token);
				break;
			case TAG_ID.COLGROUP:
				colgroupStartTagInTable(p, token);
				break;
			default: tokenInTable(p, token);
		}
	}
	function endTagInTable(p, token) {
		switch (token.tagID) {
			case TAG_ID.TABLE:
				if (p.openElements.hasInTableScope(TAG_ID.TABLE)) {
					p.openElements.popUntilTagNamePopped(TAG_ID.TABLE);
					p._resetInsertionMode();
				}
				break;
			case TAG_ID.TEMPLATE:
				templateEndTagInHead(p, token);
				break;
			case TAG_ID.BODY:
			case TAG_ID.CAPTION:
			case TAG_ID.COL:
			case TAG_ID.COLGROUP:
			case TAG_ID.HTML:
			case TAG_ID.TBODY:
			case TAG_ID.TD:
			case TAG_ID.TFOOT:
			case TAG_ID.TH:
			case TAG_ID.THEAD:
			case TAG_ID.TR: break;
			default: tokenInTable(p, token);
		}
	}
	function tokenInTable(p, token) {
		const savedFosterParentingState = p.fosterParentingEnabled;
		p.fosterParentingEnabled = true;
		modeInBody(p, token);
		p.fosterParentingEnabled = savedFosterParentingState;
	}
	function whitespaceCharacterInTableText(p, token) {
		p.pendingCharacterTokens.push(token);
	}
	function characterInTableText(p, token) {
		p.pendingCharacterTokens.push(token);
		p.hasNonWhitespacePendingCharacterToken = true;
	}
	function tokenInTableText(p, token) {
		let i = 0;
		if (p.hasNonWhitespacePendingCharacterToken) for (; i < p.pendingCharacterTokens.length; i++) tokenInTable(p, p.pendingCharacterTokens[i]);
		else for (; i < p.pendingCharacterTokens.length; i++) p._insertCharacters(p.pendingCharacterTokens[i]);
		p.insertionMode = p.originalInsertionMode;
		p._processToken(token);
	}
	var TABLE_VOID_ELEMENTS = new Set([
		TAG_ID.CAPTION,
		TAG_ID.COL,
		TAG_ID.COLGROUP,
		TAG_ID.TBODY,
		TAG_ID.TD,
		TAG_ID.TFOOT,
		TAG_ID.TH,
		TAG_ID.THEAD,
		TAG_ID.TR
	]);
	function startTagInCaption(p, token) {
		const tn = token.tagID;
		if (TABLE_VOID_ELEMENTS.has(tn)) {
			if (p.openElements.hasInTableScope(TAG_ID.CAPTION)) {
				p.openElements.generateImpliedEndTags();
				p.openElements.popUntilTagNamePopped(TAG_ID.CAPTION);
				p.activeFormattingElements.clearToLastMarker();
				p.insertionMode = InsertionMode.IN_TABLE;
				startTagInTable(p, token);
			}
		} else startTagInBody(p, token);
	}
	function endTagInCaption(p, token) {
		const tn = token.tagID;
		switch (tn) {
			case TAG_ID.CAPTION:
			case TAG_ID.TABLE:
				if (p.openElements.hasInTableScope(TAG_ID.CAPTION)) {
					p.openElements.generateImpliedEndTags();
					p.openElements.popUntilTagNamePopped(TAG_ID.CAPTION);
					p.activeFormattingElements.clearToLastMarker();
					p.insertionMode = InsertionMode.IN_TABLE;
					if (tn === TAG_ID.TABLE) endTagInTable(p, token);
				}
				break;
			case TAG_ID.BODY:
			case TAG_ID.COL:
			case TAG_ID.COLGROUP:
			case TAG_ID.HTML:
			case TAG_ID.TBODY:
			case TAG_ID.TD:
			case TAG_ID.TFOOT:
			case TAG_ID.TH:
			case TAG_ID.THEAD:
			case TAG_ID.TR: break;
			default: endTagInBody(p, token);
		}
	}
	function startTagInColumnGroup(p, token) {
		switch (token.tagID) {
			case TAG_ID.HTML:
				startTagInBody(p, token);
				break;
			case TAG_ID.COL:
				p._appendElement(token, NS.HTML);
				token.ackSelfClosing = true;
				break;
			case TAG_ID.TEMPLATE:
				startTagInHead(p, token);
				break;
			default: tokenInColumnGroup(p, token);
		}
	}
	function endTagInColumnGroup(p, token) {
		switch (token.tagID) {
			case TAG_ID.COLGROUP:
				if (p.openElements.currentTagId === TAG_ID.COLGROUP) {
					p.openElements.pop();
					p.insertionMode = InsertionMode.IN_TABLE;
				}
				break;
			case TAG_ID.TEMPLATE:
				templateEndTagInHead(p, token);
				break;
			case TAG_ID.COL: break;
			default: tokenInColumnGroup(p, token);
		}
	}
	function tokenInColumnGroup(p, token) {
		if (p.openElements.currentTagId === TAG_ID.COLGROUP) {
			p.openElements.pop();
			p.insertionMode = InsertionMode.IN_TABLE;
			p._processToken(token);
		}
	}
	function startTagInTableBody(p, token) {
		switch (token.tagID) {
			case TAG_ID.TR:
				p.openElements.clearBackToTableBodyContext();
				p._insertElement(token, NS.HTML);
				p.insertionMode = InsertionMode.IN_ROW;
				break;
			case TAG_ID.TH:
			case TAG_ID.TD:
				p.openElements.clearBackToTableBodyContext();
				p._insertFakeElement(TAG_NAMES.TR, TAG_ID.TR);
				p.insertionMode = InsertionMode.IN_ROW;
				startTagInRow(p, token);
				break;
			case TAG_ID.CAPTION:
			case TAG_ID.COL:
			case TAG_ID.COLGROUP:
			case TAG_ID.TBODY:
			case TAG_ID.TFOOT:
			case TAG_ID.THEAD:
				if (p.openElements.hasTableBodyContextInTableScope()) {
					p.openElements.clearBackToTableBodyContext();
					p.openElements.pop();
					p.insertionMode = InsertionMode.IN_TABLE;
					startTagInTable(p, token);
				}
				break;
			default: startTagInTable(p, token);
		}
	}
	function endTagInTableBody(p, token) {
		const tn = token.tagID;
		switch (token.tagID) {
			case TAG_ID.TBODY:
			case TAG_ID.TFOOT:
			case TAG_ID.THEAD:
				if (p.openElements.hasInTableScope(tn)) {
					p.openElements.clearBackToTableBodyContext();
					p.openElements.pop();
					p.insertionMode = InsertionMode.IN_TABLE;
				}
				break;
			case TAG_ID.TABLE:
				if (p.openElements.hasTableBodyContextInTableScope()) {
					p.openElements.clearBackToTableBodyContext();
					p.openElements.pop();
					p.insertionMode = InsertionMode.IN_TABLE;
					endTagInTable(p, token);
				}
				break;
			case TAG_ID.BODY:
			case TAG_ID.CAPTION:
			case TAG_ID.COL:
			case TAG_ID.COLGROUP:
			case TAG_ID.HTML:
			case TAG_ID.TD:
			case TAG_ID.TH:
			case TAG_ID.TR: break;
			default: endTagInTable(p, token);
		}
	}
	function startTagInRow(p, token) {
		switch (token.tagID) {
			case TAG_ID.TH:
			case TAG_ID.TD:
				p.openElements.clearBackToTableRowContext();
				p._insertElement(token, NS.HTML);
				p.insertionMode = InsertionMode.IN_CELL;
				p.activeFormattingElements.insertMarker();
				break;
			case TAG_ID.CAPTION:
			case TAG_ID.COL:
			case TAG_ID.COLGROUP:
			case TAG_ID.TBODY:
			case TAG_ID.TFOOT:
			case TAG_ID.THEAD:
			case TAG_ID.TR:
				if (p.openElements.hasInTableScope(TAG_ID.TR)) {
					p.openElements.clearBackToTableRowContext();
					p.openElements.pop();
					p.insertionMode = InsertionMode.IN_TABLE_BODY;
					startTagInTableBody(p, token);
				}
				break;
			default: startTagInTable(p, token);
		}
	}
	function endTagInRow(p, token) {
		switch (token.tagID) {
			case TAG_ID.TR:
				if (p.openElements.hasInTableScope(TAG_ID.TR)) {
					p.openElements.clearBackToTableRowContext();
					p.openElements.pop();
					p.insertionMode = InsertionMode.IN_TABLE_BODY;
				}
				break;
			case TAG_ID.TABLE:
				if (p.openElements.hasInTableScope(TAG_ID.TR)) {
					p.openElements.clearBackToTableRowContext();
					p.openElements.pop();
					p.insertionMode = InsertionMode.IN_TABLE_BODY;
					endTagInTableBody(p, token);
				}
				break;
			case TAG_ID.TBODY:
			case TAG_ID.TFOOT:
			case TAG_ID.THEAD:
				if (p.openElements.hasInTableScope(token.tagID) || p.openElements.hasInTableScope(TAG_ID.TR)) {
					p.openElements.clearBackToTableRowContext();
					p.openElements.pop();
					p.insertionMode = InsertionMode.IN_TABLE_BODY;
					endTagInTableBody(p, token);
				}
				break;
			case TAG_ID.BODY:
			case TAG_ID.CAPTION:
			case TAG_ID.COL:
			case TAG_ID.COLGROUP:
			case TAG_ID.HTML:
			case TAG_ID.TD:
			case TAG_ID.TH: break;
			default: endTagInTable(p, token);
		}
	}
	function startTagInCell(p, token) {
		const tn = token.tagID;
		if (TABLE_VOID_ELEMENTS.has(tn)) {
			if (p.openElements.hasInTableScope(TAG_ID.TD) || p.openElements.hasInTableScope(TAG_ID.TH)) {
				p._closeTableCell();
				startTagInRow(p, token);
			}
		} else startTagInBody(p, token);
	}
	function endTagInCell(p, token) {
		const tn = token.tagID;
		switch (tn) {
			case TAG_ID.TD:
			case TAG_ID.TH:
				if (p.openElements.hasInTableScope(tn)) {
					p.openElements.generateImpliedEndTags();
					p.openElements.popUntilTagNamePopped(tn);
					p.activeFormattingElements.clearToLastMarker();
					p.insertionMode = InsertionMode.IN_ROW;
				}
				break;
			case TAG_ID.TABLE:
			case TAG_ID.TBODY:
			case TAG_ID.TFOOT:
			case TAG_ID.THEAD:
			case TAG_ID.TR:
				if (p.openElements.hasInTableScope(tn)) {
					p._closeTableCell();
					endTagInRow(p, token);
				}
				break;
			case TAG_ID.BODY:
			case TAG_ID.CAPTION:
			case TAG_ID.COL:
			case TAG_ID.COLGROUP:
			case TAG_ID.HTML: break;
			default: endTagInBody(p, token);
		}
	}
	function startTagInSelect(p, token) {
		switch (token.tagID) {
			case TAG_ID.HTML:
				startTagInBody(p, token);
				break;
			case TAG_ID.OPTION:
				if (p.openElements.currentTagId === TAG_ID.OPTION) p.openElements.pop();
				p._insertElement(token, NS.HTML);
				break;
			case TAG_ID.OPTGROUP:
				if (p.openElements.currentTagId === TAG_ID.OPTION) p.openElements.pop();
				if (p.openElements.currentTagId === TAG_ID.OPTGROUP) p.openElements.pop();
				p._insertElement(token, NS.HTML);
				break;
			case TAG_ID.HR:
				if (p.openElements.currentTagId === TAG_ID.OPTION) p.openElements.pop();
				if (p.openElements.currentTagId === TAG_ID.OPTGROUP) p.openElements.pop();
				p._appendElement(token, NS.HTML);
				token.ackSelfClosing = true;
				break;
			case TAG_ID.INPUT:
			case TAG_ID.KEYGEN:
			case TAG_ID.TEXTAREA:
			case TAG_ID.SELECT:
				if (p.openElements.hasInSelectScope(TAG_ID.SELECT)) {
					p.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
					p._resetInsertionMode();
					if (token.tagID !== TAG_ID.SELECT) p._processStartTag(token);
				}
				break;
			case TAG_ID.SCRIPT:
			case TAG_ID.TEMPLATE: startTagInHead(p, token);
		}
	}
	function endTagInSelect(p, token) {
		switch (token.tagID) {
			case TAG_ID.OPTGROUP:
				if (p.openElements.stackTop > 0 && p.openElements.currentTagId === TAG_ID.OPTION && p.openElements.tagIDs[p.openElements.stackTop - 1] === TAG_ID.OPTGROUP) p.openElements.pop();
				if (p.openElements.currentTagId === TAG_ID.OPTGROUP) p.openElements.pop();
				break;
			case TAG_ID.OPTION:
				if (p.openElements.currentTagId === TAG_ID.OPTION) p.openElements.pop();
				break;
			case TAG_ID.SELECT:
				if (p.openElements.hasInSelectScope(TAG_ID.SELECT)) {
					p.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
					p._resetInsertionMode();
				}
				break;
			case TAG_ID.TEMPLATE: templateEndTagInHead(p, token);
		}
	}
	function startTagInSelectInTable(p, token) {
		const tn = token.tagID;
		if (tn === TAG_ID.CAPTION || tn === TAG_ID.TABLE || tn === TAG_ID.TBODY || tn === TAG_ID.TFOOT || tn === TAG_ID.THEAD || tn === TAG_ID.TR || tn === TAG_ID.TD || tn === TAG_ID.TH) {
			p.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
			p._resetInsertionMode();
			p._processStartTag(token);
		} else startTagInSelect(p, token);
	}
	function endTagInSelectInTable(p, token) {
		const tn = token.tagID;
		if (tn === TAG_ID.CAPTION || tn === TAG_ID.TABLE || tn === TAG_ID.TBODY || tn === TAG_ID.TFOOT || tn === TAG_ID.THEAD || tn === TAG_ID.TR || tn === TAG_ID.TD || tn === TAG_ID.TH) {
			if (p.openElements.hasInTableScope(tn)) {
				p.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
				p._resetInsertionMode();
				p.onEndTag(token);
			}
		} else endTagInSelect(p, token);
	}
	function startTagInTemplate(p, token) {
		switch (token.tagID) {
			case TAG_ID.BASE:
			case TAG_ID.BASEFONT:
			case TAG_ID.BGSOUND:
			case TAG_ID.LINK:
			case TAG_ID.META:
			case TAG_ID.NOFRAMES:
			case TAG_ID.SCRIPT:
			case TAG_ID.STYLE:
			case TAG_ID.TEMPLATE:
			case TAG_ID.TITLE:
				startTagInHead(p, token);
				break;
			case TAG_ID.CAPTION:
			case TAG_ID.COLGROUP:
			case TAG_ID.TBODY:
			case TAG_ID.TFOOT:
			case TAG_ID.THEAD:
				p.tmplInsertionModeStack[0] = InsertionMode.IN_TABLE;
				p.insertionMode = InsertionMode.IN_TABLE;
				startTagInTable(p, token);
				break;
			case TAG_ID.COL:
				p.tmplInsertionModeStack[0] = InsertionMode.IN_COLUMN_GROUP;
				p.insertionMode = InsertionMode.IN_COLUMN_GROUP;
				startTagInColumnGroup(p, token);
				break;
			case TAG_ID.TR:
				p.tmplInsertionModeStack[0] = InsertionMode.IN_TABLE_BODY;
				p.insertionMode = InsertionMode.IN_TABLE_BODY;
				startTagInTableBody(p, token);
				break;
			case TAG_ID.TD:
			case TAG_ID.TH:
				p.tmplInsertionModeStack[0] = InsertionMode.IN_ROW;
				p.insertionMode = InsertionMode.IN_ROW;
				startTagInRow(p, token);
				break;
			default:
				p.tmplInsertionModeStack[0] = InsertionMode.IN_BODY;
				p.insertionMode = InsertionMode.IN_BODY;
				startTagInBody(p, token);
		}
	}
	function endTagInTemplate(p, token) {
		if (token.tagID === TAG_ID.TEMPLATE) templateEndTagInHead(p, token);
	}
	function eofInTemplate(p, token) {
		if (p.openElements.tmplCount > 0) {
			p.openElements.popUntilTagNamePopped(TAG_ID.TEMPLATE);
			p.activeFormattingElements.clearToLastMarker();
			p.tmplInsertionModeStack.shift();
			p._resetInsertionMode();
			p.onEof(token);
		} else stopParsing(p, token);
	}
	function startTagAfterBody(p, token) {
		if (token.tagID === TAG_ID.HTML) startTagInBody(p, token);
		else tokenAfterBody(p, token);
	}
	function endTagAfterBody(p, token) {
		var _a;
		if (token.tagID === TAG_ID.HTML) {
			if (!p.fragmentContext) p.insertionMode = InsertionMode.AFTER_AFTER_BODY;
			if (p.options.sourceCodeLocationInfo && p.openElements.tagIDs[0] === TAG_ID.HTML) {
				p._setEndLocation(p.openElements.items[0], token);
				const bodyElement = p.openElements.items[1];
				if (bodyElement && !((_a = p.treeAdapter.getNodeSourceCodeLocation(bodyElement)) === null || _a === void 0 ? void 0 : _a.endTag)) p._setEndLocation(bodyElement, token);
			}
		} else tokenAfterBody(p, token);
	}
	function tokenAfterBody(p, token) {
		p.insertionMode = InsertionMode.IN_BODY;
		modeInBody(p, token);
	}
	function startTagInFrameset(p, token) {
		switch (token.tagID) {
			case TAG_ID.HTML:
				startTagInBody(p, token);
				break;
			case TAG_ID.FRAMESET:
				p._insertElement(token, NS.HTML);
				break;
			case TAG_ID.FRAME:
				p._appendElement(token, NS.HTML);
				token.ackSelfClosing = true;
				break;
			case TAG_ID.NOFRAMES: startTagInHead(p, token);
		}
	}
	function endTagInFrameset(p, token) {
		if (token.tagID === TAG_ID.FRAMESET && !p.openElements.isRootHtmlElementCurrent()) {
			p.openElements.pop();
			if (!p.fragmentContext && p.openElements.currentTagId !== TAG_ID.FRAMESET) p.insertionMode = InsertionMode.AFTER_FRAMESET;
		}
	}
	function startTagAfterFrameset(p, token) {
		switch (token.tagID) {
			case TAG_ID.HTML:
				startTagInBody(p, token);
				break;
			case TAG_ID.NOFRAMES: startTagInHead(p, token);
		}
	}
	function endTagAfterFrameset(p, token) {
		if (token.tagID === TAG_ID.HTML) p.insertionMode = InsertionMode.AFTER_AFTER_FRAMESET;
	}
	function startTagAfterAfterBody(p, token) {
		if (token.tagID === TAG_ID.HTML) startTagInBody(p, token);
		else tokenAfterAfterBody(p, token);
	}
	function tokenAfterAfterBody(p, token) {
		p.insertionMode = InsertionMode.IN_BODY;
		modeInBody(p, token);
	}
	function startTagAfterAfterFrameset(p, token) {
		switch (token.tagID) {
			case TAG_ID.HTML:
				startTagInBody(p, token);
				break;
			case TAG_ID.NOFRAMES: startTagInHead(p, token);
		}
	}
	function nullCharacterInForeignContent(p, token) {
		token.chars = "�";
		p._insertCharacters(token);
	}
	function characterInForeignContent(p, token) {
		p._insertCharacters(token);
		p.framesetOk = false;
	}
	function popUntilHtmlOrIntegrationPoint(p) {
		while (p.treeAdapter.getNamespaceURI(p.openElements.current) !== NS.HTML && p.openElements.currentTagId !== void 0 && !p._isIntegrationPoint(p.openElements.currentTagId, p.openElements.current)) p.openElements.pop();
	}
	function startTagInForeignContent(p, token) {
		if (causesExit(token)) {
			popUntilHtmlOrIntegrationPoint(p);
			p._startTagOutsideForeignContent(token);
		} else {
			const current = p._getAdjustedCurrentElement();
			const currentNs = p.treeAdapter.getNamespaceURI(current);
			if (currentNs === NS.MATHML) adjustTokenMathMLAttrs(token);
			else if (currentNs === NS.SVG) {
				adjustTokenSVGTagName(token);
				adjustTokenSVGAttrs(token);
			}
			adjustTokenXMLAttrs(token);
			if (token.selfClosing) p._appendElement(token, currentNs);
			else p._insertElement(token, currentNs);
			token.ackSelfClosing = true;
		}
	}
	function endTagInForeignContent(p, token) {
		if (token.tagID === TAG_ID.P || token.tagID === TAG_ID.BR) {
			popUntilHtmlOrIntegrationPoint(p);
			p._endTagOutsideForeignContent(token);
			return;
		}
		for (let i = p.openElements.stackTop; i > 0; i--) {
			const element = p.openElements.items[i];
			if (p.treeAdapter.getNamespaceURI(element) === NS.HTML) {
				p._endTagOutsideForeignContent(token);
				break;
			}
			const tagName = p.treeAdapter.getTagName(element);
			if (tagName.toLowerCase() === token.tagName) {
				token.tagName = tagName;
				p.openElements.shortenToLength(i);
				break;
			}
		}
	}
	TAG_NAMES.AREA, TAG_NAMES.BASE, TAG_NAMES.BASEFONT, TAG_NAMES.BGSOUND, TAG_NAMES.BR, TAG_NAMES.COL, TAG_NAMES.EMBED, TAG_NAMES.FRAME, TAG_NAMES.HR, TAG_NAMES.IMG, TAG_NAMES.INPUT, TAG_NAMES.KEYGEN, TAG_NAMES.LINK, TAG_NAMES.META, TAG_NAMES.PARAM, TAG_NAMES.SOURCE, TAG_NAMES.TRACK, TAG_NAMES.WBR;
	function parse(html, options) {
		return Parser.parse(html, options);
	}
	function element(node) {
		return "tagName" in node;
	}
	function children(node) {
		return "childNodes" in node ? node.childNodes : [];
	}
	function attr(node, key) {
		return element(node) ? node.attrs.find((a) => a.name === key)?.value ?? "" : "";
	}
	function descendants(node, predicate) {
		return children(node).flatMap((child) => [...element(child) && predicate(child) ? [child] : [], ...descendants(child, predicate)]);
	}
	function byId(node, id) {
		return descendants(node, (child) => attr(child, "id") === id)[0];
	}
	function controlDisabled(node) {
		const disabled = (value) => value.attrs.some((a) => a.name === "disabled");
		if (disabled(node)) return true;
		let child = node;
		for (let parent = node.parentNode; parent; parent = "parentNode" in parent ? parent.parentNode : null) {
			if (element(parent) && disabled(parent)) {
				if (parent.tagName === "optgroup" && node.tagName === "option") return true;
				if (parent.tagName === "fieldset" && children(parent).find((n) => element(n) && n.tagName === "legend") !== child) return true;
			}
			child = parent;
		}
		return false;
	}
	function hasClass(node, name) {
		return attr(node, "class").split(/\s+/).includes(name);
	}
	function text(node) {
		if (!node) return "";
		if ("value" in node) return node.value;
		if (element(node) && ["script", "style"].includes(node.tagName)) return "";
		return children(node).map(text).join("");
	}
	function label(node) {
		return text(node).replace(/\s+/g, " ").trim();
	}
	function safeURL(raw, base) {
		if (!raw.trim()) return null;
		try {
			const url = new URL(raw, base);
			return ["http:", "https:"].includes(url.protocol) && !url.username && !url.password ? url.href : null;
		} catch {
			return null;
		}
	}
	var allowed = new Set("p div span br hr strong b em i u s del ins sub sup small blockquote pre code ul ol li dl dt dd table thead tbody tfoot tr th td caption h1 h2 h3 h4 h5 h6 details summary a img".split(" "));
	var discarded = new Set("script style link meta base noscript template svg math input button select textarea".split(" "));
	var interactive = new Set("iframe object embed video audio form".split(" "));
	function content$1(node, base) {
		return children(node).flatMap((child) => {
			if ("value" in child) return [{
				kind: "text",
				text: child.value
			}];
			if (!element(child) || discarded.has(child.tagName)) return [];
			if (attr(child, "id") === "hb_mask" && hasClass(child, "mask") && descendants(child, (node) => attr(node, "id") === "hb_env" && hasClass(node, "env")).length > 0) return [{
				kind: "unsupported",
				description: "Native red-packet interaction requires the native forum.",
				children: []
			}];
			const spoilerBody = (hasClass(child, "spoiler") || hasClass(child, "spoiler_wrap")) && descendants(child, (n) => hasClass(n, "spoilerbody") || hasClass(n, "spoiler_content"))[0];
			if (spoilerBody) {
				const control = descendants(child, (n) => hasClass(n, "spoilerbutton") || hasClass(n, "spoiler_btn") || hasClass(n, "spoilerheader") || hasClass(n, "spoiler_control"))[0];
				return [{
					kind: "element",
					tag: "details",
					attributes: {},
					children: [{
						kind: "element",
						tag: "summary",
						attributes: {},
						children: [{
							kind: "text",
							text: control ? attr(control, "value") || label(control) || "Show hidden content" : "Show hidden content"
						}]
					}, ...content$1(spoilerBody, base)]
				}];
			}
			if (child.attrs.some((attribute) => attribute.name === "hidden") || /(?:^|;)\s*display\s*:\s*none(?:\s*!important)?\s*(?:;|$)/i.test(attr(child, "style")) || /(?:^|;)\s*visibility\s*:\s*hidden(?:\s*!important)?\s*(?:;|$)/i.test(attr(child, "style"))) return [{
				kind: "unsupported",
				description: "Additional native content is hidden; view it in the native forum.",
				children: []
			}];
			if (child.tagName === "ignore_js_op") return content$1(child, base);
			if (interactive.has(child.tagName)) return [{
				kind: "unsupported",
				description: "Unsupported interactive content",
				children: content$1(child, base)
			}];
			if (!allowed.has(child.tagName)) return [{
				kind: "unsupported",
				description: `Unsupported formatting (${child.tagName})`,
				children: content$1(child, base)
			}];
			const attributes = {};
			if ([
				"locked",
				"showhide",
				"attach_nopermission"
			].some((name) => hasClass(child, name))) attributes.class = "permission-notice";
			if (hasClass(child, "quote")) attributes.class = "quote";
			if (hasClass(child, "blockcode")) attributes.class = "code-block";
			const align = attr(child, "align") || /(?:^|;)\s*text-align\s*:\s*(left|right|center|justify)\s*(?:;|$)/.exec(attr(child, "style"))?.[1];
			if (align && [
				"left",
				"right",
				"center",
				"justify"
			].includes(align)) attributes.style = `text-align:${align}`;
			if (child.tagName === "a") {
				const url = safeURL(attr(child, "href"), base);
				if (url) {
					attributes.href = url;
					attributes.rel = "noopener noreferrer";
				}
			}
			if (child.tagName === "img") {
				const url = safeURL([
					"data-src",
					"zoomfile",
					"file",
					"data-original",
					"src"
				].map((key) => attr(child, key)).find(Boolean) ?? "", base);
				if (!url || !/\.(?:png|jpe?g|gif|webp|avif|bmp)$/i.test(new URL(url).pathname)) return [{
					kind: "unsupported",
					description: "Image or attachment requires native viewing",
					children: []
				}];
				attributes.src = url;
				attributes.alt = attr(child, "alt");
				attributes.loading = "lazy";
				attributes.referrerpolicy = "no-referrer";
			}
			for (const key of ["colspan", "rowspan"]) if (/^[1-9]\d?$/.test(attr(child, key))) attributes[key] = attr(child, key);
			if ([
				"ltr",
				"rtl",
				"auto"
			].includes(attr(child, "dir"))) attributes.dir = attr(child, "dir");
			if (attr(child, "title")) attributes.title = attr(child, "title");
			return [{
				kind: "element",
				tag: child.tagName,
				attributes,
				children: content$1(child, base)
			}];
		});
	}
	function documentFrom(source) {
		return parse(source);
	}
	function attachmentURL(raw, base) {
		const safe = safeURL(raw, base);
		if (!safe) return null;
		const url = new URL(safe);
		return url.origin === new URL(base).origin && url.pathname === "/forum.php" && url.searchParams.get("mod") === "attachment" && [...url.searchParams.keys()].every((key) => [
			"mod",
			"aid",
			"nothumb",
			"noupdate"
		].includes(key) && url.searchParams.getAll(key).length === 1) && url.searchParams.getAll("aid").length === 1 && url.searchParams.get("aid") && !url.hash ? url.href : null;
	}
	function attachments(post, base) {
		const candidates = descendants(post, (node) => /^attach_[1-9]\d*$/.test(attr(node, "id"))).flatMap((area) => {
			const links = descendants(area, (node) => node.tagName === "a" && Boolean(attr(node, "href")));
			return links.length === 1 ? [{
				id: attr(area, "id").slice(7),
				anchor: links[0],
				scope: "parentNode" in area && area.parentNode ? area.parentNode : area
			}] : [];
		});
		for (const list of descendants(post, (node) => node.tagName === "dl" && hasClass(node, "tattl"))) {
			const names = descendants(list, (node) => node.tagName === "p" && hasClass(node, "attnm"));
			if (names.length !== 1) continue;
			const links = descendants(names[0], (node) => node.tagName === "a" && Boolean(attr(node, "href")));
			const anchor = links.length === 1 ? links[0] : void 0;
			if (!anchor || !/^aid[1-9]\d*$/.test(attr(anchor, "id"))) continue;
			candidates.push({
				id: attr(anchor, "id").slice(3),
				anchor,
				scope: list
			});
		}
		const unique = candidates.filter((candidate, index) => candidates.findIndex((item) => item.id === candidate.id && item.anchor === candidate.anchor) === index);
		return unique.flatMap(({ id, anchor, scope }) => {
			if (unique.filter((item) => item.id === id).length !== 1 || unique.some((item) => item.anchor === anchor && item.id !== id) || /^aid[1-9]\d*$/.test(attr(anchor, "id")) && attr(anchor, "id").slice(3) !== id) return [];
			const url = attachmentURL(attr(anchor, "href"), base);
			const name = label(anchor);
			if (!url || !name || attr(anchor, "onclick") || attr(anchor, "ping")) return [];
			return [{
				id,
				name,
				url,
				details: label(scope)
			}];
		});
	}
	var keys$1 = {
		notices: [
			"mod",
			"do",
			"view",
			"type",
			"isread",
			"page"
		],
		search: [
			"mod",
			"adv",
			"searchid",
			"page",
			"orderby",
			"ascdesc",
			"searchsubmit",
			"kw"
		],
		directory: ["mod", "gid"],
		board: [
			"mod",
			"fid",
			"page",
			"filter",
			"typeid",
			"orderby",
			"digest",
			"specialtype",
			"rewardtype",
			"dateline",
			"authorid"
		],
		thread: [
			"mod",
			"tid",
			"page",
			"authorid",
			"ordertype",
			"viewpid",
			"from",
			"_dsign",
			"highlight"
		],
		redirect: [
			"mod",
			"goto",
			"tid",
			"ptid",
			"pid",
			"fromuid"
		]
	};
	function routeFor$1(value) {
		try {
			const url = new URL(value), q = url.searchParams;
			if (url.protocol !== "https:" || url.username || url.password) return null;
			let kind = null;
			if ([
				"/",
				"/index.php",
				"/forum.php"
			].includes(url.pathname) && (!q.has("mod") || q.get("mod") === "index")) kind = "directory";
			if (url.pathname === "/forum.php") {
				if (q.get("mod") === "forumdisplay" && /^[1-9]\d*$/.test(q.get("fid") ?? "")) kind = "board";
				if (q.get("mod") === "viewthread" && /^[1-9]\d*$/.test(q.get("tid") ?? "")) kind = "thread";
				if (q.get("mod") === "redirect" && (q.get("goto") === "findpost" && /^[1-9]\d*$/.test(q.get("pid") ?? "") || q.get("goto") === "lastpost" && /^[1-9]\d*$/.test(q.get("tid") ?? ""))) kind = "redirect";
			}
			if (url.pathname === "/search.php" && q.get("mod") === "forum" && (!q.has("adv") || q.get("adv") === "yes") && (!q.has("searchsubmit") || q.has("searchid") && q.get("searchsubmit") === "yes") && (!q.has("searchid") || /^[1-9]\d*$/.test(q.get("searchid") ?? ""))) kind = "search";
			if (url.pathname === "/home.php" && q.get("mod") === "space" && q.get("do") === "notice" && ["view", "type"].every((key) => !q.has(key) || key === "type" && q.get(key) === "" || /^[a-zA-Z0-9_-]+$/.test(q.get(key))) && (!q.has("isread") || ["0", "1"].includes(q.get("isread")))) kind = "notices";
			if (!kind) return null;
			const allowed = [
				...keys$1[kind],
				"extra",
				"mobile",
				"tsdmapp"
			];
			for (const key of q.keys()) if (!allowed.includes(key) || q.getAll(key).length !== 1) return null;
			for (const key of [
				"gid",
				"fid",
				"tid",
				"pid",
				"ptid",
				"page",
				"authorid",
				"viewpid",
				"fromuid"
			]) if (q.has(key) && !/^[1-9]\d*$/.test(q.get(key) ?? "")) return null;
			if (q.has("mobile") && !["2", "no"].includes(q.get("mobile"))) return null;
			return {
				kind,
				url
			};
		} catch {
			return null;
		}
	}
	function threadURL(value) {
		const route = routeFor$1(value);
		return route?.kind === "thread" ? route.url : null;
	}
	function cleanURL(value) {
		const url = new URL(value);
		url.searchParams.delete("tsdmapp");
		return url.href;
	}
	function closest(node, predicate) {
		let current = node;
		while (current) {
			if ("tagName" in current && predicate(current)) return current;
			current = "parentNode" in current ? current.parentNode : null;
		}
		return null;
	}
	function link$1(node, base) {
		if (!node) return null;
		const url = safeURL(attr(node, "href"), base);
		return url && label(node) ? {
			url: cleanURL(url),
			label: label(node)
		} : null;
	}
	function links(doc, base, predicate) {
		const items = descendants(doc, (n) => n.tagName === "a" && predicate(n)).map((n) => link$1(n, base)).filter((n) => n !== null);
		return [...new Map(items.map((n) => [n.url, n])).values()];
	}
	function pagination(doc, base) {
		const root = descendants(doc, (n) => hasClass(n, "pg") || hasClass(n, "page"))[0];
		return {
			current: label(root && descendants(root, (n) => n.tagName === "strong")[0]) || new URL(base).searchParams.get("page") || "1",
			links: root ? links(root, base, (n) => Boolean(routeFor$1(safeURL(attr(n, "href"), base) ?? ""))) : []
		};
	}
	function boards(doc, base) {
		const items = descendants(doc, (n) => n.tagName === "a" && Boolean(closest(n, (p) => p.tagName === "h2" || p.tagName === "dt" || hasClass(p, "murl")))).map((n) => {
			const item = link$1(n, base), route = item && routeFor$1(item.url);
			if (!item || route?.kind !== "board" || route.url.origin !== new URL(base).origin) return null;
			const cell = hasClass(n, "murl") ? n : closest(n, (p) => ["td", "li"].includes(p.tagName)) ?? n;
			return {
				...item,
				label: label(descendants(n, (p) => hasClass(p, "mtit"))[0]) || item.label,
				id: route.url.searchParams.get("fid"),
				description: label(descendants(cell, (p) => hasClass(p, "xg2") || hasClass(p, "mtxt"))[0]),
				stats: label(descendants(cell, (p) => hasClass(p, "xg1") || hasClass(p, "mnum"))[0])
			};
		}).filter((n) => n !== null);
		return [...new Map(items.map((n) => [n.url, n])).values()];
	}
	function decodeBoard(response, requested) {
		const request = routeFor$1(requested), actual = routeFor$1(response.url);
		const fail = (kind, message) => ({
			kind,
			message,
			account: { kind: "unknown" },
			sourceURL: requested
		});
		if (!request || !actual || actual.url.origin !== request.url.origin || actual.kind !== request.kind || request.kind === "board" && actual.url.searchParams.get("fid") !== request.url.searchParams.get("fid") || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(response.contentType)) return fail("invalid", "The forum returned an unsupported response envelope.");
		let source = response.body;
		if (/json/i.test(response.contentType) || /^\s*\{/.test(source)) try {
			const payload = JSON.parse(source);
			if (!payload || typeof payload !== "object" || !("document" in payload) || typeof payload.document !== "string") throw Error();
			source = `${"head" in payload && typeof payload.head === "string" ? payload.head : ""}${payload.document}`;
		} catch {
			return fail("invalid", "The forum returned an invalid response.");
		}
		const doc = documentFrom(source), account = accountFrom(doc, response.url);
		const title = label(descendants(doc, (n) => n.tagName === "title")[0]);
		const message = label(byId(doc, "messagetext") ?? byId(doc, "main_message"));
		if (byId(doc, "challenge-form") || byId(doc, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证|驗證您的瀏覽器/i.test(title)) return {
			...fail("challenge", "Native verification is required. Your destination is preserved."),
			account
		};
		if (response.status === 404 || response.status === 410 || /不存在|已[被經经]*删除|已[被經经]*刪除|not found/i.test(message)) return {
			...fail("missing", "This board is missing or has been deleted."),
			account
		};
		if (response.status === 401 || /未登录|未登錄|先登录|先登錄|登录后|登入後/.test(message)) return {
			...fail("login", "Sign in through the native forum, then retry."),
			account
		};
		if (response.status === 403 || /权限|權限|用户组|用戶組|無權/.test(message)) return {
			...fail("permission", "The current account does not have permission to read this board."),
			account
		};
		if (response.status === 429) return {
			...fail("limited", "The forum is limiting requests. Retry explicitly later."),
			account
		};
		if (response.status < 200 || response.status >= 300 || message) return {
			...fail("invalid", response.status === 429 ? "The forum is limiting requests. Retry explicitly later." : "The forum response could not be displayed reliably."),
			account
		};
		const url = cleanURL(response.url), common = {
			account,
			sourceURL: url
		};
		if (actual.kind === "directory") {
			const groups = descendants(doc, (n) => /^category_\d+$/.test(attr(n, "id"))).map((n) => {
				const parent = closest(n, (p) => hasClass(p, "bm"));
				return {
					title: label(parent && descendants(parent, (p) => hasClass(p, "bm_h"))[0] || void 0) || "Boards",
					boards: boards(n, url)
				};
			});
			if (!groups.length) groups.push(...descendants(doc, (n) => hasClass(n, "sub-forum")).map((n) => ({
				title: label(closest(n, (p) => hasClass(p, "forumlist")) && descendants(closest(n, (p) => hasClass(p, "forumlist")), (p) => p.tagName === "h2")[0] || void 0) || "Forum boards",
				boards: boards(n, url)
			})));
			if (!groups.length) groups.push({
				title: "Forum boards",
				boards: boards(doc, url)
			});
			if (!groups.some((g) => g.boards.length)) return {
				...fail("invalid", "The board directory could not be interpreted."),
				account
			};
			return {
				...common,
				kind: "directory",
				directory: {
					groups: groups.filter((g) => g.boards.length),
					url,
					pages: pagination(doc, url)
				}
			};
		}
		const touchContainer = descendants(doc, (n) => hasClass(n, "threadlist_box"))[0];
		const touch = Boolean(touchContainer);
		const container = touchContainer ?? byId(doc, "threadlisttableid");
		if (byId(doc, "waterfall") && !container) return {
			...fail("invalid", "This picture-board representation cannot yet be interpreted completely. Continue in the native forum."),
			account
		};
		const subboards = descendants(doc, (n) => /^subforum_\d+$/.test(attr(n, "id"))).flatMap((n) => boards(n, url));
		const threads = (container ? descendants(container, (n) => touch ? n.tagName === "li" && (hasClass(n, "list") || hasClass(n, "list_top")) : /^(normal|stick)thread_[1-9]\d*$/.test(attr(n, "id"))) : []).map((row) => {
			const item = link$1(descendants(row, (n) => n.tagName === "a" && (touch ? attr(n, "href").includes("mod=viewthread") : hasClass(n, "xst")))[0], url), route = item && routeFor$1(item.url);
			if (!item || route?.kind !== "thread" || route.url.origin !== actual.url.origin) return null;
			const id = route.url.searchParams.get("tid"), rowId = touch ? id : attr(row, "id").split("_").at(-1);
			const moved = /(?:移动|移動)\s*[:：]/.test(label(row));
			if (rowId !== id && !moved) return null;
			const by = descendants(row, (n) => n.tagName === "td" && hasClass(n, "by")), num = descendants(row, (n) => hasClass(n, "num"))[0];
			return {
				...item,
				id,
				rowId,
				moved,
				pinned: touch ? hasClass(row, "list_top") : attr(row, "id").startsWith("stick"),
				category: label(descendants(row, (n) => n.tagName === "th").flatMap((n) => descendants(n, (p) => p.tagName === "em"))[0]),
				author: label(touch ? descendants(row, (n) => hasClass(n, "muser"))[0] : by[0] && descendants(by[0], (n) => n.tagName === "cite")[0]),
				date: label(touch ? descendants(row, (n) => hasClass(n, "mtime"))[0] : by[0] && descendants(by[0], (n) => n.tagName === "em")[0]),
				replies: label(touch ? descendants(row, (n) => hasClass(n, "mreply"))[0] : num && descendants(num, (n) => n.tagName === "a")[0]),
				views: label(num && descendants(num, (n) => n.tagName === "em")[0]),
				lastPost: link$1(by.at(-1) && descendants(by.at(-1), (n) => n.tagName === "em").flatMap((n) => descendants(n, (p) => p.tagName === "a"))[0], url)
			};
		});
		const empty = container ? label(descendants(container, (n) => hasClass(n, "emp"))[0]) : "";
		if (threads.some((n) => n === null) || !threads.length && !subboards.length && !/暂无|沒有|没有|無主題|no (?:threads|posts)/i.test(empty)) return {
			...fail("invalid", "The board contains unrecognized or incomplete thread rows. Continue in the native forum for complete content."),
			account
		};
		const filters = [
			"thread_types",
			"filter_special_menu",
			"filter_orderby_menu",
			"filter_dateline_menu",
			"dhnav",
			"dhnavs"
		].flatMap((id) => {
			const root = byId(doc, id);
			return root ? links(root, url, () => true).filter((item) => routeFor$1(item.url)?.kind === "board") : [];
		});
		const criterionNames = {
			typeid: "Category",
			orderby: "Sort",
			authorid: "Author",
			dateline: "Time",
			digest: "Digest",
			specialtype: "Thread type",
			rewardtype: "Reward",
			filter: "Filter"
		};
		const criteria = [...actual.url.searchParams].filter(([key]) => key in criterionNames && !(key === "filter" && [
			"typeid",
			"orderby",
			"digest",
			"specialtype"
		].some((name) => actual.url.searchParams.has(name)))).map(([key, value]) => {
			const matching = filters.filter((item) => new URL(item.url).searchParams.get(key) === value);
			const returned = (key === "orderby" ? matching.find((item) => !new URL(item.url).searchParams.has("typeid")) : matching[0]) ?? matching[0];
			return {
				label: `${criterionNames[key]}: ${returned?.label ?? value}`,
				url
			};
		});
		const heading = touch ? descendants(doc, (n) => hasClass(n, "header"))[0] : byId(doc, "ct"), titleNode = heading && descendants(heading, (n) => n.tagName === (touch ? "h2" : "h1"))[0];
		return {
			...common,
			kind: "board",
			board: {
				id: actual.url.searchParams.get("fid"),
				title: label(titleNode) || "Board threads",
				url,
				boards: subboards,
				threads: threads.filter((n) => n !== null),
				filters: [...new Map(filters.map((n) => [n.url, n])).values()],
				criteria,
				pages: pagination(doc, url),
				empty
			}
		};
	}
	var positive = (value) => value !== null && /^[1-9]\d*$/.test(value);
	function outsidePosts(node) {
		let current = node;
		while (current) {
			if (/^(?:postlist|post_[0-9]+|postmessage_[0-9]+)$/.test(attr(current, "id")) || hasClass(current, "pcb") || hasClass(current, "pcbs") || hasClass(current, "viewthread") || hasClass(current, "nts") || hasClass(current, "ntc_body")) return false;
			current = "parentNode" in current ? current.parentNode : null;
		}
		return true;
	}
	function readable$1(nodes) {
		return nodes.some((node) => node.kind === "text" ? Boolean(node.text.trim()) : node.kind === "unsupported" || node.tag === "img" || readable$1(node.children));
	}
	function accountFrom(doc, base) {
		const headers = descendants(doc, (n) => ["um", "inner_stat"].includes(attr(n, "id")) && outsidePosts(n));
		const header = headers.length === 1 ? headers[0] : void 0;
		const members = header ? descendants(header, (n) => n.tagName === "strong").flatMap((n) => descendants(n, (a) => a.tagName === "a")).map((n) => {
			const url = safeURL(attr(n, "href"), base);
			const id = url ? new URL(url).searchParams.get("uid") : null;
			return positive(id) ? {
				kind: "member",
				id,
				name: label(n)
			} : null;
		}).filter((n) => n !== null) : [];
		if (members.length === 1 && members[0]) return members[0];
		if (members.length === 0 && descendants(doc, (n) => n.tagName === "form" && (attr(n, "id") === "lsform" || attr(n, "id").startsWith("loginform")) && outsidePosts(n)).length) return { kind: "guest" };
		return { kind: "unknown" };
	}
	function decodeThread(response, requestedURL) {
		const requestedOrigin = threadURL(requestedURL)?.origin;
		let responseOrigin = null;
		try {
			responseOrigin = new URL(response.url).origin;
		} catch {}
		if (!requestedOrigin || responseOrigin !== requestedOrigin || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(response.contentType.trim())) return {
			kind: "invalid",
			message: "The forum returned an unsupported response envelope.",
			account: { kind: "unknown" },
			sourceURL: requestedURL
		};
		let source = response.body;
		let envelopeAccount = null;
		let envelopeThreadId = null;
		if (/json/i.test(response.contentType) || /^\s*\{/.test(source)) try {
			const payload = JSON.parse(source);
			if (!payload || typeof payload !== "object" || !("document" in payload) || typeof payload.document !== "string") throw new Error("No document");
			if ("uid" in payload && typeof payload.uid === "number" && Number.isSafeInteger(payload.uid) && payload.uid >= 0) envelopeAccount = payload.uid === 0 ? { kind: "guest" } : {
				kind: "member",
				id: String(payload.uid),
				name: `Member ${payload.uid}`
			};
			if ("thread" in payload && payload.thread && typeof payload.thread === "object" && "tid" in payload.thread && (typeof payload.thread.tid === "number" || typeof payload.thread.tid === "string")) envelopeThreadId = String(payload.thread.tid);
			source = `${"head" in payload && typeof payload.head === "string" ? payload.head : ""}${payload.document}`;
		} catch {
			return {
				kind: "invalid",
				message: "The forum returned an invalid response.",
				account: { kind: "unknown" },
				sourceURL: requestedURL
			};
		}
		const doc = documentFrom(source);
		const headerAccount = accountFrom(doc, response.url);
		const result = {
			account: envelopeAccount && headerAccount.kind !== "unknown" && (envelopeAccount.kind !== headerAccount.kind || envelopeAccount.kind === "member" && headerAccount.kind === "member" && envelopeAccount.id !== headerAccount.id) ? { kind: "unknown" } : headerAccount.kind !== "unknown" ? headerAccount : envelopeAccount ?? headerAccount,
			sourceURL: response.url
		};
		const fail = (kind, message) => ({
			...result,
			kind,
			message
		});
		const title = label(descendants(doc, (n) => n.tagName === "title")[0]);
		const message = label(byId(doc, "messagetext") ?? byId(doc, "main_message"));
		if (byId(doc, "challenge-form") || byId(doc, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证|驗證您的瀏覽器/i.test(title)) return fail("challenge", "Native verification is required. Your intended thread is preserved.");
		if (response.status === 404 || response.status === 410 || /不存在|已[被經经]*删除|已[被經经]*刪除|not found/i.test(message)) return fail("missing", "This thread is missing or has been deleted.");
		if (response.status === 401 || /未登录|未登錄|先登录|先登錄|登录后|登入後/.test(message) || descendants(doc, (n) => n.tagName === "form" && attr(n, "id").startsWith("loginform")).length) return fail("login", "Sign in through the native forum, then retry this thread.");
		if (response.status === 403 || /权限|權限|用户组|用戶組|無權/.test(message)) return fail("permission", "The current account does not have permission to read this thread.");
		if (response.status === 429) return fail("limited", "The forum is limiting requests. Retry explicitly later.");
		if (response.status < 200 || response.status >= 300 || message) return fail("invalid", "The forum response could not be displayed reliably.");
		const requested = threadURL(requestedURL), actual = threadURL(response.url);
		if (!requested || !actual || actual.origin !== requested.origin || actual.searchParams.get("tid") !== requested.searchParams.get("tid")) return fail("invalid", "The forum returned a different destination. Continue in the native forum.");
		if (envelopeThreadId !== null && envelopeThreadId !== requested.searchParams.get("tid")) return fail("invalid", "The returned thread identity did not match.");
		const touch = descendants(doc, (n) => hasClass(n, "viewthread")).length > 0;
		const containers = descendants(doc, (n) => touch ? hasClass(n, "viewthread") : attr(n, "id") === "postlist");
		const container = containers[0];
		if (!container || containers.length !== 1) return fail("invalid", "Unrecognized thread content. Continue in the native forum.");
		const canonical = descendants(doc, (n) => n.tagName === "link" && attr(n, "rel") === "canonical")[0];
		if (canonical) {
			const url = safeURL(attr(canonical, "href"), response.url);
			if (!url || new URL(url).origin !== requested.origin || threadURL(url)?.searchParams.get("tid") !== requested.searchParams.get("tid")) return fail("invalid", "The returned thread identity did not match.");
		}
		const heading = touch ? descendants(container, (n) => hasClass(n, "view_tit"))[0] : byId(container, "thread_subject");
		const wrappers = descendants(container, (n) => touch ? /^pid[1-9]\d*$/.test(attr(n, "id")) && hasClass(n, "plc") : /^post_[1-9]\d*$/.test(attr(n, "id")));
		if (!label(heading) || !wrappers.length) return fail("invalid", "This thread has unrecognized or incomplete content.");
		const ids = wrappers.map((n) => attr(n, "id").slice(touch ? 3 : 5));
		if (new Set(ids).size !== ids.length) return fail("invalid", "The returned post identities are ambiguous.");
		const posts = wrappers.map((wrapper) => {
			const id = attr(wrapper, "id").slice(touch ? 3 : 5);
			const body = descendants(wrapper, (n) => touch ? hasClass(n, "message") : hasClass(n, "pcb") || hasClass(n, "pcbs"))[0] ?? descendants(wrapper, (n) => /^postmessage_/.test(attr(n, "id")))[0];
			if (!body || !children(body).length) return null;
			const bodyContent = content$1(body, response.url);
			if (!readable$1(bodyContent)) return null;
			const authorArea = descendants(wrapper, (n) => hasClass(n, "authi"))[0];
			const author = authorArea ? descendants(authorArea, (n) => n.tagName === "a" && attr(n, "href").includes("uid="))[0] : void 0;
			const authorURL = author ? safeURL(attr(author, "href"), response.url) : null;
			return {
				id,
				attachments: attachments(wrapper, response.url),
				author: label(author) || "Anonymous",
				authorId: authorURL ? new URL(authorURL).searchParams.get("uid") : null,
				floor: label(touch ? descendants(wrapper, (n) => hasClass(n, "y"))[0] : byId(wrapper, `postnum${id}`)),
				date: label(touch ? descendants(wrapper, (n) => hasClass(n, "mtime"))[0] : byId(wrapper, `authorposton${id}`)),
				url: link$1(byId(wrapper, `postnum${id}`), response.url)?.url ?? `${cleanURL(response.url).split("#")[0]}#pid${id}`,
				content: [...bodyContent, ...descendants(wrapper, (n) => hasClass(n, "locked") || hasClass(n, "attach_nopermission") || hasClass(n, "modact")).filter((n) => {
					let p = n;
					while (p) {
						if (p === body) return false;
						p = "parentNode" in p ? p.parentNode : null;
					}
					return true;
				}).flatMap((n) => [{
					kind: "element",
					tag: "p",
					attributes: { class: "permission-notice" },
					children: [{
						kind: "text",
						text: label(n)
					}]
				}])]
			};
		});
		if (posts.some((post) => post === null)) return fail("invalid", "A post could not be interpreted. Continue in the native forum for complete content.");
		const pages = pagination(doc, response.url);
		let target = /^#pid([1-9]\d*)$/.exec(requested.hash)?.[1] ?? requested.searchParams.get("viewpid");
		if (requested.hash === "#lastpost") {
			const ordered = posts.filter((post) => post !== null);
			const floors = ordered.map((post) => /^\s*([1-9]\d*)/.exec(post.floor)?.[1]).map((value) => value ? Number(value) : NaN);
			const descending = actual.searchParams.get("ordertype") === "1";
			const page = Number(pages.current);
			const links = pages.links.map((item) => Number(new URL(item.url).searchParams.get("page") ?? "1"));
			const boundary = Number.isSafeInteger(page) && page > 0 && (descending ? page === 1 && !links.some((value) => value < page) : !links.some((value) => value > page));
			const orderedFloors = floors.every((value, index) => Number.isSafeInteger(value) && (index === 0 || (descending ? value < floors[index - 1] : value > floors[index - 1])));
			if (boundary && orderedFloors && !actual.searchParams.has("authorid")) target = (descending ? ordered[0] : ordered.at(-1)).id;
			else return {
				...result,
				kind: "document-navigation",
				message: "The last reply requires canonical forum resolution.",
				destination: `${requested.origin}/forum.php?mod=redirect&goto=lastpost&tid=${requested.searchParams.get("tid")}#lastpost`
			};
		}
		return {
			...result,
			kind: "thread",
			thread: {
				id: requested.searchParams.get("tid"),
				title: label(heading),
				url: cleanURL(response.url),
				posts: posts.filter((post) => post !== null),
				pages,
				filters: [...new Map(descendants(doc, (n) => n.tagName === "a" && /[?&](authorid|ordertype)=/.test(attr(n, "href"))).map((n) => link$1(n, response.url)).filter((n) => n !== null && routeFor$1(n.url)?.kind === "thread").map((n) => [n.url, n])).values()],
				parent: (byId(doc, "pt") ? descendants(byId(doc, "pt"), (n) => n.tagName === "a").map((n) => link$1(n, response.url)).filter((n) => n !== null && ["board", "directory"].includes(routeFor$1(n.url)?.kind ?? "")) : []).at(-1) ?? null,
				target,
				notices: descendants(doc, (n) => hasClass(n, "locked") && outsidePosts(n)).map(label)
			}
		};
	}
	function within(node, predicate) {
		let current = node;
		while (current && "tagName" in current) {
			if (predicate(current)) return true;
			current = current.parentNode;
		}
		return false;
	}
	function readable(nodes) {
		return nodes.some((node) => node.kind === "text" ? Boolean(node.text.trim()) : node.kind === "unsupported" || node.tag === "img" || readable(node.children));
	}
	function noticeContent(nodes) {
		return nodes.map((node) => {
			if (node.kind === "text") return node;
			const children = noticeContent([...node.children]);
			if (node.kind === "element" && [node.attributes.href, node.attributes.src].some((value) => value && [...new URL(value).searchParams.keys()].some((key) => key.toLowerCase() === "formhash"))) return {
				kind: "unsupported",
				description: "This action requires current native forum controls.",
				children
			};
			return {
				...node,
				children
			};
		});
	}
	function sameCategory(left, right) {
		return (left.searchParams.get("view") ?? "all") === (right.searchParams.get("view") ?? "all") && (left.searchParams.get("type") ?? "") === (right.searchParams.get("type") ?? "");
	}
	function decodeNotices(response, requested) {
		let account = { kind: "unknown" };
		const fail = (message, kind = "invalid") => ({
			kind,
			message,
			account,
			sourceURL: requested
		});
		const request = routeFor$1(requested), actual = routeFor$1(response.url);
		if (request?.kind !== "notices" || actual?.kind !== "notices" || request.url.origin !== actual.url.origin || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(response.contentType)) return fail("The forum returned an unsupported notice response. This request may still have marked notices read.");
		let source = response.body;
		let uid = null;
		if (/json/i.test(response.contentType) || /^\s*\{/.test(source)) try {
			const payload = JSON.parse(source);
			if (!payload || typeof payload !== "object" || !("document" in payload) || typeof payload.document !== "string") throw Error();
			if ("uid" in payload && typeof payload.uid === "number" && Number.isSafeInteger(payload.uid) && payload.uid >= 0) uid = payload.uid;
			source = `${"head" in payload && typeof payload.head === "string" ? payload.head : ""}${payload.document}`;
		} catch {
			return fail("The notice response could not be interpreted. This request may still have marked notices read.");
		}
		const doc = documentFrom(source);
		const header = accountFrom(doc, response.url);
		const envelope = uid === null ? { kind: "unknown" } : uid === 0 ? { kind: "guest" } : {
			kind: "member",
			id: String(uid),
			name: `Member ${uid}`
		};
		const actor = (value) => value.kind === "member" ? `member:${value.id}` : value.kind;
		account = header.kind === "unknown" ? envelope : envelope.kind !== "unknown" && actor(envelope) !== actor(header) ? { kind: "unknown" } : header;
		const message = label(byId(doc, "messagetext") ?? byId(doc, "main_message"));
		const title = label(descendants(doc, (node) => node.tagName === "title")[0]);
		if (byId(doc, "challenge-form") || byId(doc, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证|驗證您的瀏覽器/i.test(title)) return fail("Native verification is required. This request may still have marked notices read.", "challenge");
		if (response.status === 401 || account.kind === "guest" || /未登录|未登錄|先登录|先登錄|登录后|登入後/.test(message)) return fail("Sign in through the native forum before loading notices deliberately. This request may still have had read effects.", "login");
		if (response.status === 403 || /权限|權限|用户组|用戶組|無權/.test(message)) return fail("The current account cannot read these notices. This request may still have had read effects.", "permission");
		if (response.status === 429) return fail("The forum is limiting requests. Retry notices only deliberately; this request may still have had read effects.", "limited");
		if (response.status < 200 || response.status >= 300 || message) return fail("The notices could not be displayed reliably. This request may still have marked notices read.");
		if (account.kind !== "member") return fail("The current notice account could not be confirmed. This request may still have had read effects.");
		if (!sameCategory(request.url, actual.url) || (request.url.searchParams.get("page") ?? "1") !== (actual.url.searchParams.get("page") ?? "1") || request.url.searchParams.get("isread") !== actual.url.searchParams.get("isread")) return fail("The forum returned a different notice category or page. This request may still have had read effects.");
		const container = byId(doc, "ct");
		if (!container) return fail("The complete notice list could not be recognized. Continue in the native forum; this request may still have marked notices read.");
		const roots = descendants(container, (node) => hasClass(node, "nts"));
		const list = roots.length === 1 ? roots[0] : void 0;
		const entries = (list ? children(list).filter((node) => "tagName" in node && node.tagName === "dl") : []).map((row) => {
			const id = attr(row, "notice") || /^notice_([1-9]\d*)$/.exec(attr(row, "id"))?.[1] || "";
			const body = descendants(row, (node) => node.tagName === "dd" && hasClass(node, "ntc_body"));
			const dt = children(row).find((node) => "tagName" in node && node.tagName === "dt");
			const stamp = dt && descendants(dt, (node) => node.tagName === "span" && Boolean(attr(node, "title")))[0];
			const plain = dt && descendants(dt, (node) => node.tagName === "span")[0];
			const time = stamp && attr(stamp, "title") || label(plain);
			const bodyContent = body.length === 1 ? noticeContent(content$1(body[0], response.url)) : [];
			return /^[1-9]\d*$/.test(id) && time && readable(bodyContent) ? {
				id,
				time,
				body: bodyContent
			} : null;
		});
		if (entries.some((entry) => entry === null) || new Set(entries.map((entry) => entry?.id)).size !== entries.length) return fail("A notice has incomplete or ambiguous content. Continue in the native forum for the complete list; this request may still have marked notices read.");
		const empty = descendants(container, (node) => hasClass(node, "emp")).map(label).filter(Boolean).join(" ");
		if ((!list || !entries.length) && !empty) return fail("The complete notice list could not be recognized. Continue in the native forum; this request may still have marked notices read.");
		const categories = [...descendants(container, (node) => node.tagName === "a" && within(node, (parent) => hasClass(parent, "tbn") || hasClass(parent, "tb") || hasClass(parent, "subsub")) && !within(node, (parent) => hasClass(parent, "nts"))).flatMap((node) => {
			const value = safeURL(attr(node, "href"), response.url), route = value && routeFor$1(value);
			return route && route.kind === "notices" && route.url.origin === request.url.origin && label(node) ? [{
				url: cleanURL(route.url.href),
				label: label(node),
				current: within(node, (parent) => parent.tagName === "li" && hasClass(parent, "a"))
			}] : [];
		}).reduce((links, link) => {
			const previous = links.get(link.url);
			links.set(link.url, {
				...link,
				current: link.current || previous?.current === true
			});
			return links;
		}, new Map()).values()];
		if (!categories.length) return fail("The returned notice categories could not be recognized. Continue in the native forum for the complete inbox; this request may still have marked notices read.");
		const pages = {
			current: actual.url.searchParams.get("page") ?? "1",
			links: []
		};
		const pagerRoots = descendants(container, (node) => (hasClass(node, "pg") || hasClass(node, "page")) && !within(node, (parent) => hasClass(parent, "nts")));
		const offeredPages = pagerRoots.flatMap((root) => descendants(root, (node) => node.tagName === "a"));
		const pageRoutes = offeredPages.map((node) => {
			const href = safeURL(attr(node, "href"), response.url);
			return href ? routeFor$1(href) : null;
		});
		const readFilter = actual.url.searchParams.get("isread") ?? pageRoutes[0]?.url.searchParams.get("isread") ?? null;
		if (pageRoutes.some((route) => {
			return !route || route.kind !== "notices" || route.url.origin !== request.url.origin || !sameCategory(route.url, actual.url) || route.url.searchParams.get("isread") !== readFilter;
		})) return fail("The returned notice pagination could not be preserved completely. Continue in the native forum; this request may still have marked notices read.");
		if (pagerRoots.length) {
			const currentPages = pagerRoots.map((root) => label(descendants(root, (node) => node.tagName === "strong")[0]) || pages.current);
			if (new Set(currentPages).size !== 1) return fail("The returned notice pagination could not be preserved completely. Continue in the native forum; this request may still have marked notices read.");
			pages.current = currentPages[0];
			pages.links = [...new Map(offeredPages.map((node) => {
				const href = cleanURL(safeURL(attr(node, "href"), response.url));
				return [href, {
					url: href,
					label: label(node)
				}];
			})).values()];
		} else pages.links = [];
		const indicators = descendants(doc, (node) => attr(node, "id") === "myprompt" && !within(node, (parent) => hasClass(parent, "nts")));
		const count = indicators.length === 1 ? /[（(]\s*(\d+)\s*[）)]\s*$/.exec(label(indicators[0]))?.[1] : void 0;
		const unread = !indicators.length ? { kind: "absent" } : count !== void 0 && Number.isSafeInteger(Number(count)) ? {
			kind: "observed",
			count: Number(count)
		} : { kind: "unknown" };
		return {
			kind: "notices",
			account,
			sourceURL: cleanURL(response.url),
			notices: {
				url: cleanURL(response.url),
				categories,
				entries: entries.filter((entry) => entry !== null),
				pages,
				empty: entries.length ? "" : empty,
				unread
			}
		};
	}
	var namedLabels = {
		srchtxt: "Keywords",
		srchuname: "Author",
		srchfrom: "Time range",
		before: "Time relation",
		orderby: "Order",
		ascdesc: "Direction",
		"srchfid[]": "Boards",
		srchfilter: "Search scope",
		"special[]": "Thread types",
		seltableid: "Search index"
	};
	var has$2 = (node, name) => node.attrs.some((a) => a.name === name);
	function disabled(node) {
		if (has$2(node, "disabled")) return true;
		let parent = node.parentNode;
		while (parent && "tagName" in parent) {
			if (["fieldset", "optgroup"].includes(parent.tagName) && has$2(parent, "disabled")) return true;
			parent = parent.parentNode;
		}
		return false;
	}
	var selected = (node) => has$2(node, "selected") || has$2(node, "checked");
	function hidden(node) {
		let current = node;
		while (current && "tagName" in current) {
			if (has$2(current, "hidden") || /(?:^|;)\s*display\s*:\s*none\s*(?:;|$)/i.test(attr(current, "style"))) return true;
			current = current.parentNode;
		}
		return false;
	}
	function fieldLabel(node, doc) {
		const linked = descendants(doc, (n) => n.tagName === "label" && attr(n, "for") === attr(node, "id") && Boolean(attr(node, "id")))[0];
		return {
			label: linked ? label(linked) : namedLabels[attr(node, "name")] ?? attr(node, "name"),
			labelFromForum: Boolean(linked)
		};
	}
	function failure(requested, message, account = { kind: "unknown" }, nativeText) {
		return {
			kind: "invalid",
			message,
			account,
			sourceURL: requested,
			...nativeText !== void 0 ? { nativeText } : {}
		};
	}
	function nativeSearchAccount(doc, base) {
		const head = descendants(doc, (node) => node.tagName === "head")[0];
		if (!head) return null;
		const bootstraps = children(head).filter((node) => "tagName" in node && node.tagName === "script" && !has$2(node, "src")).map((node) => children(node).map((child) => "value" in child ? child.value : "").join("")).filter((source) => /^\s*var\s+STYLEID\s*=/.test(source));
		if (!bootstraps.length) return null;
		const unknown = { kind: "unknown" };
		if (bootstraps.length !== 1) return unknown;
		const source = bootstraps[0].replace(/^\s*var\s+/, "");
		const literal = /\s*([A-Za-z_$][\w$]*)\s*=\s*(?:'([^'\\\r\n]*)'|"([^"\\\r\n]*)")\s*([,;])/gy;
		const fields = new Map();
		let end;
		while (true) {
			const match = literal.exec(source);
			if (!match || fields.has(match[1])) return unknown;
			fields.set(match[1], match[2] ?? match[3]);
			end = literal.lastIndex;
			if (match[4] === ";") break;
		}
		if (source.slice(end).trim() || [...fields.keys()].slice(0, 6).join(",") !== "STYLEID,STATICURL,IMGDIR,VERHASH,charset,discuz_uid") return unknown;
		const uid = fields.get("discuz_uid") ?? "";
		if (!/^(?:0|[1-9]\d*)$/.test(uid) || !Number.isSafeInteger(Number(uid)) || fields.get("SITEURL") !== `${new URL(base).origin}/`) return unknown;
		return uid === "0" ? { kind: "guest" } : {
			kind: "member",
			id: uid,
			name: `Member ${uid}`
		};
	}
	function responseDocument(response, requested) {
		try {
			if (new URL(response.url).origin !== new URL(requested).origin || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(response.contentType)) return null;
			let source = response.body;
			let envelopeAccount = null;
			if (/json/i.test(response.contentType) || /^\s*\{/.test(source)) {
				const payload = JSON.parse(source);
				if (!payload || typeof payload !== "object" || !("document" in payload) || typeof payload.document !== "string") return null;
				if ("uid" in payload && typeof payload.uid === "number" && Number.isSafeInteger(payload.uid) && payload.uid >= 0) envelopeAccount = payload.uid === 0 ? { kind: "guest" } : {
					kind: "member",
					id: String(payload.uid),
					name: `Member ${payload.uid}`
				};
				source = `${"head" in payload && typeof payload.head === "string" ? payload.head : ""}${payload.document}`;
			}
			const doc = documentFrom(source);
			const headerAccount = accountFrom(doc, response.url);
			const nativeAccount = nativeSearchAccount(doc, response.url);
			const observed = [
				headerAccount,
				envelopeAccount,
				nativeAccount
			].filter((value) => value !== null && value.kind !== "unknown");
			const preferred = observed[0] ?? { kind: "unknown" };
			return {
				doc,
				account: nativeAccount?.kind === "unknown" || observed.some((value) => value.kind !== preferred.kind || value.kind === "member" && preferred.kind === "member" && value.id !== preferred.id) ? { kind: "unknown" } : preferred
			};
		} catch {
			return null;
		}
	}
	function searchFailure(doc, response, requested, account) {
		const message = label(byId(doc, "messagetext") ?? byId(doc, "main_message"));
		const title = label(descendants(doc, (n) => n.tagName === "title")[0]);
		const fail = (kind, explanation, nativeText) => ({
			kind,
			message: explanation,
			account,
			sourceURL: requested,
			...nativeText !== void 0 ? { nativeText } : {}
		});
		if (byId(doc, "challenge-form") || byId(doc, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证|驗證您的瀏覽器/i.test(title)) return fail("challenge", "Native verification is required before another deliberate search.");
		if (response.status === 401 || account.kind === "guest" || /未登录|未登錄|先登录|先登錄|登录后|登入後/.test(message)) return fail("login", "Sign in through the native forum before another deliberate search.");
		if (/过期|過期|失效|expired/i.test(message)) return fail("expired", "Search results expired. Your criteria are retained; rerun explicitly if you accept possible credits or quota use.");
		if (/积分|積分|金币|金幣|天使币|天使幣|花费|花費|credits?|cost/i.test(message)) return fail("cost", `Search cost restriction: ${message}`, message);
		if (response.status === 429 || /秒内|秒內|频繁|頻繁|间隔|間隔|稍后|稍後|throttl|frequency|rate limit/i.test(message)) return fail("throttle", `Search frequency restriction: ${message || "The forum is limiting requests. Retry explicitly later."}`, message || null);
		if (response.status === 403 || /权限|權限|用户组|用戶組|無權/.test(message)) return fail("permission", `Search permission denied: ${message || "The current account cannot search."}`, message || null);
		if (response.status < 200 || response.status >= 300 || message) return fail("invalid", `The search response could not be interpreted: ${message || "Unexpected HTTP response."}`, message || null);
		return null;
	}
	function formFrom(doc, requested) {
		const forms = descendants(doc, (n) => n.tagName === "form" && descendants(n, (c) => attr(c, "name") === "srchuname").length > 0);
		if (forms.length !== 1) return null;
		const form = forms[0];
		const action = safeURL(attr(form, "action"), requested);
		if (!action || new URL(action).origin !== new URL(requested).origin || new URL(action).pathname !== "/search.php" || new URL(action).searchParams.get("mod") !== "forum" || attr(form, "method").toLowerCase() !== "post" || [...new URL(action).searchParams].some(([name, value]) => name !== "mod" || value !== "forum") || attr(form, "enctype") !== "" && attr(form, "enctype").toLowerCase() !== "application/x-www-form-urlencoded") return null;
		const activeControls = descendants(form, (n) => [
			"input",
			"select",
			"textarea",
			"button"
		].includes(n.tagName)).filter((node) => !disabled(node));
		for (const name of ["formhash", "searchsubmit"]) {
			const values = activeControls.filter((node) => attr(node, "name") === name);
			if (values.length !== 1 || attr(values[0], "type") !== "hidden" || !attr(values[0], "value") || name === "searchsubmit" && attr(values[0], "value") !== "yes") return null;
		}
		const seen = new Map();
		for (const node of activeControls) {
			if ([
				"formaction",
				"formmethod",
				"formenctype"
			].some((name) => has$2(node, name))) return null;
			const name = attr(node, "name"), type = attr(node, "type") || "text";
			if (!name || node.tagName === "button" || ["submit", "button"].includes(type)) continue;
			if (node.tagName === "textarea" || node.tagName === "input" && ![
				"text",
				"hidden",
				"radio",
				"checkbox"
			].includes(type)) return null;
			const shape = node.tagName === "select" ? "select" : type;
			const previous = seen.get(name);
			if (previous && (!["radio", "checkbox"].includes(shape) || previous !== shape)) return null;
			seen.set(name, shape);
		}
		const fields = [];
		for (const node of descendants(form, (n) => [
			"input",
			"select",
			"textarea"
		].includes(n.tagName))) {
			const name = attr(node, "name"), type = attr(node, "type") || "text";
			if (!name || ["submit", "button"].includes(type)) continue;
			if (type === "hidden" && [
				"formhash",
				"searchsubmit",
				"seltableid"
			].includes(name)) continue;
			if (name === "seltableid" && hidden(node)) continue;
			if (!Object.hasOwn(namedLabels, name) && !disabled(node)) return null;
			if (disabled(node) && fields.some((field) => field.name === name && !field.disabled)) continue;
			const choices = ["checkbox", "radio"].includes(type), existing = choices && fields.find((field) => field.name === name);
			const choice = {
				value: attr(node, "value"),
				label: label(node.parentNode ?? node) || attr(node, "value"),
				disabled: disabled(node)
			};
			if (existing) {
				existing.options.push(choice);
				if (selected(node) && !disabled(node)) existing.values.push(attr(node, "value"));
				continue;
			}
			const options = node.tagName === "select" ? descendants(node, (n) => n.tagName === "option").map((option) => ({
				value: has$2(option, "value") ? attr(option, "value") : label(option),
				label: label(option),
				disabled: disabled(option),
				selected: selected(option)
			})) : [];
			const values = node.tagName === "select" ? options.filter((o) => o.selected && !o.disabled).map((o) => o.value) : choices ? selected(node) && !disabled(node) ? [attr(node, "value")] : [] : [attr(node, "value")];
			const multiple = type === "checkbox" || has$2(node, "multiple");
			if (node.tagName === "select" && !multiple && !values.length) {
				const first = options.find((o) => !o.disabled);
				if (first) values.push(first.value);
			}
			fields.push({
				name,
				...fieldLabel(node, doc),
				kind: node.tagName === "select" ? "select" : choices ? "choices" : "text",
				multiple,
				disabled: disabled(node),
				readOnly: has$2(node, "readonly"),
				maxLength: /^\d+$/.test(attr(node, "maxlength")) ? Number(attr(node, "maxlength")) : null,
				options: choices ? [choice] : options.map(({ value, label, disabled }) => ({
					value,
					label,
					disabled
				})),
				values
			});
		}
		const restrictions = descendants(form, (n) => hasClass(n, "search-restrictions") || hasClass(n, "xg1")).map(label).filter(Boolean);
		return {
			form: {
				url: cleanURL(requested),
				fields,
				restrictions
			},
			node: form
		};
	}
	function decodeSearchForm(response, requested) {
		const document = responseDocument(response, requested);
		if (!document) return failure(requested, "The search form response could not be displayed reliably.");
		const { doc, account } = document;
		const blocked = searchFailure(doc, response, requested, account);
		if (blocked) return blocked;
		const parsed = formFrom(doc, requested);
		if (!parsed) return failure(requested, "The current advanced search form is unavailable. Continue in the native forum.", account);
		return {
			kind: "search",
			account,
			sourceURL: cleanURL(requested),
			search: {
				form: parsed.form,
				edited: Object.fromEntries(parsed.form.fields.filter((f) => !f.disabled).map((f) => [f.name, f.values])),
				effective: null,
				submitted: null,
				results: null
			}
		};
	}
	function prepareSearchRequest(response, requested, criteria) {
		const decoded = decodeSearchForm(response, requested);
		if (decoded.kind !== "search") return decoded;
		const { doc } = responseDocument(response, requested), parsed = formFrom(doc, requested);
		const reject = (message, nativeText) => failure(requested, message, decoded.account, nativeText);
		if (!criteria.srchtxt?.[0]?.trim() && !criteria.srchuname?.[0]?.trim()) return reject("Enter keywords or an author before searching.");
		const active = parsed.form.fields.filter((f) => !f.disabled);
		if (Object.keys(criteria).some((name) => !active.some((f) => f.name === name)) || active.some((field) => !Object.hasOwn(criteria, field.name))) return reject("Search controls changed. Refresh the form and review your criteria.");
		for (const field of active) {
			const values = criteria[field.name] ?? field.values;
			if (field.readOnly && JSON.stringify(values) !== JSON.stringify(field.values) || !field.multiple && values.length > 1 || new Set(values).size !== values.length || (field.kind === "text" ? values.length !== 1 || field.maxLength !== null && values[0].length > field.maxLength : values.some((value) => !field.options.some((o) => !o.disabled && o.value === value)))) return reject(`The current ${field.label} restriction does not allow this value. Review your criteria.`, field.labelFromForum === false ? null : field.label);
		}
		const pairs = [];
		for (const node of descendants(parsed.node, (n) => ["input", "select"].includes(n.tagName))) {
			const name = attr(node, "name"), type = attr(node, "type") || "text";
			if (!name || disabled(node) || ["button", "submit"].includes(type)) continue;
			if (type === "hidden") {
				pairs.push([name, attr(node, "value")]);
				continue;
			}
			const values = name === "seltableid" && hidden(node) ? descendants(node, (n) => n.tagName === "option" && selected(n) && !disabled(n)).map((n) => attr(n, "value")) : criteria[name] ?? active.find((f) => f.name === name)?.values ?? [];
			if (node.tagName === "select") for (const option of descendants(node, (n) => n.tagName === "option")) {
				const value = has$2(option, "value") ? attr(option, "value") : label(option);
				if (!disabled(option) && values.includes(value)) pairs.push([name, value]);
			}
			else if (["checkbox", "radio"].includes(type)) {
				if (values.includes(attr(node, "value"))) pairs.push([name, attr(node, "value")]);
			} else pairs.push([name, values[0] ?? ""]);
		}
		const url = new URL(attr(parsed.node, "action"), requested);
		url.searchParams.set("tsdmapp", "json");
		return {
			kind: "prepared",
			form: parsed.form,
			account: decoded.account,
			url: url.href,
			body: new URLSearchParams(pairs).toString()
		};
	}
	function decodeSearchResults(response, requested, form, criteria) {
		const document = responseDocument(response, requested);
		if (!document) return failure(requested, "The search result could not be displayed reliably. The request may still have used credits or quota.");
		const { doc, account } = document;
		const blocked = searchFailure(doc, response, requested, account);
		if (blocked) return blocked;
		const reject = (message) => failure(requested, message, account);
		const canonical = [response.url, ...descendants(doc, (n) => n.tagName === "a").map((n) => safeURL(attr(n, "href"), response.url)).filter((u) => u !== null)].map((u) => routeFor$1(u)).filter((r) => r?.kind === "search" && r.url.origin === new URL(requested).origin && r.url.searchParams.has("searchid"))[0];
		if (!canonical) return reject("The forum did not return a usable search identity. It will not be searched again automatically.");
		const id = canonical.url.searchParams.get("searchid"), container = byId(doc, "threadlist");
		const nodes = container ? descendants(container, (n) => n.tagName === "li") : [];
		const rows = nodes.map((node) => {
			const heading = descendants(node, (n) => n.tagName === "h3")[0];
			const subject = heading && descendants(heading, (n) => n.tagName === "a")[0];
			const raw = subject && safeURL(attr(subject, "href"), response.url), route = raw && routeFor$1(raw);
			const links = descendants(node, (n) => n.tagName === "a");
			const author = links.find((n) => {
				const u = safeURL(attr(n, "href"), response.url);
				return u && new URL(u).pathname === "/home.php" && new URL(u).searchParams.get("mod") === "space" && /^[1-9]\d*$/.test(new URL(u).searchParams.get("uid") ?? "");
			});
			const board = links.find((n) => {
				const u = safeURL(attr(n, "href"), response.url);
				return u && routeFor$1(u)?.kind === "board";
			});
			const paragraphs = children(node).filter((n) => "tagName" in n && n.tagName === "p");
			if (!hasClass(node, "pbw") || !subject || !route || route.kind !== "thread" || route.url.origin !== new URL(requested).origin || !author || !board || !label(subject)) return null;
			const metadata = paragraphs.at(-1), date = metadata && descendants(metadata, (n) => n.tagName === "span")[0];
			return {
				id: route.url.searchParams.get("tid"),
				url: route.url.href,
				label: label(subject),
				author: {
					label: label(author),
					url: safeURL(attr(author, "href"), response.url)
				},
				board: {
					label: label(board),
					url: safeURL(attr(board, "href"), response.url)
				},
				date: label(date),
				snippet: label(paragraphs[1]),
				stats: label(paragraphs[0])
			};
		});
		const heading = descendants(doc, (n) => hasClass(n, "sttl"))[0], summary = label(heading && descendants(heading, (n) => n.tagName === "em")[0]);
		const empty = descendants(doc, (n) => hasClass(n, "emp")).map(label).some((value) => /没有找到匹配结果|沒有找到匹配結果|no (?:matching|results)/i.test(value));
		const zero = /(?:内容|內容|主题|主題)\s*0\s*个|0\s+(?:results|matches)/i.test(summary) && empty && nodes.length === 0;
		if (!rows.length && !zero || rows.some((r) => !r)) return reject("The search contains unrecognized or incomplete results. It has not been treated as zero matches.");
		const pager = descendants(doc, (n) => hasClass(n, "pg"))[0];
		const pageLinks = pager ? descendants(pager, (n) => n.tagName === "a").map((n) => ({
			label: label(n),
			url: safeURL(attr(n, "href"), response.url) ?? ""
		})) : [];
		if (pageLinks.some((link) => {
			const r = routeFor$1(link.url);
			return r?.kind !== "search" || r.url.origin !== new URL(requested).origin || r.url.searchParams.get("searchid") !== id;
		})) return reject("The search contains an unsupported result-page link.");
		const effective = { ...criteria };
		for (const name of ["orderby", "ascdesc"]) {
			const value = canonical.url.searchParams.get(name);
			if (value !== null) effective[name] = [value];
		}
		const url = cleanURL(response.url).includes("searchid=") ? cleanURL(response.url) : canonical.url.href;
		return {
			kind: "search",
			account,
			sourceURL: url,
			search: {
				form,
				edited: criteria,
				effective,
				submitted: criteria,
				results: {
					id,
					url,
					summary,
					rows: rows.filter((r) => r !== null),
					pages: {
						current: label(pager && descendants(pager, (n) => n.tagName === "strong")[0]) || "1",
						links: pageLinks
					}
				}
			}
		};
	}
	var optionLabels = {
		usesig: "Signature",
		parseurloff: "Disable URL recognition",
		smileyoff: "Disable emoticons",
		bbcodeoff: "Disable BBCode",
		htmlon: "HTML",
		imgcontent: "Render content as image",
		price: "Thread price",
		readperm: "Read permission",
		hiddenreplies: "Replies visible only to author",
		ordertype: "Reverse reply order",
		allownoticeauthor: "Receive reply notifications",
		addfeed: "Publish activity",
		adddynamic: "Share with followers",
		adddynamic_doing: "Ask followers to share",
		tags: "Tags"
	};
	var has$1 = (node, name) => node.attrs.some((a) => a.name === name);
	function controlLabel(doc, node, fallback) {
		const attached = descendants(doc, (n) => n.tagName === "label" && attr(n, "for") === attr(node, "id") && Boolean(attr(node, "id")))[0];
		const parent = node.parentNode;
		const owner = attached ?? (parent && "tagName" in parent && parent.tagName === "label" ? parent : void 0);
		return (owner ? children(owner).filter((n) => !("tagName" in n) || ![
			"input",
			"select",
			"textarea"
		].includes(n.tagName)).map(text).join("").trim() : "") || fallback;
	}
	function decodeWriting(response, requested, boardId, edit) {
		let account = { kind: "unknown" };
		const fail = (kind, message) => ({
			kind,
			message,
			account,
			sourceURL: requested
		});
		const actual = safeURL(response.url, requested);
		if (!actual || new URL(actual).origin !== new URL(requested).origin || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(response.contentType)) return fail("invalid", "The forum returned an unsupported preparation response.");
		let source = response.body;
		if (/json/i.test(response.contentType) || /^\s*\{/.test(source)) try {
			const payload = JSON.parse(source);
			if (!payload || typeof payload !== "object" || !("document" in payload) || typeof payload.document !== "string") throw Error();
			source = ("head" in payload && typeof payload.head === "string" ? payload.head : "") + payload.document;
		} catch {
			return fail("invalid", "The forum returned invalid preparation data.");
		}
		const doc = documentFrom(source);
		account = accountFrom(doc, actual);
		const message = label(byId(doc, "messagetext") ?? byId(doc, "main_message"));
		if (byId(doc, "challenge-form") || byId(doc, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证/i.test(label(descendants(doc, (n) => n.tagName === "title")[0]))) return fail("challenge", "Complete native verification, then prepare again.");
		if (response.status === 401 || account.kind === "guest" || /未登录|未登錄|先登录|先登錄/.test(message)) return fail("login", "Sign in through the native forum, then prepare again. A form token does not establish an account.");
		if (response.status === 403 || /权限|權限|用户组|用戶組|無權/.test(message)) return fail("permission", "The current account cannot prepare this new thread.");
		if (response.status === 429) return fail("limited", "The forum is limiting requests. Try again explicitly later.");
		if (response.status < 200 || response.status >= 300 || message || account.kind !== "member") return fail("invalid", "A current member account and complete native form are required.");
		const forms = descendants(doc, (n) => n.tagName === "form" && attr(n, "id") === "postform");
		const form = forms.length === 1 ? forms[0] : void 0;
		const action = form && safeURL(attr(form, "action"), actual);
		if (!form || !action || attr(form, "method").toLowerCase() !== "post") return fail("invalid", "The current native new-thread form is unavailable.");
		const target = new URL(action);
		if (target.origin !== new URL(requested).origin || target.pathname !== "/forum.php" || target.searchParams.get("mod") !== "post" || target.searchParams.get("action") !== (edit ? "edit" : "newthread") || !edit && target.searchParams.get("fid") !== boardId || edit && [
			"fid",
			"tid",
			"pid"
		].some((key) => {
			const expected = key === "fid" ? boardId : key === "tid" ? edit.threadId : edit.postId;
			const values = [...target.searchParams.getAll(key), ...descendants(form, (node) => attr(node, "name") === key).map((node) => attr(node, "value"))];
			return values.length !== 1 || values[0] !== expected;
		}) || [
			"mod",
			"action",
			...!edit ? ["fid"] : []
		].some((k) => target.searchParams.getAll(k).length !== 1) || target.searchParams.has("special") && target.searchParams.get("special") !== "0") return fail("invalid", "The returned form targets a different action or board.");
		const controls = descendants(form, (n) => [
			"input",
			"select",
			"textarea"
		].includes(n.tagName));
		const named = (name) => controls.filter((n) => attr(n, "name") === name);
		if (named("subject").length !== 1 || named("message").length !== 1 || named("message")[0]?.tagName !== "textarea" || [
			"subject",
			"message",
			"typeid",
			...Object.keys(optionLabels)
		].some((name) => named(name).length > 1)) return fail("invalid", "The native form does not provide unambiguous complete source and options.");
		function option(node, fallback) {
			const choices = node.tagName === "select" ? descendants(node, (n) => n.tagName === "option").map((n) => ({
				value: has$1(n, "value") ? attr(n, "value") : text(n),
				label: label(n) || "No category",
				disabled: controlDisabled(n)
			})) : [];
			const selected = node.tagName === "select" ? descendants(node, (n) => n.tagName === "option" && has$1(n, "selected"))[0] : void 0;
			return {
				name: attr(node, "name"),
				label: controlLabel(doc, node, fallback),
				kind: node.tagName === "select" ? "select" : attr(node, "type") === "checkbox" ? "checkbox" : "text",
				value: node.tagName === "select" ? selected ? has$1(selected, "value") ? attr(selected, "value") : text(selected) : choices[0]?.value ?? "" : attr(node, "value"),
				checked: has$1(node, "checked"),
				disabled: controlDisabled(node),
				choices,
				maxLength: /^\d+$/.test(attr(node, "maxlength")) ? Number(attr(node, "maxlength")) : null
			};
		}
		const options = controls.filter((n) => Object.hasOwn(optionLabels, attr(n, "name"))).map((n) => option(n, optionLabels[attr(n, "name")]));
		const category = named("typeid")[0];
		const board = descendants(byId(doc, "pt") ?? doc, (n) => n.tagName === "a").find((n) => {
			const value = safeURL(attr(n, "href"), actual);
			if (!value) return false;
			const u = new URL(value);
			return u.origin === target.origin && u.searchParams.get("mod") === "forumdisplay" && u.searchParams.get("fid") === boardId;
		});
		const references = [...new Set(controls.map((n) => /^attachnew\[([1-9]\d*)\]/.exec(attr(n, "name"))?.[1]).filter((id) => Boolean(id)))];
		return {
			kind: "prepared",
			account,
			sourceURL: requested,
			prepared: {
				action: "new-thread",
				board: {
					id: boardId,
					label: label(board) || `Board ${boardId}`,
					url: `${target.origin}/forum.php?mod=forumdisplay&fid=${boardId}`
				},
				account,
				title: attr(named("subject")[0], "value"),
				source: text(named("message")[0]),
				category: category ? option(category, "Category") : null,
				options,
				uploadedReferences: references
			}
		};
	}
	function unresolvedWritingAttachments(writing) {
		return [...new Set([...writing.source.matchAll(/\[attach(?:img)?\]\s*([1-9]\d*)\s*\[\/attach(?:img)?\]/gi)].map((match) => match[1]))].filter((id) => !writing.uploadedReferences.includes(id));
	}
	function postCallback(response) {
		if (response.status !== 200 || response.redirect === "followed" || !/^(?:text|application)\/xml(?:;|$)/i.test(response.contentType) || response.body.length > 262144 || /<!DOCTYPE|<!ENTITY/i.test(response.body)) return null;
		const envelope = /^\s*(?:<\?xml[^?]*\?>\s*)?<root>\s*<!\[CDATA\[([\s\S]*)\]\]>\s*<\/root>\s*$/.exec(response.body);
		if (!envelope || envelope[1].includes("]]>") || envelope[1].includes("<![CDATA[")) return null;
		const scripts = descendants(documentFrom(envelope[1]), (node) => node.tagName === "script");
		if (scripts.length !== 1 || scripts[0].attrs.some((a) => !["type", "reload"].includes(a.name)) || attr(scripts[0], "type") && attr(scripts[0], "type") !== "text/javascript") return null;
		const source = children(scripts[0]).map((node) => "value" in node ? node.value : "").join("");
		let offset = 0;
		const space = () => {
			while (/\s/.test(source[offset] ?? "") && offset < source.length) offset++;
		};
		const take = (literal) => {
			space();
			if (!source.startsWith(literal, offset)) throw Error();
			offset += literal.length;
		};
		const identifier = () => {
			space();
			const match = /^[A-Za-z_$][\w$]*/.exec(source.slice(offset));
			if (!match) throw Error();
			offset += match[0].length;
			return match[0];
		};
		const string = () => {
			space();
			const quote = source[offset++];
			if (quote !== "'" && quote !== "\"") throw Error();
			let value = "";
			while (offset < source.length) {
				const char = source[offset++];
				if (char === quote) return value;
				if (!char || /[\r\n\u2028\u2029]/.test(char)) throw Error();
				if (char !== "\\") {
					value += char;
					continue;
				}
				const escape = source[offset++];
				const simple = {
					n: "\n",
					r: "\r",
					t: "	",
					b: "\b",
					f: "\f",
					v: "\v",
					"\\": "\\",
					"'": "'",
					"\"": "\"",
					"/": "/"
				};
				if (escape && Object.hasOwn(simple, escape)) value += simple[escape];
				else if (escape === "x" || escape === "u") {
					const count = escape === "x" ? 2 : 4, hex = source.slice(offset, offset + count);
					if (hex.length !== count || !/^[0-9a-f]+$/i.test(hex)) throw Error();
					value += String.fromCharCode(Number.parseInt(hex, 16));
					offset += count;
				} else throw Error();
			}
			throw Error();
		};
		try {
			let guarded = "";
			space();
			if (source.startsWith("if", offset)) {
				take("if");
				take("(");
				if (identifier() !== "typeof") return null;
				guarded = identifier();
				space();
				take(source.startsWith("===", offset) ? "===" : "==");
				if (string() !== "function") return null;
				take(")");
				take("{");
			}
			const name = identifier();
			if (![
				"succeedhandle_post",
				"errorhandle_post",
				"succeedhandle_"
			].includes(name) || name === "succeedhandle_" && guarded !== name || guarded && guarded !== name) return null;
			const success = name !== "errorhandle_post";
			take("(");
			const values = [string()];
			take(",");
			if (success) {
				values.push(string());
				take(",");
			}
			take("{");
			const fields = Object.create(null);
			space();
			if (source[offset] !== "}") for (let count = 0;; count++) {
				if (count > 100) return null;
				const key = string();
				if (Object.hasOwn(fields, key)) return null;
				take(":");
				fields[key] = string();
				space();
				if (source[offset] !== ",") break;
				take(",");
			}
			take("}");
			take(")");
			space();
			if (source[offset] === ";") take(";");
			if (guarded) {
				take("}");
				space();
				if (source[offset] === ";") take(";");
			}
			space();
			return offset === source.length ? {
				success,
				values,
				fields
			} : null;
		} catch {
			return null;
		}
	}
	var options$1 = (writing) => [...writing.category ? [writing.category] : [], ...writing.options];
	function creationName(option) {
		if (option.kind !== "checkbox") return null;
		switch (option.name) {
			case "addfeed":
			case "adddynamic":
			case "adddynamic_doing": return option.name;
			default: return null;
		}
	}
	function creationEffects(writing) {
		return writing.options.flatMap((option) => {
			const name = creationName(option);
			if (!name) return [];
			return [option.checked ? {
				name,
				requested: true,
				included: !option.disabled,
				outcome: "unknown"
			} : {
				name,
				requested: false,
				included: false,
				outcome: "not-requested"
			}];
		});
	}
	function verifyStoredWriting(submitted, stored) {
		if (submitted.title !== stored.title || submitted.source !== stored.source) return null;
		const normalizations = [];
		for (const expected of options$1(submitted)) {
			if (creationName(expected)) continue;
			const actual = options$1(stored).find((option) => option.name === expected.name);
			if (!actual || actual.kind !== expected.kind || actual.checked !== expected.checked) return null;
			if (actual.value === expected.value) continue;
			if (expected.name === "price" && expected.kind === "text" && !expected.disabled && expected.value === "" && actual.value === "0") normalizations.push({
				name: "price",
				submitted: "",
				stored: "0"
			});
			else return null;
		}
		return {
			stored: "verified",
			normalizations,
			creationEffects: creationEffects(submitted)
		};
	}
	var record = (value) => !!value && typeof value === "object" && !Array.isArray(value);
	var keys = (value, names) => Object.keys(value).length === names.length && names.every((name) => Object.hasOwn(value, name));
	function isThreadVerification(value, submitted) {
		if (!record(value) || !keys(value, [
			"stored",
			"normalizations",
			"creationEffects"
		]) || value.stored !== "verified" || !Array.isArray(value.normalizations) || value.normalizations.length > 1 || !Array.isArray(value.creationEffects)) return false;
		if (!value.normalizations.every((entry) => record(entry) && keys(entry, [
			"name",
			"submitted",
			"stored"
		]) && entry.name === "price" && entry.submitted === "" && entry.stored === "0" && submitted.options.some((option) => option.name === "price" && option.kind === "text" && !option.disabled && option.value === ""))) return false;
		const expected = creationEffects(submitted);
		const entries = value.creationEffects;
		return value.creationEffects.length === expected.length && expected.every((effect, index) => {
			const actual = entries[index];
			return record(actual) && keys(actual, [
				"name",
				"requested",
				"included",
				"outcome"
			]) && actual.name === effect.name && actual.requested === effect.requested && actual.included === effect.included && actual.outcome === effect.outcome;
		});
	}
	var same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
	var member = (account) => account.kind === "member" ? account.id : null;
	var clone = (value) => JSON.parse(JSON.stringify(value));
	var has = (node, name) => node.attrs.some((a) => a.name === name);
	function document$1(response) {
		let source = response.body;
		if (/json/i.test(response.contentType) || /^\s*\{/.test(source)) {
			const value = JSON.parse(source);
			if (!value || typeof value !== "object" || !("document" in value) || typeof value.document !== "string") throw Error();
			source = ("head" in value && typeof value.head === "string" ? value.head : "") + value.document;
		}
		return documentFrom(source);
	}
	function options(writing) {
		return [...writing.category ? [writing.category] : [], ...writing.options];
	}
	function compatible(original, current) {
		return options(original).length === options(current).length && options(current).every((fresh) => {
			const previous = options(original).find((o) => o.name === fresh.name);
			if (!previous || previous.kind !== fresh.kind || previous.disabled !== fresh.disabled || !same(previous.choices, fresh.choices) || previous.maxLength !== fresh.maxLength) return false;
			if (fresh.disabled) return previous.value === fresh.value && previous.checked === fresh.checked;
			return fresh.kind !== "select" || fresh.choices.some((choice) => choice.value === previous.value && !choice.disabled);
		});
	}
	function successful(response, writing) {
		const doc = document$1(response), form = byId(doc, "postform");
		if (!form) return null;
		const target = safeURL(attr(form, "action"), response.url);
		if (!target) return null;
		const controls = descendants(form, (n) => [
			"input",
			"textarea",
			"select",
			"button"
		].includes(n.tagName));
		if (descendants(doc, (n) => attr(n, "form") === "postform").length || controls.some((n) => attr(n, "form"))) return null;
		const tokens = controls.filter((n) => attr(n, "name") === "formhash");
		if (tokens.length !== 1 || controlDisabled(tokens[0]) || !attr(tokens[0], "value") || controls.some((n) => ["subject", "message"].includes(attr(n, "name")) && controlDisabled(n))) return null;
		const pairs = [];
		const submitters = controls.filter((n) => attr(n, "name") === "topicsubmit" && !controlDisabled(n) && (n.tagName === "button" && ["", "submit"].includes(attr(n, "type")) || n.tagName === "input" && attr(n, "type") === "submit"));
		if (submitters.length > 1 || submitters.some((n) => !["yes", "true"].includes(attr(n, "value"))) || !submitters.length && new URL(target).searchParams.get("topicsubmit") !== "yes") return null;
		if (submitters.length) pairs.push(["topicsubmit", attr(submitters[0], "value")]);
		const inactiveRush = [
			"rushreplyfrom",
			"rushreplyto",
			"rewardfloor",
			"replylimit",
			"stopfloor",
			"creditlimit"
		];
		if (controls.some((node) => attr(node, "name") === "rushreply" && has(node, "checked")) || controls.some((node) => inactiveRush.includes(attr(node, "name")) && attr(node, "value") !== "")) return null;
		for (const node of controls) {
			const name = attr(node, "name"), type = attr(node, "type").toLowerCase();
			if (!name || controlDisabled(node) || node.tagName === "button" || [
				"submit",
				"button",
				"reset",
				"image"
			].includes(type)) continue;
			if (type === "file") {
				if (attr(node, "value")) return null;
				continue;
			}
			if (["special", "save"].includes(name) && !["", "0"].includes(attr(node, "value"))) return null;
			const supplied = options(writing).find((o) => o.name === name);
			if (["checkbox", "radio"].includes(type) && !(supplied ? supplied.checked : has(node, "checked"))) continue;
			const value = name === "subject" ? writing.title : name === "message" ? writing.source : supplied ? supplied.value : node.tagName === "textarea" ? text(node) : node.tagName === "select" ? attr(descendants(node, (n) => n.tagName === "option" && has(n, "selected"))[0] ?? descendants(node, (n) => n.tagName === "option")[0] ?? node, "value") : attr(node, "value");
			if (has(node, "required") && !value.trim() || /^\d+$/.test(attr(node, "maxlength")) && value.length > Number(attr(node, "maxlength"))) return null;
			if (!supplied && ![
				"subject",
				"message",
				"checkbox",
				"rushreply",
				...inactiveRush
			].includes(name) && !([
				"formhash",
				"posttime",
				"wysiwyg",
				"save"
			].includes(name) && type === "hidden")) return null;
			pairs.push([name, value]);
		}
		const url = new URL(target);
		url.searchParams.set("inajax", "1");
		url.searchParams.delete("tsdmapp");
		return {
			url: url.href,
			body: new URLSearchParams(pairs).toString()
		};
	}
	function candidate(value, origin) {
		const safe = safeURL(value, origin);
		if (!safe) return null;
		const url = new URL(safe);
		if (url.origin !== origin || url.pathname !== "/forum.php" || url.searchParams.get("mod") !== "viewthread" || !/^[1-9]\d*$/.test(url.searchParams.get("tid") ?? "") || [...url.searchParams.keys()].some((key) => ![
			"mod",
			"tid",
			"extra"
		].includes(key) || url.searchParams.getAll(key).length !== 1)) return null;
		url.hash = "";
		return url.href;
	}
	function outcome(response, origin) {
		const call = postCallback(response), source = call?.values.join(" ") ?? "";
		if (call?.success && /审核|審核|moderation/i.test(source)) return {
			kind: "moderation",
			message: "The forum reports pending moderation. Public stored source has not been confirmed."
		};
		if (call?.success) {
			const url = candidate(call.values[0], origin);
			if (url) return {
				kind: "candidate",
				url,
				message: "The response supplied a candidate. Checking independently…"
			};
		}
		if (call && !call.success && /subject_(?:empty|invalid|toolong)|message_(?:empty|toolong)|post_(?:flood|smilies|url|validation)|标题不能为空|標題不能為空|内容不能为空|內容不能為空|验证失败|驗證失敗/.test(source)) return {
			kind: "rejected",
			message: "The forum explicitly refused validation. Nothing is confirmed published."
		};
		return {
			kind: "unknown",
			message: "The publication outcome is uncertain. Check the original attempt before considering another send."
		};
	}
	function createThreadPublisher(config) {
		const forms = new Map();
		const reviews = new Map();
		const used = new Set(), pending = new Set();
		async function verify(attempt, destination) {
			const uncertain = (message) => attempt.status === "confirmed" && attempt.result ? {
				...attempt,
				checked: true,
				message: `Previous stored confirmation retained. This recheck did not verify the current result. ${message}`
			} : {
				...attempt,
				status: "uncertain",
				checked: true,
				message,
				result: null
			};
			const url = candidate(destination, config.origin), submitted = attempt.publication.submission, writing = submitted.writing;
			if (!url) return uncertain("No supported candidate thread URL is available. Enter its thread URL to check this original attempt.");
			const startGeneration = config.generation();
			try {
				const response = await config.transport.request(url, { fresh: true });
				if (config.generation() !== startGeneration) return uncertain("The account changed during result checking. Original writing and possible effects are retained.");
				const decoded = decodeThread(response, url);
				config.observe(decoded.account);
				if (member(decoded.account) !== writing.account.id) return uncertain("The account changed during result checking. Original writing and possible effects are retained.");
				if (decoded.kind !== "thread" || decoded.thread.posts.length < 1) return uncertain("The candidate thread could not be independently read. Publication remains uncertain.");
				const thread = decoded.thread, opening = thread.posts.filter((post) => /^1\s*#?$/.test(post.floor));
				if (opening.length !== 1 || opening[0] !== thread.posts[0] || opening[0].authorId !== writing.account.id || thread.title !== writing.title || !thread.parent || new URL(thread.parent.url).searchParams.get("fid") !== writing.board.id) return uncertain("Candidate actor, board, title or opening-post identity did not match the submitted revision.");
				const post = opening[0], editURL = new URL("/forum.php", config.origin);
				for (const [key, value] of Object.entries({
					mod: "post",
					action: "edit",
					fid: writing.board.id,
					tid: thread.id,
					pid: post.id,
					tsdmapp: "json"
				})) editURL.searchParams.set(key, value);
				const beforeSource = config.generation();
				const source = await config.transport.request(editURL.href, { fresh: true });
				if (config.generation() !== beforeSource) return uncertain("The account changed during stored-source readback. Possible publication remains uncertain.");
				const observed = decodeWriting(source, editURL.href, writing.board.id, {
					threadId: thread.id,
					postId: post.id
				});
				config.observe(observed.account);
				if (config.generation() !== beforeSource || member(observed.account) !== writing.account.id) return uncertain("The account changed during stored-source readback. Possible publication remains uncertain.");
				const verification = observed.kind === "prepared" ? verifyStoredWriting(writing, observed.prepared) : null;
				if (!verification) return uncertain("Complete stored source or offered options did not match, or were unavailable. No confirmation is claimed.");
				return {
					...attempt,
					status: "confirmed",
					checked: true,
					candidateURL: url,
					message: `Confirmed stored thread ${thread.id}, post ${post.id}, submitted revision ${submitted.revision}.`,
					result: {
						threadId: thread.id,
						postId: post.id,
						url: `${url}#pid${post.id}`,
						verification
					}
				};
			} catch {
				return uncertain("Independent stored-result readback failed. Publication remains uncertain; no send was repeated.");
			}
		}
		return {
			async prepare(submission) {
				const fail = (message, kind = "validation") => ({
					kind,
					message,
					account: config.account(),
					generation: config.generation()
				});
				if (!submission.contextId || !Number.isSafeInteger(submission.revision) || submission.revision < 1 || submission.writing.action !== "new-thread" || !/^[1-9]\d*$/.test(submission.writing.board.id) || !submission.writing.title.trim() || !submission.writing.source.trim() || /[\r\n]/.test(submission.writing.title)) return fail("A title, complete source and valid ordinary new-thread revision are required.");
				submission = clone(submission);
				const id = crypto.randomUUID();
				reviews.set(submission.contextId, id);
				for (const [key, form] of forms) if (form.publication.submission.contextId === submission.contextId) forms.delete(key);
				const writing = clone(submission.writing), url = new URL("/forum.php", config.origin);
				for (const [key, value] of Object.entries({
					mod: "post",
					action: "newthread",
					fid: writing.board.id,
					tsdmapp: "json"
				})) url.searchParams.set(key, value);
				const generation = config.generation();
				try {
					const response = await config.transport.request(url.href, { fresh: true });
					if (config.generation() !== generation || reviews.get(submission.contextId) !== id) return fail("The account changed or expired during preparation. Original writing remains paused.", "stale");
					const decoded = decodeWriting(response, url.href, writing.board.id);
					config.observe(decoded.account);
					if (member(decoded.account) !== writing.account.id) return fail("The account changed or expired during preparation. Original writing remains paused.", "stale");
					if (decoded.kind !== "prepared") return fail(decoded.message);
					if (!compatible(writing, decoded.prepared)) return fail("The current native options changed or are unavailable. Review the current form before publication; no values were reset.");
					const request = successful(response, writing);
					if (!request) return fail("The current native successful controls or required values are unsupported. Nothing was sent.");
					const publication = {
						id,
						generation: config.generation(),
						submission: clone(submission)
					};
					forms.set(publication.id, {
						publication: clone(publication),
						request
					});
					return {
						kind: "ready",
						publication,
						account: config.account(),
						generation: config.generation()
					};
				} catch {
					return fail("Fresh publication preparation failed. Your writing remains here.", "network");
				}
			},
			async publish(attempt) {
				attempt = clone(attempt);
				const known = forms.get(attempt.publication.id), contextId = attempt.publication.submission.contextId;
				const notSent = (message) => ({
					...attempt,
					status: "not-sent",
					message
				});
				if (!known || !same(known.publication, attempt.publication) || attempt.status !== "pending" || !attempt.id || used.has(attempt.id) || pending.has(contextId) || config.generation() !== known.publication.generation || member(config.account()) !== known.publication.submission.writing.account.id) return notSent("This preparation, account or attempt is stale or already active. Nothing was sent.");
				used.add(attempt.id);
				pending.add(contextId);
				forms.delete(attempt.publication.id);
				let sent = false;
				try {
					const writing = known.publication.submission.writing;
					const checkURL = new URL("/forum.php", config.origin);
					for (const [key, value] of Object.entries({
						mod: "post",
						action: "newthread",
						fid: writing.board.id,
						tsdmapp: "json"
					})) checkURL.searchParams.set(key, value);
					const current = await config.transport.request(checkURL.href, { fresh: true });
					if (config.generation() !== known.publication.generation) return notSent("The account changed or expired before send. Original writing remains retained and paused.");
					const checked = decodeWriting(current, checkURL.href, writing.board.id);
					config.observe(checked.account);
					if (config.generation() !== known.publication.generation || member(checked.account) !== writing.account.id) return notSent("The account changed or expired before send. Original writing remains retained and paused.");
					if (checked.kind !== "prepared" || !compatible(writing, checked.prepared)) return notSent("The current form changed before send. Nothing was sent; review again.");
					const request = successful(current, writing);
					if (!request) return notSent("The current successful controls changed before send. Nothing was sent.");
					sent = true;
					const response = await config.transport.request(request.url, {
						method: "POST",
						body: request.body,
						fresh: true
					});
					if (config.generation() !== known.publication.generation || member(config.account()) !== known.publication.submission.writing.account.id) return {
						...attempt,
						status: "uncertain",
						message: "The account changed while publication was in flight. It may have been accepted; no rollback or atomic account isolation is guaranteed."
					};
					const result = outcome(response, config.origin);
					if (result.kind === "candidate") return await verify({
						...attempt,
						candidateURL: result.url,
						status: "uncertain"
					}, result.url);
					return {
						...attempt,
						status: result.kind === "unknown" ? "uncertain" : result.kind,
						message: result.message
					};
				} catch {
					return sent ? {
						...attempt,
						status: "uncertain",
						message: "The response was lost. The forum may have accepted this attempt. Check result; no send was repeated."
					} : notSent("Fresh preflight failed before publication was sent. Your writing is retained; review again deliberately.");
				} finally {
					pending.delete(contextId);
				}
			},
			check: (attempt, url) => verify(clone(attempt), url || attempt.candidateURL || "")
		};
	}
	function describeDestination(value) {
		const route = routeFor$1(value);
		return route ? {
			kind: route.kind,
			url: route.url.href
		} : null;
	}
	var actor = (account) => account.kind === "member" ? `member:${account.id}` : account.kind;
	function createForumClient(options) {
		let account = { kind: "unknown" };
		let generation = 0;
		let sequence = 0;
		let downloadSequence = 0;
		const publisher = createThreadPublisher({
			...options,
			account: () => account,
			generation: () => generation,
			observe: (observed) => {
				if (actor(observed) !== actor(account)) {
					account = observed;
					generation++;
				}
			}
		});
		return {
			prepareThreadPublication: publisher.prepare,
			publishThread: publisher.publish,
			checkThreadResult: publisher.check,
			async readNotices(destination, prior, expectedAccount) {
				const current = ++sequence;
				const route = routeFor$1(destination);
				const fail = (message, kind = "invalid") => ({
					kind,
					message,
					account,
					generation,
					sourceURL: destination
				});
				if (route?.kind !== "notices" || route.url.origin !== options.origin) return fail("This is not a supported notice destination.");
				if (prior && ![
					prior.url,
					...prior.categories.map((link) => link.url),
					...prior.pages.links.map((link) => link.url)
				].includes(destination)) return fail("This category or page was not offered by the current notice list.");
				route.url.searchParams.set("tsdmapp", "json");
				try {
					const response = await options.transport.request(route.url.href, { fresh: true });
					if (current !== sequence) return fail("A newer request replaced this notice load. It may still have marked notices read.", "stale");
					const decoded = decodeNotices(response, destination);
					if (actor(decoded.account) !== actor(account)) {
						account = decoded.account;
						generation++;
					}
					if (decoded.kind === "notices" && expectedAccount && actor(decoded.account) !== actor(expectedAccount)) return fail("The account changed while loading notices. Previous notices were cleared. This request may still have had read effects.");
					return {
						...decoded,
						generation
					};
				} catch {
					return fail("The notice request failed. It may still have marked notices read. Retry only deliberately.", current !== sequence ? "stale" : "network");
				}
			},
			async prepareNewThread(boardId) {
				const current = ++sequence;
				const url = new URL("/forum.php", options.origin);
				url.searchParams.set("mod", "post");
				url.searchParams.set("action", "newthread");
				url.searchParams.set("fid", boardId);
				url.searchParams.set("tsdmapp", "json");
				if (!/^[1-9]\d*$/.test(boardId)) return {
					kind: "invalid",
					message: "A valid board is required.",
					account,
					generation,
					sourceURL: url.href
				};
				try {
					const response = await options.transport.request(url.href);
					if (current !== sequence) return {
						kind: "stale",
						message: "A newer account request replaced this preparation.",
						account,
						generation,
						sourceURL: url.href
					};
					const result = decodeWriting(response, url.href, boardId);
					if (JSON.stringify(result.account) !== JSON.stringify(account)) {
						account = result.account;
						generation++;
					}
					return {
						...result,
						generation
					};
				} catch {
					return {
						kind: current !== sequence ? "stale" : "network",
						message: "The form could not be reached. Your writing is retained.",
						account,
						generation,
						sourceURL: url.href
					};
				}
			},
			get account() {
				return account;
			},
			get generation() {
				return generation;
			},
			cancelDownload() {
				downloadSequence++;
			},
			async downloadAttachment(request) {
				const attempt = ++downloadSequence;
				const stale = () => ({
					kind: "stale",
					message: "This download attempt was replaced or cancelled."
				});
				if (!options.transport.requestFile) return {
					kind: "invalid",
					message: "File downloads are unavailable in this host."
				};
				const checked = await this.readPage(request.threadURL, { fresh: true });
				if (checked.kind !== "thread") return {
					kind: "invalid",
					message: "Current attachment access could not be confirmed. Refresh the thread or continue in the native forum."
				};
				if (attempt !== downloadSequence) return stale();
				const identity = (value) => value.kind === "member" ? `member:${value.id}` : value.kind;
				if (checked.account.kind === "unknown" || identity(checked.account) !== identity(request.account)) return {
					kind: "stale",
					message: "The forum account changed or could not be confirmed. Refresh the thread before downloading."
				};
				const found = checked.thread.posts.find((post) => post.id === request.postId)?.attachments?.filter((item) => item.id === request.attachmentId);
				if (found?.length !== 1) return {
					kind: "permission",
					message: "The forum no longer offers this attachment for direct download. No purchase was attempted."
				};
				const attachment = found[0];
				const ticket = generation;
				try {
					const response = await options.transport.requestFile(attachment.url);
					if (attempt !== downloadSequence) return stale();
					if (generation !== ticket) return {
						kind: "stale",
						message: "The forum account changed while receiving the file. Refresh the thread before downloading."
					};
					const failure = fileFailure(response);
					if (failure) return failure;
					if (response.url !== attachment.url) return {
						kind: "invalid",
						message: "The forum returned a different file destination. Nothing is ready to save."
					};
					return {
						kind: "file",
						name: attachment.name,
						contentType: response.contentType,
						bytes: response.bytes,
						generation: ticket
					};
				} catch {
					return {
						kind: "network",
						message: "The file transfer failed or was interrupted. Nothing is ready to save."
					};
				}
			},
			async readSearchPage(destination, prior, expectedAccount) {
				const current = ++sequence;
				const fail = (kind, message) => ({
					kind,
					message,
					account,
					generation,
					sourceURL: destination
				});
				if (!prior.results || !prior.effective || !prior.results.pages.links.some((link) => link.url === destination)) return fail("invalid", "This page was not offered by the current search results.");
				const url = new URL(destination);
				url.searchParams.set("tsdmapp", "json");
				try {
					const response = await options.transport.request(url.href);
					if (current !== sequence) return fail("stale", "A newer request replaced this search page.");
					const decoded = decodeSearchResults(response, destination, prior.form, prior.effective);
					if (actor(decoded.account) !== actor(account)) {
						account = decoded.account;
						generation++;
					}
					if (decoded.kind === "search") {
						if (decoded.account.kind === "unknown") return fail("invalid", "The current account could not be established from this search page. Review the current account before searching again deliberately.");
						if (actor(decoded.account) !== actor(expectedAccount)) return fail("invalid", "The account changed while reading search results. Review the current account before searching again deliberately.");
						if (decoded.search.results?.id !== prior.results.id) return fail("invalid", "The returned page belongs to a different search.");
						decoded.search.edited = prior.edited;
						decoded.search.submitted = prior.submitted;
					}
					return {
						...decoded,
						generation
					};
				} catch {
					return fail(current !== sequence ? "stale" : "network", "The search page could not be loaded. It has not been requested again automatically.");
				}
			},
			async search(criteria, form, expectedAccount) {
				const current = ++sequence;
				const fail = (kind, message) => ({
					kind,
					message,
					account,
					generation,
					sourceURL: form.url
				});
				const formURL = new URL(form.url);
				if (formURL.origin !== options.origin || formURL.pathname !== "/search.php") return fail("invalid", "The search form is not from this forum.");
				formURL.searchParams.set("tsdmapp", "json");
				try {
					const fresh = await options.transport.request(formURL.href);
					if (current !== sequence) return fail("stale", "A newer action replaced this search.");
					const prepared = prepareSearchRequest(fresh, form.url, criteria);
					if (prepared.kind !== "prepared") return {
						...prepared,
						generation
					};
					if (prepared.account.kind === "unknown" || expectedAccount.kind === "unknown") return fail("invalid", "The current account could not be established. Search has not been submitted.");
					if (actor(prepared.account) !== actor(expectedAccount)) {
						account = prepared.account;
						generation++;
						return fail("invalid", "The account changed while preparing search. Review the current form and submit again deliberately.");
					}
					const response = await options.transport.request(prepared.url, {
						method: "POST",
						body: prepared.body
					});
					if (current !== sequence) return fail("stale", "A newer action replaced this search. The earlier request may still have had effects.");
					const decoded = decodeSearchResults(response, form.url, prepared.form, criteria);
					if (actor(decoded.account) !== actor(account)) {
						account = decoded.account;
						generation++;
					}
					if (decoded.kind === "search" && decoded.account.kind === "unknown") return fail("invalid", "The current account could not be established from the search response. The request may still have used credits or quota.");
					if (decoded.kind === "search" && actor(decoded.account) !== actor(expectedAccount)) return fail("invalid", "The account changed during search. Its effects are not isolated; review the current account before another deliberate search.");
					return {
						...decoded,
						generation
					};
				} catch {
					return fail(current !== sequence ? "stale" : "network", "Search could not be completed. It may have used credits or quota. Submit again only deliberately.");
				}
			},
			readThread(destination) {
				return this.readPage(destination);
			},
			async readPage(destination, readOptions) {
				const current = ++sequence;
				const route = routeFor$1(destination);
				const url = route?.url;
				if (route?.kind === "notices") return {
					kind: "invalid",
					message: "Notices must be loaded deliberately. Each load may mark notices read.",
					account,
					generation,
					sourceURL: destination
				};
				if (route?.kind === "search" && url?.searchParams.has("searchid")) return {
					kind: "invalid",
					message: "An existing search page must be opened deliberately from its returned results. Open Search to prepare a new search.",
					account,
					generation,
					sourceURL: destination
				};
				if (!url || url.origin !== options.origin) return {
					kind: "invalid",
					message: "This is not a supported thread destination.",
					account,
					generation,
					sourceURL: destination
				};
				url.searchParams.set("tsdmapp", "json");
				try {
					const response = await options.transport.request(url.href, readOptions);
					if (current !== sequence) return {
						kind: "stale",
						message: "A newer request has replaced this result.",
						account,
						generation,
						sourceURL: destination
					};
					if (route?.kind === "redirect" && response.redirect === "opaque") return {
						kind: "document-navigation",
						message: "The forum redirect requires a document navigation.",
						destination,
						account,
						generation,
						sourceURL: destination
					};
					const decoded = route?.kind === "search" ? decodeSearchForm(response, destination) : route?.kind === "thread" ? decodeThread(response, destination) : decodeBoard(response, destination);
					if (actor(decoded.account) !== actor(account)) {
						account = decoded.account;
						generation++;
					}
					return {
						...decoded,
						generation
					};
				} catch {
					return {
						kind: current !== sequence ? "stale" : "network",
						message: "The forum could not be reached. Retry or continue in the native forum.",
						account,
						generation,
						sourceURL: destination
					};
				}
			}
		};
	}
	function createBrowserTransport() {
		return {
			async requestFile(url) {
				const response = await fetch(url, {
					credentials: "same-origin",
					redirect: "error",
					cache: "no-store"
				});
				return {
					status: response.status,
					url: response.url,
					redirected: response.redirected,
					contentType: response.headers.get("content-type") ?? "",
					contentLength: response.headers.get("content-length"),
					contentEncoding: response.headers.get("content-encoding") ?? "",
					disposition: response.headers.get("content-disposition") ?? "",
					bytes: new Uint8Array(await response.arrayBuffer())
				};
			},
			async request(url, request) {
				const response = await fetch(url, {
					credentials: "same-origin",
					cache: request?.fresh ? "no-store" : "default",
					...request?.method ? {
						method: request.method,
						body: request.body
					} : {},
					redirect: new URL(url).searchParams.get("mod") === "redirect" ? "manual" : "follow",
					headers: {
						Accept: "application/json, text/html;q=0.9",
						...request?.method ? { "Content-Type": "application/x-www-form-urlencoded" } : {}
					}
				});
				return {
					status: response.status,
					redirect: response.type === "opaqueredirect" ? "opaque" : response.redirected ? "followed" : "none",
					url: response.url,
					contentType: response.headers.get("content-type") ?? "",
					body: await response.text()
				};
			}
		};
	}
	function nativeDestination(destination) {
		const url = new URL(destination);
		url.searchParams.set("tsdm-native", "1");
		url.searchParams.delete("tsdmapp");
		return url.href;
	}
	function suspendNativeBackground(root) {
		const stopNativeKeyup = (event) => event.stopPropagation();
		root.addEventListener("keyup", stopNativeKeyup);
		const previous = new Map();
		const suspend = () => {
			for (const sibling of document.body.children) if (sibling instanceof HTMLElement && sibling !== root && !previous.has(sibling)) {
				previous.set(sibling, {
					inert: sibling.inert,
					ariaHidden: sibling.getAttribute("aria-hidden")
				});
				sibling.inert = true;
				sibling.setAttribute("aria-hidden", "true");
			}
		};
		const observer = new MutationObserver(suspend);
		suspend();
		observer.observe(document.body, { childList: true });
		return () => {
			root.removeEventListener("keyup", stopNativeKeyup);
			observer.disconnect();
			for (const [element, state] of previous) {
				element.inert = state.inert;
				if (state.ariaHidden === null) element.removeAttribute("aria-hidden");
				else element.setAttribute("aria-hidden", state.ariaHidden);
			}
		};
	}
	function createWriting(client, changed, accountObserved) {
		const state = shallowRef({
			context: null,
			visible: false,
			preparing: false,
			message: "",
			replacement: null,
			acknowledged: 0,
			recoveryAvailable: null,
			accountVerified: false,
			copy: null,
			composing: false,
			compositionDeferred: false,
			publication: null,
			publishing: false,
			resend: null
		});
		let sequence = 0;
		let deferred = null;
		function deferViewChange(action) {
			if (!state.value.composing) return false;
			deferred = action;
			state.value = {
				...state.value,
				compositionDeferred: true
			};
			return true;
		}
		function endComposition() {
			state.value = {
				...state.value,
				composing: false
			};
			setTimeout(() => {
				if (state.value.composing) return;
				const action = deferred;
				deferred = null;
				state.value = {
					...state.value,
					compositionDeferred: false
				};
				action?.();
			}, 0);
		}
		async function prepare(boardId, replace = false) {
			if (deferViewChange(() => {
				prepare(boardId, replace);
			})) return;
			const existing = state.value.context;
			if (state.value.publishing && (replace || existing?.board.id !== boardId)) {
				state.value = {
					...state.value,
					message: "Publication or result checking is pending. Keep this context until it settles."
				};
				return;
			}
			if (existing && !replace) {
				if (existing.board.id === boardId) {
					state.value = {
						...state.value,
						visible: true,
						replacement: null
					};
					return;
				}
				state.value = {
					...state.value,
					replacement: boardId
				};
				return;
			}
			const current = ++sequence;
			state.value = {
				...state.value,
				preparing: true,
				message: ""
			};
			const result = await client.prepareNewThread(boardId);
			if (result.kind !== "stale") {
				accountObserved(result.account);
				observe(result.account, result.kind === "prepared");
			}
			if (current !== sequence) return;
			if (result.kind !== "prepared") {
				state.value = {
					...state.value,
					preparing: false,
					message: result.message
				};
				return;
			}
			if (existing && (state.value.context?.id !== existing.id || state.value.context.revision !== existing.revision || state.value.composing)) {
				state.value = {
					...state.value,
					preparing: false,
					message: "Writing changed while the new form was loading. Return to it or deliberately prepare replacement again."
				};
				return;
			}
			state.value = {
				...state.value,
				context: {
					...result.prepared,
					id: crypto.randomUUID(),
					revision: 1,
					selection: {
						start: 0,
						end: 0,
						direction: "none"
					},
					...existing?.attempts?.length ? { attempts: existing.attempts } : {}
				},
				preparing: false,
				visible: true,
				replacement: null,
				message: "",
				acknowledged: 0,
				accountVerified: true,
				copy: null
			};
			changed();
		}
		function edit(patch) {
			const context = state.value.context;
			if (context) {
				if (Object.entries(patch).every(([key, value]) => JSON.stringify(context[key]) === JSON.stringify(value))) return;
				state.value = {
					...state.value,
					context: {
						...context,
						...patch,
						revision: context.revision + 1
					},
					publication: null
				};
				changed();
			}
		}
		function submission(context) {
			const { id, revision, selection: _selection, attempts: _attempts, ...content } = context;
			return {
				contextId: id,
				revision,
				writing: content
			};
		}
		function updateAttempt(attempt) {
			const context = state.value.context;
			if (!context || context.id !== attempt.publication.submission.contextId && !context.attempts?.some((item) => item.id === attempt.id)) return;
			state.value = {
				...state.value,
				context: {
					...context,
					attempts: [...(context.attempts ?? []).filter((item) => item.id !== attempt.id), attempt]
				}
			};
		}
		async function reviewPublication(resendId) {
			const context = state.value.context;
			if (!context || state.value.preparing || state.value.publishing || state.value.composing) return;
			const unresolved = context.attempts?.filter((attempt) => [
				"pending",
				"uncertain",
				"moderation"
			].includes(attempt.status)) ?? [];
			if (unresolved.length && !unresolved.some((attempt) => attempt.id === resendId && attempt.checked && attempt.status === "uncertain")) {
				state.value = {
					...state.value,
					message: "An earlier attempt may already exist. Check result, then explicitly accept duplicate risk before another send."
				};
				return;
			}
			state.value = {
				...state.value,
				preparing: true,
				publication: null,
				message: ""
			};
			const result = await client.prepareThreadPublication(submission(context));
			accountObserved(result.account);
			observe(result.account, result.kind === "ready");
			if (state.value.context?.id !== context.id || state.value.context.revision !== context.revision) {
				state.value = {
					...state.value,
					preparing: false,
					message: "Writing changed during publication preparation. Review the current revision again."
				};
				return;
			}
			state.value = {
				...state.value,
				preparing: false,
				publication: result.kind === "ready" ? result.publication : null,
				message: result.kind === "ready" ? "" : result.message
			};
		}
		async function publish() {
			const publication = state.value.publication, context = state.value.context;
			if (!publication || !context || state.value.publishing || state.value.composing || publication.submission.revision !== context.revision) return;
			state.value = {
				...state.value,
				publishing: true,
				publication: null
			};
			const attempt = {
				id: crypto.randomUUID(),
				publication,
				status: "pending",
				message: "Publication is pending. Refresh will retain it as uncertain without replay.",
				checked: false,
				candidateURL: null,
				result: null
			};
			updateAttempt(attempt);
			const saved = await changed();
			let result;
			if (!saved || state.value.context?.revision !== context.revision || client.generation !== publication.generation) result = {
				...attempt,
				status: "not-sent",
				message: "Publication was not sent because recovery, writing or the account changed before send. Your source is retained."
			};
			else result = await client.publishThread(attempt);
			accountObserved(client.account);
			observe(client.account);
			updateAttempt(result);
			state.value = {
				...state.value,
				publishing: false
			};
			await changed();
		}
		async function checkResult(id, url) {
			const attempt = state.value.context?.attempts?.find((item) => item.id === id);
			if (!attempt || state.value.publishing || state.value.preparing) return;
			state.value = {
				...state.value,
				publishing: true,
				publication: null
			};
			const result = await client.checkThreadResult(attempt, url);
			accountObserved(client.account);
			observe(client.account);
			updateAttempt(result);
			state.value = {
				...state.value,
				publishing: false
			};
			await changed();
		}
		function observe(account, verified = true) {
			state.value = {
				...state.value,
				accountVerified: verified && account.kind === "member" && account.id === state.value.context?.account.id
			};
			if (state.value.copy && (account.kind !== "member" || account.id !== state.value.copy.prepared.account.id || client.generation !== state.value.copy.generation)) state.value = {
				...state.value,
				copy: null
			};
		}
		async function check(copyText = false) {
			const original = state.value.context;
			if (!original || state.value.publishing) return;
			const current = ++sequence;
			state.value = {
				...state.value,
				preparing: true,
				copy: null,
				message: ""
			};
			const result = await client.prepareNewThread(original.board.id);
			if (result.kind !== "stale") {
				accountObserved(result.account);
				observe(result.account, result.kind === "prepared");
			}
			if (current !== sequence || state.value.context?.id !== original.id) return;
			if (result.kind !== "prepared") {
				state.value = {
					...state.value,
					preparing: false,
					message: result.message
				};
				return;
			}
			state.value = {
				...state.value,
				preparing: false,
				copy: copyText ? {
					prepared: result.prepared,
					generation: result.generation,
					originalId: original.id
				} : null
			};
		}
		function confirmCopy() {
			if (deferViewChange(confirmCopy)) return;
			const candidate = state.value.copy, original = state.value.context;
			if (!candidate || !original || candidate.originalId !== original.id || state.value.publishing) return;
			if (candidate.generation !== client.generation || client.account.kind !== "member" || client.account.id !== candidate.prepared.account.id) {
				state.value = {
					...state.value,
					copy: null,
					accountVerified: false,
					message: "The account changed again. Prepare the text copy again."
				};
				return;
			}
			state.value = {
				...state.value,
				context: {
					...candidate.prepared,
					title: original.title,
					source: original.source,
					uploadedReferences: [],
					id: crypto.randomUUID(),
					revision: 1,
					selection: { ...original.selection },
					...original.attempts?.length ? { attempts: original.attempts } : {}
				},
				copy: null,
				acknowledged: 0,
				accountVerified: true
			};
			changed();
		}
		return {
			deferViewChange,
			startComposition: () => {
				state.value = {
					...state.value,
					composing: true
				};
			},
			endComposition,
			observe,
			check,
			reviewPublication,
			publish,
			checkResult,
			warnResend: (id) => {
				const attempt = state.value.context?.attempts?.find((item) => item.id === id);
				if (attempt?.status === "uncertain" && attempt.checked) state.value = {
					...state.value,
					resend: id
				};
			},
			confirmResend: () => {
				const id = state.value.resend;
				state.value = {
					...state.value,
					resend: null
				};
				if (id) reviewPublication(id);
			},
			cancelResend: () => {
				state.value = {
					...state.value,
					resend: null
				};
			},
			confirmCopy,
			cancelCopy: () => {
				state.value = {
					...state.value,
					copy: null
				};
			},
			snapshot: () => state.value.context,
			restore: (context) => {
				const pending = context?.attempts?.some((attempt) => attempt.status === "pending");
				if (context?.attempts) context = {
					...context,
					attempts: context.attempts.map((attempt) => attempt.status === "pending" ? {
						...attempt,
						status: "uncertain",
						checked: false,
						message: "Pending publication restored as uncertain. Nothing has been replayed; check the original attempt."
					} : attempt)
				};
				state.value = {
					...state.value,
					context,
					visible: context !== null,
					acknowledged: context?.revision ?? 0,
					recoveryAvailable: true,
					accountVerified: false,
					copy: null,
					publication: null,
					publishing: false,
					resend: null
				};
				if (pending) changed();
			},
			acknowledge: (id, revision, available) => {
				state.value = {
					...state.value,
					recoveryAvailable: available,
					acknowledged: available && state.value.context?.id === id ? Math.max(state.value.acknowledged, revision) : state.value.acknowledged
				};
			},
			unresolvedAttachments: computed(() => {
				const context = state.value.context;
				return context ? unresolvedWritingAttachments(context) : [];
			}),
			state: readonly(state),
			prepare,
			edit,
			show: () => {
				const show = () => {
					++sequence;
					state.value = {
						...state.value,
						visible: true,
						replacement: null,
						preparing: false
					};
				};
				if (!deferViewChange(show)) show();
			},
			hide: () => {
				const hide = () => {
					state.value = {
						...state.value,
						visible: false
					};
				};
				if (!deferViewChange(hide)) hide();
			},
			discardAndPrepare: () => {
				const boardId = state.value.replacement;
				if (boardId) prepare(boardId, true);
			}
		};
	}
	var object$1 = (value) => !!value && typeof value === "object" && !Array.isArray(value);
	var string$1 = (value) => typeof value === "string";
	var integer = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
	function isWritingContext(value) {
		if (!object$1(value) || !string$1(value.id) || !integer(value.revision) || value.revision < 1 || value.action !== "new-thread" || !object$1(value.board) || !string$1(value.board.id) || !/^[1-9]\d*$/.test(value.board.id) || !string$1(value.board.label) || !string$1(value.board.url) || !object$1(value.account) || value.account.kind !== "member" || !string$1(value.account.id) || !/^[1-9]\d*$/.test(value.account.id) || !string$1(value.account.name) || !string$1(value.title) || !string$1(value.source)) return false;
		try {
			const url = new URL(value.board.url);
			if (url.origin !== location.origin || url.pathname !== "/forum.php" || url.searchParams.get("mod") !== "forumdisplay" || url.searchParams.get("fid") !== value.board.id) return false;
		} catch {
			return false;
		}
		const option = (o) => object$1(o) && string$1(o.name) && string$1(o.label) && [
			"checkbox",
			"select",
			"text"
		].includes(String(o.kind)) && string$1(o.value) && typeof o.checked === "boolean" && typeof o.disabled === "boolean" && (o.maxLength === null || integer(o.maxLength)) && Array.isArray(o.choices) && o.choices.every((c) => object$1(c) && string$1(c.value) && string$1(c.label) && typeof c.disabled === "boolean");
		const selection = value.selection;
		const attempts = value.attempts;
		return (attempts === void 0 || Array.isArray(attempts) && attempts.every(isAttempt)) && (value.category === null || option(value.category)) && Array.isArray(value.options) && value.options.every(option) && Array.isArray(value.uploadedReferences) && value.uploadedReferences.every((id) => string$1(id) && /^[1-9]\d*$/.test(id)) && object$1(selection) && integer(selection.start) && integer(selection.end) && selection.start <= selection.end && selection.end <= value.source.length && [
			"forward",
			"backward",
			"none"
		].includes(String(selection.direction));
	}
	function isAttempt(value) {
		if (!object$1(value) || !string$1(value.id) || !value.id || !string$1(value.status) || ![
			"pending",
			"uncertain",
			"rejected",
			"moderation",
			"confirmed",
			"not-sent"
		].includes(value.status) || !string$1(value.message) || typeof value.checked !== "boolean" || !(value.candidateURL === null || safeThreadURL(value.candidateURL)) || !object$1(value.publication) || !string$1(value.publication.id) || !value.publication.id || !integer(value.publication.generation) || !object$1(value.publication.submission)) return false;
		const submission = value.publication.submission;
		if (!object$1(submission.writing)) return false;
		const submittedWriting = {
			...submission.writing,
			id: submission.contextId,
			revision: submission.revision,
			selection: {
				start: 0,
				end: 0,
				direction: "none"
			},
			attempts: void 0
		};
		if (!isWritingContext(submittedWriting)) return false;
		return value.result === null && value.status !== "confirmed" || object$1(value.result) && value.status === "confirmed" && value.checked === true && string$1(value.result.threadId) && /^[1-9]\d*$/.test(value.result.threadId) && string$1(value.result.postId) && /^[1-9]\d*$/.test(value.result.postId) && safeThreadURL(value.result.url) && new URL(value.result.url).searchParams.get("tid") === value.result.threadId && new URL(value.result.url).hash === `#pid${value.result.postId}` && (!Object.hasOwn(value.result, "verification") || isThreadVerification(value.result.verification, submittedWriting));
	}
	function safeThreadURL(value) {
		if (!string$1(value)) return false;
		try {
			const url = new URL(value);
			return url.origin === location.origin && !url.username && !url.password && url.pathname === "/forum.php" && url.searchParams.get("mod") === "viewthread" && /^[1-9]\d*$/.test(url.searchParams.get("tid") ?? "");
		} catch {
			return false;
		}
	}
	var object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
	var string = (value) => typeof value === "string";
	var nullableString = (value) => value === null || string(value);
	var finite = (value) => typeof value === "number" && Number.isFinite(value);
	var list = (value, item) => Array.isArray(value) && value.every(item);
	var id = (value) => string(value) && /^[1-9]\d*$/.test(value);
	var key$1 = (value) => string(value) && /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(value);
	function url(value, sameOrigin = false) {
		if (!string(value)) return false;
		try {
			const parsed = new URL(value);
			return ["https:", "http:"].includes(parsed.protocol) && !parsed.username && !parsed.password && (!sameOrigin || parsed.origin === location.origin);
		} catch {
			return false;
		}
	}
	var destination$1 = (value) => url(value, true) && describeDestination(value) !== null;
	var link = (value) => object(value) && string(value.label) && url(value.url);
	var pages = (value) => object(value) && string(value.current) && list(value.links, link);
	var boardLink = (value) => object(value) && link(value) && id(value.id) && string(value.description) && string(value.stats);
	var account = (value) => object(value) && (value.kind === "guest" || value.kind === "unknown" || value.kind === "member" && id(value.id) && string(value.name));
	var tags = new Set("p div span br hr strong b em i u s del ins sub sup small blockquote pre code ul ol li dl dt dd table thead tbody tfoot tr th td caption h1 h2 h3 h4 h5 h6 details summary a img".split(" "));
	function attribute(tag, name, value) {
		if (!string(value)) return false;
		switch (name) {
			case "class": return [
				"permission-notice",
				"quote",
				"code-block"
			].includes(value);
			case "style": return /^text-align:(left|right|center|justify)$/.test(value);
			case "href": return tag === "a" && url(value);
			case "rel": return tag === "a" && value === "noopener noreferrer";
			case "src": return tag === "img" && url(value) && /\.(?:png|jpe?g|gif|webp|avif|bmp)$/i.test(new URL(value).pathname);
			case "alt": return tag === "img";
			case "loading": return tag === "img" && value === "lazy";
			case "referrerpolicy": return tag === "img" && value === "no-referrer";
			case "colspan":
			case "rowspan": return /^[1-9]\d?$/.test(value);
			case "dir": return [
				"ltr",
				"rtl",
				"auto"
			].includes(value);
			case "title": return true;
			default: return false;
		}
	}
	function content(value) {
		if (!object(value)) return false;
		if (value.kind === "text") return string(value.text);
		if (value.kind === "unsupported") return string(value.description) && list(value.children, content);
		if (value.kind !== "element" || !string(value.tag) || !tags.has(value.tag) || !object(value.attributes)) return false;
		const tag = value.tag;
		return Object.entries(value.attributes).every(([name, value]) => attribute(tag, name, value)) && list(value.children, content);
	}
	function post(value) {
		return object(value) && id(value.id) && string(value.author) && (value.authorId === null || id(value.authorId)) && string(value.floor) && string(value.date) && url(value.url, true) && (value.attachments === void 0 || list(value.attachments, (attachment) => object(attachment) && id(attachment.id) && string(attachment.name) && url(attachment.url, true) && string(attachment.details))) && list(value.content, content);
	}
	function result(value) {
		if (!object(value) || !account(value.account) || !finite(value.generation) || !Number.isInteger(value.generation) || value.generation < 0 || !url(value.sourceURL, true)) return false;
		if (value.kind === "search") {
			const search = value.search;
			return object(search) && object(search.form) && destination$1(search.form.url) && list(search.form.restrictions, string) && list(search.form.fields, (field) => object(field) && string(field.name) && string(field.label) && (field.labelFromForum === void 0 || typeof field.labelFromForum === "boolean") && [
				"text",
				"select",
				"choices"
			].includes(String(field.kind)) && typeof field.multiple === "boolean" && typeof field.disabled === "boolean" && typeof field.readOnly === "boolean" && (field.maxLength === null || finite(field.maxLength)) && list(field.values, string) && list(field.options, (option) => object(option) && string(option.value) && string(option.label) && typeof option.disabled === "boolean")) && (search.submitted === null || object(search.submitted) && Object.values(search.submitted).every((value) => list(value, string))) && (search.effective === null || object(search.effective) && Object.values(search.effective).every((value) => list(value, string))) && (search.results === null || object(search.results) && id(search.results.id) && destination$1(search.results.url) && string(search.results.summary) && pages(search.results.pages) && list(search.results.rows, (row) => object(row) && id(row.id) && link(row) && link(row.author) && link(row.board) && string(row.date) && string(row.snippet) && string(row.stats))) && object(search.edited) && Object.values(search.edited).every((value) => list(value, string));
		}
		if (value.kind === "notices") {
			const notices = value.notices;
			return object(notices) && destination$1(notices.url) && list(notices.categories, (category) => link(category) && object(category) && typeof category.current === "boolean") && pages(notices.pages) && string(notices.empty) && object(notices.unread) && (["unknown", "absent"].includes(String(notices.unread.kind)) || notices.unread.kind === "observed" && finite(notices.unread.count) && Number.isSafeInteger(notices.unread.count) && notices.unread.count >= 0) && list(notices.entries, (entry) => object(entry) && id(entry.id) && string(entry.time) && list(entry.body, content));
		}
		if (value.kind === "thread") {
			const t = value.thread;
			return object(t) && id(t.id) && string(t.title) && destination$1(t.url) && list(t.posts, post) && pages(t.pages) && list(t.filters, link) && (t.parent === null || link(t.parent)) && (t.target === null || id(t.target)) && list(t.notices, string);
		}
		if (value.kind === "board") {
			const b = value.board;
			return object(b) && id(b.id) && string(b.title) && destination$1(b.url) && list(b.boards, boardLink) && list(b.threads, (row) => object(row) && link(row) && id(row.id) && string(row.rowId) && typeof row.pinned === "boolean" && typeof row.moved === "boolean" && string(row.category) && string(row.author) && string(row.date) && string(row.replies) && string(row.views) && (row.lastPost === null || link(row.lastPost))) && list(b.filters, link) && list(b.criteria, link) && pages(b.pages) && string(b.empty);
		}
		if (value.kind === "directory") {
			const d = value.directory;
			return object(d) && destination$1(d.url) && pages(d.pages) && list(d.groups, (group) => object(group) && string(group.title) && list(group.boards, boardLink));
		}
		return string(value.kind) && [
			"cost",
			"throttle",
			"expired",
			"limited",
			"login",
			"permission",
			"missing",
			"challenge",
			"invalid",
			"network",
			"stale"
		].includes(value.kind) && string(value.message) && (value.nativeText === void 0 || nullableString(value.nativeText));
	}
	function isNavigationRecord(value) {
		if (!object(value) || value.schema !== 2 || !object(value.entries)) return false;
		if (!(value.writing === null || isWritingContext(value.writing))) return false;
		const entries = value.entries;
		for (const [entryKey, entry] of Object.entries(entries)) {
			if (!key$1(entryKey) || !object(entry) || entry.section !== void 0 && (typeof entry.section !== "string" || ![
				"boards",
				"search",
				"saved",
				"notices",
				"drafts"
			].includes(entry.section)) || entry.key !== entryKey || !destination$1(entry.destination) || !(entry.originKey === null || key$1(entry.originKey) && Object.hasOwn(entries, entry.originKey)) || !nullableString(entry.selection) || !nullableString(entry.account) || !(entry.documentNavigations === 0 || entry.documentNavigations === 1) || !(entry.result === null || result(entry.result))) return false;
			const position = entry.position;
			if (!(position === null || object(position) && nullableString(position.anchor) && finite(position.offset) && finite(position.scrollTop) && position.scrollTop >= 0)) return false;
		}
		if (value.pending === null) return true;
		const pending = value.pending;
		if (!object(pending) || !key$1(pending.entryKey) || !Object.hasOwn(entries, pending.entryKey) || !destination$1(pending.destination)) return false;
		const entry = entries[pending.entryKey];
		return object(entry) && entry.documentNavigations === 1 && entry.destination === pending.destination;
	}
	var storageKey = "tsdm.workspace.recovery";
	function createBrowserNavigation() {
		let saveQueue = Promise.resolve(true);
		let problem = null;
		const entryKey = () => /^#workspace=([a-zA-Z0-9-]+)$/.exec(location.hash)?.[1] ?? null;
		const address = (key) => `${location.origin}/forum.php#workspace=${key}`;
		return {
			entryKey,
			recoveryProblem: () => problem,
			resetRecovery: () => {
				problem = null;
			},
			async load() {
				let raw = null;
				try {
					raw = sessionStorage.getItem(storageKey);
					if (raw === null) return null;
					let value;
					try {
						value = JSON.parse(raw);
					} catch {
						problem = {
							kind: "incompatible",
							raw
						};
						return null;
					}
					if (value && typeof value === "object" && "schema" in value && value.schema === 1) value = {
						...value,
						schema: 2,
						writing: null
					};
					if (isNavigationRecord(value)) return value;
					problem = {
						kind: "incompatible",
						raw
					};
					return null;
				} catch {
					problem = {
						kind: "refused",
						raw
					};
					return null;
				}
			},
			save(record) {
				if (problem?.kind === "incompatible") return Promise.resolve(false);
				let snapshot;
				try {
					snapshot = JSON.stringify(record);
				} catch {
					return Promise.resolve(false);
				}
				saveQueue = saveQueue.then(() => {
					try {
						sessionStorage.setItem(storageKey, snapshot);
						return sessionStorage.getItem(storageKey) === snapshot;
					} catch {
						return false;
					}
				});
				return saveQueue;
			},
			push(key) {
				history.pushState({ tsdmEntry: key }, "", address(key));
			},
			replace(key) {
				history.replaceState({ tsdmEntry: key }, "", address(key));
			},
			onPop(action) {
				window.addEventListener("popstate", () => action(entryKey()));
			},
			back() {
				history.back();
			},
			navigateDocument(url) {
				location.replace(url);
			}
		};
	}
	async function recoverNavigationDestination() {
		const host = createBrowserNavigation(), key = host.entryKey();
		if (!key) return location.href;
		const entry = (await host.load())?.entries[key];
		if (entry && typeof entry.destination === "string") try {
			const url = new URL(entry.destination);
			if (url.origin === location.origin && url.protocol === "https:" && !url.username && !url.password) return url.href;
		} catch {}
		return `${location.origin}/forum.php`;
	}
	var defaults = {
		schema: 1,
		theme: "light",
		textSize: 100,
		language: "en"
	};
	function normalize(value) {
		if (!value || typeof value !== "object" || !("schema" in value) || value.schema !== 1) return { ...defaults };
		const candidate = value;
		return {
			schema: 1,
			theme: candidate.theme === "alias" || candidate.theme === "mono" || candidate.theme === "dark" ? candidate.theme : "light",
			language: candidate.language === "zh-CN" || candidate.language === "zh-TW" ? candidate.language : "en",
			textSize: typeof candidate.textSize === "number" && Number.isInteger(candidate.textSize) && candidate.textSize >= 70 && candidate.textSize <= 150 && candidate.textSize % 10 === 0 ? candidate.textSize : 100
		};
	}
	function createPreferences(host) {
		const loaded = host.load();
		const state = shallowRef(normalize(loaded.value));
		const persistent = shallowRef(loaded.available);
		function set(update) {
			state.value = normalize({
				...state.value,
				...update
			});
			persistent.value = host.save(state.value);
		}
		return {
			state: readonly(state),
			persistent: readonly(persistent),
			set,
			setTextSize: (textSize) => set({ textSize })
		};
	}
	var routeFor = (value) => {
		const route = describeDestination(value);
		return route ? {
			...route,
			url: new URL(route.url)
		} : null;
	};
	var accountKey = (account) => account.kind === "member" ? `member:${account.id}` : account.kind === "guest" ? "guest" : null;
	var success = (result) => [
		"thread",
		"board",
		"directory",
		"search",
		"notices"
	].includes(result.kind);
	function createWorkspace(client, destination, host, preferenceHost, downloads) {
		const preferences = createPreferences(preferenceHost);
		const writing = createWriting(client, () => {
			record.writing = writing.snapshot();
			return persist();
		}, (account) => {
			if (observeAccount(account)) persist();
		});
		const state = shallowRef({
			section: "boards",
			loading: false,
			result: null,
			failure: null,
			destination,
			key: "",
			selection: null,
			stale: false,
			missing: false,
			restored: false,
			recoveryAvailable: null,
			canBack: false,
			origin: null,
			documentNavigation: null,
			recoveryProblem: null
		});
		const download = shallowRef(null);
		let prepared = null;
		let downloadSequence = 0;
		function clearDownload() {
			downloadSequence++;
			client.cancelDownload();
			prepared?.dispose();
			prepared = null;
			download.value = null;
		}
		watch(() => writing.state.value.visible, (visible) => {
			if (visible) clearDownload();
		}, { flush: "sync" });
		async function prepareDownload(postId, attachmentId) {
			if (download.value?.status === "checking") return;
			const result = state.value.result;
			if (result?.kind !== "thread") return;
			const attachment = result.thread.posts.find((post) => post.id === postId)?.attachments?.find((item) => item.id === attachmentId);
			if (!attachment) return;
			clearDownload();
			const ticket = downloadSequence;
			const identity = {
				postId,
				attachmentId
			};
			download.value = {
				...identity,
				status: "checking",
				name: attachment.name,
				message: "Checking current attachment access and receiving file…"
			};
			const accountGeneration = client.generation;
			const received = await client.downloadAttachment({
				threadURL: result.thread.url,
				postId,
				attachmentId,
				account: result.account
			});
			if (client.generation !== accountGeneration) {
				observeAccount(client.account);
				writing.observe(client.account);
				persist();
			}
			if (ticket !== downloadSequence) return;
			if (received.kind !== "file") {
				download.value = {
					...identity,
					status: "failure",
					name: attachment.name,
					message: received.message
				};
				return;
			}
			try {
				if (!downloads) throw new Error("No download host");
				prepared = downloads.prepare(received.bytes, received.name, received.contentType);
				download.value = {
					...identity,
					status: "ready",
					name: received.name,
					message: "File ready to save"
				};
			} catch {
				download.value = {
					...identity,
					status: "failure",
					name: attachment.name,
					message: "Browser file preparation failed. No save was requested."
				};
			}
		}
		function saveDownload() {
			if (!prepared || !download.value) return;
			try {
				prepared.save();
				download.value = {
					...download.value,
					status: "requested",
					message: "Browser save requested. Check your browser Downloads for completion; this workspace cannot confirm whether the file was saved or cancelled."
				};
			} catch {
				download.value = {
					...download.value,
					status: "failure",
					message: "Browser save could not start. File delivery is unconfirmed."
				};
			}
		}
		let sequence = 0;
		let record = {
			schema: 2,
			entries: {},
			pending: null,
			writing: null
		};
		let saveSequence = 0;
		const entryFor = (key) => Object.hasOwn(record.entries, key) ? record.entries[key] : void 0;
		let view = null;
		let knownAccount = null;
		function capture() {
			const entry = entryFor(state.value.key);
			if (entry && view) entry.position = view.capture();
		}
		async function persist() {
			const current = ++saveSequence;
			const context = record.writing;
			const saved = await host.save(record);
			if (current === saveSequence) {
				state.value = {
					...state.value,
					recoveryAvailable: saved
				};
				writing.acknowledge(context?.id ?? null, context?.revision ?? 0, saved);
			}
			return saved;
		}
		function originContext(entry) {
			const visited = new Set();
			let key = entry.originKey;
			while (key && !visited.has(key)) {
				visited.add(key);
				const origin = entryFor(key);
				if (!origin) return null;
				if (origin.result?.kind !== "thread") return origin.result;
				key = origin.originKey;
			}
			return null;
		}
		function show(entry, restored = false) {
			const mismatch = knownAccount !== null && entry.account !== null && entry.account !== knownAccount;
			state.value = {
				...state.value,
				section: entry.section ?? (routeFor(entry.destination)?.kind === "search" || entry.result?.kind === "search" || originContext(entry)?.kind === "search" ? "search" : entry.result?.kind === "notices" || originContext(entry)?.kind === "notices" ? "notices" : "boards"),
				key: entry.key,
				destination: entry.destination,
				result: mismatch ? null : entry.result,
				failure: null,
				loading: false,
				selection: entry.selection,
				missing: mismatch || !entry.result && (!entry.section || entry.section === "boards" || routeFor(entry.destination)?.kind === "notices"),
				stale: restored && entry.result !== null,
				restored,
				canBack: entry.originKey !== null,
				documentNavigation: null,
				origin: originContext(entry)
			};
			nextTick().then(() => view?.restore(entry.position, entry.result?.kind === "thread" ? entry.result.thread.target : null, entry.selection));
		}
		function newEntry(url, originKey) {
			const entry = {
				key: crypto.randomUUID(),
				section: routeFor(url)?.kind === "search" || state.value.section === "search" && ["thread", "redirect"].includes(routeFor(url)?.kind ?? "") ? "search" : routeFor(url)?.kind === "notices" || state.value.section === "notices" && ["thread", "redirect"].includes(routeFor(url)?.kind ?? "") ? "notices" : "boards",
				destination: url,
				originKey,
				selection: null,
				position: null,
				result: null,
				account: null,
				documentNavigations: 0
			};
			record.entries[entry.key] = entry;
			return entry;
		}
		function observeAccount(account) {
			let invalidated = false;
			const observed = accountKey(account);
			if (account.kind === "unknown") {
				for (const entry of Object.values(record.entries)) if (entry.result?.kind === "notices") {
					entry.result = null;
					invalidated = true;
				}
				if (state.value.result?.kind === "notices") state.value = {
					...state.value,
					result: null,
					restored: false,
					missing: true
				};
				if (state.value.origin?.kind === "notices") state.value = {
					...state.value,
					origin: null
				};
			}
			if (observed) {
				knownAccount = observed;
				if (state.value.result && accountKey(state.value.result.account) !== observed) state.value = {
					...state.value,
					result: null,
					restored: false,
					missing: true
				};
				if (state.value.origin && accountKey(state.value.origin.account) !== observed) state.value = {
					...state.value,
					origin: null
				};
				for (const other of Object.values(record.entries)) if (other.result && other.account && other.account !== observed) {
					other.result = null;
					invalidated = true;
				}
			}
			return invalidated;
		}
		async function read(entry, submitted) {
			const current = ++sequence;
			state.value = {
				...state.value,
				loading: true,
				stale: state.value.result !== null,
				failure: null,
				missing: false
			};
			const result = await (submitted ?? client.readPage(entry.destination));
			if (current !== sequence || result.kind === "stale") return;
			if (result.kind === "document-navigation") {
				if (entry.documentNavigations >= 1) {
					const failure = {
						kind: "invalid",
						message: "The exact destination could not be resolved after navigation. Continue in the native forum.",
						account: result.account,
						generation: result.generation,
						sourceURL: entry.destination
					};
					state.value = {
						...state.value,
						result: failure,
						failure,
						loading: false,
						missing: false
					};
					record.pending = null;
					persist();
					return;
				}
				entry.documentNavigations++;
				entry.destination = result.destination;
				record.pending = {
					entryKey: entry.key,
					destination: entry.destination
				};
				state.value = {
					...state.value,
					loading: false
				};
				if (await persist()) host.navigateDocument(entry.destination);
				else state.value = {
					...state.value,
					documentNavigation: entry.destination
				};
				return;
			}
			const previousSearch = state.value.result?.kind === "search" ? state.value.result : null;
			const observed = accountKey(result.account);
			writing.observe(result.account, result.kind !== "network");
			observeAccount(result.account);
			if (previousSearch && observed && accountKey(previousSearch.account) !== observed && !success(result)) {
				const retained = {
					...previousSearch,
					account: result.account,
					generation: result.generation,
					search: {
						...previousSearch.search,
						effective: null,
						results: null
					}
				};
				entry.result = retained;
				entry.account = observed;
				state.value = {
					...state.value,
					result: retained,
					restored: false,
					missing: false
				};
			}
			if (success(result)) {
				if (result.kind === "thread") result.thread.target = /^#pid([1-9]\d*)$/.exec(new URL(entry.destination).hash)?.[1] ?? result.thread.target;
				entry.result = result;
				entry.account = observed;
				if (result.kind === "search" && result.search.results) entry.destination = result.search.results.url;
				if (result.kind === "thread") {
					const actual = new URL(result.thread.url);
					const requested = new URL(entry.destination);
					if (requested.hash === "#lastpost" && result.thread.target) actual.hash = `pid${result.thread.target}`;
					else if (requested.hash) actual.hash = requested.hash;
					entry.destination = actual.href;
				}
				state.value = {
					...state.value,
					result,
					loading: false,
					missing: false,
					failure: null,
					stale: false,
					restored: false,
					destination: entry.destination
				};
				nextTick().then(() => view?.restore(entry.position, result.kind === "thread" ? result.thread.target : null, entry.selection));
			} else state.value = {
				...state.value,
				loading: false,
				failure: result,
				result: state.value.result ?? result,
				stale: state.value.result !== null
			};
			persist();
		}
		async function openThread(url, selection = null) {
			if (writing.deferViewChange(() => {
				openThread(url, selection);
			})) return;
			if (routeFor(url)?.kind === "notices") return loadNotices(url);
			clearDownload();
			const current = state.value.result;
			const requested = routeFor(url);
			if (current?.kind === "thread" && requested?.kind === "thread" && requested.url.searchParams.get("tid") === current.thread.id && requested.url.hash && requested.url.pathname + requested.url.search === new URL(state.value.destination).pathname + new URL(state.value.destination).search) {
				updateAnchor(requested.url.hash);
				return;
			}
			writing.hide();
			capture();
			const previous = entryFor(state.value.key);
			if (previous && selection) previous.selection = selection;
			const entry = newEntry(url, previous?.key ?? null);
			host.push(entry.key);
			const searchContext = current?.kind === "search" ? current : state.value.origin;
			const searchPage = requested?.kind === "search" && requested.url.searchParams.has("searchid") && searchContext?.kind === "search" ? searchContext : null;
			if (searchPage) {
				entry.result = searchPage;
				entry.account = accountKey(searchPage.account);
			}
			show(entry);
			persist();
			await read(entry, searchPage ? client.readSearchPage(url, searchPage.search, searchPage.account) : void 0);
		}
		async function loadNotices(url) {
			if (state.value.loading) return;
			if (writing.deferViewChange(() => {
				loadNotices(url);
			})) return;
			const current = state.value.result?.kind === "notices" ? state.value.result : state.value.origin?.kind === "notices" ? state.value.origin : null;
			const destinationURL = url ?? current?.notices.url ?? (routeFor(state.value.destination)?.kind === "notices" ? state.value.destination : `${new URL(destination).origin}/home.php?mod=space&do=notice`);
			clearDownload();
			writing.hide();
			capture();
			const entry = newEntry(destinationURL, state.value.key || null);
			entry.section = "notices";
			if (current) {
				entry.result = current;
				entry.account = accountKey(current.account);
			}
			host.push(entry.key);
			show(entry);
			await read(entry, client.readNotices(destinationURL, current?.notices, current?.account));
		}
		function updateAnchor(hash) {
			if (!/^#pid[1-9]\d*$/.test(hash)) return;
			const entry = entryFor(state.value.key);
			if (!entry) return;
			const url = new URL(entry.destination);
			url.hash = hash;
			entry.destination = url.href;
			if (entry.result?.kind === "thread") entry.result = {
				...entry.result,
				thread: {
					...entry.result.thread,
					target: hash.slice(4)
				}
			};
			state.value = {
				...state.value,
				destination: entry.destination,
				result: entry.result
			};
			nextTick().then(() => view?.restore(null, hash.slice(4), entry.selection));
			host.replace(entry.key);
			persist();
		}
		function restoreHistory(key) {
			if (writing.deferViewChange(() => restoreHistory(key))) return;
			clearDownload();
			++sequence;
			capture();
			const entry = key ? entryFor(key) : null;
			if (entry) show(entry, true);
			else state.value = {
				...state.value,
				section: "boards",
				key: key ?? "",
				loading: false,
				result: null,
				failure: null,
				missing: true,
				restored: true,
				stale: false,
				canBack: false,
				origin: null
			};
			persist();
		}
		async function start() {
			const recovered = await host.load();
			state.value = {
				...state.value,
				recoveryProblem: host.recoveryProblem()
			};
			if (recovered) {
				record = recovered;
				writing.restore(recovered.writing);
			}
			host.onPop(restoreHistory);
			const key = host.entryKey();
			if (key) {
				const entry = entryFor(key);
				if (entry) show(entry, true);
				else state.value = {
					...state.value,
					key,
					missing: true,
					restored: true
				};
				return;
			}
			const pending = record.pending;
			if (pending && entryFor(pending.entryKey)) {
				const entry = entryFor(pending.entryKey);
				const requested = routeFor(pending.destination), actual = routeFor(destination);
				const expected = requested?.url.searchParams.get("ptid") ?? requested?.url.searchParams.get("tid");
				if (actual?.kind === "thread" && (!expected || actual.url.searchParams.get("tid") === expected)) {
					const pid = requested?.url.searchParams.get("pid");
					if (pid) actual.url.hash = `pid${pid}`;
					entry.destination = actual.url.href;
					record.pending = null;
					host.replace(entry.key);
					show(entry);
					await read(entry);
					return;
				}
				record.pending = null;
				entry.result = {
					kind: "invalid",
					message: "The forum redirect returned a different thread. The requested destination is preserved for native recovery.",
					account: { kind: "unknown" },
					generation: client.generation,
					sourceURL: pending.destination
				};
				host.replace(entry.key);
				show(entry);
				persist();
				return;
			}
			const initial = new URL(destination);
			if (routeFor(destination)?.kind === "notices") {
				const entry = newEntry(destination, null);
				entry.section = "notices";
				entry.result = {
					kind: "invalid",
					account: { kind: "unknown" },
					generation: client.generation,
					sourceURL: entry.destination,
					message: "This native notice request may have marked notices read before the workspace started. No notice request has been repeated. Load notices only deliberately."
				};
				host.replace(entry.key);
				show(entry);
				persist();
				return;
			}
			if (initial.pathname === "/search.php" && (initial.searchParams.has("searchid") || initial.searchParams.has("searchsubmit") || initial.searchParams.has("srchtxt") || initial.searchParams.has("srchuname"))) {
				const entry = newEntry(routeFor(destination)?.url.href ?? `${initial.origin}/search.php?mod=forum&adv=yes`, null);
				entry.result = {
					kind: "invalid",
					account: { kind: "unknown" },
					generation: client.generation,
					sourceURL: entry.destination,
					message: "This native search request may have used credits or quota before the workspace started. No search has been repeated. Open Search to prepare a deliberate new search."
				};
				host.replace(entry.key);
				show(entry);
				persist();
				return;
			}
			const entry = newEntry(destination, null);
			host.replace(entry.key);
			show(entry);
			await read(entry);
		}
		async function refresh() {
			if (state.value.section === "notices" && state.value.result?.kind !== "thread") return loadNotices();
			if (![
				"boards",
				"search",
				"notices"
			].includes(state.value.section)) return;
			clearDownload();
			let entry = entryFor(state.value.key);
			if (!entry) {
				entry = newEntry(`${new URL(destination).origin}/forum.php`, null);
				host.replace(entry.key);
				show(entry);
			}
			if (routeFor(entry.destination)?.kind === "search") entry.destination = `${new URL(destination).origin}/search.php?mod=forum&adv=yes`;
			capture();
			await read(entry);
		}
		function openSection(section) {
			if (writing.deferViewChange(() => {
				openSection(section);
			})) return;
			writing.hide();
			if (section === "boards") return openThread(`${new URL(destination).origin}/forum.php`);
			if (state.value.section === section && (section !== "search" || state.value.result?.kind === "search" || state.value.result?.kind === "thread")) return;
			if (section === "search") return openThread(`${new URL(destination).origin}/search.php?mod=forum&adv=yes`);
			clearDownload();
			++sequence;
			capture();
			const entry = newEntry(`${new URL(destination).origin}/forum.php`, state.value.key || null);
			entry.section = section;
			host.push(entry.key);
			show(entry);
			persist();
		}
		return {
			preferences,
			openSection,
			loadNotices,
			writing,
			resetRecovery: () => {
				host.resetRecovery();
				state.value = {
					...state.value,
					recoveryProblem: null
				};
				persist();
			},
			state: readonly(state),
			download: readonly(download),
			prepareDownload,
			saveDownload,
			continueWithoutRecovery: () => {
				if (state.value.documentNavigation) host.navigateDocument(state.value.documentNavigation);
			},
			start,
			openThread,
			refresh,
			updateAnchor,
			back: () => {
				if (!writing.deferViewChange(() => host.back())) host.back();
			},
			setViewAdapter: (adapter) => {
				view = adapter;
			},
			submitSearch: async (effective = false) => {
				const entry = entryFor(state.value.key);
				if (state.value.loading || entry?.result?.kind !== "search") return;
				const { search, account } = entry.result;
				const criteria = structuredClone(effective && search.effective ? search.effective : search.edited);
				capture();
				const next = newEntry(search.form.url, entry.key);
				next.result = entry.result;
				next.account = entry.account;
				host.push(next.key);
				show(next);
				await read(next, client.search(criteria, search.form, account));
			},
			editSearch: (name, values) => {
				const entry = entryFor(state.value.key);
				if (entry?.result?.kind !== "search") return;
				const search = entry.result.search;
				entry.result = {
					...entry.result,
					search: {
						...search,
						edited: {
							...search.edited,
							[name]: values
						}
					}
				};
				state.value = {
					...state.value,
					result: entry.result
				};
				persist();
			},
			supports: (url) => routeFor(url) !== null
		};
	}
	var key = "tsdm.workspace.preferences";
	function createBrowserPreferences() {
		return {
			load() {
				try {
					const raw = localStorage.getItem(key);
					let value = null;
					try {
						value = raw === null ? null : JSON.parse(raw);
					} catch {}
					return {
						value,
						available: true
					};
				} catch {
					return {
						value: null,
						available: false
					};
				}
			},
			save(value) {
				try {
					const snapshot = JSON.stringify(value);
					localStorage.setItem(key, snapshot);
					return localStorage.getItem(key) === snapshot;
				} catch {
					return false;
				}
			}
		};
	}
	function createContext(providerComponentName, contextName) {
		const symbolDescription = typeof providerComponentName === "string" && !contextName ? `${providerComponentName}Context` : contextName;
		const injectionKey = Symbol(symbolDescription);
		const injectContext = (fallback) => {
			const context = inject(injectionKey, fallback);
			if (context) return context;
			if (context === null) return context;
			throw new Error(`Injection \`${injectionKey.toString()}\` not found. Component must be used within ${Array.isArray(providerComponentName) ? `one of the following components: ${providerComponentName.join(", ")}` : `\`${providerComponentName}\``}`);
		};
		const provideContext = (contextValue) => {
			provide(injectionKey, contextValue);
			return contextValue;
		};
		return [injectContext, provideContext];
	}
	function getActiveElement() {
		let activeElement = document.activeElement;
		if (activeElement == null) return null;
		while (activeElement != null && activeElement.shadowRoot != null && activeElement.shadowRoot.activeElement != null) activeElement = activeElement.shadowRoot.activeElement;
		return activeElement;
	}
	function handleAndDispatchCustomEvent(name, handler, detail) {
		const target = detail.originalEvent.target;
		const event = new CustomEvent(name, {
			bubbles: false,
			cancelable: true,
			detail
		});
		if (handler) target.addEventListener(name, handler, { once: true });
		target.dispatchEvent(event);
	}
	function tryOnScopeDispose(fn, failSilently) {
		if (getCurrentScope()) {
			onScopeDispose(fn, failSilently);
			return true;
		}
		return false;
	}
	function createGlobalState(stateFactory) {
		let initialized = false;
		let state;
		const scope = effectScope(true);
		return ((...args) => {
			if (!initialized) {
				state = scope.run(() => stateFactory(...args));
				initialized = true;
			}
			return state;
		});
	}
	var isClient = typeof window !== "undefined" && typeof document !== "undefined";
	typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope;
	var isDef = (val) => typeof val !== "undefined";
	var toString = Object.prototype.toString;
	var isObject = (val) => toString.call(val) === "[object Object]";
	var isIOS = getIsIOS();
	function getIsIOS() {
		var _window, _window2, _window3;
		return isClient && !!((_window = window) === null || _window === void 0 || (_window = _window.navigator) === null || _window === void 0 ? void 0 : _window.userAgent) && (/iP(?:ad|hone|od)/.test(window.navigator.userAgent) || ((_window2 = window) === null || _window2 === void 0 || (_window2 = _window2.navigator) === null || _window2 === void 0 ? void 0 : _window2.maxTouchPoints) > 2 && /iPad|Macintosh/.test((_window3 = window) === null || _window3 === void 0 ? void 0 : _window3.navigator.userAgent));
	}
	function toArray(value) {
		return Array.isArray(value) ? value : [value];
	}
	function getLifeCycleTarget(target) {
		return target || getCurrentInstance();
	}
	function createSharedComposable(composable) {
		if (!isClient) return composable;
		let subscribers = 0;
		let state;
		let scope;
		const dispose = () => {
			subscribers -= 1;
			if (scope && subscribers <= 0) {
				scope.stop();
				state = void 0;
				scope = void 0;
			}
		};
		return ((...args) => {
			subscribers += 1;
			if (!scope) {
				scope = effectScope(true);
				state = scope.run(() => composable(...args));
			}
			tryOnScopeDispose(dispose);
			return state;
		});
	}
	function tryOnBeforeUnmount(fn, target) {
		if (getLifeCycleTarget(target)) onBeforeUnmount(fn, target);
	}
	function watchImmediate(source, cb, options) {
		return watch(source, cb, {
			...options,
			immediate: true
		});
	}
	var defaultWindow = isClient ? window : void 0;
	isClient && window.document;
	isClient && window.navigator;
	isClient && window.location;
	function unrefElement(elRef) {
		var _$el;
		const plain = toValue(elRef);
		return (_$el = plain === null || plain === void 0 ? void 0 : plain.$el) !== null && _$el !== void 0 ? _$el : plain;
	}
	function useEventListener(...args) {
		const register = (el, event, listener, options) => {
			el.addEventListener(event, listener, options);
			return () => el.removeEventListener(event, listener, options);
		};
		const firstParamTargets = computed(() => {
			const test = toArray(toValue(args[0])).filter((e) => e != null);
			return test.every((e) => typeof e !== "string") ? test : void 0;
		});
		return watchImmediate(() => {
			var _firstParamTargets$va, _firstParamTargets$va2;
			return [
				(_firstParamTargets$va = (_firstParamTargets$va2 = firstParamTargets.value) === null || _firstParamTargets$va2 === void 0 ? void 0 : _firstParamTargets$va2.map((e) => unrefElement(e))) !== null && _firstParamTargets$va !== void 0 ? _firstParamTargets$va : [defaultWindow].filter((e) => e != null),
				toArray(toValue(firstParamTargets.value ? args[1] : args[0])),
				toArray(unref(firstParamTargets.value ? args[2] : args[1])),
				toValue(firstParamTargets.value ? args[3] : args[2])
			];
		}, ([raw_targets, raw_events, raw_listeners, raw_options], _, onCleanup) => {
			if (!(raw_targets === null || raw_targets === void 0 ? void 0 : raw_targets.length) || !(raw_events === null || raw_events === void 0 ? void 0 : raw_events.length) || !(raw_listeners === null || raw_listeners === void 0 ? void 0 : raw_listeners.length)) return;
			const optionsClone = isObject(raw_options) ? { ...raw_options } : raw_options;
			const cleanups = raw_targets.flatMap((el) => raw_events.flatMap((event) => raw_listeners.map((listener) => register(el, event, listener, optionsClone))));
			onCleanup(() => {
				cleanups.forEach((fn) => fn());
			});
		}, { flush: "post" });
	}
	function useMounted() {
		const isMounted = shallowRef(false);
		const instance = getCurrentInstance();
		if (instance) onMounted(() => {
			isMounted.value = true;
		}, instance);
		return isMounted;
	}
	function createKeyPredicate(keyFilter) {
		if (typeof keyFilter === "function") return keyFilter;
		else if (typeof keyFilter === "string") return (event) => event.key === keyFilter;
		else if (Array.isArray(keyFilter)) return (event) => keyFilter.includes(event.key);
		return () => true;
	}
	function onKeyStroke(...args) {
		let key;
		let handler;
		let options = {};
		if (args.length === 3) {
			key = args[0];
			handler = args[1];
			options = args[2];
		} else if (args.length === 2) if (typeof args[1] === "object") {
			key = true;
			handler = args[0];
			options = args[1];
		} else {
			key = args[0];
			handler = args[1];
		}
		else {
			key = true;
			handler = args[0];
		}
		const { target = defaultWindow, eventName = "keydown", passive = false, dedupe = false } = options;
		const predicate = createKeyPredicate(key);
		const listener = (e) => {
			if (e.repeat && toValue(dedupe)) return;
			if (predicate(e)) handler(e);
		};
		return useEventListener(target, eventName, listener, passive);
	}
	function cloneFnJSON(source) {
		return JSON.parse(JSON.stringify(source));
	}
	function useVModel(props, key, emit, options = {}) {
		var _vm$$emit, _vm$proxy;
		const { clone = false, passive = false, eventName, deep = false, defaultValue, shouldEmit } = options;
		const vm = getCurrentInstance();
		const _emit = emit || (vm === null || vm === void 0 ? void 0 : vm.emit) || (vm === null || vm === void 0 || (_vm$$emit = vm.$emit) === null || _vm$$emit === void 0 ? void 0 : _vm$$emit.bind(vm)) || (vm === null || vm === void 0 || (_vm$proxy = vm.proxy) === null || _vm$proxy === void 0 || (_vm$proxy = _vm$proxy.$emit) === null || _vm$proxy === void 0 ? void 0 : _vm$proxy.bind(vm === null || vm === void 0 ? void 0 : vm.proxy));
		let event = eventName;
		if (!key) key = "modelValue";
		event = event || `update:${key.toString()}`;
		const cloneFn = (val) => !clone ? val : typeof clone === "function" ? clone(val) : cloneFnJSON(val);
		const getValue = () => isDef(props[key]) ? cloneFn(props[key]) : defaultValue;
		const triggerEmit = (value) => {
			if (shouldEmit) {
				if (shouldEmit(value)) _emit(event, value);
			} else _emit(event, value);
		};
		if (passive) {
			const proxy = ref(getValue());
			let isUpdating = false;
			watch(() => props[key], (v) => {
				if (!isUpdating) {
					isUpdating = true;
					proxy.value = cloneFn(v);
					nextTick(() => isUpdating = false);
				}
			});
			watch(proxy, (v) => {
				if (!isUpdating && (v !== props[key] || deep)) triggerEmit(v);
			}, { deep });
			return proxy;
		} else return computed({
			get() {
				return getValue();
			},
			set(value) {
				triggerEmit(value);
			}
		});
	}
	function renderSlotFragments(children) {
		if (!children) return [];
		return children.flatMap((child) => {
			if (child.type === Fragment) return renderSlotFragments(child.children);
			return [child];
		});
	}
	var [injectConfigProviderContext, provideConfigProviderContext] = createContext("ConfigProvider");
	var locks = new WeakMap();
	function acquireBodyPointerEvents(doc, owner) {
		let lock = locks.get(doc);
		if (!lock) {
			lock = {
				owners: new Set(),
				original: doc.body.style.pointerEvents
			};
			locks.set(doc, lock);
		}
		lock.owners.add(owner);
		doc.body.style.pointerEvents = "none";
	}
	function releaseBodyPointerEvents(doc, owner) {
		const lock = locks.get(doc);
		if (!lock?.owners.delete(owner)) return;
		if (lock.owners.size === 0) {
			locks.delete(doc);
			doc.body.style.pointerEvents = lock.original;
		}
	}
	function isPlainObject(value) {
		if (value === null || typeof value !== "object") return false;
		const prototype = Object.getPrototypeOf(value);
		if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) return false;
		if (Symbol.iterator in value) return false;
		if (Symbol.toStringTag in value) return Object.prototype.toString.call(value) === "[object Module]";
		return true;
	}
	function _defu(baseObject, defaults, namespace = ".", merger) {
		if (!isPlainObject(defaults)) return _defu(baseObject, {}, namespace, merger);
		const object = { ...defaults };
		for (const key of Object.keys(baseObject)) {
			if (key === "__proto__" || key === "constructor") continue;
			const value = baseObject[key];
			if (value === null || value === void 0) continue;
			if (merger && merger(object, key, value, namespace)) continue;
			if (Array.isArray(value) && Array.isArray(object[key])) object[key] = [...value, ...object[key]];
			else if (isPlainObject(value) && isPlainObject(object[key])) object[key] = _defu(value, object[key], (namespace ? `${namespace}.` : "") + key.toString(), merger);
			else object[key] = value;
		}
		return object;
	}
	function createDefu(merger) {
		return (...arguments_) => arguments_.reduce((p, c) => _defu(p, c, "", merger), {});
	}
	var defu = createDefu();
	var pointerEventsOwner = Symbol("useBodyScrollLock");
	var useBodyLockStackCount = createSharedComposable(() => {
		const map = ref(new Map());
		const initialOverflow = ref();
		const locked = computed(() => {
			for (const value of map.value.values()) if (value) return true;
			return false;
		});
		const context = injectConfigProviderContext({ scrollBody: ref(true) });
		let stopTouchMoveListener = null;
		const resetBodyStyle = () => {
			document.body.style.paddingRight = "";
			document.body.style.marginRight = "";
			releaseBodyPointerEvents(document, pointerEventsOwner);
			document.documentElement.style.removeProperty("--scrollbar-width");
			document.body.style.overflow = initialOverflow.value ?? "";
			isIOS && stopTouchMoveListener?.();
			initialOverflow.value = void 0;
		};
		watch(locked, (val, oldVal) => {
			if (!isClient) return;
			if (!val) {
				if (oldVal) resetBodyStyle();
				return;
			}
			if (initialOverflow.value === void 0) initialOverflow.value = document.body.style.overflow;
			const verticalScrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
			const defaultConfig = {
				padding: verticalScrollbarWidth,
				margin: 0
			};
			const config = context.scrollBody?.value ? typeof context.scrollBody.value === "object" ? defu({
				padding: context.scrollBody.value.padding === true ? verticalScrollbarWidth : context.scrollBody.value.padding,
				margin: context.scrollBody.value.margin === true ? verticalScrollbarWidth : context.scrollBody.value.margin
			}, defaultConfig) : defaultConfig : {
				padding: 0,
				margin: 0
			};
			if (verticalScrollbarWidth > 0) {
				document.body.style.paddingRight = typeof config.padding === "number" ? `${config.padding}px` : String(config.padding);
				document.body.style.marginRight = typeof config.margin === "number" ? `${config.margin}px` : String(config.margin);
				document.documentElement.style.setProperty("--scrollbar-width", `${verticalScrollbarWidth}px`);
				document.body.style.overflow = "hidden";
			}
			if (isIOS) stopTouchMoveListener = useEventListener(document, "touchmove", (e) => preventDefault(e), { passive: false });
			nextTick(() => {
				if (!locked.value) return;
				acquireBodyPointerEvents(document, pointerEventsOwner);
				document.body.style.overflow = "hidden";
			});
		}, {
			immediate: true,
			flush: "sync"
		});
		return map;
	});
	function useBodyScrollLock(initialState) {
		const id = Math.random().toString(36).substring(2, 7);
		const map = useBodyLockStackCount();
		map.value.set(id, initialState ?? false);
		const locked = computed({
			get: () => map.value.get(id) ?? false,
			set: (value) => map.value.set(id, value)
		});
		tryOnBeforeUnmount(() => {
			map.value.delete(id);
		});
		return locked;
	}
	function checkOverflowScroll(ele) {
		const style = window.getComputedStyle(ele);
		if (style.overflowX === "scroll" || style.overflowY === "scroll" || style.overflowX === "auto" && ele.clientWidth < ele.scrollWidth || style.overflowY === "auto" && ele.clientHeight < ele.scrollHeight) return true;
		else {
			const parent = ele.parentNode;
			if (!(parent instanceof Element) || parent.tagName === "BODY") return false;
			return checkOverflowScroll(parent);
		}
	}
	function preventDefault(rawEvent) {
		const e = rawEvent || window.event;
		const _target = e.target;
		if (_target instanceof Element && checkOverflowScroll(_target)) return false;
		if (e.touches.length > 1) return true;
		if (e.preventDefault && e.cancelable) e.preventDefault();
		return false;
	}
	function useEmitAsProps(emit) {
		const vm = getCurrentInstance();
		const events = vm?.type.emits;
		const result = {};
		if (!events?.length) console.warn(`No emitted event found. Please check component: ${vm?.type.__name}`);
		events?.forEach((ev) => {
			result[toHandlerKey(camelize$1(ev))] = (...arg) => emit(ev, ...arg);
		});
		return result;
	}
	function useForwardExpose() {
		const instance = getCurrentInstance();
		const currentRef = ref();
		const currentElement = computed(() => resolveCurrentElement());
		onUpdated(() => {
			if (currentElement.value !== resolveCurrentElement()) triggerRef(currentRef);
		});
		function resolveCurrentElement() {
			return currentRef.value && "$el" in currentRef.value && ["#text", "#comment"].includes(currentRef.value.$el.nodeName) ? currentRef.value.$el.nextElementSibling : unrefElement(currentRef);
		}
		const localExpose = Object.assign({}, instance.exposed);
		const ret = {};
		for (const key in instance.props) Object.defineProperty(ret, key, {
			enumerable: true,
			configurable: true,
			get: () => instance.props[key]
		});
		if (Object.keys(localExpose).length > 0) for (const key in localExpose) Object.defineProperty(ret, key, {
			enumerable: true,
			configurable: true,
			get: () => localExpose[key]
		});
		Object.defineProperty(ret, "$el", {
			enumerable: true,
			configurable: true,
			get: () => instance.vnode.el
		});
		instance.exposed = ret;
		function forwardRef(ref$1) {
			currentRef.value = ref$1;
			if (!ref$1) return;
			Object.defineProperty(ret, "$el", {
				enumerable: true,
				configurable: true,
				get: () => ref$1 instanceof Element ? ref$1 : ref$1.$el
			});
			if (!(ref$1 instanceof Element) && !Object.hasOwn(ref$1, "$el")) {
				const childExposed = ref$1.$.exposed;
				const merged = Object.assign({}, ret);
				for (const key in childExposed) Object.defineProperty(merged, key, {
					enumerable: true,
					configurable: true,
					get: () => childExposed[key]
				});
				instance.exposed = merged;
			}
		}
		return {
			forwardRef,
			currentRef,
			currentElement
		};
	}
	var getDefaultParent = function(originalTarget) {
		if (typeof document === "undefined") return null;
		return (Array.isArray(originalTarget) ? originalTarget[0] : originalTarget).ownerDocument.body;
	};
	var counterMap = new WeakMap();
	var uncontrolledNodes = new WeakMap();
	var markerMap = {};
	var lockCount = 0;
	var unwrapHost = function(node) {
		return node && (node.host || unwrapHost(node.parentNode));
	};
	var correctTargets = function(parent, targets) {
		return targets.map(function(target) {
			if (parent.contains(target)) return target;
			var correctedTarget = unwrapHost(target);
			if (correctedTarget && parent.contains(correctedTarget)) return correctedTarget;
			console.error("aria-hidden", target, "in not contained inside", parent, ". Doing nothing");
			return null;
		}).filter(function(x) {
			return Boolean(x);
		});
	};
	var applyAttributeToOthers = function(originalTarget, parentNode, markerName, controlAttribute) {
		var targets = correctTargets(parentNode, Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
		if (!markerMap[markerName]) markerMap[markerName] = new WeakMap();
		var markerCounter = markerMap[markerName];
		var hiddenNodes = [];
		var elementsToKeep = new Set();
		var elementsToStop = new Set(targets);
		var keep = function(el) {
			if (!el || elementsToKeep.has(el)) return;
			elementsToKeep.add(el);
			keep(el.parentNode);
		};
		targets.forEach(keep);
		var deep = function(parent) {
			if (!parent || elementsToStop.has(parent)) return;
			Array.prototype.forEach.call(parent.children, function(node) {
				if (elementsToKeep.has(node)) deep(node);
				else try {
					var attr = node.getAttribute(controlAttribute);
					var alreadyHidden = attr !== null && attr !== "false";
					var counterValue = (counterMap.get(node) || 0) + 1;
					var markerValue = (markerCounter.get(node) || 0) + 1;
					counterMap.set(node, counterValue);
					markerCounter.set(node, markerValue);
					hiddenNodes.push(node);
					if (counterValue === 1 && alreadyHidden) uncontrolledNodes.set(node, true);
					if (markerValue === 1) node.setAttribute(markerName, "true");
					if (!alreadyHidden) node.setAttribute(controlAttribute, "true");
				} catch (e) {
					console.error("aria-hidden: cannot operate on ", node, e);
				}
			});
		};
		deep(parentNode);
		elementsToKeep.clear();
		lockCount++;
		return function() {
			hiddenNodes.forEach(function(node) {
				var counterValue = counterMap.get(node) - 1;
				var markerValue = markerCounter.get(node) - 1;
				counterMap.set(node, counterValue);
				markerCounter.set(node, markerValue);
				if (!counterValue) {
					if (!uncontrolledNodes.has(node)) node.removeAttribute(controlAttribute);
					uncontrolledNodes.delete(node);
				}
				if (!markerValue) node.removeAttribute(markerName);
			});
			lockCount--;
			if (!lockCount) {
				counterMap = new WeakMap();
				counterMap = new WeakMap();
				uncontrolledNodes = new WeakMap();
				markerMap = {};
			}
		};
	};
	var hideOthers = function(originalTarget, parentNode, markerName) {
		if (markerName === void 0) markerName = "data-aria-hidden";
		var targets = Array.from(Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
		var activeParentNode = parentNode || getDefaultParent(originalTarget);
		if (!activeParentNode) return function() {
			return null;
		};
		targets.push.apply(targets, Array.from(activeParentNode.querySelectorAll("[aria-live], script")));
		return applyAttributeToOthers(targets, activeParentNode, markerName, "aria-hidden");
	};
	function useHideOthers(target) {
		let undo;
		watch(() => unrefElement(target), (el) => {
			let isInsideClosedPopover = false;
			try {
				isInsideClosedPopover = !!el?.closest("[popover]:not(:popover-open)");
			} catch {}
			if (el && !isInsideClosedPopover) undo = hideOthers(el);
			else if (undo) undo();
		});
		onUnmounted(() => {
			if (undo) undo();
		});
	}
	var count = 0;
	function useId(deterministicId, prefix = "reka") {
		if (deterministicId) return deterministicId;
		let id;
		const configProviderContext = injectConfigProviderContext({ useId: void 0 });
		if (configProviderContext.useId) id = configProviderContext.useId();
		else if ("useId" in vue_runtime_esm_bundler_exports) id = useId$1?.();
		else id = `${++count}`;
		return prefix ? `${prefix}-${id}` : id;
	}
	function useStateMachine(initialState, machine) {
		const state = ref(initialState);
		function reducer(event) {
			return machine[state.value][event] ?? state.value;
		}
		const dispatch = (event) => {
			state.value = reducer(event);
		};
		return {
			state,
			dispatch
		};
	}
	function usePresence(present, node) {
		const stylesRef = ref({});
		const prevAnimationNameRef = ref("none");
		const prevPresentRef = ref(present);
		const initialState = present.value ? "mounted" : "unmounted";
		let timeoutId;
		const ownerWindow = node.value?.ownerDocument.defaultView ?? defaultWindow;
		const { state, dispatch } = useStateMachine(initialState, {
			mounted: {
				UNMOUNT: "unmounted",
				ANIMATION_OUT: "unmountSuspended"
			},
			unmountSuspended: {
				MOUNT: "mounted",
				ANIMATION_END: "unmounted"
			},
			unmounted: { MOUNT: "mounted" }
		});
		const dispatchCustomEvent = (name) => {
			if (isClient) {
				const customEvent = new CustomEvent(name, {
					bubbles: false,
					cancelable: false
				});
				node.value?.dispatchEvent(customEvent);
			}
		};
		watch(present, async (currentPresent, prevPresent) => {
			const hasPresentChanged = prevPresent !== currentPresent;
			await nextTick();
			if (hasPresentChanged) {
				const prevAnimationName = prevAnimationNameRef.value;
				const currentAnimationName = getAnimationName(node.value);
				if (currentPresent) {
					dispatch("MOUNT");
					dispatchCustomEvent("enter");
					if (currentAnimationName === "none") dispatchCustomEvent("after-enter");
				} else if (currentAnimationName === "none" || currentAnimationName === "undefined" || stylesRef.value?.display === "none") {
					dispatch("UNMOUNT");
					dispatchCustomEvent("leave");
					dispatchCustomEvent("after-leave");
				} else if (prevPresent && prevAnimationName !== currentAnimationName) {
					dispatch("ANIMATION_OUT");
					dispatchCustomEvent("leave");
				} else {
					dispatch("UNMOUNT");
					dispatchCustomEvent("after-leave");
				}
			}
		}, { immediate: true });
		const handleAnimationEnd = (event) => {
			if (event.target !== node.value) return;
			const currentAnimationName = getAnimationName(node.value);
			const isCurrentAnimation = currentAnimationName.includes(CSS.escape(event.animationName));
			const directionName = state.value === "mounted" ? "enter" : "leave";
			if (isCurrentAnimation) {
				dispatchCustomEvent(`after-${directionName}`);
				dispatch("ANIMATION_END");
				if (!prevPresentRef.value) {
					const currentFillMode = node.value.style.animationFillMode;
					node.value.style.animationFillMode = "forwards";
					timeoutId = ownerWindow?.setTimeout(() => {
						if (node.value?.style.animationFillMode === "forwards") node.value.style.animationFillMode = currentFillMode;
					});
				}
			}
			if (currentAnimationName === "none") dispatch("ANIMATION_END");
		};
		const handleAnimationStart = (event) => {
			if (event.target === node.value) prevAnimationNameRef.value = getAnimationName(node.value);
		};
		const watcher = watch(node, (newNode, oldNode) => {
			if (newNode) {
				stylesRef.value = getComputedStyle(newNode);
				newNode.addEventListener("animationstart", handleAnimationStart);
				newNode.addEventListener("animationcancel", handleAnimationEnd);
				newNode.addEventListener("animationend", handleAnimationEnd);
			} else {
				dispatch("ANIMATION_END");
				if (timeoutId !== void 0) ownerWindow?.clearTimeout(timeoutId);
				oldNode?.removeEventListener("animationstart", handleAnimationStart);
				oldNode?.removeEventListener("animationcancel", handleAnimationEnd);
				oldNode?.removeEventListener("animationend", handleAnimationEnd);
			}
		}, { immediate: true });
		const stateWatcher = watch(state, () => {
			const currentAnimationName = getAnimationName(node.value);
			prevAnimationNameRef.value = state.value === "mounted" ? currentAnimationName : "none";
		});
		onUnmounted(() => {
			watcher();
			stateWatcher();
			if (node.value) {
				node.value.removeEventListener("animationstart", handleAnimationStart);
				node.value.removeEventListener("animationcancel", handleAnimationEnd);
				node.value.removeEventListener("animationend", handleAnimationEnd);
			}
			if (timeoutId !== void 0) ownerWindow?.clearTimeout(timeoutId);
		});
		return { isPresent: computed(() => ["mounted", "unmountSuspended"].includes(state.value)) };
	}
	function getAnimationName(node) {
		return node ? getComputedStyle(node).animationName || "none" : "none";
	}
	var Presence_default = defineComponent({
		name: "Presence",
		props: {
			present: {
				type: Boolean,
				required: true
			},
			forceMount: { type: Boolean }
		},
		slots: {},
		setup(props, { slots, expose }) {
			const { present, forceMount } = toRefs(props);
			const node = ref();
			const { isPresent } = usePresence(present, node);
			expose({ present: isPresent });
			let children = slots.default({ present: isPresent.value });
			children = renderSlotFragments(children || []);
			const instance = getCurrentInstance();
			if (children && children?.length > 1) {
				const componentName = instance?.parent?.type.name ? `<${instance.parent.type.name} />` : "component";
				throw new Error([
					`Detected an invalid children for \`${componentName}\` for  \`Presence\` component.`,
					"",
					"Note: Presence works similarly to `v-if` directly, but it waits for animation/transition to finished before unmounting. So it expect only one direct child of valid VNode type.",
					"You can apply a few solutions:",
					["Provide a single child element so that `presence` directive attach correctly.", "Ensure the first child is an actual element instead of a raw text node or comment node."].map((line) => `  - ${line}`).join("\n")
				].join("\n"));
			}
			return () => {
				if (forceMount.value || present.value || isPresent.value) return h(slots.default({ present: isPresent.value })[0], { ref: (v) => {
					const el = unrefElement(v);
					if (typeof el?.hasAttribute === "undefined") return el;
					if (el?.hasAttribute("data-reka-popper-content-wrapper")) node.value = el.firstElementChild;
					else node.value = el;
					return el;
				} });
				else return null;
			};
		}
	});
	var Slot = defineComponent({
		name: "PrimitiveSlot",
		inheritAttrs: false,
		setup(_, { attrs, slots }) {
			return () => {
				if (!slots.default) return null;
				const children = renderSlotFragments(slots.default());
				const firstNonCommentChildrenIndex = children.findIndex((child) => child.type !== Comment);
				if (firstNonCommentChildrenIndex === -1) return children;
				const firstNonCommentChildren = children[firstNonCommentChildrenIndex];
				delete firstNonCommentChildren.props?.ref;
				const mergedProps = firstNonCommentChildren.props ? mergeProps(attrs, firstNonCommentChildren.props) : attrs;
				const cloned = cloneVNode({
					...firstNonCommentChildren,
					props: {}
				}, mergedProps);
				if (children.length === 1) return cloned;
				children[firstNonCommentChildrenIndex] = cloned;
				return children;
			};
		}
	});
	var SELF_CLOSING_TAGS = [
		"area",
		"img",
		"input"
	];
	var Primitive = defineComponent({
		name: "Primitive",
		inheritAttrs: false,
		props: {
			asChild: {
				type: Boolean,
				default: false
			},
			as: {
				type: [String, Object],
				default: "div"
			}
		},
		setup(props, { attrs, slots }) {
			const asTag = props.asChild ? "template" : props.as;
			if (typeof asTag === "string" && SELF_CLOSING_TAGS.includes(asTag)) return () => h(asTag, attrs);
			if (asTag !== "template") return () => h(props.as, attrs, { default: slots.default });
			return () => h(Slot, attrs, { default: slots.default });
		}
	});
	var [injectDialogRootContext, provideDialogRootContext] = createContext("DialogRoot");
	var DialogRoot_default = defineComponent({
		inheritAttrs: false,
		__name: "DialogRoot",
		props: {
			open: {
				type: Boolean,
				required: false,
				default: void 0
			},
			defaultOpen: {
				type: Boolean,
				required: false,
				default: false
			},
			modal: {
				type: Boolean,
				required: false,
				default: true
			},
			unmountOnHide: {
				type: Boolean,
				required: false,
				default: true
			}
		},
		emits: ["update:open"],
		setup(__props, { emit: __emit }) {
			const props = __props;
			const open = useVModel(props, "open", __emit, {
				defaultValue: props.defaultOpen,
				passive: props.open === void 0
			});
			const triggerElement = ref();
			const contentElement = ref();
			const { modal, unmountOnHide } = toRefs(props);
			provideDialogRootContext({
				open,
				modal,
				unmountOnHide,
				openModal: () => {
					open.value = true;
				},
				onOpenChange: (value) => {
					open.value = value;
				},
				onOpenToggle: () => {
					open.value = !open.value;
				},
				contentId: "",
				titleId: "",
				descriptionId: "",
				triggerElement,
				contentElement
			});
			return (_ctx, _cache) => {
				return renderSlot(_ctx.$slots, "default", {
					open: unref(open),
					close: () => open.value = false
				});
			};
		}
	});
	var DialogClose_default = defineComponent({
		__name: "DialogClose",
		props: {
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false,
				default: "button"
			}
		},
		setup(__props) {
			const props = __props;
			useForwardExpose();
			const rootContext = injectDialogRootContext();
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(Primitive), mergeProps(props, {
					type: __props.as === "button" ? "button" : void 0,
					onClick: _cache[0] || (_cache[0] = ($event) => unref(rootContext).onOpenChange(false))
				}), {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 16, ["type"]);
			};
		}
	});
	var POINTER_DOWN_OUTSIDE = "dismissableLayer.pointerDownOutside";
	var FOCUS_OUTSIDE = "dismissableLayer.focusOutside";
	function isElement(node) {
		if (typeof node !== "object" || node === null) return false;
		const ownerWindow = node.ownerDocument?.defaultView;
		return typeof Element !== "undefined" && node instanceof Element || !!ownerWindow && node instanceof ownerWindow.Element;
	}
	function isLayerExist(layerElement, targetElement) {
		if (!isElement(targetElement)) return false;
		if (layerElement.contains(targetElement)) return true;
		const targetLayer = targetElement.closest("[data-dismissable-layer]");
		const mainLayer = layerElement.dataset.dismissableLayer === "" ? layerElement : layerElement.querySelector("[data-dismissable-layer]");
		const nodeList = Array.from(layerElement.ownerDocument.querySelectorAll("[data-dismissable-layer]"));
		if (targetLayer && (mainLayer === targetLayer || nodeList.indexOf(mainLayer) < nodeList.indexOf(targetLayer))) return true;
		else return false;
	}
	function usePointerDownOutside(onPointerDownOutside, element, enabled = true) {
		const isPointerInsideDOMTree = ref(false);
		const handleClickRef = ref(() => {});
		watchEffect((cleanupFn) => {
			if (!isClient || !toValue(enabled)) return;
			const ownerDocument = element?.value?.ownerDocument ?? globalThis.document;
			const handlePointerDown = async (event) => {
				const target = event.target;
				if (!element?.value || !target) return;
				if (isLayerExist(element.value, target)) {
					ownerDocument.removeEventListener("click", handleClickRef.value);
					isPointerInsideDOMTree.value = false;
					return;
				}
				if (event.target && !isPointerInsideDOMTree.value) {
					const eventDetail = { originalEvent: event };
					function handleAndDispatchPointerDownOutsideEvent() {
						handleAndDispatchCustomEvent(POINTER_DOWN_OUTSIDE, onPointerDownOutside, eventDetail);
					}
					if (event.pointerType === "touch") {
						ownerDocument.removeEventListener("click", handleClickRef.value);
						handleClickRef.value = handleAndDispatchPointerDownOutsideEvent;
						ownerDocument.addEventListener("click", handleClickRef.value, { once: true });
					} else handleAndDispatchPointerDownOutsideEvent();
				} else ownerDocument.removeEventListener("click", handleClickRef.value);
				isPointerInsideDOMTree.value = false;
			};
			const timerId = window.setTimeout(() => {
				ownerDocument.addEventListener("pointerdown", handlePointerDown);
			}, 0);
			cleanupFn(() => {
				window.clearTimeout(timerId);
				ownerDocument.removeEventListener("pointerdown", handlePointerDown);
				ownerDocument.removeEventListener("click", handleClickRef.value);
			});
		});
		return { onPointerDownCapture: () => {
			if (!toValue(enabled)) return;
			isPointerInsideDOMTree.value = true;
		} };
	}
	function useFocusOutside(onFocusOutside, element, enabled = true) {
		const isFocusInsideDOMTree = ref(false);
		watchEffect((cleanupFn) => {
			if (!isClient || !toValue(enabled)) return;
			const ownerDocument = element?.value?.ownerDocument ?? globalThis.document;
			const handleFocus = async (event) => {
				if (!element?.value) return;
				await nextTick();
				await nextTick();
				const target = event.target;
				if (!element.value || !target || isLayerExist(element.value, target)) return;
				if (event.target && !isFocusInsideDOMTree.value) handleAndDispatchCustomEvent(FOCUS_OUTSIDE, onFocusOutside, { originalEvent: event });
			};
			ownerDocument.addEventListener("focusin", handleFocus);
			cleanupFn(() => ownerDocument.removeEventListener("focusin", handleFocus));
		});
		return {
			onFocusCapture: () => {
				if (!toValue(enabled)) return;
				isFocusInsideDOMTree.value = true;
			},
			onBlurCapture: () => {
				if (!toValue(enabled)) return;
				isFocusInsideDOMTree.value = false;
			}
		};
	}
	var context = reactive({
		layersRoot: new Set(),
		layersWithOutsidePointerEventsDisabled: new Set(),
		branches: new Set()
	});
	var DismissableLayer_default = defineComponent({
		__name: "DismissableLayer",
		props: {
			disableOutsidePointerEvents: {
				type: Boolean,
				required: false,
				default: false
			},
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false
			},
			present: {
				type: Boolean,
				required: false,
				default: true
			}
		},
		emits: [
			"escapeKeyDown",
			"pointerDownOutside",
			"focusOutside",
			"interactOutside",
			"dismiss"
		],
		setup(__props, { emit: __emit }) {
			const props = __props;
			const emits = __emit;
			const { forwardRef, currentElement: layerElement } = useForwardExpose();
			const ownerDocument = computed(() => layerElement.value?.ownerDocument ?? globalThis.document);
			const layers = computed(() => context.layersRoot);
			const index = computed(() => {
				return layerElement.value ? Array.from(layers.value).indexOf(layerElement.value) : -1;
			});
			const isBodyPointerEventsDisabled = computed(() => {
				return context.layersWithOutsidePointerEventsDisabled.size > 0;
			});
			const isPointerEventsEnabled = computed(() => {
				const localLayers = Array.from(layers.value);
				const [highestLayerWithOutsidePointerEventsDisabled] = [...context.layersWithOutsidePointerEventsDisabled].slice(-1);
				const highestLayerWithOutsidePointerEventsDisabledIndex = localLayers.indexOf(highestLayerWithOutsidePointerEventsDisabled);
				return index.value >= highestLayerWithOutsidePointerEventsDisabledIndex;
			});
			const pointerDownOutside = usePointerDownOutside(async (event) => {
				const isPointerDownOnBranch = [...context.branches].some((branch) => branch?.contains(event.target));
				if (!props.present || !isPointerEventsEnabled.value || isPointerDownOnBranch) return;
				emits("pointerDownOutside", event);
				emits("interactOutside", event);
				await nextTick();
				if (!event.defaultPrevented) emits("dismiss");
			}, layerElement, () => props.present);
			const focusOutside = useFocusOutside((event) => {
				const isFocusInBranch = [...context.branches].some((branch) => branch?.contains(event.target));
				if (!props.present || isFocusInBranch) return;
				emits("focusOutside", event);
				emits("interactOutside", event);
				if (!event.defaultPrevented) emits("dismiss");
			}, layerElement);
			onKeyStroke("Escape", (event) => {
				if (!props.present) return;
				if (!(index.value === layers.value.size - 1)) return;
				emits("escapeKeyDown", event);
				if (!event.defaultPrevented) emits("dismiss");
			}, { target: () => ownerDocument.value?.defaultView ?? globalThis.window });
			watch([
				layerElement,
				() => props.disableOutsidePointerEvents,
				() => props.present
			], ([element, disableOutsidePointerEvents, present], _, onCleanup) => {
				if (!element || !present) return;
				if (disableOutsidePointerEvents) {
					const doc = element.ownerDocument;
					acquireBodyPointerEvents(doc, element);
					context.layersWithOutsidePointerEventsDisabled.add(element);
					onCleanup(() => {
						context.layersWithOutsidePointerEventsDisabled.delete(element);
						releaseBodyPointerEvents(doc, element);
					});
				}
			}, { immediate: true });
			watch([layerElement, () => props.present], ([element, present], _, onCleanup) => {
				if (!element || !present) return;
				layers.value.add(element);
				onCleanup(() => {
					layers.value.delete(element);
				});
			}, { immediate: true });
			watchEffect((cleanupFn) => {
				cleanupFn(() => {
					if (!layerElement.value) return;
					layers.value.delete(layerElement.value);
					context.layersWithOutsidePointerEventsDisabled.delete(layerElement.value);
				});
			});
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(Primitive), {
					ref: unref(forwardRef),
					"as-child": __props.asChild,
					as: __props.as,
					"data-dismissable-layer": "",
					style: normalizeStyle({ pointerEvents: isBodyPointerEventsDisabled.value ? isPointerEventsEnabled.value ? "auto" : "none" : void 0 }),
					onFocusCapture: unref(focusOutside).onFocusCapture,
					onBlurCapture: unref(focusOutside).onBlurCapture,
					onPointerdownCapture: unref(pointerDownOutside).onPointerDownCapture
				}, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 8, [
					"as-child",
					"as",
					"style",
					"onFocusCapture",
					"onBlurCapture",
					"onPointerdownCapture"
				]);
			};
		}
	});
	var useFocusStackState = createGlobalState(() => {
		return ref([]);
	});
	function createFocusScopesStack() {
		const stack = useFocusStackState();
		return {
			add(focusScope) {
				const activeFocusScope = stack.value[0];
				if (focusScope !== activeFocusScope) activeFocusScope?.pause();
				stack.value = arrayRemove(stack.value, focusScope);
				stack.value.unshift(focusScope);
			},
			remove(focusScope) {
				stack.value = arrayRemove(stack.value, focusScope);
				stack.value[0]?.resume();
			}
		};
	}
	function arrayRemove(array, item) {
		const updatedArray = [...array];
		const index = updatedArray.indexOf(item);
		if (index !== -1) updatedArray.splice(index, 1);
		return updatedArray;
	}
	var AUTOFOCUS_ON_MOUNT = "focusScope.autoFocusOnMount";
	var AUTOFOCUS_ON_UNMOUNT = "focusScope.autoFocusOnUnmount";
	var EVENT_OPTIONS = {
		bubbles: false,
		cancelable: true
	};
	function containsComposed(container, node) {
		let current = node;
		while (current) {
			if (container.contains(current)) return true;
			current = current.getRootNode().host ?? null;
		}
		return false;
	}
	function focusFirst(candidates, { select = false } = {}) {
		const previouslyFocusedElement = getActiveElement();
		for (const candidate of candidates) {
			focus(candidate, { select });
			if (getActiveElement() !== previouslyFocusedElement) return true;
		}
	}
	function getTabbableEdges(container) {
		const candidates = getTabbableCandidates(container);
		return [findVisible(candidates, container), findVisible(candidates.reverse(), container)];
	}
	function getTabbableCandidates(container) {
		const nodes = [];
		const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, { acceptNode: (node) => {
			const isHiddenInput = node.tagName === "INPUT" && node.type === "hidden";
			if (node.disabled || node.hidden || isHiddenInput) return NodeFilter.FILTER_SKIP;
			return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
		} });
		while (walker.nextNode()) nodes.push(walker.currentNode);
		return nodes.sort((a, b) => {
			if (a.tabIndex === b.tabIndex) return 0;
			if (a.tabIndex === 0) return 1;
			if (b.tabIndex === 0) return -1;
			return a.tabIndex - b.tabIndex;
		});
	}
	function findVisible(elements, container) {
		for (const element of elements) if (!isHidden(element, { upTo: container })) return element;
	}
	function isHidden(node, { upTo }) {
		if (getComputedStyle(node).visibility === "hidden") return true;
		while (node) {
			if (upTo !== void 0 && node === upTo) return false;
			if (getComputedStyle(node).display === "none") return true;
			node = node.parentElement;
		}
		return false;
	}
	function isSelectableInput(element) {
		return element instanceof HTMLInputElement && "select" in element;
	}
	function focus(element, { select = false } = {}) {
		if (element && element.focus) {
			const previouslyFocusedElement = getActiveElement();
			element.focus({ preventScroll: true });
			if (element !== previouslyFocusedElement && isSelectableInput(element) && select) element.select();
		}
	}
	var FocusScope_default = defineComponent({
		__name: "FocusScope",
		props: {
			loop: {
				type: Boolean,
				required: false,
				default: false
			},
			trapped: {
				type: Boolean,
				required: false,
				default: false
			},
			present: {
				type: Boolean,
				required: false,
				default: true
			},
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false
			}
		},
		emits: ["mountAutoFocus", "unmountAutoFocus"],
		setup(__props, { emit: __emit }) {
			const props = __props;
			const emits = __emit;
			const { currentRef, currentElement } = useForwardExpose();
			const lastFocusedElementRef = ref(null);
			const focusScopesStack = createFocusScopesStack();
			const focusScope = reactive({
				paused: false,
				pause() {
					this.paused = true;
				},
				resume() {
					this.paused = false;
				}
			});
			watchEffect((cleanupFn) => {
				if (!isClient) return;
				const container = currentElement.value;
				if (!props.trapped) return;
				const ownerDocument = container?.ownerDocument ?? document;
				const root = container ? container.getRootNode() : ownerDocument;
				function handleFocusIn(event) {
					if (focusScope.paused || !container) return;
					const target = event.target;
					if (container.contains(target)) lastFocusedElementRef.value = target;
					else focus(lastFocusedElementRef.value, { select: true });
				}
				function handleFocusOut(event) {
					if (focusScope.paused || !container) return;
					const relatedTarget = event.relatedTarget;
					if (relatedTarget === null) return;
					if (!container.contains(relatedTarget)) focus(lastFocusedElementRef.value, { select: true });
				}
				function handleMutations(mutations) {
					const lastFocusedElement = lastFocusedElementRef.value;
					if (lastFocusedElement === null) return;
					if (!mutations.some((m) => m.removedNodes.length > 0)) return;
					const activeElement = getActiveElement();
					if (activeElement && container.contains(activeElement)) return;
					if (!container.contains(lastFocusedElement)) focus(container);
				}
				function handleDocumentFocusIn(event) {
					if (focusScope.paused || !container) return;
					const target = event.composedPath()[0];
					if (!containsComposed(container, target)) focus(lastFocusedElementRef.value, { select: true });
				}
				root.addEventListener("focusin", handleFocusIn);
				root.addEventListener("focusout", handleFocusOut);
				if (root !== ownerDocument) ownerDocument.addEventListener("focusin", handleDocumentFocusIn);
				const mutationObserver = new MutationObserver(handleMutations);
				if (container) mutationObserver.observe(container, {
					childList: true,
					subtree: true
				});
				cleanupFn(() => {
					root.removeEventListener("focusin", handleFocusIn);
					root.removeEventListener("focusout", handleFocusOut);
					if (root !== ownerDocument) ownerDocument.removeEventListener("focusin", handleDocumentFocusIn);
					mutationObserver.disconnect();
				});
			});
			function dispatchMountAutoFocus(container, previouslyFocusedElement) {
				const mountEvent = new CustomEvent(AUTOFOCUS_ON_MOUNT, EVENT_OPTIONS);
				const handleMountAutoFocus = (ev) => emits("mountAutoFocus", ev);
				container.addEventListener(AUTOFOCUS_ON_MOUNT, handleMountAutoFocus);
				container.dispatchEvent(mountEvent);
				container.removeEventListener(AUTOFOCUS_ON_MOUNT, handleMountAutoFocus);
				if (!mountEvent.defaultPrevented) {
					focusFirst(getTabbableCandidates(container), { select: true });
					if (getActiveElement() === previouslyFocusedElement) focus(container);
				}
			}
			watchEffect(async (cleanupFn) => {
				const container = currentElement.value;
				await nextTick();
				if (!container) return;
				if (props.present !== false) focusScopesStack.add(focusScope);
				const previouslyFocusedElement = getActiveElement();
				if (!container.contains(previouslyFocusedElement) && props.present !== false) dispatchMountAutoFocus(container, previouslyFocusedElement);
				cleanupFn(() => {
					const unmountEvent = new CustomEvent(AUTOFOCUS_ON_UNMOUNT, EVENT_OPTIONS);
					const unmountEventHandler = (ev) => {
						emits("unmountAutoFocus", ev);
					};
					container.addEventListener(AUTOFOCUS_ON_UNMOUNT, unmountEventHandler);
					container.dispatchEvent(unmountEvent);
					container.setAttribute("data-focus-scope-unmounting", "");
					setTimeout(() => {
						if (!unmountEvent.defaultPrevented) focus(previouslyFocusedElement ?? document.body, { select: true });
						container.removeEventListener(AUTOFOCUS_ON_UNMOUNT, unmountEventHandler);
						focusScopesStack.remove(focusScope);
						container.removeAttribute("data-focus-scope-unmounting");
					}, 0);
				});
			});
			watch(() => props.present, async (present, prevPresent) => {
				if (!isClient) return;
				if (present === false && prevPresent === true) {
					focusScopesStack.remove(focusScope);
					return;
				}
				if (present !== true || prevPresent !== false) return;
				focusScopesStack.add(focusScope);
				await nextTick();
				const container = currentElement.value;
				if (!container) return;
				const previouslyFocusedElement = getActiveElement();
				if (!container.contains(previouslyFocusedElement)) dispatchMountAutoFocus(container, previouslyFocusedElement);
			});
			function handleKeyDown(event) {
				if (!props.loop && !props.trapped) return;
				if (focusScope.paused) return;
				const isTabKey = event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey;
				const focusedElement = getActiveElement();
				if (isTabKey && focusedElement) {
					const container = event.currentTarget;
					const [first, last] = getTabbableEdges(container);
					if (!(first && last)) {
						if (focusedElement === container) event.preventDefault();
					} else if (!event.shiftKey && focusedElement === last) {
						event.preventDefault();
						if (props.loop) focus(first, { select: true });
					} else if (event.shiftKey && focusedElement === first) {
						event.preventDefault();
						if (props.loop) focus(last, { select: true });
					}
				}
			}
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(Primitive), {
					ref_key: "currentRef",
					ref: currentRef,
					tabindex: "-1",
					"as-child": __props.asChild,
					as: __props.as,
					onKeydown: handleKeyDown
				}, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 8, ["as-child", "as"]);
			};
		}
	});
	var SELECTION_KEYS = ["Enter", " "];
	var FIRST_KEYS = [
		"ArrowDown",
		"PageUp",
		"Home"
	];
	var LAST_KEYS = [
		"ArrowUp",
		"PageDown",
		"End"
	];
	[...FIRST_KEYS, ...LAST_KEYS];
	[...SELECTION_KEYS], [...SELECTION_KEYS];
	function getOpenState(open) {
		return open ? "open" : "closed";
	}
	var DialogContentImpl_default = defineComponent({
		__name: "DialogContentImpl",
		props: {
			forceMount: {
				type: Boolean,
				required: false
			},
			trapFocus: {
				type: Boolean,
				required: false
			},
			disableOutsidePointerEvents: {
				type: Boolean,
				required: false
			},
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false
			},
			present: {
				type: Boolean,
				required: false
			}
		},
		emits: [
			"escapeKeyDown",
			"pointerDownOutside",
			"focusOutside",
			"interactOutside",
			"openAutoFocus",
			"closeAutoFocus"
		],
		setup(__props, { emit: __emit }) {
			const props = __props;
			const emits = __emit;
			const rootContext = injectDialogRootContext();
			const { forwardRef, currentElement: contentElement } = useForwardExpose();
			rootContext.titleId ||= useId(void 0, "reka-dialog-title");
			rootContext.descriptionId ||= useId(void 0, "reka-dialog-description");
			onMounted(() => {
				rootContext.contentElement = contentElement;
				if (getActiveElement() !== document.body) rootContext.triggerElement.value = getActiveElement();
			});
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(FocusScope_default), {
					"as-child": "",
					loop: "",
					trapped: props.trapFocus,
					present: props.present,
					onMountAutoFocus: _cache[5] || (_cache[5] = ($event) => emits("openAutoFocus", $event)),
					onUnmountAutoFocus: _cache[6] || (_cache[6] = ($event) => emits("closeAutoFocus", $event))
				}, {
					default: withCtx(() => [createVNode(unref(DismissableLayer_default), mergeProps({
						id: unref(rootContext).contentId,
						ref: unref(forwardRef),
						as: __props.as,
						"as-child": __props.asChild,
						present: props.present,
						"disable-outside-pointer-events": __props.disableOutsidePointerEvents,
						role: "dialog",
						"aria-describedby": unref(rootContext).descriptionId,
						"aria-labelledby": unref(rootContext).titleId,
						"data-state": unref(getOpenState)(unref(rootContext).open.value)
					}, _ctx.$attrs, {
						onDismiss: _cache[0] || (_cache[0] = ($event) => unref(rootContext).onOpenChange(false)),
						onEscapeKeyDown: _cache[1] || (_cache[1] = ($event) => emits("escapeKeyDown", $event)),
						onFocusOutside: _cache[2] || (_cache[2] = ($event) => emits("focusOutside", $event)),
						onInteractOutside: _cache[3] || (_cache[3] = ($event) => emits("interactOutside", $event)),
						onPointerDownOutside: _cache[4] || (_cache[4] = ($event) => emits("pointerDownOutside", $event))
					}), {
						default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
						_: 3
					}, 16, [
						"id",
						"as",
						"as-child",
						"present",
						"disable-outside-pointer-events",
						"aria-describedby",
						"aria-labelledby",
						"data-state"
					])]),
					_: 3
				}, 8, ["trapped", "present"]);
			};
		}
	});
	var DialogContentModal_default = defineComponent({
		__name: "DialogContentModal",
		props: {
			forceMount: {
				type: Boolean,
				required: false
			},
			trapFocus: {
				type: Boolean,
				required: false
			},
			disableOutsidePointerEvents: {
				type: Boolean,
				required: false,
				default: true
			},
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false
			},
			present: {
				type: Boolean,
				required: true
			}
		},
		emits: [
			"escapeKeyDown",
			"pointerDownOutside",
			"focusOutside",
			"interactOutside",
			"openAutoFocus",
			"closeAutoFocus"
		],
		setup(__props, { emit: __emit }) {
			const props = __props;
			const emits = __emit;
			const rootContext = injectDialogRootContext();
			const emitsAsProps = useEmitAsProps(emits);
			const { forwardRef, currentElement } = useForwardExpose();
			useHideOthers(computed(() => props.present ? currentElement.value : void 0));
			const forwardedProps = computed(() => {
				const { present: _, ...rest } = props;
				return rest;
			});
			watch(() => props.present, (isPresent, wasPresent) => {
				if (!isPresent && wasPresent) rootContext.triggerElement.value?.focus();
			});
			return (_ctx, _cache) => {
				return openBlock(), createBlock(DialogContentImpl_default, mergeProps({
					...forwardedProps.value,
					...unref(emitsAsProps)
				}, {
					ref: unref(forwardRef),
					present: __props.present,
					"trap-focus": unref(rootContext).open.value,
					"disable-outside-pointer-events": props.disableOutsidePointerEvents,
					onCloseAutoFocus: _cache[0] || (_cache[0] = (event) => {
						if (!event.defaultPrevented) {
							event.preventDefault();
							unref(rootContext).triggerElement.value?.focus();
						}
					}),
					onPointerDownOutside: _cache[1] || (_cache[1] = (event) => {
						const originalEvent = event.detail.originalEvent;
						const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
						if (originalEvent.button === 2 || ctrlLeftClick) event.preventDefault();
					}),
					onFocusOutside: _cache[2] || (_cache[2] = (event) => {
						event.preventDefault();
					})
				}), {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 16, [
					"present",
					"trap-focus",
					"disable-outside-pointer-events"
				]);
			};
		}
	});
	var DialogContentNonModal_default = defineComponent({
		__name: "DialogContentNonModal",
		props: {
			forceMount: {
				type: Boolean,
				required: false
			},
			trapFocus: {
				type: Boolean,
				required: false
			},
			disableOutsidePointerEvents: {
				type: Boolean,
				required: false
			},
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false
			},
			present: {
				type: Boolean,
				required: true
			}
		},
		emits: [
			"escapeKeyDown",
			"pointerDownOutside",
			"focusOutside",
			"interactOutside",
			"openAutoFocus",
			"closeAutoFocus"
		],
		setup(__props, { emit: __emit }) {
			const props = __props;
			const emitsAsProps = useEmitAsProps(__emit);
			useForwardExpose();
			const rootContext = injectDialogRootContext();
			const hasInteractedOutsideRef = ref(false);
			const hasPointerDownOutsideRef = ref(false);
			const forwardedProps = computed(() => {
				const { present: _, ...rest } = props;
				return rest;
			});
			watch(() => props.present, (isPresent, wasPresent) => {
				if (!isPresent && wasPresent) {
					if (!hasInteractedOutsideRef.value) rootContext.triggerElement.value?.focus();
					hasInteractedOutsideRef.value = false;
					hasPointerDownOutsideRef.value = false;
				}
			});
			return (_ctx, _cache) => {
				return openBlock(), createBlock(DialogContentImpl_default, mergeProps({
					...forwardedProps.value,
					...unref(emitsAsProps)
				}, {
					present: __props.present,
					"trap-focus": false,
					"disable-outside-pointer-events": false,
					onCloseAutoFocus: _cache[0] || (_cache[0] = (event) => {
						if (!event.defaultPrevented) {
							if (!hasInteractedOutsideRef.value) unref(rootContext).triggerElement.value?.focus();
							event.preventDefault();
						}
						hasInteractedOutsideRef.value = false;
						hasPointerDownOutsideRef.value = false;
					}),
					onInteractOutside: _cache[1] || (_cache[1] = (event) => {
						if (!event.defaultPrevented) {
							hasInteractedOutsideRef.value = true;
							if (event.detail.originalEvent.type === "pointerdown") hasPointerDownOutsideRef.value = true;
						}
						const target = event.target;
						if (unref(rootContext).triggerElement.value?.contains(target)) event.preventDefault();
						if (event.detail.originalEvent.type === "focusin" && hasPointerDownOutsideRef.value) event.preventDefault();
					})
				}), {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 16, ["present"]);
			};
		}
	});
	var DialogContent_default = defineComponent({
		__name: "DialogContent",
		props: {
			forceMount: {
				type: Boolean,
				required: false
			},
			disableOutsidePointerEvents: {
				type: Boolean,
				required: false,
				default: void 0
			},
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false
			}
		},
		emits: [
			"escapeKeyDown",
			"pointerDownOutside",
			"focusOutside",
			"interactOutside",
			"openAutoFocus",
			"closeAutoFocus"
		],
		setup(__props, { emit: __emit }) {
			const props = __props;
			const emits = __emit;
			const rootContext = injectDialogRootContext();
			const emitsAsProps = useEmitAsProps(emits);
			const { forwardRef } = useForwardExpose();
			const staysMounted = computed(() => props.forceMount || !rootContext.unmountOnHide.value);
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(Presence_default), {
					present: unref(rootContext).open.value,
					"force-mount": staysMounted.value
				}, {
					default: withCtx(({ present }) => [unref(rootContext).modal.value ? withDirectives((openBlock(), createBlock(DialogContentModal_default, mergeProps({
						key: 0,
						ref: unref(forwardRef),
						present: staysMounted.value ? present : true
					}, {
						...props,
						...unref(emitsAsProps),
						..._ctx.$attrs
					}), {
						default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
						_: 3
					}, 16, ["present"])), [[vShow, __props.forceMount || unref(rootContext).unmountOnHide.value || present]]) : withDirectives((openBlock(), createBlock(DialogContentNonModal_default, mergeProps({
						key: 1,
						ref: unref(forwardRef),
						present: staysMounted.value ? present : true
					}, {
						...props,
						...unref(emitsAsProps),
						..._ctx.$attrs
					}), {
						default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
						_: 3
					}, 16, ["present"])), [[vShow, __props.forceMount || unref(rootContext).unmountOnHide.value || present]])]),
					_: 3
				}, 8, ["present", "force-mount"]);
			};
		}
	});
	var DialogDescription_default = defineComponent({
		__name: "DialogDescription",
		props: {
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false,
				default: "p"
			}
		},
		setup(__props) {
			const props = __props;
			useForwardExpose();
			const rootContext = injectDialogRootContext();
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(Primitive), mergeProps(props, { id: unref(rootContext).descriptionId }), {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 16, ["id"]);
			};
		}
	});
	var DialogOverlayImpl_default = defineComponent({
		__name: "DialogOverlayImpl",
		props: {
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false
			},
			present: {
				type: Boolean,
				required: false,
				default: true
			}
		},
		setup(__props) {
			const props = __props;
			const rootContext = injectDialogRootContext();
			const scrollLocked = useBodyScrollLock(props.present);
			watch(() => props.present, (val) => scrollLocked.value = val);
			useForwardExpose();
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(Primitive), {
					as: __props.as,
					"as-child": __props.asChild,
					"data-state": unref(rootContext).open.value ? "open" : "closed",
					style: { "pointer-events": "auto" },
					onPointerdown: _cache[0] || (_cache[0] = withModifiers(() => {}, [
						"left",
						"self",
						"prevent"
					]))
				}, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 8, [
					"as",
					"as-child",
					"data-state"
				]);
			};
		}
	});
	var DialogOverlay_default = defineComponent({
		__name: "DialogOverlay",
		props: {
			forceMount: {
				type: Boolean,
				required: false
			},
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false
			}
		},
		setup(__props) {
			const props = __props;
			const rootContext = injectDialogRootContext();
			const { forwardRef } = useForwardExpose();
			const staysMounted = computed(() => props.forceMount || !rootContext.unmountOnHide.value);
			return (_ctx, _cache) => {
				return unref(rootContext)?.modal.value ? (openBlock(), createBlock(unref(Presence_default), {
					key: 0,
					present: unref(rootContext).open.value,
					"force-mount": staysMounted.value
				}, {
					default: withCtx(({ present }) => [withDirectives(createVNode(DialogOverlayImpl_default, mergeProps(_ctx.$attrs, {
						ref: unref(forwardRef),
						as: __props.as,
						"as-child": __props.asChild,
						present: staysMounted.value ? present : true
					}), {
						default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
						_: 3
					}, 16, [
						"as",
						"as-child",
						"present"
					]), [[vShow, __props.forceMount || unref(rootContext).unmountOnHide.value || present]])]),
					_: 3
				}, 8, ["present", "force-mount"])) : createCommentVNode("v-if", true);
			};
		}
	});
	var Teleport_default = defineComponent({
		__name: "Teleport",
		props: {
			to: {
				type: null,
				required: false
			},
			disabled: {
				type: Boolean,
				required: false
			},
			defer: {
				type: Boolean,
				required: false
			},
			forceMount: {
				type: Boolean,
				required: false
			}
		},
		setup(__props) {
			const props = __props;
			const configContext = injectConfigProviderContext({});
			const target = computed(() => props.to ?? configContext.teleportTo?.value ?? "body");
			const isMounted = useMounted();
			return (_ctx, _cache) => {
				return unref(isMounted) || __props.forceMount ? (openBlock(), createBlock(Teleport, {
					key: 0,
					to: target.value,
					disabled: __props.disabled,
					defer: __props.defer
				}, [renderSlot(_ctx.$slots, "default")], 8, [
					"to",
					"disabled",
					"defer"
				])) : createCommentVNode("v-if", true);
			};
		}
	});
	var DialogPortal_default = defineComponent({
		__name: "DialogPortal",
		props: {
			to: {
				type: null,
				required: false
			},
			disabled: {
				type: Boolean,
				required: false
			},
			defer: {
				type: Boolean,
				required: false
			},
			forceMount: {
				type: Boolean,
				required: false
			}
		},
		setup(__props) {
			const props = __props;
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(Teleport_default), normalizeProps(guardReactiveProps(props)), {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 16);
			};
		}
	});
	var DialogTitle_default = defineComponent({
		__name: "DialogTitle",
		props: {
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false,
				default: "h2"
			}
		},
		setup(__props) {
			const props = __props;
			const rootContext = injectDialogRootContext();
			useForwardExpose();
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(Primitive), mergeProps(props, { id: unref(rootContext).titleId }), {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 16, ["id"]);
			};
		}
	});
	var DialogTrigger_default = defineComponent({
		__name: "DialogTrigger",
		props: {
			asChild: {
				type: Boolean,
				required: false
			},
			as: {
				type: null,
				required: false,
				default: "button"
			}
		},
		setup(__props) {
			const props = __props;
			const rootContext = injectDialogRootContext();
			const { forwardRef, currentElement } = useForwardExpose();
			rootContext.contentId ||= useId(void 0, "reka-dialog-content");
			onMounted(() => {
				rootContext.triggerElement.value = currentElement.value;
			});
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(Primitive), mergeProps(props, {
					ref: unref(forwardRef),
					type: __props.as === "button" ? "button" : void 0,
					"aria-haspopup": "dialog",
					"aria-expanded": unref(rootContext).open.value || false,
					"aria-controls": unref(rootContext).open.value ? unref(rootContext).contentId : void 0,
					"data-state": unref(rootContext).open.value ? "open" : "closed",
					onClick: unref(rootContext).onOpenToggle
				}), {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 16, [
					"type",
					"aria-expanded",
					"aria-controls",
					"data-state",
					"onClick"
				]);
			};
		}
	});
	var english = {
		searchOverviewLabel: "Search overview",
		searchExplanation: "Search threads or authors. Editing criteria does not run a search.",
		searchEffects: "Each deliberate search may use forum credits or quota. No search is repeated automatically.",
		forumDefault: "Forum default",
		editedSearch: "Edited criteria have not been searched.",
		searchResults: "Search results",
		noSearchMatches: "No matching threads.",
		effectiveSearch: "Effective search criteria",
		searchPages: "Search pages",
		searchNavigation: "Search navigation",
		newSearch: "New search",
		deliberateSearch: "Only deliberate submissions run a search.",
		rerunSearch: "Rerun effective search (may use credits)",
		missingSearch: "Searches are never rerun automatically. Open Search to submit again deliberately; a new search may use credits or quota.",
		attachments: "Attachments",
		download: "Download",
		saveFile: "Save file",
		fileDownload: "File download",
		settings: "Settings",
		settingsDescription: "Changes preview and save immediately.",
		textSize: "Text size",
		compact: "Compact",
		default: "Default",
		spacing: "spacing",
		reset: "Reset to 100%",
		close: "Close",
		theme: "Color theme",
		language: "Interface language",
		storageUnavailable: "Preferences are available for this page only. Storage is unavailable; changes may not survive reload.",
		about: "About this workspace",
		aboutDescription: "TSDM Workspace 0.4.0. Reading uses your current forum account.",
		nativeHelp: "For unsupported content or verification, continue at the same destination in the native forum.",
		snapshotMember: "Snapshot from {value}",
		snapshotGuest: "Snapshot from guest browsing",
		signedIn: "Signed in as {value}",
		guest: "Browsing as a guest",
		accountUnknown: "Account not yet confirmed",
		actions: "Thread actions",
		allBoards: "All boards",
		back: "Back",
		refresh: "Refresh",
		refreshThread: "Refresh thread",
		native: "Continue in native forum",
		boardNavigation: "Board navigation",
		chooseBoard: "Choose a board",
		recoveryUnavailable: "Refresh recovery unavailable. This tab keeps navigation while the page remains open.",
		snapshotUnavailable: "This navigation snapshot is unavailable.",
		snapshotReload: "Reload explicitly to request the destination again. If its saved context is unavailable, Reload opens Boards.",
		reload: "Reload",
		returnUnavailable: "Return recovery could not be saved. Continue only if you accept losing this return snapshot.",
		continueWithoutRecovery: "Continue without return recovery",
		restored: "Restored snapshot — account and content have not been rechecked.",
		stale: "Previous results are stale.",
		loading: "Loading…",
		mainDestinations: "Main destinations",
		sectionNavigation: "Section navigation",
		boards: "Boards",
		search: "Search",
		saved: "Saved",
		notices: "Notices",
		drafts: "Drafts",
		browseBoards: "Browse boards",
		boardsNavigation: "Boards navigation",
		boardsOverview: "Boards overview",
		chooseBoardDescription: "Choose a board to read its threads.",
		directoryPages: "Directory pages",
		threadResults: "Thread results",
		subordinateBoards: "Subordinate boards",
		boardFilters: "Board filters",
		criteria: "Effective criteria",
		page: "Page",
		pinned: "Pinned",
		moved: "Moved",
		replies: "replies",
		views: "views",
		lastReply: "Last reply to {value}",
		boardPages: "Board pages",
		threadReading: "Thread reading",
		thread: "THREAD",
		threadFilters: "Thread filters",
		missingPost: "Requested post {value} is missing from this page.",
		post: "Post",
		floor: "Floor",
		unknown: "unknown",
		pages: "Pages",
		contentUnavailable: "Content unavailable",
		chooseThread: "Choose a thread",
		chooseThreadDescription: "Read complete posts, follow exact replies, and return to this result page.",
		searchHeading: "Search threads or authors",
		savedHeading: "Saved boards and threads",
		noticesHeading: "Load notices deliberately",
		noticesOverviewLabel: "Notices overview",
		loadNotices: "Load notices",
		refreshNotices: "Refresh notices",
		noticeEffects: "Every load, refresh, category and page request can mark notices read on the server. Failed loading can still have effects.",
		noticeCategories: "Notice categories",
		noticePages: "Notice pages",
		noticeUnreadObserved: "Returned unread indicator: {value}. Current unread state may already have changed.",
		noticeUnreadAbsent: "No unread indicator was returned. The current unread count is unknown.",
		noticeUnreadUnknown: "The returned unread indicator could not be interpreted. The current unread count is unknown.",
		deferredNotices: "Private messages, broadcasts and native activity actions continue in the forum. Standard social-activity notices are included in the list.",
		nativePM: "Private messages and broadcasts — continue in native forum",
		nativeNotices: "Notice actions — continue in native forum",
		draftsHeading: "Forum drafts",
		searchOverview: "Search threads or authors in the native forum.",
		savedOverview: "View your saved boards and threads in the native forum.",
		noticesOverview: "Opening this overview makes no notice request. Notices are loaded only by your deliberate action; there is no background polling.",
		draftsOverview: "View and resume your forum drafts in the native forum.",
		savedBoards: "Boards",
		savedThreads: "Threads",
		searchScope: "Thread and author criteria",
		noticesScope: "Reply, mention, system and activity notices",
		draftsScope: "Saved forum drafts",
		newThread: "New thread",
		returnWriting: "Return to writing",
		preparingForm: "Preparing current form…",
		replaceWritingWarning: "Another writing context is already retained. Replacing it discards local changes; existing forum content and uploads are unchanged.",
		returnOriginal: "Return",
		discardPrepare: "Discard local changes and prepare",
		writingContext: "Writing context",
		finishComposition: "Finish the current input composition to change views.",
		newThreadIn: "New thread in {value}",
		writingAs: "Writing as {value}",
		writingBoard: "Board {value}",
		writingPaused: "Sending paused — the current account is expired, changed or not yet rechecked. Original writing remains bound to {value}.",
		unresolvedAttachments: "Attachment references need reattachment or explicit removal: {value}. Source is preserved; uploads are not transferred.",
		checkWriting: "Check current account and form",
		prepareTextCopy: "Prepare text copy for current account",
		copyWritingPrompt: "Replace writing from {value} with a text copy for {account}?",
		copyWritingLimits: "Only title and complete source are copied. Category, permissions and credit settings come from the fresh form; uploads and ownership are not transferred.",
		keepWriting: "Keep original writing",
		replaceTextCopy: "Replace with text copy",
		localWriting: "Local writing only. Nothing has been submitted or saved as a forum draft.",
		writingRecoveryUnavailable: "Refresh recovery unavailable. Live writing remains here; unacknowledged changes may be lost on reload.",
		writingAcknowledged: "Recovery acknowledged for revision {value} in this browser page session. Restoration depends on the browser.",
		writingPending: "Recovery pending for revision {value}; acknowledged revision {acknowledged}.",
		writingTitle: "Title",
		writingCategory: "Category",
		completeSource: "Complete source",
		currentFormOptions: "Current form options",
		returnReading: "Return to reading",
		openConfirmedThread: "Open confirmed thread",
		normalizedStoredPrice: "Stored price: 0 (normalized from an empty submitted value).",
		deliveryUnverified: "Delivery unverified",
		effectNotRequested: "Not requested",
		effectNotIncluded: "Not included in the command",
		legacyStoredConfirmation: "Previous stored confirmation. This legacy result has no separate normalization or creation-effect evidence.",
		candidateThreadURL: "Candidate thread URL",
		checkThreadResult: "Check result",
		prepareAnotherAttempt: "Prepare another attempt",
		duplicatePublicationWarning: "The earlier attempt remains unknown. Sending again may create a duplicate thread and repeat its effects. This cannot undo the first attempt.",
		keepOriginalAttempt: "Keep original attempt",
		acceptDuplicateReview: "Accept duplicate risk and review",
		reviewPublication: "Review publication",
		publicationReview: "Review revision {value} for {account} in {board}. Publishing may create a public thread with the selected price and read permission.",
		publishThread: "Publish thread",
		incompatibleRecovery: "Stored recovery data is incompatible or malformed. It is retained without overwriting; new changes cannot be recovered until you resolve it.",
		inspectRecovery: "Inspect retained recovery data",
		retainedRecovery: "Retained recovery data",
		resetRecovery: "Reset incompatible recovery",
		discardRecoveryWarning: "Copy any needed source before discarding this local recovery record. This cannot restore its old writing afterward.",
		keepRecovery: "Keep recovery record",
		discardRecovery: "Discard incompatible recovery record",
		readRecoveryRefused: "Browser page-session storage could not be read. Live work remains available; refresh recovery is unavailable."
	};
	var simplified = {
		searchOverviewLabel: "搜索总览",
		searchExplanation: "搜索主题或作者。编辑条件不会执行搜索。",
		searchEffects: "每次主动搜索都可能消耗论坛积分或额度。系统不会自动重复搜索。",
		forumDefault: "论坛默认值",
		editedSearch: "尚未使用编辑后的条件搜索。",
		searchResults: "搜索结果",
		noSearchMatches: "没有匹配的主题。",
		effectiveSearch: "当前有效搜索条件",
		searchPages: "搜索结果分页",
		searchNavigation: "搜索导航",
		newSearch: "新搜索",
		deliberateSearch: "只有主动提交才会执行搜索。",
		rerunSearch: "重新执行有效搜索（可能消耗积分）",
		missingSearch: "系统绝不会自动重新搜索。请打开搜索并主动再次提交；新搜索可能消耗积分或额度。",
		attachments: "附件",
		download: "下载",
		saveFile: "保存文件",
		fileDownload: "文件下载",
		settings: "设置",
		settingsDescription: "更改会立即预览并保存。",
		textSize: "文字大小",
		compact: "紧凑",
		default: "默认",
		spacing: "间距",
		reset: "重设为 100%",
		close: "关闭",
		theme: "颜色主题",
		language: "界面语言",
		storageUnavailable: "偏好设置仅在当前页面有效。存储不可用；重新加载后可能无法保留更改。",
		about: "关于此工作区",
		aboutDescription: "TSDM 工作区 0.4.0。阅读使用当前论坛账号。",
		nativeHelp: "如需查看不支持的内容或完成验证，请在原版论坛中继续访问同一目标。",
		snapshotMember: "来自 {value} 的快照",
		snapshotGuest: "游客浏览快照",
		signedIn: "当前登录：{value}",
		guest: "正在以游客身份浏览",
		accountUnknown: "尚未确认账号",
		actions: "主题操作",
		allBoards: "全部版块",
		back: "返回",
		refresh: "刷新",
		refreshThread: "刷新主题",
		native: "在原版论坛中继续",
		boardNavigation: "版块导航",
		chooseBoard: "选择版块",
		recoveryUnavailable: "刷新恢复不可用。页面保持打开时，此标签页仍会保留导航。",
		snapshotUnavailable: "此导航快照不可用。",
		snapshotReload: "请主动重新加载以再次请求目标。若保存的上下文不可用，将打开版块总览。",
		reload: "重新加载",
		returnUnavailable: "无法保存返回快照。仅在接受丢失此返回快照时继续。",
		continueWithoutRecovery: "不保留返回快照并继续",
		restored: "已恢复快照 — 尚未重新检查账号与内容。",
		stale: "先前的结果已过时。",
		loading: "正在加载…",
		mainDestinations: "主要导航",
		sectionNavigation: "栏目导航",
		boards: "版块",
		search: "搜索",
		saved: "收藏",
		notices: "通知",
		drafts: "草稿",
		browseBoards: "浏览版块",
		boardsNavigation: "版块导航列表",
		boardsOverview: "版块总览",
		chooseBoardDescription: "选择版块以阅读主题。",
		directoryPages: "版块总览分页",
		threadResults: "主题列表",
		subordinateBoards: "子版块",
		boardFilters: "版块筛选",
		criteria: "当前有效条件",
		page: "第",
		pinned: "置顶",
		moved: "已移动",
		replies: "回复",
		views: "浏览",
		lastReply: "{value} 的最新回复",
		boardPages: "版块分页",
		threadReading: "主题阅读",
		thread: "主题",
		threadFilters: "主题筛选",
		missingPost: "请求的帖子 {value} 不在此页中。",
		post: "帖子",
		floor: "楼层",
		unknown: "未知",
		pages: "分页",
		contentUnavailable: "内容不可用",
		chooseThread: "选择主题",
		chooseThreadDescription: "阅读完整帖子、跳转到指定回复，并返回此结果页。",
		searchHeading: "搜索主题或作者",
		savedHeading: "收藏的版块与主题",
		noticesHeading: "主动加载通知",
		noticesOverviewLabel: "通知总览",
		loadNotices: "加载通知",
		refreshNotices: "刷新通知",
		noticeEffects: "每次加载、刷新、分类和翻页请求都可能在服务器上将通知标为已读。加载失败也可能产生影响。",
		noticeCategories: "通知分类",
		noticePages: "通知分页",
		noticeUnreadObserved: "返回的未读提示：{value}。当前未读状态可能已改变。",
		noticeUnreadAbsent: "响应没有返回未读提示。当前未读数量未知。",
		noticeUnreadUnknown: "无法识别返回的未读提示。当前未读数量未知。",
		deferredNotices: "私信、广播和原版动态操作请继续前往论坛。标准坛友互动通知包含在列表中。",
		nativePM: "私信与广播 — 前往原版论坛",
		nativeNotices: "通知操作 — 前往原版论坛",
		draftsHeading: "论坛草稿",
		searchOverview: "在原版论坛中搜索主题或作者。",
		savedOverview: "在原版论坛中查看收藏的版块与主题。",
		noticesOverview: "打开此总览不会请求通知。只有您的主动操作才会加载通知；没有后台轮询。",
		draftsOverview: "在原版论坛中查看及继续编辑论坛草稿。",
		savedBoards: "版块",
		savedThreads: "主题",
		searchScope: "主题与作者条件",
		noticesScope: "回复、提及、系统与动态通知",
		draftsScope: "已保存的论坛草稿",
		newThread: "新主题",
		returnWriting: "返回写作",
		preparingForm: "正在准备当前表单…",
		replaceWritingWarning: "已保留另一份写作内容。替换将丢弃本地更改；现有论坛内容和上传文件保持不变。",
		returnOriginal: "返回原内容",
		discardPrepare: "丢弃本地更改并准备",
		writingContext: "写作内容",
		finishComposition: "请完成当前输入组合后再切换视图。",
		newThreadIn: "在 {value} 中发表新主题",
		writingAs: "写作账号：{value}",
		writingBoard: "版块 {value}",
		writingPaused: "发送已暂停 — 当前账号已过期、已变更或尚未重新检查。原写作内容仍属于 {value}。",
		unresolvedAttachments: "附件引用需要重新附加或明确移除：{value}。源码已保留；上传文件不会转移。",
		checkWriting: "检查当前账号和表单",
		prepareTextCopy: "为当前账号准备文字副本",
		copyWritingPrompt: "将 {value} 的写作内容替换为 {account} 的文字副本？",
		copyWritingLimits: "仅复制标题和完整源码。分类、权限和积分设置来自新表单；上传文件和所有权不会转移。",
		keepWriting: "保留原写作内容",
		replaceTextCopy: "替换为文字副本",
		localWriting: "仅在本地写作。尚未提交内容或保存论坛草稿。",
		writingRecoveryUnavailable: "刷新恢复不可用。当前写作内容仍在此处；未经确认的更改可能在重新加载时丢失。",
		writingAcknowledged: "已确认此浏览器页面会话中版本 {value} 的恢复记录。能否恢复取决于浏览器。",
		writingPending: "版本 {value} 的恢复记录待确认；已确认版本 {acknowledged}。",
		writingTitle: "标题",
		writingCategory: "分类",
		completeSource: "完整源码",
		currentFormOptions: "当前表单选项",
		returnReading: "返回阅读",
		openConfirmedThread: "打开已确认的主题",
		normalizedStoredPrice: "存储售价为 0（由提交的空值规范化）。",
		deliveryUnverified: "尚未验证送达",
		effectNotRequested: "未请求",
		effectNotIncluded: "未包含在提交指令中",
		legacyStoredConfirmation: "先前的存储确认。此旧版结果没有独立的规范化或创建影响证据。",
		candidateThreadURL: "待检查的主题网址",
		checkThreadResult: "检查结果",
		prepareAnotherAttempt: "准备再次尝试",
		duplicatePublicationWarning: "先前尝试的结果仍未知。再次发送可能建立重复主题并重复其影响，而且无法撤销首次尝试。",
		keepOriginalAttempt: "保留原尝试",
		acceptDuplicateReview: "接受重复风险并检查",
		reviewPublication: "检查发布",
		publicationReview: "检查 {account} 在 {board} 的第 {value} 版。发布可能建立公开主题，并采用所选售价和阅读权限。",
		publishThread: "发布主题",
		incompatibleRecovery: "存储的恢复数据不兼容或格式错误。数据将保留而不被覆盖；解决前无法恢复新的更改。",
		inspectRecovery: "查看保留的恢复数据",
		retainedRecovery: "保留的恢复数据",
		resetRecovery: "重置不兼容的恢复记录",
		discardRecoveryWarning: "丢弃此本地恢复记录前，请复制需要的源码。之后将无法恢复原写作内容。",
		keepRecovery: "保留恢复记录",
		discardRecovery: "丢弃不兼容的恢复记录",
		readRecoveryRefused: "无法读取浏览器页面会话存储。当前内容仍可使用；刷新恢复不可用。"
	};
	var traditional = {
		searchOverviewLabel: "搜尋總覽",
		searchExplanation: "搜尋主題或作者。編輯條件不會執行搜尋。",
		searchEffects: "每次主動搜尋都可能消耗論壇積分或額度。系統不會自動重複搜尋。",
		forumDefault: "論壇預設值",
		editedSearch: "尚未使用編輯後的條件搜尋。",
		searchResults: "搜尋結果",
		noSearchMatches: "沒有相符的主題。",
		effectiveSearch: "目前有效搜尋條件",
		searchPages: "搜尋結果分頁",
		searchNavigation: "搜尋導覽",
		newSearch: "新搜尋",
		deliberateSearch: "只有主動提交才會執行搜尋。",
		rerunSearch: "重新執行有效搜尋（可能消耗積分）",
		missingSearch: "系統絕不會自動重新搜尋。請開啟搜尋並主動再次提交；新搜尋可能消耗積分或額度。",
		attachments: "附件",
		download: "下載",
		saveFile: "儲存檔案",
		fileDownload: "檔案下載",
		settings: "設定",
		settingsDescription: "變更會立即預覽並儲存。",
		textSize: "文字大小",
		compact: "緊湊",
		default: "預設",
		spacing: "間距",
		reset: "重設為 100%",
		close: "關閉",
		theme: "色彩主題",
		language: "介面語言",
		storageUnavailable: "偏好設定僅在目前頁面有效。儲存空間無法使用；重新載入後可能無法保留變更。",
		about: "關於此工作區",
		aboutDescription: "TSDM 工作區 0.4.0。閱讀使用目前論壇帳號。",
		nativeHelp: "如需查看不支援的內容或完成驗證，請在原版論壇中繼續存取同一目標。",
		snapshotMember: "來自 {value} 的快照",
		snapshotGuest: "訪客瀏覽快照",
		signedIn: "目前登入：{value}",
		guest: "正在以訪客身分瀏覽",
		accountUnknown: "尚未確認帳號",
		actions: "主題操作",
		allBoards: "全部版塊",
		back: "返回",
		refresh: "重新整理",
		refreshThread: "重新整理主題",
		native: "在原版論壇中繼續",
		boardNavigation: "版塊導覽",
		chooseBoard: "選擇版塊",
		recoveryUnavailable: "重新載入復原無法使用。頁面保持開啟時，此分頁仍會保留導覽。",
		snapshotUnavailable: "此導覽快照無法使用。",
		snapshotReload: "請主動重新載入以再次請求目標。若儲存的情境無法使用，將開啟版塊總覽。",
		reload: "重新載入",
		returnUnavailable: "無法儲存返回快照。僅在接受遺失此返回快照時繼續。",
		continueWithoutRecovery: "不保留返回快照並繼續",
		restored: "已復原快照 — 尚未重新檢查帳號與內容。",
		stale: "先前的結果已過時。",
		loading: "正在載入…",
		mainDestinations: "主要導覽",
		sectionNavigation: "欄目導覽",
		boards: "版塊",
		search: "搜尋",
		saved: "收藏",
		notices: "通知",
		drafts: "草稿",
		browseBoards: "瀏覽版塊",
		boardsNavigation: "版塊導覽清單",
		boardsOverview: "版塊總覽",
		chooseBoardDescription: "選擇版塊以閱讀主題。",
		directoryPages: "版塊總覽分頁",
		threadResults: "主題清單",
		subordinateBoards: "子版塊",
		boardFilters: "版塊篩選",
		criteria: "目前有效條件",
		page: "第",
		pinned: "置頂",
		moved: "已移動",
		replies: "回覆",
		views: "瀏覽",
		lastReply: "{value} 的最新回覆",
		boardPages: "版塊分頁",
		threadReading: "主題閱讀",
		thread: "主題",
		threadFilters: "主題篩選",
		missingPost: "請求的帖子 {value} 不在此頁中。",
		post: "帖子",
		floor: "樓層",
		unknown: "未知",
		pages: "分頁",
		contentUnavailable: "內容無法使用",
		chooseThread: "選擇主題",
		chooseThreadDescription: "閱讀完整帖子、跳轉至指定回覆，並返回此結果頁。",
		searchHeading: "搜尋主題或作者",
		savedHeading: "收藏的版塊與主題",
		noticesHeading: "主動載入通知",
		noticesOverviewLabel: "通知總覽",
		loadNotices: "載入通知",
		refreshNotices: "重新載入通知",
		noticeEffects: "每次載入、重新載入、分類和翻頁請求都可能在伺服器上將通知標為已讀。載入失敗也可能產生影響。",
		noticeCategories: "通知分類",
		noticePages: "通知分頁",
		noticeUnreadObserved: "傳回的未讀提示：{value}。目前未讀狀態可能已改變。",
		noticeUnreadAbsent: "回應沒有傳回未讀提示。目前未讀數量未知。",
		noticeUnreadUnknown: "無法識別傳回的未讀提示。目前未讀數量未知。",
		deferredNotices: "私訊、廣播和原版動態操作請繼續前往論壇。標準壇友互動通知包含在清單中。",
		nativePM: "私訊與廣播 — 前往原版論壇",
		nativeNotices: "通知操作 — 前往原版論壇",
		draftsHeading: "論壇草稿",
		searchOverview: "在原版論壇中搜尋主題或作者。",
		savedOverview: "在原版論壇中查看收藏的版塊與主題。",
		noticesOverview: "開啟此總覽不會請求通知。只有您的主動操作才會載入通知；沒有背景輪詢。",
		draftsOverview: "在原版論壇中查看及繼續編輯論壇草稿。",
		savedBoards: "版塊",
		savedThreads: "主題",
		searchScope: "主題與作者條件",
		noticesScope: "回覆、提及、系統與動態通知",
		draftsScope: "已儲存的論壇草稿",
		newThread: "新主題",
		returnWriting: "返回寫作",
		preparingForm: "正在準備目前表單…",
		replaceWritingWarning: "已保留另一份寫作內容。替換將捨棄本機變更；現有論壇內容和上傳檔案保持不變。",
		returnOriginal: "返回原內容",
		discardPrepare: "捨棄本機變更並準備",
		writingContext: "寫作內容",
		finishComposition: "請完成目前輸入組合後再切換檢視。",
		newThreadIn: "在 {value} 中發表新主題",
		writingAs: "寫作帳號：{value}",
		writingBoard: "版塊 {value}",
		writingPaused: "傳送已暫停 — 目前帳號已過期、已變更或尚未重新檢查。原寫作內容仍屬於 {value}。",
		unresolvedAttachments: "附件引用需要重新附加或明確移除：{value}。原始碼已保留；上傳檔案不會轉移。",
		checkWriting: "檢查目前帳號和表單",
		prepareTextCopy: "為目前帳號準備文字副本",
		copyWritingPrompt: "將 {value} 的寫作內容替換為 {account} 的文字副本？",
		copyWritingLimits: "僅複製標題和完整原始碼。分類、權限和積分設定來自新表單；上傳檔案和所有權不會轉移。",
		keepWriting: "保留原寫作內容",
		replaceTextCopy: "替換為文字副本",
		localWriting: "僅在本機寫作。尚未提交內容或儲存論壇草稿。",
		writingRecoveryUnavailable: "重新載入復原無法使用。目前寫作內容仍在此處；未經確認的變更可能在重新載入時遺失。",
		writingAcknowledged: "已確認此瀏覽器頁面工作階段中版本 {value} 的復原記錄。能否復原取決於瀏覽器。",
		writingPending: "版本 {value} 的復原記錄待確認；已確認版本 {acknowledged}。",
		writingTitle: "標題",
		writingCategory: "分類",
		completeSource: "完整原始碼",
		currentFormOptions: "目前表單選項",
		returnReading: "返回閱讀",
		openConfirmedThread: "開啟已確認的主題",
		normalizedStoredPrice: "儲存售價為 0（由提交的空值正規化）。",
		deliveryUnverified: "尚未驗證送達",
		effectNotRequested: "未請求",
		effectNotIncluded: "未包含在提交指令中",
		legacyStoredConfirmation: "先前的儲存確認。此舊版結果沒有獨立的正規化或建立影響證據。",
		candidateThreadURL: "待檢查的主題網址",
		checkThreadResult: "檢查結果",
		prepareAnotherAttempt: "準備再次嘗試",
		duplicatePublicationWarning: "先前嘗試的結果仍未知。再次傳送可能建立重複主題並重複其影響，而且無法撤銷首次嘗試。",
		keepOriginalAttempt: "保留原嘗試",
		acceptDuplicateReview: "接受重複風險並檢查",
		reviewPublication: "檢查發佈",
		publicationReview: "檢查 {account} 在 {board} 的第 {value} 版。發佈可能建立公開主題，並採用所選售價和閱讀權限。",
		publishThread: "發佈主題",
		incompatibleRecovery: "儲存的復原資料不相容或格式錯誤。資料將保留而不被覆寫；解決前無法復原新的變更。",
		inspectRecovery: "檢視保留的復原資料",
		retainedRecovery: "保留的復原資料",
		resetRecovery: "重設不相容的復原記錄",
		discardRecoveryWarning: "捨棄此本機復原記錄前，請複製需要的原始碼。之後將無法復原原寫作內容。",
		keepRecovery: "保留復原記錄",
		discardRecovery: "捨棄不相容的復原記錄",
		readRecoveryRefused: "無法讀取瀏覽器頁面工作階段儲存空間。目前內容仍可使用；重新載入復原無法使用。"
	};
	function strings(language) {
		return language === "zh-CN" ? simplified : language === "zh-TW" ? traditional : english;
	}
	var insert = (pattern, value) => pattern.replace("{value}", String(value));
	var descriptions = {
		"The forum reports pending moderation. Public stored source has not been confirmed.": ["论坛报告正在等待审核。尚未确认公开储存的源码。", "論壇回報正在等候審核。尚未確認公開儲存的原始碼。"],
		"The forum explicitly refused validation. Nothing is confirmed published.": ["论坛明确拒绝了验证。尚未确认发布任何内容。", "論壇明確拒絕了驗證。尚未確認發佈任何內容。"],
		"The publication outcome is uncertain. Check the original attempt before considering another send.": ["发布结果不确定。考虑再次发送前，请检查原尝试。", "發佈結果不確定。考慮再次傳送前，請檢查原嘗試。"],
		"No supported candidate thread URL is available. Enter its thread URL to check this original attempt.": ["没有可用的受支持主题网址。请输入主题网址以检查原尝试。", "沒有可用的受支援主題網址。請輸入主題網址以檢查原嘗試。"],
		"The account changed during result checking. Original writing and possible effects are retained.": ["检查结果时账号发生变化。保留原写作内容和可能产生的影响。", "檢查結果時帳號發生變更。保留原寫作內容和可能產生的影響。"],
		"The candidate thread could not be independently read. Publication remains uncertain.": ["无法独立读取待检查的主题。发布结果仍不确定。", "無法獨立讀取待檢查的主題。發佈結果仍不確定。"],
		"Candidate actor, board, title or opening-post identity did not match the submitted revision.": ["待检查主题的作者、版块、标题或首帖身份与提交版本不符。", "待檢查主題的作者、版塊、標題或首帖身分與提交版本不符。"],
		"The account changed during stored-source readback. Possible publication remains uncertain.": ["回读已储存源码时账号发生变化。可能已发布，但结果仍不确定。", "回讀已儲存原始碼時帳號發生變更。可能已發佈，但結果仍不確定。"],
		"Complete stored source or offered options did not match, or were unavailable. No confirmation is claimed.": ["完整储存源码或所提供选项不符或无法取得。尚未确认发布成功。", "完整儲存原始碼或所提供選項不符或無法取得。尚未確認發佈成功。"],
		"Independent stored-result readback failed. Publication remains uncertain; no send was repeated.": ["独立回读储存结果失败。发布结果仍不确定；没有重复发送。", "獨立回讀儲存結果失敗。發佈結果仍不確定；沒有重複傳送。"],
		"A title, complete source and valid ordinary new-thread revision are required.": ["需要标题、完整源码和有效的普通新主题版本。", "需要標題、完整原始碼和有效的普通新主題版本。"],
		"The account changed or expired during preparation. Original writing remains paused.": ["准备期间账号发生变化或已过期。原写作内容保持暂停发送。", "準備期間帳號發生變更或已過期。原寫作內容保持暫停傳送。"],
		"The current native options changed or are unavailable. Review the current form before publication; no values were reset.": ["当前原生选项已变化或无法取得。发布前请检查当前表单；没有重设任何值。", "目前原生選項已變更或無法取得。發佈前請檢查目前表單；沒有重設任何值。"],
		"The current native successful controls or required values are unsupported. Nothing was sent.": ["不支持当前原生表单的提交控件或必要值。没有发送任何内容。", "不支援目前原生表單的提交控制項或必要值。沒有傳送任何內容。"],
		"Fresh publication preparation failed. Your writing remains here.": ["重新准备发布失败。写作内容仍保留在这里。", "重新準備發佈失敗。寫作內容仍保留在這裡。"],
		"This preparation, account or attempt is stale or already active. Nothing was sent.": ["此准备、账号或尝试已失效或正在进行。没有发送任何内容。", "此準備、帳號或嘗試已失效或正在進行。沒有傳送任何內容。"],
		"The account changed or expired before send. Original writing remains retained and paused.": ["发送前账号已变化或过期。保留原写作内容并暂停发送。", "傳送前帳號已變更或過期。保留原寫作內容並暫停傳送。"],
		"The current form changed before send. Nothing was sent; review again.": ["发送前当前表单已变化。没有发送任何内容；请重新检查。", "傳送前目前表單已變更。沒有傳送任何內容；請重新檢查。"],
		"The current successful controls changed before send. Nothing was sent.": ["发送前当前表单的提交控件已变化。没有发送任何内容。", "傳送前目前表單的提交控制項已變更。沒有傳送任何內容。"],
		"The account changed while publication was in flight. It may have been accepted; no rollback or atomic account isolation is guaranteed.": ["发布请求进行期间账号发生变化。请求可能已被接受；无法保证回滚或账号的原子隔离。", "發佈請求進行期間帳號發生變更。請求可能已被接受；無法保證回滾或帳號的原子隔離。"],
		"The response was lost. The forum may have accepted this attempt. Check result; no send was repeated.": ["响应已丢失。论坛可能已接受此尝试。请检查结果；没有重复发送。", "回應已遺失。論壇可能已接受此嘗試。請檢查結果；沒有重複傳送。"],
		"Fresh preflight failed before publication was sent. Your writing is retained; review again deliberately.": ["发布发送前的重新检查失败。写作内容已保留；请主动重新检查。", "發佈傳送前的重新檢查失敗。寫作內容已保留；請主動重新檢查。"],
		"Publication or result checking is pending. Keep this context until it settles.": ["发布或结果检查正在进行。请保留此写作内容，直到操作结束。", "發佈或結果檢查正在進行。請保留此寫作內容，直到操作結束。"],
		"An earlier attempt may already exist. Check result, then explicitly accept duplicate risk before another send.": ["先前尝试可能已产生主题。再次发送前，请检查结果并明确接受重复风险。", "先前嘗試可能已產生主題。再次傳送前，請檢查結果並明確接受重複風險。"],
		"Writing changed during publication preparation. Review the current revision again.": ["准备发布期间写作内容已变化。请重新检查当前版本。", "準備發佈期間寫作內容已變更。請重新檢查目前版本。"],
		"Publication is pending. Refresh will retain it as uncertain without replay.": ["发布正在进行。刷新后将保留为不确定状态，不会重新发送。", "發佈正在進行。重新載入後將保留為不確定狀態，不會重新傳送。"],
		"Publication was not sent because recovery, writing or the account changed before send. Your source is retained.": ["由于恢复、写作内容或账号在发送前变化，发布尚未发送。源码已保留。", "由於復原、寫作內容或帳號在傳送前變更，發佈尚未傳送。原始碼已保留。"],
		"Pending publication restored as uncertain. Nothing has been replayed; check the original attempt.": ["进行中的发布已恢复为不确定状态。没有重新发送；请检查原尝试。", "進行中的發佈已復原為不確定狀態。沒有重新傳送；請檢查原嘗試。"],
		Cost: ["积分限制", "積分限制"],
		Throttle: ["搜索频率受限", "搜尋頻率受限"],
		Expired: ["搜索结果已过期", "搜尋結果已過期"],
		"This page was not offered by the current search results.": ["当前搜索结果未提供此分页。", "目前搜尋結果未提供此分頁。"],
		"A newer request replaced this search page.": ["此搜索分页已被较新的请求替代。", "此搜尋分頁已被較新的請求取代。"],
		"The current account could not be established from this search page. Review the current account before searching again deliberately.": ["无法从此搜索分页确认当前账号。再次主动搜索前，请检查当前账号。", "無法從此搜尋分頁確認目前帳號。再次主動搜尋前，請檢查目前帳號。"],
		"The account changed while reading search results. Review the current account before searching again deliberately.": ["阅读搜索结果时账号发生了变化。再次主动搜索前，请检查当前账号。", "閱讀搜尋結果時帳號發生了變更。再次主動搜尋前，請檢查目前帳號。"],
		"The returned page belongs to a different search.": ["返回的分页属于另一次搜索。", "傳回的分頁屬於另一次搜尋。"],
		"The search page could not be loaded. It has not been requested again automatically.": ["无法加载搜索分页。系统未自动再次请求此页。", "無法載入搜尋分頁。系統未自動再次請求此頁。"],
		"The search form is not from this forum.": ["此搜索表单不属于当前论坛。", "此搜尋表單不屬於目前論壇。"],
		"A newer action replaced this search.": ["此搜索已被较新的操作替代。", "此搜尋已被較新的操作取代。"],
		"The current account could not be established. Search has not been submitted.": ["无法确认当前账号。尚未提交搜索。", "無法確認目前帳號。尚未提交搜尋。"],
		"The account changed while preparing search. Review the current form and submit again deliberately.": ["准备搜索时账号发生了变化。请检查当前表单，再主动提交。", "準備搜尋時帳號發生了變更。請檢查目前表單，再主動提交。"],
		"A newer action replaced this search. The earlier request may still have had effects.": ["此搜索已被较新的操作替代。先前的请求仍可能已经产生影响。", "此搜尋已被較新的操作取代。先前的請求仍可能已經產生影響。"],
		"The current account could not be established from the search response. The request may still have used credits or quota.": ["无法从搜索响应确认当前账号。该请求仍可能已经消耗积分或额度。", "無法從搜尋回應確認目前帳號。該請求仍可能已經消耗積分或額度。"],
		"The account changed during search. Its effects are not isolated; review the current account before another deliberate search.": ["搜索期间账号发生了变化，其影响无法隔离。再次主动搜索前，请检查当前账号。", "搜尋期間帳號發生了變更，其影響無法隔離。再次主動搜尋前，請檢查目前帳號。"],
		"Search could not be completed. It may have used credits or quota. Submit again only deliberately.": ["无法完成搜索。此次搜索可能已经消耗积分或额度。仅在主动选择后再次提交。", "無法完成搜尋。此次搜尋可能已經消耗積分或額度。僅在主動選擇後再次提交。"],
		"An existing search page must be opened deliberately from its returned results. Open Search to prepare a new search.": ["已有搜索分页必须从返回的结果中主动打开。请打开搜索以准备新搜索。", "既有搜尋分頁必須從傳回的結果中主動開啟。請開啟搜尋以準備新搜尋。"],
		"Native verification is required before another deliberate search.": ["再次主动搜索前，需要在原版论坛完成验证。", "再次主動搜尋前，需要在原版論壇完成驗證。"],
		"Sign in through the native forum before another deliberate search.": ["再次主动搜索前，请先在原版论坛登录。", "再次主動搜尋前，請先在原版論壇登入。"],
		"Search results expired. Your criteria are retained; rerun explicitly if you accept possible credits or quota use.": ["搜索结果已过期。条件已保留；若接受可能消耗积分或额度，请主动重新搜索。", "搜尋結果已過期。條件已保留；若接受可能消耗積分或額度，請主動重新搜尋。"],
		"The search form response could not be displayed reliably.": ["无法可靠地显示搜索表单响应。", "無法可靠地顯示搜尋表單回應。"],
		"The current advanced search form is unavailable. Continue in the native forum.": ["当前高级搜索表单不可用。请在原版论坛中继续。", "目前進階搜尋表單無法使用。請在原版論壇中繼續。"],
		"Enter keywords or an author before searching.": ["搜索前，请输入关键词或作者。", "搜尋前，請輸入關鍵字或作者。"],
		"Search controls changed. Refresh the form and review your criteria.": ["搜索控件已更改。请刷新表单并检查条件。", "搜尋控制項已變更。請重新整理表單並檢查條件。"],
		"The search result could not be displayed reliably. The request may still have used credits or quota.": ["无法可靠地显示搜索结果。该请求仍可能已经消耗积分或额度。", "無法可靠地顯示搜尋結果。該請求仍可能已經消耗積分或額度。"],
		"The forum did not return a usable search identity. It will not be searched again automatically.": ["论坛未返回可用的搜索标识。系统不会自动再次搜索。", "論壇未傳回可用的搜尋識別。系統不會自動再次搜尋。"],
		"The search contains unrecognized or incomplete results. It has not been treated as zero matches.": ["搜索结果无法识别或不完整，未将其视为零条匹配结果。", "搜尋結果無法辨識或不完整，未將其視為零筆相符結果。"],
		"The search contains an unsupported result-page link.": ["搜索结果包含不支持的分页链接。", "搜尋結果包含不支援的分頁連結。"],
		"This native search request may have used credits or quota before the workspace started. No search has been repeated. Open Search to prepare a deliberate new search.": ["此原版搜索请求可能在工作区启动前就已消耗积分或额度。系统未重复搜索。请打开搜索，准备主动执行新搜索。", "此原版搜尋請求可能在工作區啟動前就已消耗積分或額度。系統未重複搜尋。請開啟搜尋，準備主動執行新搜尋。"],
		"The current account cannot search.": ["当前账号无法搜索。", "目前帳號無法搜尋。"],
		"Unexpected HTTP response.": ["收到非预期的 HTTP 响应。", "收到非預期的 HTTP 回應。"],
		Keywords: ["关键词", "關鍵字"],
		Author: ["作者", "作者"],
		"Time range": ["时间范围", "時間範圍"],
		"Time relation": ["时间关系", "時間關係"],
		Order: ["排序依据", "排序依據"],
		Direction: ["排序方向", "排序方向"],
		Boards: ["版块", "版塊"],
		"Search scope": ["搜索范围", "搜尋範圍"],
		"Thread types": ["主题类型", "主題類型"],
		"Search index": ["搜索索引", "搜尋索引"],
		"This download attempt was replaced or cancelled.": ["本次下载已被替代或取消。", "本次下載已被取代或取消。"],
		"File downloads are unavailable in this host.": ["当前运行环境不支持文件下载。", "目前執行環境不支援檔案下載。"],
		"Current attachment access could not be confirmed. Refresh the thread or continue in the native forum.": ["无法确认当前附件权限。请刷新主题或在原版论坛中继续。", "無法確認目前附件權限。請重新整理主題或在原版論壇中繼續。"],
		"The forum account changed or could not be confirmed. Refresh the thread before downloading.": ["论坛账号已改变或无法确认。请刷新主题后再下载。", "論壇帳號已變更或無法確認。請重新整理主題後再下載。"],
		"The forum no longer offers this attachment for direct download. No purchase was attempted.": ["论坛已不再提供此附件的直接下载。未尝试购买。", "論壇已不再提供此附件的直接下載。未嘗試購買。"],
		"The forum account changed while receiving the file. Refresh the thread before downloading.": ["接收文件时论坛账号发生了改变。请刷新主题后再下载。", "接收檔案時論壇帳號發生了變更。請重新整理主題後再下載。"],
		"The forum returned a different file destination. Nothing is ready to save.": ["论坛返回了不同的文件目标。没有可保存的文件。", "論壇傳回了不同的檔案目標。沒有可儲存的檔案。"],
		"The file transfer failed or was interrupted. Nothing is ready to save.": ["文件传输失败或已中断。没有可保存的文件。", "檔案傳輸失敗或已中斷。沒有可儲存的檔案。"],
		"The forum returned a login page instead of a file. Sign in through the native forum, then try again.": ["论坛返回了登录页面，未返回文件。请在原版论坛登录后重试。", "論壇傳回了登入頁面，未傳回檔案。請在原版論壇登入後重試。"],
		"The forum returned a verification challenge instead of a file. Complete it in the native forum.": ["论坛返回了验证页面，未返回文件。请在原版论坛完成验证。", "論壇傳回了驗證頁面，未傳回檔案。請在原版論壇完成驗證。"],
		"The forum requires payment before download. No purchase was attempted and no file is ready to save.": ["论坛要求付费后才能下载。未尝试购买，也没有可保存的文件。", "論壇要求付費後才能下載。未嘗試購買，也沒有可儲存的檔案。"],
		"The forum refused download permission. No file is ready to save.": ["论坛拒绝了下载权限。没有可保存的文件。", "論壇拒絕了下載權限。沒有可儲存的檔案。"],
		"The attachment file is missing. No file is ready to save.": ["附件文件不存在。没有可保存的文件。", "附件檔案不存在。沒有可儲存的檔案。"],
		"The forum returned an HTML page instead of a confirmed file. Nothing is ready to save.": ["论坛返回了 HTML 页面，无法确认是文件。没有可保存的文件。", "論壇傳回了 HTML 頁面，無法確認是檔案。沒有可儲存的檔案。"],
		"The forum returned a response document instead of a confirmed file. Nothing is ready to save.": ["论坛返回了响应文档，无法确认是文件。没有可保存的文件。", "論壇傳回了回應文件，無法確認是檔案。沒有可儲存的檔案。"],
		"The forum did not return a complete file. Nothing is ready to save.": ["论坛未返回完整文件。没有可保存的文件。", "論壇未傳回完整檔案。沒有可儲存的檔案。"],
		"The file response was empty or incomplete. Nothing is ready to save.": ["文件响应为空或不完整。没有可保存的文件。", "檔案回應為空或不完整。沒有可儲存的檔案。"],
		"Browser file preparation failed. No save was requested.": ["浏览器准备文件失败。尚未请求保存。", "瀏覽器準備檔案失敗。尚未要求儲存。"],
		"Browser save could not start. File delivery is unconfirmed.": ["无法启动浏览器保存。文件是否送达尚未确认。", "無法啟動瀏覽器儲存。檔案是否送達尚未確認。"],
		"Checking current attachment access and receiving file…": ["正在检查当前附件权限并接收文件…", "正在檢查目前附件權限並接收檔案…"],
		"File ready to save": ["文件已准备好，可以保存", "檔案已準備好，可以儲存"],
		"Browser save requested. Check your browser Downloads for completion; this workspace cannot confirm whether the file was saved or cancelled.": ["已请求浏览器保存。请在浏览器的下载记录中检查是否完成；本工作区无法确认文件是否已保存或已取消。", "已要求瀏覽器儲存。請在瀏覽器的下載紀錄中檢查是否完成；本工作區無法確認檔案是否已儲存或已取消。"],
		"Scrollable code": ["可滚动的代码", "可捲動的程式碼"],
		"Scrollable table": ["可滚动的表格", "可捲動的表格"],
		Login: ["需要登录", "需要登入"],
		Permission: ["权限不足", "權限不足"],
		Missing: ["目标不存在", "目標不存在"],
		Challenge: ["需要验证", "需要驗證"],
		Limited: ["请求受限", "請求受限"],
		Network: ["网络故障", "網路故障"],
		Stale: ["结果已被替代", "結果已被取代"],
		"The current account does not have permission to read this thread.": ["当前账号没有阅读此主题的权限。", "目前帳號沒有閱讀此主題的權限。"],
		"The current account does not have permission to read this board.": ["当前账号没有阅读此版块的权限。", "目前帳號沒有閱讀此版塊的權限。"],
		"Sign in through the native forum, then retry this thread.": ["请在原版论坛登录，然后重试此主题。", "請在原版論壇登入，然後重試此主題。"],
		"Sign in through the native forum, then retry.": ["请在原版论坛登录，然后重试。", "請在原版論壇登入，然後重試。"],
		"Native verification is required. Your intended thread is preserved.": ["需要在原版论坛完成验证。已保留目标主题。", "需要在原版論壇完成驗證。已保留目標主題。"],
		"Native verification is required. Your destination is preserved.": ["需要在原版论坛完成验证。已保留目标。", "需要在原版論壇完成驗證。已保留目標。"],
		"This thread is missing or has been deleted.": ["此主题不存在或已被删除。", "此主題不存在或已被刪除。"],
		"This board is missing or has been deleted.": ["此版块不存在或已被删除。", "此版塊不存在或已被刪除。"],
		"The forum could not be reached. Retry or continue in the native forum.": ["无法连接论坛。请重试或在原版论坛中继续。", "無法連線論壇。請重試或在原版論壇中繼續。"],
		"The forum is limiting requests. Retry explicitly later.": ["论坛正在限制请求。请稍后主动重试。", "論壇正在限制請求。請稍後主動重試。"],
		"This is not a supported thread destination.": ["不支持此主题目标。", "不支援此主題目標。"],
		"A newer request has replaced this result.": ["此结果已被较新的请求替代。", "此結果已被較新的請求取代。"],
		"The forum redirect requires a document navigation.": ["论坛跳转需要重新加载页面。", "論壇跳轉需要重新載入頁面。"],
		"The forum returned an unsupported response envelope.": ["论坛返回了不支持的响应格式。", "論壇傳回了不支援的回應格式。"],
		"The forum returned an invalid response.": ["论坛返回了无效响应。", "論壇傳回了無效回應。"],
		"The forum response could not be displayed reliably.": ["无法可靠地显示论坛响应。", "無法可靠地顯示論壇回應。"],
		"The forum returned a different destination. Continue in the native forum.": ["论坛返回了不同目标。请在原版论坛中继续。", "論壇傳回了不同目標。請在原版論壇中繼續。"],
		"The returned thread identity did not match.": ["返回的主题标识不匹配。", "傳回的主題識別不符。"],
		"Unrecognized thread content. Continue in the native forum.": ["无法识别主题内容。请在原版论坛中继续。", "無法辨識主題內容。請在原版論壇中繼續。"],
		"This thread has unrecognized or incomplete content.": ["此主题的内容无法识别或不完整。", "此主題的內容無法辨識或不完整。"],
		"The returned post identities are ambiguous.": ["返回的帖子标识存在歧义。", "傳回的帖子識別存在歧義。"],
		"The last reply requires canonical forum resolution.": ["最新回复需要由论坛解析实际目标。", "最新回覆需要由論壇解析實際目標。"],
		"The exact destination could not be resolved after navigation. Continue in the native forum.": ["跳转后无法解析确切目标。请在原版论坛中继续。", "跳轉後無法解析確切目標。請在原版論壇中繼續。"],
		"The forum redirect returned a different thread. The requested destination is preserved for native recovery.": ["论坛跳转返回了不同主题。已保留原目标以便在原版论坛恢复。", "論壇跳轉傳回了不同主題。已保留原目標以便在原版論壇復原。"],
		"Unsupported interactive content": ["不支持的交互内容", "不支援的互動內容"],
		"This action requires current native forum controls.": ["此操作需要当前的原版论坛控件。", "此操作需要目前的原版論壇控制項。"],
		"The notice request failed. It may still have marked notices read. Retry only deliberately.": ["通知请求失败，仍可能已将通知标为已读。请仅在主动操作时重试。", "通知請求失敗，仍可能已將通知標為已讀。請僅在主動操作時重試。"],
		"This is not a supported notice destination.": ["此目标不是受支持的通知页面。", "此目標不是受支援的通知頁面。"],
		"This category or page was not offered by the current notice list.": ["当前通知列表未提供此分类或分页。", "目前通知清單未提供此分類或分頁。"],
		"A newer request replaced this notice load. It may still have marked notices read.": ["较新的请求已替代此次通知加载。之前的请求仍可能已将通知标为已读。", "較新的請求已替代此次通知載入。先前的請求仍可能已將通知標為已讀。"],
		"The account changed while loading notices. Previous notices were cleared. This request may still have had read effects.": ["加载通知时账号已更改。之前的通知已清除；此次请求仍可能产生已读影响。", "載入通知時帳號已更改。先前的通知已清除；此次請求仍可能產生已讀影響。"],
		"Notices must be loaded deliberately. Each load may mark notices read.": ["请主动加载通知。每次加载都可能将通知标为已读。", "請主動載入通知。每次載入都可能將通知標為已讀。"],
		"This native notice request may have marked notices read before the workspace started. No notice request has been repeated. Load notices only deliberately.": ["此原版通知请求可能在工作区启动前已将通知标为已读。没有重复请求通知。请仅主动加载通知。", "此原版通知請求可能在工作區啟動前已將通知標為已讀。沒有重複請求通知。請僅主動載入通知。"],
		"The forum returned an unsupported notice response. This request may still have marked notices read.": ["论坛返回了不支持的通知响应。此次请求仍可能已将通知标为已读。", "論壇傳回了不支援的通知回應。此次請求仍可能已將通知標為已讀。"],
		"The notice response could not be interpreted. This request may still have marked notices read.": ["无法识别通知响应。此次请求仍可能已将通知标为已读。", "無法識別通知回應。此次請求仍可能已將通知標為已讀。"],
		"Native verification is required. This request may still have marked notices read.": ["需要原版论坛验证。此次请求仍可能已将通知标为已读。", "需要原版論壇驗證。此次請求仍可能已將通知標為已讀。"],
		"Sign in through the native forum before loading notices deliberately. This request may still have had read effects.": ["请先在原版论坛登录，再主动加载通知。此次请求仍可能产生已读影响。", "請先在原版論壇登入，再主動載入通知。此次請求仍可能產生已讀影響。"],
		"The current account cannot read these notices. This request may still have had read effects.": ["当前账号无法读取这些通知。此次请求仍可能产生已读影响。", "目前帳號無法讀取這些通知。此次請求仍可能產生已讀影響。"],
		"The forum is limiting requests. Retry notices only deliberately; this request may still have had read effects.": ["论坛正在限制请求。请仅主动重试通知；此次请求仍可能产生已读影响。", "論壇正在限制請求。請僅主動重試通知；此次請求仍可能產生已讀影響。"],
		"The notices could not be displayed reliably. This request may still have marked notices read.": ["无法可靠地显示通知。此次请求仍可能已将通知标为已读。", "無法可靠地顯示通知。此次請求仍可能已將通知標為已讀。"],
		"The current notice account could not be confirmed. This request may still have had read effects.": ["无法确认当前通知账号。此次请求仍可能产生已读影响。", "無法確認目前通知帳號。此次請求仍可能產生已讀影響。"],
		"The forum returned a different notice category or page. This request may still have had read effects.": ["论坛返回了不同通知分类或分页。此次请求仍可能产生已读影响。", "論壇傳回了不同通知分類或分頁。此次請求仍可能產生已讀影響。"],
		"The complete notice list could not be recognized. Continue in the native forum; this request may still have marked notices read.": ["无法识别完整通知列表。请前往原版论坛；此次请求仍可能已将通知标为已读。", "無法識別完整通知清單。請前往原版論壇；此次請求仍可能已將通知標為已讀。"],
		"A notice has incomplete or ambiguous content. Continue in the native forum for the complete list; this request may still have marked notices read.": ["一则通知的内容不完整或有歧义。请前往原版论坛查看完整列表；此次请求仍可能已将通知标为已读。", "一則通知的內容不完整或有歧義。請前往原版論壇查看完整清單；此次請求仍可能已將通知標為已讀。"],
		"The returned notice categories could not be recognized. Continue in the native forum for the complete inbox; this request may still have marked notices read.": ["无法识别返回的通知分类。请前往原版论坛查看完整通知；此次请求仍可能已将通知标为已读。", "無法識別傳回的通知分類。請前往原版論壇查看完整通知；此次請求仍可能已將通知標為已讀。"],
		"The returned notice pagination could not be preserved completely. Continue in the native forum; this request may still have marked notices read.": ["无法完整保留返回的通知分页。请前往原版论坛；此次请求仍可能已将通知标为已读。", "無法完整保留傳回的通知分頁。請前往原版論壇；此次請求仍可能已將通知標為已讀。"],
		"Image or attachment requires native viewing": ["图片或附件需要在原版论坛中查看", "圖片或附件需要在原版論壇中查看"],
		"Native red-packet interaction requires the native forum.": ["红包交互需要在原版论坛中完成。", "紅包互動需要在原版論壇中完成。"],
		"Additional native content is hidden; view it in the native forum.": ["其他原版内容处于隐藏状态；请在原版论坛中查看。", "其他原版內容處於隱藏狀態；請在原版論壇中查看。"],
		"A valid board is required.": ["需要有效的版块。", "需要有效的版塊。"],
		"A newer account request replaced this preparation.": ["较新的账号请求已替代此次准备。", "較新的帳號請求已取代此次準備。"],
		"The form could not be reached. Your writing is retained.": ["无法获取表单。写作内容已保留。", "無法取得表單。寫作內容已保留。"],
		"The forum returned an unsupported preparation response.": ["论坛返回了不支持的准备响应。", "論壇傳回了不支援的準備回應。"],
		"The forum returned invalid preparation data.": ["论坛返回了无效的准备数据。", "論壇傳回了無效的準備資料。"],
		"Complete native verification, then prepare again.": ["请在原版论坛完成验证，然后重新准备。", "請在原版論壇完成驗證，然後重新準備。"],
		"Sign in through the native forum, then prepare again. A form token does not establish an account.": ["请通过原版论坛登录，然后重新准备。表单令牌不能确认账号身份。", "請透過原版論壇登入，然後重新準備。表單權杖不能確認帳號身分。"],
		"The current account cannot prepare this new thread.": ["当前账号无法准备此新主题。", "目前帳號無法準備此新主題。"],
		"The forum is limiting requests. Try again explicitly later.": ["论坛正在限制请求。请稍后主动重试。", "論壇正在限制請求。請稍後主動重試。"],
		"A current member account and complete native form are required.": ["需要当前会员账号和完整的原版表单。", "需要目前會員帳號和完整的原版表單。"],
		"The current native new-thread form is unavailable.": ["当前原版新主题表单不可用。", "目前原版新主題表單無法使用。"],
		"The returned form targets a different action or board.": ["返回的表单指向不同的操作或版块。", "傳回的表單指向不同的操作或版塊。"],
		"The native form does not provide unambiguous complete source and options.": ["原版表单未提供明确完整的源码和选项。", "原版表單未提供明確完整的原始碼和選項。"],
		"Writing changed while the new form was loading. Return to it or deliberately prepare replacement again.": ["加载新表单时写作内容已更改。请返回原内容，或主动重新准备替换。", "載入新表單時寫作內容已變更。請返回原內容，或主動重新準備替換。"],
		"The account changed again. Prepare the text copy again.": ["账号再次变更。请重新准备文字副本。", "帳號再次變更。請重新準備文字副本。"]
	};
	var searchPrefixes = {
		"Search cost restriction: ": ["搜索积分限制：", "搜尋積分限制："],
		"Search frequency restriction: ": ["搜索频率限制：", "搜尋頻率限制："],
		"Search permission denied: ": ["搜索权限不足：", "搜尋權限不足："],
		"The search response could not be interpreted: ": ["无法解析搜索响应：", "無法解析搜尋回應："]
	};
	function description(value, language, nativeText) {
		if (language === "en") return value;
		if (value.startsWith("Previous stored confirmation retained. This recheck did not verify the current result. ")) return (language === "zh-CN" ? "保留先前的存储确认。本次检查未验证当前结果。" : "保留先前的儲存確認。本次檢查未驗證目前結果。") + description(value.slice(87), language, nativeText);
		const localized = descriptions[value];
		if (localized) return localized[language === "zh-CN" ? 0 : 1];
		const publication = /^Confirmed stored thread (\d+), post (\d+), submitted revision (\d+)\.$/.exec(value);
		if (publication) return language === "zh-CN" ? `已确认储存主题 ${publication[1]}、帖子 ${publication[2]}，提交版本 ${publication[3]}。` : `已確認儲存主題 ${publication[1]}、帖子 ${publication[2]}，提交版本 ${publication[3]}。`;
		for (const [prefix, translated] of Object.entries(searchPrefixes)) {
			if (!value.startsWith(prefix)) continue;
			const suffix = value.slice(prefix.length);
			return translated[language === "zh-CN" ? 0 : 1] + (nativeText === null ? description(suffix, language) : suffix);
		}
		const restriction = /^The current (.+) restriction does not allow this value\. Review your criteria\.$/.exec(value);
		if (restriction) {
			const field = nativeText === null ? description(restriction[1], language) : restriction[1];
			return language === "zh-CN" ? `当前的「${field}」限制不允许此值。请检查条件。` : `目前的「${field}」限制不允許此值。請檢查條件。`;
		}
		const formatting = /^Unsupported formatting \((.+)\)$/.exec(value);
		if (formatting) return `${language === "zh-CN" ? "不支持的格式" : "不支援的格式"} (${formatting[1]})`;
		return value;
	}
	var _hoisted_1$4 = ["aria-label"];
	var _hoisted_2$4 = ["disabled"];
	var _hoisted_3$4 = [
		"type",
		"name",
		"value",
		"checked",
		"disabled",
		"onChange"
	];
	var _hoisted_4$4 = {
		key: 1,
		class: "search-field"
	};
	var _hoisted_5$4 = [
		"value",
		"maxlength",
		"readonly",
		"disabled",
		"onInput"
	];
	var _hoisted_6$4 = [
		"aria-label",
		"multiple",
		"value",
		"disabled",
		"onChange"
	];
	var _hoisted_7$4 = ["value", "disabled"];
	var _hoisted_8$4 = ["disabled"];
	var _hoisted_9$4 = {
		key: 1,
		role: "status"
	};
	var _hoisted_10$3 = ["aria-label"];
	var _hoisted_11$3 = { key: 0 };
	var _hoisted_12$3 = ["aria-label"];
	var _hoisted_13$3 = ["id", "data-thread-id"];
	var _hoisted_14$2 = ["href", "aria-current"];
	var _hoisted_15$2 = ["aria-label"];
	var _hoisted_16$2 = ["href"];
	var SearchView_default = defineComponent({
		__name: "SearchView",
		props: {
			search: {},
			loading: { type: Boolean },
			language: {},
			secondary: { type: Boolean },
			selection: {}
		},
		emits: ["edit", "submit"],
		setup(__props, { emit: __emit }) {
			const props = __props;
			const text = computed(() => strings(props.language));
			const fieldLabel = (field) => field.labelFromForum === false ? description(field.label, props.language) : field.label;
			const emit = __emit;
			function edit(name, event) {
				const target = event.target;
				if (target instanceof HTMLInputElement) emit("edit", name, [target.value]);
				if (target instanceof HTMLSelectElement) emit("edit", name, [...target.selectedOptions].map((option) => option.value));
			}
			function choice(name, value, multiple, event) {
				const target = event.target;
				if (!(target instanceof HTMLInputElement)) return;
				emit("edit", name, multiple ? target.checked ? [...props.search.edited[name] ?? [], value] : (props.search.edited[name] ?? []).filter((v) => v !== value) : [value]);
			}
			const changed = computed(() => props.search.effective !== null && JSON.stringify(props.search.edited) !== JSON.stringify(props.search.submitted));
			const effective = computed(() => Object.entries(props.search.effective ?? {}).map(([name, values]) => {
				const field = props.search.form.fields.find((f) => f.name === name && !f.disabled);
				return `${field ? fieldLabel(field) : name}: ${values.map((v) => field?.options.find((o) => o.value === v)?.label ?? v).join(", ") || text.value.forumDefault}`;
			}));
			return (_ctx, _cache) => {
				return openBlock(), createElementBlock("section", {
					class: normalizeClass(["overview pane search-pane", { "secondary-results": __props.secondary }]),
					"data-scroll-pane": "overview",
					"aria-label": text.value.searchOverviewLabel
				}, [
					createBaseVNode("h1", null, toDisplayString(text.value.search), 1),
					createBaseVNode("p", null, toDisplayString(text.value.searchExplanation), 1),
					createBaseVNode("p", null, toDisplayString(text.value.searchEffects), 1),
					(openBlock(true), createElementBlock(Fragment, null, renderList(__props.search.form.restrictions, (restriction) => {
						return openBlock(), createElementBlock("p", { key: restriction }, toDisplayString(restriction), 1);
					}), 128)),
					!__props.secondary ? (openBlock(), createElementBlock("form", {
						key: 0,
						onSubmit: _cache[0] || (_cache[0] = withModifiers(($event) => emit("submit"), ["prevent"]))
					}, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.search.form.fields, (field, index) => {
						return openBlock(), createElementBlock(Fragment, { key: `${field.name}-${index}` }, [field.kind === "choices" ? (openBlock(), createElementBlock("fieldset", {
							key: 0,
							disabled: field.disabled || __props.loading
						}, [createBaseVNode("legend", null, toDisplayString(fieldLabel(field)), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(field.options, (option) => {
							return openBlock(), createElementBlock("label", { key: option.value }, [createBaseVNode("input", {
								type: field.multiple ? "checkbox" : "radio",
								name: field.name,
								value: option.value,
								checked: __props.search.edited[field.name]?.includes(option.value) ?? false,
								disabled: option.disabled,
								onChange: ($event) => choice(field.name, option.value, field.multiple, $event)
							}, null, 40, _hoisted_3$4), createTextVNode(toDisplayString(option.label), 1)]);
						}), 128))], 8, _hoisted_2$4)) : (openBlock(), createElementBlock("label", _hoisted_4$4, [createTextVNode(toDisplayString(fieldLabel(field)) + " ", 1), field.kind === "text" ? (openBlock(), createElementBlock("input", {
							key: 0,
							value: __props.search.edited[field.name]?.[0] ?? "",
							maxlength: field.maxLength ?? void 0,
							readonly: field.readOnly,
							disabled: field.disabled || __props.loading,
							onInput: ($event) => edit(field.name, $event)
						}, null, 40, _hoisted_5$4)) : (openBlock(), createElementBlock("select", {
							key: 1,
							"aria-label": fieldLabel(field),
							multiple: field.multiple,
							value: field.multiple ? __props.search.edited[field.name] : __props.search.edited[field.name]?.[0],
							disabled: field.disabled || __props.loading,
							onChange: ($event) => edit(field.name, $event)
						}, [(openBlock(true), createElementBlock(Fragment, null, renderList(field.options, (option) => {
							return openBlock(), createElementBlock("option", {
								key: option.value,
								value: option.value,
								disabled: option.disabled
							}, toDisplayString(option.label), 9, _hoisted_7$4);
						}), 128))], 40, _hoisted_6$4))]))], 64);
					}), 128)), createBaseVNode("button", {
						type: "submit",
						disabled: __props.loading
					}, toDisplayString(text.value.search), 9, _hoisted_8$4)], 32)) : createCommentVNode("", true),
					changed.value ? (openBlock(), createElementBlock("p", _hoisted_9$4, toDisplayString(text.value.editedSearch), 1)) : createCommentVNode("", true),
					__props.search.results ? (openBlock(), createElementBlock("section", {
						key: 2,
						class: "search-results",
						"aria-label": text.value.searchResults
					}, [
						createBaseVNode("h2", null, toDisplayString(text.value.searchResults), 1),
						createBaseVNode("p", null, toDisplayString(__props.search.results.summary), 1),
						!__props.search.results.rows.length ? (openBlock(), createElementBlock("p", _hoisted_11$3, toDisplayString(text.value.noSearchMatches), 1)) : createCommentVNode("", true),
						createBaseVNode("ul", { "aria-label": text.value.effectiveSearch }, [(openBlock(true), createElementBlock(Fragment, null, renderList(effective.value, (item) => {
							return openBlock(), createElementBlock("li", { key: item }, toDisplayString(item), 1);
						}), 128))], 8, _hoisted_12$3),
						createBaseVNode("p", null, toDisplayString(text.value.page) + " " + toDisplayString(__props.search.results.pages.current), 1),
						(openBlock(true), createElementBlock(Fragment, null, renderList(__props.search.results.rows, (row) => {
							return openBlock(), createElementBlock("div", {
								id: `row-${row.id}`,
								key: row.id,
								class: "thread-row",
								"data-thread-id": row.id
							}, [
								createBaseVNode("a", {
									class: "subject",
									href: row.url,
									"aria-current": __props.selection === row.id ? "true" : void 0
								}, toDisplayString(row.label), 9, _hoisted_14$2),
								createBaseVNode("span", null, toDisplayString(row.author.label), 1),
								createBaseVNode("span", null, toDisplayString(row.board.label), 1),
								createBaseVNode("time", null, toDisplayString(row.date), 1),
								createBaseVNode("span", null, toDisplayString(row.stats), 1),
								createBaseVNode("p", null, toDisplayString(row.snippet), 1)
							], 8, _hoisted_13$3);
						}), 128)),
						createBaseVNode("nav", { "aria-label": text.value.searchPages }, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.search.results.pages.links, (link) => {
							return openBlock(), createElementBlock("a", {
								key: link.url,
								href: link.url
							}, toDisplayString(link.label), 9, _hoisted_16$2);
						}), 128))], 8, _hoisted_15$2)
					], 8, _hoisted_10$3)) : createCommentVNode("", true)
				], 10, _hoisted_1$4);
			};
		}
	});
	function render(node, language, nativeLinks = false) {
		const children = () => node.kind === "text" ? [] : node.children.map((child) => render(child, language, nativeLinks));
		if (node.kind === "text") return node.text;
		if (node.kind === "unsupported") return h("div", [h("p", { class: "content-notice" }, description(node.description, language)), ...children()]);
		if (node.tag === "table") return h("div", {
			class: "table-overflow",
			role: "region",
			"aria-label": description("Scrollable table", language),
			tabindex: "0"
		}, [h(node.tag, node.attributes, children())]);
		if (nativeLinks && node.tag === "a" && node.attributes.href && new URL(node.attributes.href).origin === location.origin && !["thread", "redirect"].includes(describeDestination(node.attributes.href)?.kind ?? "")) return h("a", {
			...node.attributes,
			href: nativeDestination(node.attributes.href)
		}, [...children(), ` — ${strings(language).native}`]);
		const attributes = node.tag === "pre" || node.attributes.class === "code-block" ? {
			...node.attributes,
			role: "region",
			"aria-label": description("Scrollable code", language),
			tabindex: "0"
		} : node.attributes;
		return h(node.tag, attributes, children());
	}
	var ContentView_default = defineComponent({
		name: "ContentView",
		props: {
			language: {
				type: String,
				default: "en"
			},
			nodes: {
				type: Array,
				required: true
			},
			nativeLinks: {
				type: Boolean,
				default: false
			}
		},
		setup: (props) => () => h("div", { class: "post-content" }, props.nodes.map((node) => render(node, props.language, props.nativeLinks)))
	});
	var _hoisted_1$3 = ["aria-label"];
	var _hoisted_2$3 = ["disabled"];
	var _hoisted_3$3 = { key: 0 };
	var _hoisted_4$3 = { key: 1 };
	var _hoisted_5$3 = ["aria-label"];
	var _hoisted_6$3 = ["href", "aria-current"];
	var _hoisted_7$3 = { key: 2 };
	var _hoisted_8$3 = [
		"id",
		"data-notice-id",
		"aria-current"
	];
	var _hoisted_9$3 = ["aria-label"];
	var _hoisted_10$2 = ["href"];
	var _hoisted_11$2 = ["aria-label"];
	var _hoisted_12$2 = ["href"];
	var _hoisted_13$2 = ["href"];
	var NoticesView_default = defineComponent({
		__name: "NoticesView",
		props: {
			notices: {},
			loading: { type: Boolean },
			language: {},
			secondary: { type: Boolean },
			selection: {}
		},
		emits: ["load"],
		setup(__props, { emit: __emit }) {
			const props = __props;
			const text = computed(() => strings(props.language));
			const emit = __emit;
			return (_ctx, _cache) => {
				return openBlock(), createElementBlock("section", {
					class: normalizeClass(["overview pane notices-pane", { "secondary-results": __props.secondary }]),
					"data-scroll-pane": "overview",
					"aria-label": text.value.noticesOverviewLabel
				}, [
					createBaseVNode("h1", null, toDisplayString(text.value.notices), 1),
					createBaseVNode("h2", null, toDisplayString(text.value.noticesHeading), 1),
					createBaseVNode("p", null, toDisplayString(text.value.noticesOverview), 1),
					createBaseVNode("p", null, toDisplayString(text.value.noticeEffects), 1),
					createBaseVNode("button", {
						disabled: __props.loading,
						onClick: _cache[0] || (_cache[0] = ($event) => emit("load"))
					}, toDisplayString(__props.notices ? text.value.refreshNotices : text.value.loadNotices), 9, _hoisted_2$3),
					__props.notices ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
						__props.notices.unread.kind === "observed" ? (openBlock(), createElementBlock("p", _hoisted_3$3, toDisplayString(unref(insert)(text.value.noticeUnreadObserved, String(__props.notices.unread.count))), 1)) : (openBlock(), createElementBlock("p", _hoisted_4$3, toDisplayString(__props.notices.unread.kind === "absent" ? text.value.noticeUnreadAbsent : text.value.noticeUnreadUnknown), 1)),
						createBaseVNode("nav", {
							class: "notices-inline-categories",
							"aria-label": text.value.noticeCategories
						}, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.notices.categories, (category) => {
							return openBlock(), createElementBlock("a", {
								key: category.url,
								href: category.url,
								"aria-current": category.current ? "page" : void 0
							}, toDisplayString(category.label), 9, _hoisted_6$3);
						}), 128))], 8, _hoisted_5$3),
						createBaseVNode("p", null, toDisplayString(text.value.page) + " " + toDisplayString(__props.notices.pages.current), 1),
						__props.notices.empty ? (openBlock(), createElementBlock("p", _hoisted_7$3, toDisplayString(__props.notices.empty), 1)) : createCommentVNode("", true),
						(openBlock(true), createElementBlock(Fragment, null, renderList(__props.notices.entries, (notice) => {
							return openBlock(), createElementBlock("article", {
								id: `notice-${notice.id}`,
								key: notice.id,
								"data-notice-id": notice.id,
								"aria-current": __props.selection === notice.id ? "true" : void 0,
								tabindex: "-1"
							}, [createBaseVNode("header", null, [createBaseVNode("time", null, toDisplayString(notice.time), 1)]), createVNode(unref(ContentView_default), {
								nodes: notice.body,
								language: __props.language,
								"native-links": ""
							}, null, 8, ["nodes", "language"])], 8, _hoisted_8$3);
						}), 128)),
						createBaseVNode("nav", { "aria-label": text.value.noticePages }, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.notices.pages.links, (link) => {
							return openBlock(), createElementBlock("a", {
								key: link.url,
								href: link.url
							}, toDisplayString(link.label), 9, _hoisted_10$2);
						}), 128))], 8, _hoisted_9$3)
					], 64)) : createCommentVNode("", true),
					createBaseVNode("p", null, toDisplayString(text.value.deferredNotices), 1),
					createBaseVNode("nav", { "aria-label": text.value.native }, [createBaseVNode("a", { href: unref(nativeDestination)("https://www.tsdm39.com/home.php?mod=space&do=pm") }, toDisplayString(text.value.nativePM), 9, _hoisted_12$2), createBaseVNode("a", { href: unref(nativeDestination)("https://www.tsdm39.com/home.php?mod=space&do=notice") }, toDisplayString(text.value.nativeNotices), 9, _hoisted_13$2)], 8, _hoisted_11$2)
				], 10, _hoisted_1$3);
			};
		}
	});
	var _hoisted_1$2 = ["aria-label"];
	var _hoisted_2$2 = {
		key: 0,
		role: "status"
	};
	var _hoisted_3$2 = {
		key: 1,
		role: "alert"
	};
	var _hoisted_4$2 = {
		key: 2,
		role: "alert"
	};
	var _hoisted_5$2 = { class: "writing-actions" };
	var _hoisted_6$2 = ["disabled"];
	var _hoisted_7$2 = ["disabled"];
	var _hoisted_8$2 = {
		key: 3,
		role: "alert"
	};
	var _hoisted_9$2 = ["disabled"];
	var _hoisted_10$1 = { key: 4 };
	var _hoisted_11$1 = { key: 0 };
	var _hoisted_12$1 = { key: 0 };
	var _hoisted_13$1 = { key: 1 };
	var _hoisted_14$1 = ["href", "onClick"];
	var _hoisted_15$1 = ["onUpdate:modelValue", "placeholder"];
	var _hoisted_16$1 = ["disabled", "onClick"];
	var _hoisted_17$1 = ["disabled", "onClick"];
	var _hoisted_18$1 = {
		key: 5,
		role: "alert"
	};
	var _hoisted_19$1 = { class: "writing-actions" };
	var _hoisted_20$1 = ["disabled"];
	var _hoisted_21$1 = {
		key: 0,
		role: "alert"
	};
	var _hoisted_22$1 = ["disabled"];
	var _hoisted_23$1 = {
		key: 6,
		role: "alert"
	};
	var _hoisted_24$1 = {
		key: 7,
		role: "status"
	};
	var _hoisted_25$1 = {
		key: 8,
		role: "status"
	};
	var _hoisted_26$1 = ["value"];
	var _hoisted_27$1 = { key: 9 };
	var _hoisted_28$1 = [
		"aria-label",
		"value",
		"disabled"
	];
	var _hoisted_29$1 = ["value", "disabled"];
	var _hoisted_30$1 = ["value"];
	var _hoisted_31$1 = [
		"checked",
		"value",
		"disabled",
		"onChange"
	];
	var _hoisted_32$1 = [
		"aria-label",
		"value",
		"disabled",
		"onChange"
	];
	var _hoisted_33$1 = ["value", "disabled"];
	var _hoisted_34$1 = [
		"value",
		"disabled",
		"maxlength",
		"onInput"
	];
	var SourceWriting_default = defineComponent({
		__name: "SourceWriting",
		props: { workspace: {} },
		setup(__props) {
			const props = __props;
			const state = props.workspace.writing.state;
			const text = computed(() => strings(props.workspace.preferences.state.value.language));
			const unresolved = props.workspace.writing.unresolvedAttachments;
			const editor = ref(null);
			const candidateURLs = ref({});
			function effectLabel(options, name) {
				return description(options.find((option) => option.name === name)?.label ?? "", props.workspace.preferences.state.value.language);
			}
			function selection() {
				const element = editor.value;
				if (element) props.workspace.writing.edit({ selection: {
					start: element.selectionStart,
					end: element.selectionEnd,
					direction: element.selectionDirection
				} });
			}
			function editSource(event) {
				const element = event.target;
				props.workspace.writing.edit({
					source: element.value,
					selection: {
						start: element.selectionStart,
						end: element.selectionEnd,
						direction: element.selectionDirection
					}
				});
			}
			onMounted(() => {
				const range = state.value.context?.selection;
				if (editor.value && range) {
					editor.value.focus();
					editor.value.setSelectionRange(range.start, range.end, range.direction);
				}
			});
			function value(event) {
				return event.target.value;
			}
			function updateOption(option, event) {
				const context = state.value.context;
				if (!context || option.disabled) return;
				const next = {
					...option,
					value: value(event),
					checked: event.target.checked ?? option.checked
				};
				if (option.name === "typeid") props.workspace.writing.edit({ category: next });
				else props.workspace.writing.edit({ options: context.options.map((item) => item.name === option.name ? next : {
					...item,
					choices: [...item.choices]
				}) });
			}
			return (_ctx, _cache) => {
				return unref(state).context ? (openBlock(), createElementBlock("section", {
					key: 0,
					class: "source-writing",
					"aria-label": text.value.writingContext,
					onCompositionstart: _cache[11] || (_cache[11] = ($event) => __props.workspace.writing.startComposition()),
					onCompositionend: _cache[12] || (_cache[12] = ($event) => __props.workspace.writing.endComposition())
				}, [
					unref(state).compositionDeferred ? (openBlock(), createElementBlock("p", _hoisted_2$2, toDisplayString(text.value.finishComposition), 1)) : createCommentVNode("", true),
					createBaseVNode("h1", null, toDisplayString(unref(insert)(text.value.newThreadIn, unref(state).context.board.label)), 1),
					createBaseVNode("p", null, toDisplayString(unref(insert)(text.value.writingAs, unref(state).context.account.name)) + " · " + toDisplayString(unref(insert)(text.value.writingBoard, unref(state).context.board.id)), 1),
					!unref(state).accountVerified ? (openBlock(), createElementBlock("p", _hoisted_3$2, toDisplayString(unref(insert)(text.value.writingPaused, unref(state).context.account.name)), 1)) : createCommentVNode("", true),
					unref(unresolved).length ? (openBlock(), createElementBlock("p", _hoisted_4$2, toDisplayString(unref(insert)(text.value.unresolvedAttachments, unref(unresolved).join(", "))), 1)) : createCommentVNode("", true),
					createBaseVNode("div", _hoisted_5$2, [createBaseVNode("button", {
						disabled: unref(state).preparing || unref(state).publishing,
						onClick: _cache[0] || (_cache[0] = ($event) => __props.workspace.writing.check())
					}, toDisplayString(text.value.checkWriting), 9, _hoisted_6$2), createBaseVNode("button", {
						disabled: unref(state).preparing || unref(state).publishing,
						onClick: _cache[1] || (_cache[1] = ($event) => __props.workspace.writing.check(true))
					}, toDisplayString(text.value.prepareTextCopy), 9, _hoisted_7$2)]),
					unref(state).copy ? (openBlock(), createElementBlock("section", _hoisted_8$2, [
						createBaseVNode("p", null, toDisplayString(unref(insert)(text.value.copyWritingPrompt, unref(state).context.account.name).replace("{account}", unref(state).copy.prepared.account.name)), 1),
						createBaseVNode("p", null, toDisplayString(text.value.copyWritingLimits), 1),
						createBaseVNode("button", { onClick: _cache[2] || (_cache[2] = ($event) => __props.workspace.writing.cancelCopy()) }, toDisplayString(text.value.keepWriting), 1),
						createBaseVNode("button", {
							disabled: unref(state).publishing,
							onClick: _cache[3] || (_cache[3] = ($event) => __props.workspace.writing.confirmCopy())
						}, toDisplayString(text.value.replaceTextCopy), 9, _hoisted_9$2)
					])) : createCommentVNode("", true),
					!unref(state).context.attempts?.length ? (openBlock(), createElementBlock("p", _hoisted_10$1, toDisplayString(text.value.localWriting), 1)) : createCommentVNode("", true),
					(openBlock(true), createElementBlock(Fragment, null, renderList(unref(state).context.attempts, (attempt) => {
						return openBlock(), createElementBlock("section", {
							key: attempt.id,
							role: "status"
						}, [
							createBaseVNode("p", null, toDisplayString(unref(description)(attempt.message, __props.workspace.preferences.state.value.language)), 1),
							attempt.result?.verification ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [(openBlock(true), createElementBlock(Fragment, null, renderList(attempt.result.verification.normalizations, (normalization) => {
								return openBlock(), createElementBlock("p", { key: normalization.name }, toDisplayString(text.value.normalizedStoredPrice), 1);
							}), 128)), attempt.result.verification.creationEffects.length ? (openBlock(), createElementBlock("ul", _hoisted_11$1, [(openBlock(true), createElementBlock(Fragment, null, renderList(attempt.result.verification.creationEffects, (effect) => {
								return openBlock(), createElementBlock("li", { key: effect.name }, [
									createTextVNode(toDisplayString(effectLabel(attempt.publication.submission.writing.options, effect.name)) + ": ", 1),
									createBaseVNode("span", null, toDisplayString(effect.outcome === "unknown" ? text.value.deliveryUnverified : text.value.effectNotRequested), 1),
									effect.requested && !effect.included ? (openBlock(), createElementBlock("span", _hoisted_12$1, " · " + toDisplayString(text.value.effectNotIncluded), 1)) : createCommentVNode("", true)
								]);
							}), 128))])) : createCommentVNode("", true)], 64)) : attempt.result ? (openBlock(), createElementBlock("p", _hoisted_13$1, toDisplayString(text.value.legacyStoredConfirmation), 1)) : createCommentVNode("", true),
							attempt.result ? (openBlock(), createElementBlock("a", {
								key: 2,
								href: attempt.result.url,
								onClick: withModifiers(($event) => __props.workspace.openThread(attempt.result.url), ["prevent"])
							}, toDisplayString(text.value.openConfirmedThread), 9, _hoisted_14$1)) : createCommentVNode("", true),
							attempt.status === "uncertain" || attempt.status === "moderation" ? (openBlock(), createElementBlock(Fragment, { key: 3 }, [
								createBaseVNode("label", null, [createTextVNode(toDisplayString(text.value.candidateThreadURL), 1), withDirectives(createBaseVNode("input", {
									"onUpdate:modelValue": ($event) => candidateURLs.value[attempt.id] = $event,
									type: "url",
									placeholder: attempt.candidateURL ?? ""
								}, null, 8, _hoisted_15$1), [[vModelText, candidateURLs.value[attempt.id]]])]),
								createBaseVNode("button", {
									disabled: unref(state).publishing,
									onClick: ($event) => __props.workspace.writing.checkResult(attempt.id, candidateURLs.value[attempt.id])
								}, toDisplayString(text.value.checkThreadResult), 9, _hoisted_16$1),
								attempt.status === "uncertain" ? (openBlock(), createElementBlock("button", {
									key: 0,
									disabled: !attempt.checked || unref(state).publishing,
									onClick: ($event) => __props.workspace.writing.warnResend(attempt.id)
								}, toDisplayString(text.value.prepareAnotherAttempt), 9, _hoisted_17$1)) : createCommentVNode("", true)
							], 64)) : createCommentVNode("", true)
						]);
					}), 128)),
					unref(state).resend ? (openBlock(), createElementBlock("section", _hoisted_18$1, [
						createBaseVNode("p", null, toDisplayString(text.value.duplicatePublicationWarning), 1),
						createBaseVNode("button", { onClick: _cache[4] || (_cache[4] = ($event) => __props.workspace.writing.cancelResend()) }, toDisplayString(text.value.keepOriginalAttempt), 1),
						createBaseVNode("button", { onClick: _cache[5] || (_cache[5] = ($event) => __props.workspace.writing.confirmResend()) }, toDisplayString(text.value.acceptDuplicateReview), 1)
					])) : createCommentVNode("", true),
					createBaseVNode("div", _hoisted_19$1, [createBaseVNode("button", {
						disabled: unref(state).preparing || unref(state).publishing,
						onClick: _cache[6] || (_cache[6] = ($event) => __props.workspace.writing.reviewPublication())
					}, toDisplayString(text.value.reviewPublication), 9, _hoisted_20$1), unref(state).publication ? (openBlock(), createElementBlock("section", _hoisted_21$1, [createBaseVNode("p", null, toDisplayString(unref(insert)(text.value.publicationReview, unref(state).publication.submission.revision).replace("{account}", unref(state).context.account.name).replace("{board}", unref(state).context.board.label)), 1), createBaseVNode("button", {
						disabled: unref(state).publishing,
						onClick: _cache[7] || (_cache[7] = ($event) => __props.workspace.writing.publish())
					}, toDisplayString(text.value.publishThread), 9, _hoisted_22$1)])) : createCommentVNode("", true)]),
					unref(state).recoveryAvailable === false ? (openBlock(), createElementBlock("p", _hoisted_23$1, toDisplayString(text.value.writingRecoveryUnavailable), 1)) : unref(state).acknowledged === unref(state).context.revision ? (openBlock(), createElementBlock("p", _hoisted_24$1, toDisplayString(unref(insert)(text.value.writingAcknowledged, unref(state).acknowledged)), 1)) : (openBlock(), createElementBlock("p", _hoisted_25$1, toDisplayString(unref(insert)(text.value.writingPending, unref(state).context.revision).replace("{acknowledged}", String(unref(state).acknowledged))), 1)),
					createBaseVNode("label", null, [createTextVNode(toDisplayString(text.value.writingTitle), 1), createBaseVNode("input", {
						value: unref(state).context.title,
						onInput: _cache[8] || (_cache[8] = ($event) => __props.workspace.writing.edit({ title: value($event) }))
					}, null, 40, _hoisted_26$1)]),
					unref(state).context.category ? (openBlock(), createElementBlock("label", _hoisted_27$1, [createTextVNode(toDisplayString(text.value.writingCategory), 1), createBaseVNode("select", {
						"aria-label": text.value.writingCategory,
						value: unref(state).context.category.value,
						disabled: unref(state).context.category.disabled,
						onChange: _cache[9] || (_cache[9] = ($event) => updateOption(unref(state).context.category, $event))
					}, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(state).context.category.choices, (choice) => {
						return openBlock(), createElementBlock("option", {
							key: choice.value,
							value: choice.value,
							disabled: choice.disabled
						}, toDisplayString(choice.label), 9, _hoisted_29$1);
					}), 128))], 40, _hoisted_28$1)])) : createCommentVNode("", true),
					createBaseVNode("label", null, [createTextVNode(toDisplayString(text.value.completeSource), 1), createBaseVNode("textarea", {
						ref_key: "editor",
						ref: editor,
						value: unref(state).context.source,
						rows: "14",
						spellcheck: "false",
						onSelect: selection,
						onKeyup: selection,
						onClick: selection,
						onBlur: selection,
						onInput: editSource
					}, null, 40, _hoisted_30$1)]),
					createBaseVNode("fieldset", null, [createBaseVNode("legend", null, toDisplayString(text.value.currentFormOptions), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(unref(state).context.options, (option) => {
						return openBlock(), createElementBlock("label", { key: option.name }, [option.kind === "checkbox" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createBaseVNode("input", {
							type: "checkbox",
							checked: option.checked,
							value: option.value,
							disabled: option.disabled,
							onChange: ($event) => updateOption(option, $event)
						}, null, 40, _hoisted_31$1), createTextVNode(toDisplayString(option.label), 1)], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [createTextVNode(toDisplayString(option.label), 1), option.kind === "select" ? (openBlock(), createElementBlock("select", {
							key: 0,
							"aria-label": option.label,
							value: option.value,
							disabled: option.disabled,
							onChange: ($event) => updateOption(option, $event)
						}, [(openBlock(true), createElementBlock(Fragment, null, renderList(option.choices, (choice) => {
							return openBlock(), createElementBlock("option", {
								key: choice.value,
								value: choice.value,
								disabled: choice.disabled
							}, toDisplayString(choice.label), 9, _hoisted_33$1);
						}), 128))], 40, _hoisted_32$1)) : (openBlock(), createElementBlock("input", {
							key: 1,
							value: option.value,
							disabled: option.disabled,
							maxlength: option.maxLength ?? void 0,
							onInput: ($event) => updateOption(option, $event)
						}, null, 40, _hoisted_34$1))], 64))]);
					}), 128))]),
					createBaseVNode("button", { onClick: _cache[10] || (_cache[10] = ($event) => __props.workspace.writing.hide()) }, toDisplayString(text.value.returnReading), 1)
				], 40, _hoisted_1$2)) : createCommentVNode("", true);
			};
		}
	});
	var _hoisted_1$1 = { for: "text-size" };
	var _hoisted_2$1 = ["value"];
	var _hoisted_3$1 = { role: "status" };
	var _hoisted_4$1 = { class: "theme-choices" };
	var _hoisted_5$1 = [
		"value",
		"checked",
		"onChange"
	];
	var _hoisted_6$1 = ["data-swatch"];
	var _hoisted_7$1 = { for: "interface-language" };
	var _hoisted_8$1 = ["value"];
	var _hoisted_9$1 = { key: 0 };
	var SettingsDialog_default = defineComponent({
		__name: "SettingsDialog",
		props: {
			workspace: {},
			portal: {}
		},
		setup(__props) {
			const props = __props;
			const preferences = props.workspace.preferences;
			const state = preferences.state;
			const open = ref(false);
			function changeOpen(value) {
				const change = () => {
					open.value = value;
				};
				if (!props.workspace.writing.deferViewChange(change)) change();
			}
			const text = computed(() => strings(state.value.language));
			const themes = [
				"light",
				"alias",
				"mono",
				"dark"
			];
			function language(event) {
				if (!(event.target instanceof HTMLSelectElement)) return;
				const value = event.target.value;
				if (value === "en" || value === "zh-CN" || value === "zh-TW") preferences.set({ language: value });
			}
			function input(event) {
				if (event.target instanceof HTMLInputElement) preferences.setTextSize(Number(event.target.value));
			}
			function escape(event) {
				if (event.defaultPrevented) return;
				event.stopPropagation();
				open.value = false;
			}
			return (_ctx, _cache) => {
				return openBlock(), createBlock(unref(DialogRoot_default), {
					open: open.value,
					"onUpdate:open": changeOpen
				}, {
					default: withCtx(() => [createVNode(unref(DialogTrigger_default), null, {
						default: withCtx(() => [createTextVNode(toDisplayString(text.value.settings), 1)]),
						_: 1
					}), createVNode(unref(DialogPortal_default), { to: __props.portal }, {
						default: withCtx(() => [createVNode(unref(DialogOverlay_default), { class: "dialog-overlay" }), createVNode(unref(DialogContent_default), {
							class: "dialog-content settings-dialog",
							onKeydown: withKeys(escape, ["esc"])
						}, {
							default: withCtx(() => [
								createVNode(unref(DialogTitle_default), null, {
									default: withCtx(() => [createTextVNode(toDisplayString(text.value.settings), 1)]),
									_: 1
								}),
								createVNode(unref(DialogDescription_default), null, {
									default: withCtx(() => [createTextVNode(toDisplayString(text.value.settingsDescription), 1)]),
									_: 1
								}),
								createBaseVNode("label", _hoisted_1$1, toDisplayString(text.value.textSize), 1),
								createBaseVNode("input", {
									id: "text-size",
									type: "range",
									min: "70",
									max: "150",
									step: "10",
									value: unref(state).textSize,
									onInput: input
								}, null, 40, _hoisted_2$1),
								createBaseVNode("p", _hoisted_3$1, toDisplayString(unref(state).textSize) + "% · " + toDisplayString(unref(state).textSize < 100 ? text.value.compact : text.value.default) + " " + toDisplayString(text.value.spacing), 1),
								createBaseVNode("button", { onClick: _cache[0] || (_cache[0] = ($event) => unref(preferences).setTextSize(100)) }, toDisplayString(text.value.reset), 1),
								createBaseVNode("fieldset", _hoisted_4$1, [createBaseVNode("legend", null, toDisplayString(text.value.theme), 1), (openBlock(), createElementBlock(Fragment, null, renderList(themes, (theme) => {
									return createBaseVNode("label", { key: theme }, [
										createBaseVNode("input", {
											type: "radio",
											name: "theme",
											value: theme,
											checked: unref(state).theme === theme,
											onChange: ($event) => unref(preferences).set({ theme })
										}, null, 40, _hoisted_5$1),
										createBaseVNode("span", {
											class: "theme-swatch",
											"data-swatch": theme,
											"aria-hidden": "true"
										}, null, 8, _hoisted_6$1),
										createTextVNode(" " + toDisplayString(theme.charAt(0).toUpperCase() + theme.slice(1)), 1)
									]);
								}), 64))]),
								createBaseVNode("label", _hoisted_7$1, toDisplayString(text.value.language), 1),
								createBaseVNode("select", {
									id: "interface-language",
									value: unref(state).language,
									onChange: language
								}, [..._cache[1] || (_cache[1] = [
									createBaseVNode("option", { value: "en" }, "English", -1),
									createBaseVNode("option", { value: "zh-CN" }, "简体中文", -1),
									createBaseVNode("option", { value: "zh-TW" }, "繁體中文", -1)
								])], 40, _hoisted_8$1),
								!unref(preferences).persistent.value ? (openBlock(), createElementBlock("p", _hoisted_9$1, toDisplayString(text.value.storageUnavailable), 1)) : createCommentVNode("", true),
								createVNode(unref(DialogClose_default), null, {
									default: withCtx(() => [createTextVNode(toDisplayString(text.value.close), 1)]),
									_: 1
								})
							]),
							_: 1
						})]),
						_: 1
					}, 8, ["to"])]),
					_: 1
				}, 8, ["open"]);
			};
		}
	});
	var _hoisted_1 = { class: "workspace-tools" };
	var _hoisted_2 = ["aria-label"];
	var _hoisted_3 = {
		key: 0,
		class: "narrow-overview-link",
		href: "https://www.tsdm39.com/forum.php"
	};
	var _hoisted_4 = {
		key: 1,
		class: "narrow-overview-link search-new-link",
		href: "https://www.tsdm39.com/search.php?mod=forum&adv=yes"
	};
	var _hoisted_5 = ["href"];
	var _hoisted_6 = {
		key: 0,
		class: "board-picker"
	};
	var _hoisted_7 = ["aria-label", "value"];
	var _hoisted_8 = {
		key: 0,
		value: "",
		disabled: ""
	};
	var _hoisted_9 = { value: "https://www.tsdm39.com/forum.php" };
	var _hoisted_10 = ["value"];
	var _hoisted_11 = ["value"];
	var _hoisted_12 = {
		key: 1,
		class: "board-picker"
	};
	var _hoisted_13 = [
		"aria-label",
		"value",
		"disabled"
	];
	var _hoisted_14 = {
		value: "",
		disabled: ""
	};
	var _hoisted_15 = ["value"];
	var _hoisted_16 = {
		key: 2,
		class: "board-picker"
	};
	var _hoisted_17 = ["aria-label", "value"];
	var _hoisted_18 = ["value"];
	var _hoisted_19 = { class: "narrow-section-picker" };
	var _hoisted_20 = ["aria-label", "value"];
	var _hoisted_21 = ["value"];
	var _hoisted_22 = { class: "writing-actions" };
	var _hoisted_23 = ["disabled"];
	var _hoisted_24 = {
		key: 2,
		role: "status"
	};
	var _hoisted_25 = {
		key: 3,
		role: "alert"
	};
	var _hoisted_26 = {
		key: 4,
		role: "alert"
	};
	var _hoisted_27 = ["disabled"];
	var _hoisted_28 = { class: "workspace-status" };
	var _hoisted_29 = {
		key: 0,
		role: "alert"
	};
	var _hoisted_30 = { key: 0 };
	var _hoisted_31 = ["aria-label", "value"];
	var _hoisted_32 = { key: 1 };
	var _hoisted_33 = {
		key: 1,
		role: "alert"
	};
	var _hoisted_34 = {
		key: 2,
		class: "recovery-note"
	};
	var _hoisted_35 = {
		key: 3,
		role: "alert"
	};
	var _hoisted_36 = { key: 0 };
	var _hoisted_37 = { key: 1 };
	var _hoisted_38 = {
		key: 4,
		role: "alert"
	};
	var _hoisted_39 = {
		key: 5,
		role: "status"
	};
	var _hoisted_40 = {
		key: 6,
		role: "status"
	};
	var _hoisted_41 = {
		key: 7,
		role: "alert"
	};
	var _hoisted_42 = {
		key: 8,
		class: "notice",
		role: "alert"
	};
	var _hoisted_43 = ["data-view"];
	var _hoisted_44 = ["aria-label"];
	var _hoisted_45 = ["aria-current", "onClick"];
	var _hoisted_46 = ["aria-label"];
	var _hoisted_47 = { href: "https://www.tsdm39.com/forum.php" };
	var _hoisted_48 = ["href"];
	var _hoisted_49 = ["href"];
	var _hoisted_50 = ["href"];
	var _hoisted_51 = ["aria-label"];
	var _hoisted_52 = {
		key: 2,
		class: "overview pane",
		"data-scroll-pane": "overview"
	};
	var _hoisted_53 = ["href"];
	var _hoisted_54 = ["aria-label"];
	var _hoisted_55 = { href: "https://www.tsdm39.com/search.php?mod=forum&adv=yes" };
	var _hoisted_56 = ["aria-label"];
	var _hoisted_57 = ["href", "aria-current"];
	var _hoisted_58 = { key: 0 };
	var _hoisted_59 = ["aria-label"];
	var _hoisted_60 = { class: "board-grid" };
	var _hoisted_61 = ["href", "aria-label"];
	var _hoisted_62 = ["aria-label"];
	var _hoisted_63 = ["href"];
	var _hoisted_64 = ["aria-label"];
	var _hoisted_65 = { key: 0 };
	var _hoisted_66 = { class: "board-grid" };
	var _hoisted_67 = ["href", "aria-label"];
	var _hoisted_68 = ["aria-label"];
	var _hoisted_69 = ["href"];
	var _hoisted_70 = ["aria-label"];
	var _hoisted_71 = ["id", "data-thread-id"];
	var _hoisted_72 = { key: 0 };
	var _hoisted_73 = { key: 1 };
	var _hoisted_74 = ["href", "aria-current"];
	var _hoisted_75 = ["href"];
	var _hoisted_76 = { key: 1 };
	var _hoisted_77 = ["aria-label"];
	var _hoisted_78 = ["href"];
	var _hoisted_79 = ["aria-label"];
	var _hoisted_80 = { class: "thread-heading" };
	var _hoisted_81 = { class: "eyebrow" };
	var _hoisted_82 = ["href"];
	var _hoisted_83 = ["aria-label"];
	var _hoisted_84 = ["href"];
	var _hoisted_85 = {
		key: 0,
		role: "alert"
	};
	var _hoisted_86 = [
		"id",
		"aria-label",
		"data-targeted"
	];
	var _hoisted_87 = ["href"];
	var _hoisted_88 = ["aria-label"];
	var _hoisted_89 = ["disabled", "onClick"];
	var _hoisted_90 = ["aria-label"];
	var _hoisted_91 = ["role"];
	var _hoisted_92 = ["aria-label"];
	var _hoisted_93 = ["href"];
	var _hoisted_94 = {
		key: 10,
		class: "board-overview pane"
	};
	var WorkspaceLayout_default = defineComponent({
		__name: "WorkspaceLayout",
		props: {
			workspace: {},
			portal: {}
		},
		setup(__props) {
			const props = __props;
			const state = props.workspace.state;
			const text = computed(() => strings(props.workspace.preferences.state.value.language));
			const sections = [
				"boards",
				"search",
				"saved",
				"notices",
				"drafts"
			];
			const sectionInfo = computed(() => {
				const section = state.value.section;
				if (section === "boards" || section === "search" || section === "notices") return null;
				return {
					title: text.value[section],
					heading: text.value[`${section}Heading`],
					description: text.value[`${section}Overview`],
					secondary: section === "saved" ? [text.value.savedBoards, text.value.savedThreads] : [text.value[`${section}Scope`]],
					nativeURL: section === "saved" ? "https://www.tsdm39.com/home.php?mod=space&do=favorite&type=thread" : "https://www.tsdm39.com/home.php?mod=space&do=thread&view=me&type=thread&filter=save"
				};
			});
			function chooseSection(event) {
				if (event.target instanceof HTMLSelectElement && sections.includes(event.target.value)) props.workspace.openSection(event.target.value);
			}
			let viewportPositions = [];
			let appearanceAnchors = [];
			let viewportWidth = window.innerWidth;
			let viewportHeight = window.innerHeight;
			const workspaceHost = () => props.portal.getRootNode().host;
			function capturePositions(retained = []) {
				return [...workspaceHost().shadowRoot?.querySelectorAll(".pane") ?? []].flatMap((pane) => {
					if (!pane.getClientRects().length) return [];
					const bounds = pane.getBoundingClientRect();
					const anchor = retained.find((position) => position.pane === pane && position.anchor.isConnected && position.scrollTop === pane.scrollTop)?.anchor ?? [...pane.querySelectorAll(".post-content p, .post-content pre, .post-content .table-overflow, .post-content summary, .thread-row, .board-card, .board-group > h2, .thread-heading")].find((node) => node.getBoundingClientRect().bottom > bounds.top + 1 && node.getBoundingClientRect().top < bounds.bottom);
					return anchor ? [{
						pane,
						anchor,
						offset: anchor.getBoundingClientRect().top,
						paneTop: bounds.top
					}] : [];
				});
			}
			function rememberPositions() {
				if (window.innerWidth !== viewportWidth || window.innerHeight !== viewportHeight) return;
				const current = capturePositions();
				viewportPositions = [...viewportPositions.filter(({ pane }) => pane.isConnected && !current.some((position) => position.pane === pane)), ...current];
			}
			function restorePositions(positions, relativeToPane = false) {
				for (const { pane, anchor, offset, paneTop } of positions) if (anchor.isConnected && pane.getClientRects().length) pane.scrollTop += anchor.getBoundingClientRect().top - offset - (relativeToPane ? pane.getBoundingClientRect().top - paneTop : 0);
			}
			function resize() {
				restorePositions(viewportPositions, true);
				viewportWidth = window.innerWidth;
				viewportHeight = window.innerHeight;
				rememberPositions();
			}
			watch(() => [state.value.result, state.value.section], rememberPositions, { flush: "post" });
			onMounted(() => {
				rememberPositions();
				workspaceHost().shadowRoot.addEventListener("scroll", rememberPositions, true);
				window.addEventListener("resize", resize);
			});
			onUnmounted(() => {
				workspaceHost().shadowRoot.removeEventListener("scroll", rememberPositions, true);
				window.removeEventListener("resize", resize);
			});
			watch(props.workspace.preferences.state, () => {
				const host = workspaceHost();
				const positions = capturePositions(appearanceAnchors);
				host.style.setProperty("--text-scale", String(props.workspace.preferences.state.value.textSize / 100));
				host.dataset.theme = props.workspace.preferences.state.value.theme;
				host.dataset.spacing = props.workspace.preferences.state.value.textSize < 100 ? "compact" : "default";
				host.lang = props.workspace.preferences.state.value.language;
				nextTick().then(() => {
					restorePositions(positions);
					appearanceAnchors = positions.map(({ pane, anchor }) => ({
						pane,
						anchor,
						scrollTop: pane.scrollTop
					}));
					rememberPositions();
				});
			}, {
				immediate: true,
				flush: "sync"
			});
			const download = props.workspace.download;
			watch(download, async (value) => {
				if (value?.status !== "ready" && value?.status !== "failure") return;
				await nextTick();
				const root = props.portal.getRootNode();
				if (root instanceof ShadowRoot) root.querySelector("[data-download-status]")?.scrollIntoView({ block: "nearest" });
			});
			const writing = props.workspace.writing.state;
			function prepareWriting() {
				const url = pickerBoard.value?.url;
				const id = url && new URL(url).searchParams.get("fid");
				if (id) props.workspace.writing.prepare(id);
			}
			const boardContext = computed(() => state.value.section !== "boards" ? null : state.value.result?.kind === "board" ? state.value.result.board : state.value.result?.kind !== "directory" && state.value.origin?.kind === "board" ? state.value.origin.board : null);
			const searchContext = computed(() => state.value.section !== "search" ? null : state.value.result?.kind === "search" ? state.value.result.search : state.value.result?.kind === "thread" && state.value.origin?.kind === "search" ? state.value.origin.search : null);
			const selectedThread = computed(() => state.value.result?.kind === "thread" ? state.value.result.thread.id : null);
			const noticeContext = computed(() => state.value.section !== "notices" ? null : state.value.result?.kind === "notices" ? state.value.result.notices : state.value.origin?.kind === "notices" ? state.value.origin.notices : null);
			const boardChoices = computed(() => state.value.result?.kind === "directory" ? state.value.result.directory.groups.flatMap((group) => group.boards) : boardContext.value?.boards ?? []);
			const pickerBoard = computed(() => {
				if (state.value.result?.kind === "directory") return null;
				if (boardContext.value) return {
					url: boardContext.value.url,
					label: boardContext.value.title
				};
				return state.value.result?.kind === "thread" ? state.value.result.thread.parent : null;
			});
			const pickerValue = computed(() => state.value.result?.kind === "directory" ? "https://www.tsdm39.com/forum.php" : pickerBoard.value?.url ?? "");
			function chooseBoard(event) {
				const target = event.target;
				if (target instanceof HTMLSelectElement && target.value) props.workspace.openThread(target.value);
			}
			function chooseNoticeCategory(event) {
				const target = event.target;
				if (target instanceof HTMLSelectElement && target.value) props.workspace.loadNotices(target.value);
			}
			const aboutOpen = ref(false);
			function changeAboutOpen(value) {
				const change = () => {
					aboutOpen.value = value;
				};
				if (!props.workspace.writing.deferViewChange(change)) change();
			}
			const inspectRecovery = ref(false), confirmReset = ref(false);
			const missingTarget = computed(() => {
				const result = state.value.result;
				return result?.kind === "thread" && result.thread.target && !result.thread.posts.some((p) => p.id === result.thread.target);
			});
			function closeAboutOnEscape(event) {
				if (event.defaultPrevented) return;
				event.stopPropagation();
				aboutOpen.value = false;
			}
			function navigate(event) {
				const link = event.composedPath().find((node) => node instanceof HTMLAnchorElement);
				if (!(link instanceof HTMLAnchorElement) || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || link.target || link.href.includes("tsdm-native")) return;
				const current = state.value.result;
				if (current?.kind === "thread") {
					const post = current.thread.posts.find((item) => `pid${item.id}` === link.closest("article")?.id);
					const attachment = post?.attachments?.find((item) => item.url === link.href);
					if (post && attachment) {
						event.preventDefault();
						props.workspace.prepareDownload(post.id, attachment.id);
						return;
					}
				}
				const route = describeDestination(link.href);
				if (!route || new URL(route.url).origin !== location.origin) return;
				event.preventDefault();
				props.workspace.openThread(link.href, link.closest("[data-notice-id]")?.getAttribute("data-notice-id") ?? link.closest("[data-thread-id]")?.getAttribute("data-thread-id") ?? null);
			}
			let stopReadingImageRestore;
			function followPendingReadingImages(container, target, savedScrollTop) {
				const pending = new Set([...container.querySelectorAll("img")].filter((image) => !image.complete && !!(target.compareDocumentPosition(image) & Node.DOCUMENT_POSITION_PRECEDING)));
				if (!pending.size) return;
				let expectedScrollTop = container.scrollTop;
				const inputEvents = [
					"wheel",
					"touchstart",
					"pointerdown",
					"keydown"
				];
				const stop = () => {
					container.removeEventListener("load", settled, true);
					container.removeEventListener("error", settled, true);
					container.removeEventListener("scroll", scrolled);
					for (const event of inputEvents) container.removeEventListener(event, stop);
					if (stopReadingImageRestore === stop) stopReadingImageRestore = void 0;
				};
				const scrolled = () => {
					if (container.scrollTop !== expectedScrollTop) stop();
				};
				const settled = (event) => {
					if (!(event.target instanceof HTMLImageElement) || !pending.delete(event.target)) return;
					if (!target.isConnected) return stop();
					if (savedScrollTop !== null) container.scrollTop = savedScrollTop;
					else target.scrollIntoView({ block: "start" });
					expectedScrollTop = container.scrollTop;
					if (!pending.size) stop();
				};
				container.addEventListener("load", settled, true);
				container.addEventListener("error", settled, true);
				container.addEventListener("scroll", scrolled);
				for (const event of inputEvents) container.addEventListener(event, stop, { passive: true });
				stopReadingImageRestore = stop;
			}
			watch([
				() => state.value.key,
				() => state.value.section,
				() => state.value.result,
				() => writing.value.visible
			], () => stopReadingImageRestore?.(), { flush: "sync" });
			onUnmounted(() => stopReadingImageRestore?.());
			onMounted(() => {
				const root = props.portal.getRootNode().host;
				const pane = () => root.shadowRoot?.querySelector(`[data-scroll-pane="${state.value.result?.kind === "thread" ? "reading" : state.value.result?.kind === "board" ? "results" : "overview"}"]`);
				props.workspace.setViewAdapter({
					capture() {
						const container = pane();
						const anchor = [...container?.querySelectorAll("article[id], [data-thread-id]") ?? []].find((node) => node.getBoundingClientRect().bottom > (container?.getBoundingClientRect().top ?? 0));
						return {
							anchor: anchor?.id ?? null,
							offset: anchor?.getBoundingClientRect().top ?? 0,
							scrollTop: container?.scrollTop ?? root.scrollTop
						};
					},
					restore(position, target, selection) {
						stopReadingImageRestore?.();
						if (writing.value.visible) return;
						const container = pane();
						if (container) container.scrollTop = position?.scrollTop ?? 0;
						const node = target ? root.shadowRoot?.getElementById(`pid${target}`) : null;
						if (node && !position) node.scrollIntoView({ block: "start" });
						if (!position && !state.value.loading && state.value.result?.kind === "search" && state.value.result.search.results) container?.querySelector(".search-results h2")?.scrollIntoView({ block: "start" });
						const selected = selection ? root.shadowRoot?.getElementById(`notice-${selection}`) ?? root.shadowRoot?.getElementById(`row-${selection}`)?.querySelector(".subject") : null;
						(node ?? selected)?.focus({ preventScroll: true });
						if (container && node) followPendingReadingImages(container, node, position?.scrollTop ?? null);
					}
				});
			});
			const accountLabel = computed(() => {
				const account = state.value.result?.account;
				if (state.value.restored && account?.kind === "member") return insert(text.value.snapshotMember, account.name);
				if (state.value.restored && account?.kind === "guest") return text.value.snapshotGuest;
				return account?.kind === "member" ? insert(text.value.signedIn, account.name) : account?.kind === "guest" ? text.value.guest : text.value.accountUnknown;
			});
			return (_ctx, _cache) => {
				return openBlock(), createElementBlock("div", {
					class: "workspace",
					onClick: navigate
				}, [
					createBaseVNode("header", null, [
						_cache[15] || (_cache[15] = createBaseVNode("a", {
							class: "brand",
							href: "https://www.tsdm39.com/"
						}, "TSDM", -1)),
						createBaseVNode("span", null, toDisplayString(accountLabel.value), 1),
						createVNode(SettingsDialog_default, {
							workspace: __props.workspace,
							portal: __props.portal
						}, null, 8, ["workspace", "portal"]),
						createVNode(unref(DialogRoot_default), {
							open: aboutOpen.value,
							"onUpdate:open": changeAboutOpen
						}, {
							default: withCtx(() => [createVNode(unref(DialogTrigger_default), null, {
								default: withCtx(() => [createTextVNode(toDisplayString(text.value.about), 1)]),
								_: 1
							}), createVNode(unref(DialogPortal_default), { to: __props.portal }, {
								default: withCtx(() => [createVNode(unref(DialogOverlay_default), { class: "dialog-overlay" }), createVNode(unref(DialogContent_default), {
									class: "dialog-content",
									onKeydown: withKeys(closeAboutOnEscape, ["esc"])
								}, {
									default: withCtx(() => [
										createVNode(unref(DialogTitle_default), null, {
											default: withCtx(() => [createTextVNode(toDisplayString(text.value.about), 1)]),
											_: 1
										}),
										createVNode(unref(DialogDescription_default), null, {
											default: withCtx(() => [createTextVNode(toDisplayString(text.value.aboutDescription), 1)]),
											_: 1
										}),
										createBaseVNode("p", null, toDisplayString(text.value.nativeHelp), 1),
										createVNode(unref(DialogClose_default), null, {
											default: withCtx(() => [createTextVNode(toDisplayString(text.value.close), 1)]),
											_: 1
										})
									]),
									_: 1
								})]),
								_: 1
							}, 8, ["to"])]),
							_: 1
						}, 8, ["open"])
					]),
					createBaseVNode("div", _hoisted_1, [
						createBaseVNode("nav", { "aria-label": text.value.actions }, [
							unref(state).result?.kind !== "directory" ? (openBlock(), createElementBlock("a", _hoisted_3, toDisplayString(text.value.allBoards), 1)) : createCommentVNode("", true),
							unref(state).section === "search" ? (openBlock(), createElementBlock("a", _hoisted_4, toDisplayString(text.value.newSearch), 1)) : createCommentVNode("", true),
							unref(state).canBack ? (openBlock(), createElementBlock("button", {
								key: 2,
								onClick: _cache[0] || (_cache[0] = ($event) => __props.workspace.back())
							}, toDisplayString(text.value.back), 1)) : createCommentVNode("", true),
							unref(state).result?.kind === "search" && unref(state).result.search.effective ? (openBlock(), createElementBlock("button", {
								key: 3,
								onClick: _cache[1] || (_cache[1] = ($event) => __props.workspace.submitSearch(true))
							}, toDisplayString(text.value.rerunSearch), 1)) : (openBlock(), createElementBlock("button", {
								key: 4,
								onClick: _cache[2] || (_cache[2] = ($event) => __props.workspace.refresh())
							}, toDisplayString(unref(state).destination.includes("mod=viewthread") ? text.value.refreshThread : text.value.refresh), 1)),
							createBaseVNode("a", { href: unref(nativeDestination)(sectionInfo.value?.nativeURL ?? unref(state).destination) }, toDisplayString(text.value.native), 9, _hoisted_5)
						], 8, _hoisted_2),
						unref(state).section === "boards" ? (openBlock(), createElementBlock("label", _hoisted_6, [createTextVNode(toDisplayString(text.value.boardNavigation), 1), createBaseVNode("select", {
							"aria-label": text.value.boardNavigation,
							value: pickerValue.value,
							onChange: chooseBoard
						}, [
							!pickerValue.value ? (openBlock(), createElementBlock("option", _hoisted_8, toDisplayString(text.value.chooseBoard), 1)) : createCommentVNode("", true),
							createBaseVNode("option", _hoisted_9, toDisplayString(text.value.allBoards), 1),
							pickerBoard.value ? (openBlock(), createElementBlock("option", {
								key: 1,
								value: pickerBoard.value.url
							}, toDisplayString(pickerBoard.value.label), 9, _hoisted_10)) : createCommentVNode("", true),
							(openBlock(true), createElementBlock(Fragment, null, renderList(boardChoices.value, (board) => {
								return openBlock(), createElementBlock("option", {
									key: board.url,
									value: board.url
								}, toDisplayString(board.label), 9, _hoisted_11);
							}), 128))
						], 40, _hoisted_7)])) : createCommentVNode("", true),
						unref(state).section === "notices" && noticeContext.value ? (openBlock(), createElementBlock("label", _hoisted_12, [createTextVNode(toDisplayString(text.value.noticeCategories), 1), createBaseVNode("select", {
							"aria-label": text.value.noticeCategories,
							value: noticeContext.value.categories.find((category) => category.current)?.url ?? "",
							disabled: unref(state).loading,
							onChange: chooseNoticeCategory
						}, [createBaseVNode("option", _hoisted_14, toDisplayString(text.value.noticeCategories), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(noticeContext.value.categories, (category) => {
							return openBlock(), createElementBlock("option", {
								key: category.url,
								value: category.url
							}, toDisplayString(category.label), 9, _hoisted_15);
						}), 128))], 40, _hoisted_13)])) : unref(state).section !== "boards" ? (openBlock(), createElementBlock("label", _hoisted_16, [createTextVNode(toDisplayString(text.value.sectionNavigation), 1), createBaseVNode("select", {
							"aria-label": text.value.sectionNavigation,
							value: unref(state).section,
							onChange: chooseSection
						}, [(openBlock(), createElementBlock(Fragment, null, renderList(sections, (section) => {
							return createBaseVNode("option", {
								key: section,
								value: section
							}, toDisplayString(text.value[section]), 9, _hoisted_18);
						}), 64))], 40, _hoisted_17)])) : createCommentVNode("", true),
						createBaseVNode("label", _hoisted_19, [createTextVNode(toDisplayString(text.value.mainDestinations), 1), createBaseVNode("select", {
							"aria-label": text.value.mainDestinations,
							value: unref(state).section,
							onChange: chooseSection
						}, [(openBlock(), createElementBlock(Fragment, null, renderList(sections, (section) => {
							return createBaseVNode("option", {
								key: section,
								value: section
							}, toDisplayString(text.value[section]), 9, _hoisted_21);
						}), 64))], 40, _hoisted_20)])
					]),
					createBaseVNode("div", _hoisted_22, [
						pickerBoard.value ? (openBlock(), createElementBlock("button", {
							key: 0,
							disabled: unref(writing).preparing,
							onClick: _cache[3] || (_cache[3] = ($event) => prepareWriting())
						}, toDisplayString(text.value.newThread), 9, _hoisted_23)) : createCommentVNode("", true),
						unref(writing).context ? (openBlock(), createElementBlock("button", {
							key: 1,
							onClick: _cache[4] || (_cache[4] = ($event) => __props.workspace.writing.show())
						}, toDisplayString(text.value.returnWriting), 1)) : createCommentVNode("", true),
						unref(writing).preparing ? (openBlock(), createElementBlock("p", _hoisted_24, toDisplayString(text.value.preparingForm), 1)) : createCommentVNode("", true),
						unref(writing).message ? (openBlock(), createElementBlock("p", _hoisted_25, toDisplayString(unref(description)(unref(writing).message, __props.workspace.preferences.state.value.language)), 1)) : createCommentVNode("", true),
						unref(writing).replacement ? (openBlock(), createElementBlock("section", _hoisted_26, [
							createBaseVNode("p", null, toDisplayString(text.value.replaceWritingWarning), 1),
							createBaseVNode("button", { onClick: _cache[5] || (_cache[5] = ($event) => __props.workspace.writing.show()) }, toDisplayString(text.value.returnOriginal), 1),
							createBaseVNode("button", {
								disabled: unref(writing).preparing,
								onClick: _cache[6] || (_cache[6] = ($event) => __props.workspace.writing.discardAndPrepare())
							}, toDisplayString(text.value.discardPrepare), 9, _hoisted_27)
						])) : createCommentVNode("", true)
					]),
					unref(writing).visible ? (openBlock(), createBlock(SourceWriting_default, {
						key: 0,
						workspace: __props.workspace
					}, null, 8, ["workspace"])) : createCommentVNode("", true),
					createBaseVNode("div", _hoisted_28, [
						unref(state).recoveryProblem?.kind === "incompatible" ? (openBlock(), createElementBlock("section", _hoisted_29, [
							createBaseVNode("p", null, toDisplayString(text.value.incompatibleRecovery), 1),
							createBaseVNode("button", { onClick: _cache[7] || (_cache[7] = ($event) => inspectRecovery.value = !inspectRecovery.value) }, toDisplayString(text.value.inspectRecovery), 1),
							inspectRecovery.value ? (openBlock(), createElementBlock("label", _hoisted_30, [createTextVNode(toDisplayString(text.value.retainedRecovery), 1), createBaseVNode("textarea", {
								"aria-label": text.value.retainedRecovery,
								readonly: "",
								value: unref(state).recoveryProblem.raw ?? ""
							}, null, 8, _hoisted_31)])) : createCommentVNode("", true),
							createBaseVNode("button", { onClick: _cache[8] || (_cache[8] = ($event) => confirmReset.value = true) }, toDisplayString(text.value.resetRecovery), 1),
							confirmReset.value ? (openBlock(), createElementBlock("section", _hoisted_32, [
								createBaseVNode("p", null, toDisplayString(text.value.discardRecoveryWarning), 1),
								createBaseVNode("button", { onClick: _cache[9] || (_cache[9] = ($event) => confirmReset.value = false) }, toDisplayString(text.value.keepRecovery), 1),
								createBaseVNode("button", { onClick: _cache[10] || (_cache[10] = ($event) => {
									__props.workspace.resetRecovery();
									confirmReset.value = false;
									inspectRecovery.value = false;
								}) }, toDisplayString(text.value.discardRecovery), 1)
							])) : createCommentVNode("", true)
						])) : createCommentVNode("", true),
						unref(state).recoveryProblem?.kind === "refused" ? (openBlock(), createElementBlock("p", _hoisted_33, toDisplayString(text.value.readRecoveryRefused), 1)) : createCommentVNode("", true),
						unref(state).recoveryAvailable === false ? (openBlock(), createElementBlock("p", _hoisted_34, toDisplayString(text.value.recoveryUnavailable), 1)) : createCommentVNode("", true),
						unref(state).missing ? (openBlock(), createElementBlock("section", _hoisted_35, [
							createBaseVNode("p", null, toDisplayString(text.value.snapshotUnavailable), 1),
							unref(download)?.status === "failure" ? (openBlock(), createElementBlock("p", _hoisted_36, toDisplayString(unref(description)(unref(download).message, __props.workspace.preferences.state.value.language)), 1)) : createCommentVNode("", true),
							createBaseVNode("p", null, toDisplayString(text.value.snapshotReload), 1),
							createBaseVNode("p", null, toDisplayString(text.value.missingSearch), 1),
							unref(state).section === "notices" ? (openBlock(), createElementBlock("p", _hoisted_37, toDisplayString(text.value.noticeEffects), 1)) : createCommentVNode("", true),
							createBaseVNode("button", { onClick: _cache[11] || (_cache[11] = ($event) => __props.workspace.refresh()) }, toDisplayString(text.value.reload), 1)
						])) : createCommentVNode("", true),
						unref(state).documentNavigation ? (openBlock(), createElementBlock("section", _hoisted_38, [createBaseVNode("p", null, toDisplayString(text.value.returnUnavailable), 1), createBaseVNode("button", { onClick: _cache[12] || (_cache[12] = ($event) => __props.workspace.continueWithoutRecovery()) }, toDisplayString(text.value.continueWithoutRecovery), 1)])) : createCommentVNode("", true),
						unref(state).stale ? (openBlock(), createElementBlock("p", _hoisted_39, toDisplayString(unref(state).restored ? text.value.restored : text.value.stale), 1)) : createCommentVNode("", true),
						unref(state).loading ? (openBlock(), createElementBlock("p", _hoisted_40, toDisplayString(text.value.loading), 1)) : createCommentVNode("", true),
						unref(state).failure && unref(state).result !== unref(state).failure && "message" in unref(state).failure ? (openBlock(), createElementBlock("p", _hoisted_41, toDisplayString(unref(description)(unref(state).failure.message, __props.workspace.preferences.state.value.language, "nativeText" in unref(state).failure ? unref(state).failure.nativeText : void 0)), 1)) : createCommentVNode("", true),
						[
							"boards",
							"search",
							"notices"
						].includes(unref(state).section) && unref(state).result && ![
							"directory",
							"board",
							"thread",
							"search",
							"notices"
						].includes(unref(state).result.kind) ? (openBlock(), createElementBlock("section", _hoisted_42, [createBaseVNode("h1", null, toDisplayString(unref(state).result.kind === "invalid" ? text.value.contentUnavailable : unref(description)(unref(state).result.kind.charAt(0).toUpperCase() + unref(state).result.kind.slice(1), __props.workspace.preferences.state.value.language)), 1), createBaseVNode("p", null, toDisplayString("message" in unref(state).result ? unref(description)(unref(state).result.message, __props.workspace.preferences.state.value.language, "nativeText" in unref(state).result ? unref(state).result.nativeText : void 0) : ""), 1)])) : createCommentVNode("", true)
					]),
					withDirectives(createBaseVNode("main", {
						class: "workspace-body",
						"data-view": unref(state).result?.kind ?? "unavailable"
					}, [
						createBaseVNode("nav", {
							"aria-label": text.value.mainDestinations,
							class: "main-destinations pane"
						}, [(openBlock(), createElementBlock(Fragment, null, renderList(sections, (section) => {
							return createBaseVNode("button", {
								key: section,
								"aria-current": unref(state).section === section ? "page" : void 0,
								onClick: ($event) => __props.workspace.openSection(section)
							}, toDisplayString(text.value[section]), 9, _hoisted_45);
						}), 64))], 8, _hoisted_44),
						unref(state).section === "boards" ? (openBlock(), createElementBlock("nav", {
							key: 0,
							"aria-label": text.value.boardsNavigation,
							class: "boards-navigation pane"
						}, [
							createBaseVNode("h2", null, toDisplayString(text.value.browseBoards), 1),
							createBaseVNode("a", _hoisted_47, toDisplayString(text.value.allBoards), 1),
							boardContext.value ? (openBlock(), createElementBlock("a", {
								key: 0,
								href: boardContext.value.url
							}, toDisplayString(boardContext.value.title), 9, _hoisted_48)) : unref(state).result?.kind === "thread" && unref(state).result.thread.parent ? (openBlock(), createElementBlock("a", {
								key: 1,
								href: unref(state).result.thread.parent.url
							}, toDisplayString(unref(state).result.thread.parent.label), 9, _hoisted_49)) : createCommentVNode("", true),
							(openBlock(true), createElementBlock(Fragment, null, renderList(boardChoices.value, (board) => {
								return openBlock(), createElementBlock("a", {
									key: board.url,
									href: board.url
								}, toDisplayString(board.label), 9, _hoisted_50);
							}), 128))
						], 8, _hoisted_46)) : createCommentVNode("", true),
						sectionInfo.value ? (openBlock(), createElementBlock("nav", {
							key: 1,
							class: "boards-navigation pane",
							"aria-label": text.value.sectionNavigation
						}, [createBaseVNode("h2", null, toDisplayString(sectionInfo.value.title), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(sectionInfo.value.secondary, (label) => {
							return openBlock(), createElementBlock("p", { key: label }, toDisplayString(label), 1);
						}), 128))], 8, _hoisted_51)) : createCommentVNode("", true),
						sectionInfo.value ? (openBlock(), createElementBlock("section", _hoisted_52, [
							createBaseVNode("h1", null, toDisplayString(sectionInfo.value.title), 1),
							createBaseVNode("h2", null, toDisplayString(sectionInfo.value.heading), 1),
							createBaseVNode("p", null, toDisplayString(sectionInfo.value.description), 1),
							createBaseVNode("a", { href: unref(nativeDestination)(sectionInfo.value.nativeURL) }, toDisplayString(text.value.native), 9, _hoisted_53)
						])) : createCommentVNode("", true),
						unref(state).section === "search" ? (openBlock(), createElementBlock("nav", {
							key: 3,
							class: "boards-navigation pane",
							"aria-label": text.value.searchNavigation
						}, [
							createBaseVNode("h2", null, toDisplayString(text.value.search), 1),
							createBaseVNode("a", _hoisted_55, toDisplayString(text.value.newSearch), 1),
							createBaseVNode("p", null, toDisplayString(text.value.deliberateSearch), 1)
						], 8, _hoisted_54)) : createCommentVNode("", true),
						searchContext.value ? (openBlock(), createBlock(SearchView_default, {
							key: 4,
							search: searchContext.value,
							language: __props.workspace.preferences.state.value.language,
							secondary: unref(state).result?.kind === "thread",
							selection: unref(state).selection ?? selectedThread.value,
							loading: unref(state).loading,
							onSubmit: __props.workspace.submitSearch,
							onEdit: __props.workspace.editSearch
						}, null, 8, [
							"search",
							"language",
							"secondary",
							"selection",
							"loading",
							"onSubmit",
							"onEdit"
						])) : createCommentVNode("", true),
						unref(state).section === "notices" ? (openBlock(), createBlock(NoticesView_default, {
							key: 5,
							notices: noticeContext.value,
							loading: unref(state).loading,
							language: __props.workspace.preferences.state.value.language,
							secondary: unref(state).result?.kind === "thread",
							selection: unref(state).selection,
							onLoad: _cache[13] || (_cache[13] = ($event) => __props.workspace.loadNotices())
						}, null, 8, [
							"notices",
							"loading",
							"language",
							"secondary",
							"selection"
						])) : createCommentVNode("", true),
						unref(state).section === "notices" ? (openBlock(), createElementBlock("nav", {
							key: 6,
							class: "boards-navigation pane notices-navigation",
							"aria-label": text.value.noticeCategories
						}, [
							createBaseVNode("h2", null, toDisplayString(text.value.notices), 1),
							(openBlock(true), createElementBlock(Fragment, null, renderList(noticeContext.value?.categories ?? [], (category) => {
								return openBlock(), createElementBlock("a", {
									key: category.url,
									href: category.url,
									"aria-current": category.current ? "page" : void 0
								}, toDisplayString(category.label), 9, _hoisted_57);
							}), 128)),
							!noticeContext.value ? (openBlock(), createElementBlock("p", _hoisted_58, toDisplayString(text.value.noticesHeading), 1)) : createCommentVNode("", true)
						], 8, _hoisted_56)) : createCommentVNode("", true),
						unref(state).section === "boards" && unref(state).result?.kind === "directory" ? (openBlock(), createElementBlock("section", {
							key: 7,
							class: "overview pane",
							"data-scroll-pane": "overview",
							"aria-label": text.value.boardsOverview
						}, [
							createBaseVNode("h1", null, toDisplayString(text.value.boards), 1),
							createBaseVNode("p", null, toDisplayString(text.value.chooseBoardDescription), 1),
							(openBlock(true), createElementBlock(Fragment, null, renderList(unref(state).result.directory.groups, (group) => {
								return openBlock(), createElementBlock("section", {
									key: group.title,
									class: "board-group"
								}, [createBaseVNode("h2", null, toDisplayString(group.title), 1), createBaseVNode("div", _hoisted_60, [(openBlock(true), createElementBlock(Fragment, null, renderList(group.boards, (board) => {
									return openBlock(), createElementBlock("a", {
										key: board.url,
										href: board.url,
										"aria-label": board.label,
										class: "board-card"
									}, [
										createBaseVNode("strong", null, toDisplayString(board.label), 1),
										createBaseVNode("span", null, toDisplayString(board.description), 1),
										createBaseVNode("small", null, toDisplayString(board.stats), 1)
									], 8, _hoisted_61);
								}), 128))])]);
							}), 128)),
							createBaseVNode("nav", { "aria-label": text.value.directoryPages }, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(state).result.directory.pages.links, (link) => {
								return openBlock(), createElementBlock("a", {
									key: link.url,
									href: link.url
								}, toDisplayString(link.label), 9, _hoisted_63);
							}), 128))], 8, _hoisted_62)
						], 8, _hoisted_59)) : createCommentVNode("", true),
						boardContext.value ? (openBlock(), createElementBlock("section", {
							key: 8,
							class: normalizeClass(["results-pane pane", { "secondary-results": unref(state).result?.kind === "thread" }]),
							"data-scroll-pane": "results",
							"aria-label": text.value.threadResults
						}, [
							createBaseVNode("h1", null, toDisplayString(boardContext.value.title), 1),
							boardContext.value.boards.length ? (openBlock(), createElementBlock("section", _hoisted_65, [createBaseVNode("h2", null, toDisplayString(text.value.subordinateBoards), 1), createBaseVNode("div", _hoisted_66, [(openBlock(true), createElementBlock(Fragment, null, renderList(boardContext.value.boards, (board) => {
								return openBlock(), createElementBlock("a", {
									key: board.url,
									href: board.url,
									"aria-label": board.label,
									class: "board-card"
								}, toDisplayString(board.label), 9, _hoisted_67);
							}), 128))])])) : createCommentVNode("", true),
							createBaseVNode("nav", { "aria-label": text.value.boardFilters }, [(openBlock(true), createElementBlock(Fragment, null, renderList(boardContext.value.filters, (filter) => {
								return openBlock(), createElementBlock("a", {
									key: filter.url,
									href: filter.url
								}, toDisplayString(filter.label), 9, _hoisted_69);
							}), 128))], 8, _hoisted_68),
							createBaseVNode("ul", { "aria-label": text.value.criteria }, [(openBlock(true), createElementBlock(Fragment, null, renderList(boardContext.value.criteria, (criterion) => {
								return openBlock(), createElementBlock("li", { key: criterion.label }, toDisplayString(criterion.label), 1);
							}), 128))], 8, _hoisted_70),
							createBaseVNode("p", null, toDisplayString(text.value.page) + " " + toDisplayString(boardContext.value.pages.current), 1),
							(openBlock(true), createElementBlock(Fragment, null, renderList(boardContext.value.threads, (row) => {
								return openBlock(), createElementBlock("div", {
									id: `row-${row.rowId}`,
									key: row.rowId,
									class: "thread-row",
									"data-thread-id": row.id
								}, [
									row.pinned ? (openBlock(), createElementBlock("span", _hoisted_72, toDisplayString(text.value.pinned), 1)) : createCommentVNode("", true),
									row.moved ? (openBlock(), createElementBlock("span", _hoisted_73, toDisplayString(text.value.moved), 1)) : createCommentVNode("", true),
									createBaseVNode("span", null, toDisplayString(row.category), 1),
									createBaseVNode("a", {
										href: row.url,
										class: "subject",
										"aria-current": (unref(state).selection ?? selectedThread.value) === row.id ? "true" : void 0
									}, toDisplayString(row.label), 9, _hoisted_74),
									createBaseVNode("span", null, toDisplayString(row.author), 1),
									createBaseVNode("time", null, toDisplayString(row.date), 1),
									createBaseVNode("span", null, toDisplayString(row.replies) + " " + toDisplayString(text.value.replies) + " · " + toDisplayString(row.views) + " " + toDisplayString(text.value.views), 1),
									row.lastPost ? (openBlock(), createElementBlock("a", {
										key: 2,
										href: row.lastPost.url
									}, toDisplayString(unref(insert)(text.value.lastReply, row.label)), 9, _hoisted_75)) : createCommentVNode("", true)
								], 8, _hoisted_71);
							}), 128)),
							!boardContext.value.threads.length ? (openBlock(), createElementBlock("p", _hoisted_76, toDisplayString(boardContext.value.empty), 1)) : createCommentVNode("", true),
							createBaseVNode("nav", { "aria-label": text.value.boardPages }, [(openBlock(true), createElementBlock(Fragment, null, renderList(boardContext.value.pages.links, (link) => {
								return openBlock(), createElementBlock("a", {
									key: link.url,
									href: link.url
								}, toDisplayString(link.label), 9, _hoisted_78);
							}), 128))], 8, _hoisted_77)
						], 10, _hoisted_64)) : createCommentVNode("", true),
						[
							"boards",
							"search",
							"notices"
						].includes(unref(state).section) && unref(state).result?.kind === "thread" ? (openBlock(), createElementBlock("section", {
							key: 9,
							class: "reading-pane pane",
							"data-scroll-pane": "reading",
							"aria-label": text.value.threadReading
						}, [
							createBaseVNode("section", _hoisted_80, [
								createBaseVNode("p", _hoisted_81, toDisplayString(text.value.thread) + " " + toDisplayString(unref(state).result.thread.id), 1),
								createBaseVNode("h1", null, toDisplayString(unref(state).result.thread.title), 1),
								createBaseVNode("p", null, toDisplayString(text.value.page) + " " + toDisplayString(unref(state).result.thread.pages.current), 1),
								unref(state).result.thread.parent ? (openBlock(), createElementBlock("a", {
									key: 0,
									href: unref(state).result.thread.parent.url
								}, toDisplayString(unref(state).result.thread.parent.label), 9, _hoisted_82)) : createCommentVNode("", true)
							]),
							createBaseVNode("nav", { "aria-label": text.value.threadFilters }, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(state).result.thread.filters, (filter) => {
								return openBlock(), createElementBlock("a", {
									key: filter.url,
									href: filter.url
								}, toDisplayString(filter.label), 9, _hoisted_84);
							}), 128))], 8, _hoisted_83),
							missingTarget.value ? (openBlock(), createElementBlock("p", _hoisted_85, toDisplayString(unref(insert)(text.value.missingPost, unref(state).result.thread.target ?? "")), 1)) : createCommentVNode("", true),
							(openBlock(true), createElementBlock(Fragment, null, renderList(unref(state).result.thread.notices, (notice) => {
								return openBlock(), createElementBlock("p", {
									key: notice,
									class: "permission-notice"
								}, toDisplayString(notice), 1);
							}), 128)),
							(openBlock(true), createElementBlock(Fragment, null, renderList(unref(state).result.thread.posts, (post) => {
								return openBlock(), createElementBlock("article", {
									id: `pid${post.id}`,
									key: post.id,
									"aria-label": `${text.value.post} ${post.id}`,
									"data-targeted": unref(state).result.thread.target === post.id,
									tabindex: "-1"
								}, [
									createBaseVNode("header", null, [
										createBaseVNode("strong", null, toDisplayString(post.author), 1),
										createBaseVNode("span", null, toDisplayString(text.value.floor) + " " + toDisplayString(post.floor || text.value.unknown), 1),
										createBaseVNode("time", null, toDisplayString(post.date), 1),
										createBaseVNode("a", { href: post.url }, toDisplayString(text.value.post) + " " + toDisplayString(post.id), 9, _hoisted_87)
									]),
									createVNode(unref(ContentView_default), {
										nodes: post.content,
										language: __props.workspace.preferences.state.value.language
									}, null, 8, ["nodes", "language"]),
									post.attachments?.length ? (openBlock(), createElementBlock("ul", {
										key: 0,
										"aria-label": text.value.attachments
									}, [(openBlock(true), createElementBlock(Fragment, null, renderList(post.attachments, (attachment) => {
										return openBlock(), createElementBlock("li", { key: attachment.id }, [createBaseVNode("button", {
											disabled: unref(download)?.status === "checking",
											onClick: ($event) => __props.workspace.prepareDownload(post.id, attachment.id)
										}, toDisplayString(text.value.download) + " " + toDisplayString(attachment.name), 9, _hoisted_89), unref(download)?.postId === post.id && unref(download)?.attachmentId === attachment.id ? (openBlock(), createElementBlock("section", {
											key: 0,
											"data-download-status": "",
											"aria-label": text.value.fileDownload
										}, [
											createBaseVNode("strong", null, toDisplayString(unref(download).name), 1),
											createBaseVNode("p", { role: unref(download).status === "failure" ? "alert" : "status" }, toDisplayString(unref(description)(unref(download).message, __props.workspace.preferences.state.value.language)), 9, _hoisted_91),
											unref(download).status === "ready" || unref(download).status === "requested" ? (openBlock(), createElementBlock("button", {
												key: 0,
												onClick: _cache[14] || (_cache[14] = ($event) => __props.workspace.saveDownload())
											}, toDisplayString(text.value.saveFile), 1)) : createCommentVNode("", true)
										], 8, _hoisted_90)) : createCommentVNode("", true)]);
									}), 128))], 8, _hoisted_88)) : createCommentVNode("", true)
								], 8, _hoisted_86);
							}), 128)),
							createBaseVNode("nav", { "aria-label": text.value.pages }, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(state).result.thread.pages.links, (link) => {
								return openBlock(), createElementBlock("a", {
									key: link.url,
									href: link.url
								}, toDisplayString(link.label), 9, _hoisted_93);
							}), 128))], 8, _hoisted_92)
						], 8, _hoisted_79)) : createCommentVNode("", true),
						unref(state).result?.kind === "board" ? (openBlock(), createElementBlock("section", _hoisted_94, [createBaseVNode("h2", null, toDisplayString(text.value.chooseThread), 1), createBaseVNode("p", null, toDisplayString(text.value.chooseThreadDescription), 1)])) : createCommentVNode("", true)
					], 8, _hoisted_43), [[vShow, !unref(writing).visible]])
				]);
			};
		}
	});
	var styles_default = ":host{all:initial;--surface:#fff;--ink:#000;--soft:#eee;--accent:#ebf5e8;--secondary-accent:#a29bba;--separator:#b8b8b8;--boundary:#666;--lightningcss-light:initial;--lightningcss-dark: ;color-scheme:light;font-family:system-ui,Noto Sans CJK TC,PingFang TC,Microsoft JhengHei,sans-serif;font-size:calc(1.125rem * var(--text-scale,1));color:var(--ink);background:var(--surface)}*{box-sizing:border-box}.workspace,.dialog-content{word-break:normal}.workspace{background:var(--surface);min-height:100%;color:var(--ink);line-height:1.45}header,nav{flex-wrap:wrap;align-items:center;gap:16px;display:flex}.workspace>header{border-bottom:1px solid var(--separator);min-height:72px;padding:16px 32px}.brand{font-size:calc(2rem * var(--text-scale,1));margin-right:auto;font-weight:540;text-decoration:none}main{max-width:1120px;margin:auto;padding:32px}nav{margin-bottom:32px}a{color:inherit;text-underline-offset:3px}a,button{align-items:center;min-width:44px;min-height:44px;display:inline-flex}button{font:inherit;color:var(--ink);background:var(--soft);cursor:pointer;border:0;border-radius:50px;padding:10px 20px}button:hover{text-decoration:underline}:focus-visible{outline:3px solid var(--ink);outline-offset:2px;box-shadow:0 0 0 2px var(--surface)}.thread-heading{background:var(--accent);color:#000;border-radius:24px;margin-bottom:32px;padding:32px}h1{font-size:calc(2rem * var(--text-scale,1));overflow-wrap:anywhere;margin:8px 0;font-weight:540;line-height:1.35}.eyebrow{font-family:ui-monospace,monospace;font-size:calc(.875rem * var(--text-scale,1));letter-spacing:.03em}article{border:1px solid var(--separator);border-radius:24px;margin-bottom:24px;padding:32px}article header{font-size:calc(.875rem * var(--text-scale,1));margin-bottom:24px}.post-content{overflow-wrap:anywhere;max-width:48em}.post-content p{margin-block:1em}.post-content blockquote,.post-content pre{background:var(--soft);color:var(--ink);border-radius:8px;margin-inline:0;padding:16px}.post-content blockquote{background:var(--accent);color:#000;border-left:3px solid #000}.post-content img{max-width:100%;height:auto}.post-content pre{white-space:pre;overflow:auto}.post-content table{border-collapse:collapse;display:block;overflow-x:auto}.post-content td,.post-content th{border:1px solid var(--boundary);padding:8px 12px}.notice,.content-notice{background:var(--accent);color:#000;border-radius:8px;padding:16px}.content-notice{font-size:calc(.875rem * var(--text-scale,1))}.dialog-overlay{z-index:1;background:#0009;position:fixed;inset:0}.dialog-content{z-index:2;background:var(--surface);color:var(--ink);overflow-wrap:anywhere;border-radius:24px;width:min(520px,100vw - 32px);padding:32px;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);box-shadow:0 16px 48px #0000003d}@media (width<=767px){main,.workspace>header,article,.thread-heading{padding:16px}h1{font-size:calc(1.625rem * var(--text-scale,1))}}.main-destinations{border-bottom:1px solid var(--separator);padding:12px 32px}.board-grid{grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;display:grid}.board-card{border:1px solid var(--separator);border-radius:16px;flex-direction:column;align-items:start;gap:8px;padding:24px;display:flex}.board-card span,.board-card small{font-size:calc(.875rem * var(--text-scale,1))}.board-group{margin-bottom:32px}.thread-row{border-block-start:1px solid var(--separator);flex-wrap:wrap;gap:12px;padding:24px 16px;display:flex}.thread-row .subject{font-size:calc(1.375rem * var(--text-scale,1));overflow-wrap:anywhere;flex-basis:100%;display:block}article[data-targeted=true]{outline:3px solid var(--ink);outline-offset:3px}.post-content pre,.post-content .code-block,.post-content .table-overflow{max-width:100%;overflow:auto}.post-content table{width:max-content;max-width:none;display:table}.post-content .table-overflow{margin-block:16px}.post-content blockquote blockquote{margin-inline-start:12px}.post-content blockquote blockquote blockquote{margin-inline:0;padding-inline:4px}.permission-notice{border-inline-start:3px solid var(--boundary);background:var(--soft);padding:12px}summary{cursor:pointer;min-width:44px;min-height:44px;padding-block:10px}.workspace{font-size:calc(1.125rem * var(--text-scale,1));flex-direction:column;height:100dvh;min-height:0;font-weight:320;display:flex}.dialog-content{font-size:calc(1.125rem * var(--text-scale,1));max-height:calc(100dvh - 32px);line-height:1.45;overflow:auto}.settings-dialog input[type=range]{accent-color:var(--ink);width:100%;min-height:48px;margin:8px 0;display:block}.workspace>header{flex:none;padding:12px 24px}.workspace-tools{border-bottom:1px solid var(--separator);justify-content:space-between;align-items:center;gap:16px;padding:12px 24px;display:flex}.workspace-tools nav{margin:0}.workspace-status{flex:none}.workspace-status:empty{display:none}.workspace-status>p,.workspace-status>section{font-size:calc(.875rem * var(--text-scale,1));background:var(--soft);margin:0;padding:8px 24px}.workspace-body{flex:1;grid-template-columns:128px 200px minmax(280px,340px) minmax(0,1fr);width:100%;max-width:none;min-height:0;margin:0;padding:0;display:grid}.pane{overflow-anchor:none;overscroll-behavior:contain;min-width:0;padding:24px;overflow:auto}.main-destinations{border:0;border-right:1px solid var(--separator);background:var(--soft);margin:0;padding:12px 8px;display:block}.main-destinations a{width:100%;font-size:calc(.875rem * var(--text-scale,1));justify-content:center}.main-destinations button{width:100%;font-size:calc(.875rem * var(--text-scale,1));overflow-wrap:normal;background:0 0;margin-bottom:8px;padding:8px 4px}.main-destinations [aria-current=page]{background:var(--ink);color:var(--surface)}.narrow-section-picker{display:none}@media (width<=959px){.narrow-section-picker{font-size:calc(.875rem * var(--text-scale,1));align-items:center;gap:8px;display:flex}.narrow-section-picker select{max-width:100%}}.boards-navigation{border-right:1px solid var(--separator);flex-flow:column;justify-content:flex-start;align-items:stretch;gap:8px;margin:0;padding:20px 16px;display:flex}.boards-navigation h2{font-size:calc(1.125rem * var(--text-scale,1));margin:0 0 16px}.boards-navigation a{overflow-wrap:anywhere;font-size:calc(1rem * var(--text-scale,1))}.results-pane{border-right:1px solid var(--separator);padding:20px 16px}.results-pane h1{font-size:calc(1.5rem * var(--text-scale,1))}.results-pane h2{font-size:calc(1.125rem * var(--text-scale,1))}.results-pane .board-grid{display:block}.results-pane .board-card{margin-bottom:8px;padding:12px}.results-pane nav{font-size:calc(.875rem * var(--text-scale,1));gap:8px;margin-block:16px}.results-pane ul{font-size:calc(.875rem * var(--text-scale,1));padding-left:20px}.thread-row{gap:8px;padding:16px 24px}.thread-row .subject{font-weight:540;font-size:calc(1.125rem * var(--text-scale,1));line-height:1.5}.thread-row:has([aria-current=true]){background:var(--accent);color:#000}.thread-row>span,.thread-row>time,.thread-row>a:not(.subject){font-size:calc(.875rem * var(--text-scale,1))}.overview{grid-column:3/5}.reading-pane,.board-overview{grid-column:4}h1{font-size:calc(2rem * var(--text-scale,1))}h2{font-size:calc(1.5rem * var(--text-scale,1))}article header,.eyebrow,.content-notice,.board-card small,.board-card span{font-size:calc(.875rem * var(--text-scale,1))}.post-content pre,.post-content code{font-family:ui-monospace,monospace;font-size:calc(1rem * var(--text-scale,1))}.board-picker{font-size:calc(.875rem * var(--text-scale,1));display:none}select{min-height:48px;font:inherit;background:var(--surface);max-width:300px;color:var(--ink);border:1px solid var(--boundary);border-radius:8px;padding:8px}:host([data-spacing=compact]) .thread-row{padding:12px 16px}:host([data-spacing=compact]) article{padding:16px}:host([data-spacing=compact]) .post-content p{margin-block:.75em}:host([data-spacing=compact]) .pane{padding:16px}:host([data-spacing=compact]) .board-card{padding:12px 16px}@media (width<=1279px){.workspace-body{grid-template-columns:128px minmax(260px,320px) minmax(0,1fr)}.boards-navigation{display:none}.board-picker{align-items:center;gap:8px;display:flex}.overview{grid-column:2/4}.reading-pane,.board-overview{grid-column:3}}@media (width<=959px){.workspace>header{gap:8px;padding:8px 12px}.workspace>header .brand{font-size:calc(1.5rem * var(--text-scale,1))}.workspace-tools{flex-wrap:wrap;gap:8px;padding:8px 12px}.workspace-tools nav{gap:8px}.workspace-tools a,.workspace-tools button{font-size:calc(.875rem * var(--text-scale,1))}.board-picker{display:none}.workspace-body{grid-template-columns:1fr;position:relative}.main-destinations{display:none}.overview,.reading-pane,.results-pane,.board-overview{grid-column:1}.secondary-results,.board-overview{display:none}.pane{padding:16px 12px}.reading-pane article,.thread-heading{border-radius:16px;padding:16px}.thread-heading{margin-bottom:16px}.workspace-status>p,.workspace-status>section{padding:8px 12px}:host([data-spacing=compact]) .thread-row{padding:12px}}.narrow-overview-link{display:none}@media (width<=959px){.narrow-overview-link{display:inline-flex}}:host([data-theme=alias]){--secondary-accent:#c2b8da}:host([data-theme=mono]){--accent:#e9e9e9;--secondary-accent:#e4e4e4}:host([data-theme=dark]){--surface:#000;--ink:#fff;--soft:#666;--separator:#666;--boundary:#e9e9e9;--lightningcss-light: ;--lightningcss-dark:initial;color-scheme:dark}.thread-heading{background:var(--secondary-accent);color:#000}.thread-heading :focus-visible,.post-content blockquote :focus-visible{outline-color:#000;box-shadow:0 0 0 2px #fff}.thread-row:has([aria-current=true]) :focus-visible{outline-color:#000;box-shadow:0 0 0 2px #fff}.post-content{font-weight:320}.post-content strong{font-weight:700}.reading-pane>article,.thread-heading{max-width:calc(48em + 64px)}.settings-dialog{padding:32px}.settings-dialog>label{margin-top:16px;display:block}.settings-dialog select{width:100%;max-width:none}.theme-choices{border:1px solid var(--boundary);flex-wrap:wrap;gap:8px;margin:24px 0;padding:12px;display:flex}.theme-choices label{cursor:pointer;align-items:center;gap:8px;min-height:44px;display:flex}.theme-choices input{width:20px;height:20px;accent-color:var(--ink);margin:0}.theme-swatch{border:1px solid var(--boundary);background:#ebf5e8;border-radius:50%;flex:0 0 20px;width:20px;height:20px}.theme-swatch[data-swatch=alias]{background:#c2b8da}.theme-swatch[data-swatch=mono]{background:#e9e9e9}.theme-swatch[data-swatch=dark]{background:#000}:host([data-spacing=compact]) .workspace>header,:host([data-spacing=compact]) .workspace-tools{gap:12px;padding:8px 16px}:host([data-spacing=compact]) nav{gap:12px}:host([data-spacing=compact]) .boards-navigation{gap:4px;padding:16px 12px}:host([data-spacing=compact]) .main-destinations{padding:8px 4px}:host([data-spacing=compact]) .board-grid{gap:12px}:host([data-spacing=compact]) .board-card{gap:4px}:host([data-spacing=compact]) .board-group{margin-bottom:24px}:host([data-spacing=compact]) .thread-heading{margin-bottom:24px;padding:24px}:host([data-spacing=compact]) article{margin-bottom:16px}:host([data-spacing=compact]) article header{gap:12px;margin-bottom:16px}:host([data-spacing=compact]) .post-content pre,:host([data-spacing=compact]) .post-content blockquote{padding:12px}@media (width<=959px){.thread-row{padding:16px}:host([data-spacing=compact]) .thread-row{padding:12px}:host([data-spacing=compact]) .workspace>header,:host([data-spacing=compact]) .workspace-tools{gap:4px;padding:4px 8px}}@media (width<=767px){.reading-pane article{padding:24px}:host([data-spacing=compact]) .reading-pane article{padding:16px}}@media (prefers-reduced-motion:reduce){*,:before,:after{scroll-behavior:auto!important;transition:none!important;animation:none!important}}.search-pane fieldset label{align-items:center;gap:8px;min-height:44px;padding:4px 8px;display:inline-flex}.search-pane fieldset{min-width:0}.search-field{flex-direction:column;align-items:start;gap:8px;margin-block:16px;display:flex}.search-field input{font:inherit;background:var(--surface);min-height:48px;color:var(--ink);border:1px solid var(--boundary);border-radius:8px;max-width:100%;padding:8px}.search-field select{max-width:100%}.search-pane.secondary-results,.notices-pane.secondary-results{border-right:1px solid var(--separator);grid-column:3}.notices-navigation{grid-area:1/2}.notices-inline-categories{display:none}@media (width<=1279px){.search-pane.secondary-results,.notices-pane.secondary-results{grid-column:2}}@media (width<=959px){.notices-inline-categories{display:flex}.search-pane.secondary-results,.notices-pane.secondary-results{display:none}}@media (width<=1279px){.search-new-link{display:inline-flex}}.writing-actions{flex-wrap:wrap;flex:none;align-items:center;gap:12px;padding:12px 24px;display:flex}.source-writing{flex:1;width:100%;max-width:1000px;min-height:0;margin:0 auto;padding:24px;overflow:auto}.source-writing label{margin:12px 0;display:block}.source-writing input:not([type=checkbox]),.source-writing textarea,.source-writing select{font:inherit;border:1px solid var(--boundary);background:var(--surface);width:100%;min-height:44px;color:var(--ink);border-radius:8px;padding:10px;display:block}.source-writing textarea{resize:vertical;font-family:ui-monospace,monospace}.source-writing fieldset{border:1px solid var(--boundary);border-radius:12px;margin:16px 0}.source-writing label:has(input[type=checkbox]){align-items:center;gap:8px;min-height:44px;display:flex}.source-writing input[type=checkbox]{width:20px;height:20px;accent-color:var(--ink);flex:0 0 20px;margin:0}:host([data-spacing=compact]) .source-writing{padding:16px}:host([data-spacing=compact]) .source-writing label{margin-block:8px}:host([data-spacing=compact]) .writing-actions{gap:8px;padding:8px 16px}";
	var destination = new URL(location.href);
	var recover = async () => location.assign(nativeDestination(await recoverNavigationDestination()));
	if (typeof GM_registerMenuCommand === "function") GM_registerMenuCommand("Open this destination in native forum", () => recover());
	if (destination.origin === "https://www.tsdm39.com" && (describeDestination(destination.href) || destination.pathname === "/search.php" && destination.searchParams.get("mod") === "forum" || destination.pathname === "/forum.php" && [
		"viewthread",
		"forumdisplay",
		"redirect"
	].includes(destination.searchParams.get("mod") ?? "")) && !destination.searchParams.has("tsdm-native") && !document.getElementById("tsdm-workspace")) {
		const root = document.createElement("div");
		root.id = "tsdm-workspace";
		root.style.cssText = "position:fixed;inset:0;overflow:auto;z-index:2147483600;visibility:hidden";
		const shadow = root.attachShadow({ mode: "open" });
		const style = document.createElement("style");
		style.textContent = styles_default;
		const mount = document.createElement("div");
		const portal = document.createElement("div");
		shadow.append(style, mount, portal);
		document.body.append(root);
		let restoreNative = () => {};
		try {
			const workspace = createWorkspace(createForumClient({
				origin: destination.origin,
				transport: createBrowserTransport()
			}), destination.href, createBrowserNavigation(), createBrowserPreferences(), createBrowserDownloads());
			recover = async () => location.assign(nativeDestination(workspace.state.value.destination));
			createApp(WorkspaceLayout_default, {
				workspace,
				portal
			}).mount(mount);
			root.style.visibility = "visible";
			window.addEventListener("hashchange", () => workspace.updateAnchor(location.hash));
			restoreNative = suspendNativeBackground(root);
			workspace.start();
		} catch {
			restoreNative();
			root.remove();
			const recovery = document.createElement("a");
			recovery.href = nativeDestination(location.href);
			recovery.addEventListener("click", (event) => {
				event.preventDefault();
				recover();
			});
			recovery.textContent = "Workspace could not start — continue in native forum";
			document.body.prepend(recovery);
		}
	}
})();
